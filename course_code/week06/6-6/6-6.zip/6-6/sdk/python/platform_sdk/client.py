"""平台 Python 客户端实现。标准库 urllib，不引入第三方依赖。

错误只有一种形状：所有非 2xx 统一抛 :class:`ApiError`，调用方按 ``status`` + ``code``
分支，不需要再记各服务历史上不同的响应体。
"""
from __future__ import annotations

import json
import socket
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from typing import Any, Dict, Iterator, List, Optional, Sequence

DEFAULT_TIMEOUT = 30.0
RETRY_BASE_S = 0.25
RETRYABLE_STATUS = (429, 502, 503, 504)


class ApiError(Exception):
    """非 2xx 的统一出口。

    ``status`` 是 HTTP 语义，``code`` 是业务语义。两者都要有：只看状态码会把
    「预算耗尽」和「限流」混为一谈，只看 code 又会丢掉重试提示。
    """

    def __init__(self, status: int, code: str, message: str,
                 details: Optional[List[Dict[str, Any]]] = None,
                 request_id: str = "", method: str = "", path: str = "",
                 retry_after: Optional[float] = None, body: Any = None):
        super().__init__(message)
        self.status = status
        self.code = code
        self.message = message
        self.details = details or []
        self.request_id = request_id
        self.method = method
        self.path = path
        self.retry_after = retry_after
        self.body = body

    @property
    def retryable(self) -> bool:
        return self.status in RETRYABLE_STATUS or self.status >= 500

    def __repr__(self) -> str:  # 日志里一眼能看出是哪一类失败
        return (f"ApiError(status={self.status}, code={self.code!r}, "
                f"request_id={self.request_id!r}, method={self.method}, path={self.path})")


def _new_request_id() -> str:
    return f"req-{uuid.uuid4().hex[:12]}"


def _retry_after_seconds(value: Optional[str]) -> Optional[float]:
    if not value:
        return None
    try:
        return float(value)
    except ValueError:
        return None


def _normalize_error(status: int, method: str, path: str, payload: Any,
                     request_id_header: Optional[str],
                     retry_after_header: Optional[str]) -> ApiError:
    record = payload if isinstance(payload, dict) else {}
    nested = record.get("error") if isinstance(record.get("error"), dict) else {}
    legacy = record.get("error") if isinstance(record.get("error"), str) else ""
    code = str(record.get("code") or nested.get("code") or f"HTTP_{status}")
    # 用 or 而不是「只判 None」：旧形状里 error 可能是空串，空串要退化到状态码描述。
    message = str(nested.get("message") or legacy or f"HTTP {status}")
    details = record.get("details")
    if isinstance(details, dict):
        details = [details]
    elif not isinstance(details, list):
        details = []
    return ApiError(status=status, code=code, message=message, details=details,
                    request_id=str(record.get("request_id") or request_id_header or ""),
                    method=method, path=path,
                    retry_after=_retry_after_seconds(retry_after_header),
                    body=payload)


def _canonical_query(query: Optional[Dict[str, Any]]) -> str:
    if not query:
        return ""
    clean = {key: value for key, value in query.items()
             if value is not None and value != ""}
    if not clean:
        return ""
    return "?" + urllib.parse.urlencode(clean, doseq=True)


class HttpClient:
    """极薄的 HTTP 层：拼 URL、带鉴权头、重试、把错误压成一种形状。"""

    def __init__(self, base_url: str, api_key: Optional[str] = None,
                 timeout: float = DEFAULT_TIMEOUT, max_retries: int = 2,
                 request_id: Optional[str] = None, retry_base: float = RETRY_BASE_S,
                 opener: Any = None, default_headers: Optional[Dict[str, str]] = None):
        if not base_url:
            raise ValueError("base_url 必填")
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.timeout = timeout
        self.max_retries = max(0, max_retries)
        self.fixed_request_id = request_id
        self.retry_base = retry_base
        self._opener = opener or urllib.request.build_opener()
        self.default_headers = default_headers or {}

    # ------------------------------------------------------------ 公共入口

    def request(self, method: str, path: str,
                query: Optional[Dict[str, Any]] = None,
                body: Any = None,
                headers: Optional[Dict[str, str]] = None) -> Any:
        response = self.send(method, path, query=query, body=body, headers=headers)
        return self._decode(response)

    def text(self, method: str, path: str,
             query: Optional[Dict[str, Any]] = None,
             headers: Optional[Dict[str, str]] = None) -> str:
        response = self.send(method, path, query=query, headers=headers)
        return response.read().decode("utf-8", "replace")

    def stream(self, method: str, path: str,
               query: Optional[Dict[str, Any]] = None,
               headers: Optional[Dict[str, str]] = None) -> Any:
        """返回已确认 2xx 的响应对象，由调用方逐行消费（SSE）。"""
        return self.send(method, path, query=query, headers=headers)

    # ------------------------------------------------------------ 内部

    def send(self, method: str, path: str,
             query: Optional[Dict[str, Any]] = None,
             body: Any = None,
             headers: Optional[Dict[str, str]] = None) -> Any:
        url = self.base_url + path + _canonical_query(query)
        merged = {"Accept": "application/json", **self.default_headers, **(headers or {})}
        if body is not None:
            merged["Content-Type"] = "application/json"
        if self.api_key:
            merged["Authorization"] = f"Bearer {self.api_key}"
        request_id = (headers or {}).get("X-Request-Id") or self.fixed_request_id or _new_request_id()
        merged["X-Request-Id"] = request_id

        payload = None if body is None else json.dumps(body, ensure_ascii=False).encode("utf-8")
        attempt = 0
        while True:
            request = urllib.request.Request(url, data=payload, method=method, headers=merged)
            try:
                return self._opener.open(request, timeout=self.timeout)
            except urllib.error.HTTPError as error:
                raw = error.read()
                parsed = self._parse(raw)
                failure = _normalize_error(error.code, method, path, parsed,
                                           error.headers.get("X-Request-Id") if error.headers else None,
                                           error.headers.get("Retry-After") if error.headers else None)
                # 只重试「服务端没处理完」的状态：4xx 重试没有意义，只会放大错误。
                if error.code in RETRYABLE_STATUS and attempt < self.max_retries:
                    self._sleep(failure.retry_after, attempt)
                    attempt += 1
                    continue
                raise failure from None
            except (urllib.error.URLError, socket.timeout, TimeoutError, OSError) as error:
                if attempt < self.max_retries:
                    self._sleep(None, attempt)
                    attempt += 1
                    continue
                raise ApiError(status=0, code="NETWORK_ERROR", method=method, path=path,
                               message=f"请求失败：{error}", request_id=request_id) from None

    def _sleep(self, retry_after: Optional[float], attempt: int) -> None:
        wait = retry_after if retry_after is not None else self.retry_base * (2 ** attempt)
        time.sleep(min(wait, 5.0))

    @staticmethod
    def _parse(raw: bytes) -> Any:
        if not raw:
            return None
        text = raw.decode("utf-8", "replace")
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            return text

    def _decode(self, response: Any) -> Any:
        raw = response.read()
        if not raw:
            return None
        return self._parse(raw)


def _path(value: str) -> str:
    return urllib.parse.quote(str(value), safe="")


# ---------------------------------------------------------------- platform

class PlatformClient:
    """控制面客户端。方法名对着动作走，不逐字翻译路径。"""

    def __init__(self, base_url: str, api_key: Optional[str] = None, **options: Any):
        options.setdefault("base_url", base_url)
        self.http = HttpClient(api_key=api_key, **options)

    def identity(self) -> Dict[str, Any]:
        return self.http.request("GET", "/v1/identities")

    def list_releases(self) -> Dict[str, Any]:
        return self.http.request("GET", "/v1/releases")

    def draft_release(self, version: Optional[str] = None, auto_check: bool = False,
                      components: Optional[Dict[str, Any]] = None,
                      cases: Optional[Sequence[Dict[str, Any]]] = None) -> Dict[str, Any]:
        body: Dict[str, Any] = {"auto_check": auto_check}
        if version:
            body["version"] = version
        if components:
            body["components"] = components
        if cases:
            body["cases"] = list(cases)
        return self.http.request("POST", "/v1/releases", body=body)

    def get_release(self, version: str) -> Dict[str, Any]:
        return self.http.request("GET", f"/v1/releases/{_path(version)}")

    def check(self, version: str) -> Dict[str, Any]:
        return self.http.request("POST", f"/v1/releases/{_path(version)}/check")

    def publish(self, version: str, track: str = "stable",
                pilot_ratio: float = 0.0) -> Dict[str, Any]:
        return self.http.request("POST", f"/v1/releases/{_path(version)}/publish",
                                 body={"track": track, "pilot_ratio": pilot_ratio})

    def rollback(self, reason: str = "", version: Optional[str] = None) -> Dict[str, Any]:
        body: Dict[str, Any] = {}
        if reason:
            body["reason"] = reason
        if version:
            body["version"] = version
        return self.http.request("POST", "/v1/releases/rollback", body=body)

    def route(self) -> Dict[str, Any]:
        return self.http.request("GET", "/v1/releases/route")

    def preview_route(self, run_id: str, group: Optional[str] = None) -> Dict[str, Any]:
        return self.http.request("GET", "/v1/releases/route/preview",
                                 query={"run_id": run_id, "group": group})

    def record_usage(self, **usage: Any) -> Dict[str, Any]:
        return self.http.request("POST", "/v1/usage", body=usage)

    def cost_report(self, group_by: str = "tenant", days: Optional[int] = None,
                    tenant: Optional[str] = None) -> Dict[str, Any]:
        return self.http.request("GET", "/v1/cost/report",
                                 query={"groupBy": group_by, "days": days,
                                        "tenant": tenant, "format": "json"})

    def cost_report_markdown(self, group_by: str = "tenant", days: Optional[int] = None,
                             tenant: Optional[str] = None) -> str:
        return self.http.text("GET", "/v1/cost/report",
                              query={"groupBy": group_by, "days": days,
                                     "tenant": tenant, "format": "md"})

    def list_budgets(self) -> Dict[str, Any]:
        return self.http.request("GET", "/v1/budgets")

    def set_budget(self, scope: str, limit_usd: float, period: str = "daily",
                   warn_ratio: Optional[float] = None) -> Dict[str, Any]:
        body: Dict[str, Any] = {"scope": scope, "limit_usd": limit_usd, "period": period}
        if warn_ratio is not None:
            body["warn_ratio"] = warn_ratio
        return self.http.request("POST", "/v1/budgets", body=body)

    def check_budget(self, scopes: Sequence[str]) -> Dict[str, Any]:
        """预算耗尽时抛 ApiError(code=BUDGET_EXCEEDED)，body 里仍有 allowed=false。"""
        return self.http.request("GET", "/v1/budgets/check", query={"scope": list(scopes)})

    def audit(self, tenant: Optional[str] = None, limit: int = 50,
              action: Optional[str] = None) -> Dict[str, Any]:
        return self.http.request("GET", "/v1/audit",
                                 query={"tenant": tenant, "limit": limit, "action": action})

    def list_replays(self, tenant: Optional[str] = None, limit: int = 20) -> Dict[str, Any]:
        return self.http.request("GET", "/v1/replays",
                                 query={"tenant": tenant, "limit": limit})

    def replay(self, run_id: str) -> Dict[str, Any]:
        return self.http.request("POST", "/v1/replays", body={"run_id": run_id})


# ---------------------------------------------------------------- agent

class AgentClient:
    def __init__(self, base_url: str, api_key: Optional[str] = None, **options: Any):
        options.setdefault("base_url", base_url)
        self.http = HttpClient(api_key=api_key, **options)

    def run(self, prompt: str, task: Optional[str] = None, goal: Optional[str] = None,
            user: Optional[str] = None, model_alias: Optional[str] = None,
            release_group: Optional[str] = None) -> Dict[str, Any]:
        body: Dict[str, Any] = {"prompt": prompt}
        for key, value in (("task", task), ("goal", goal), ("user", user),
                           ("model_alias", model_alias), ("release_group", release_group)):
            if value is not None:
                body[key] = value
        return self.http.request("POST", "/v1/runs", body=body)

    def get(self, run_id: str) -> Dict[str, Any]:
        return self.http.request("GET", f"/v1/runs/{_path(run_id)}")

    def list(self) -> Dict[str, Any]:
        return self.http.request("GET", "/v1/runs")

    def replay(self, run_id: str) -> Dict[str, Any]:
        return self.http.request("POST", f"/v1/runs/{_path(run_id)}/replay")

    def wait(self, run_id: str, timeout: float = 120.0,
             interval: float = 0.5) -> Dict[str, Any]:
        """等终态。轮询而不是 SSE：等结果用轮询更省连接，重连语义也不用在这里重复实现。"""
        deadline = time.monotonic() + timeout
        while True:
            run = self.get(run_id)
            if run.get("status") != "running":
                return run
            if time.monotonic() > deadline:
                raise ApiError(status=408, code="WAIT_TIMEOUT", method="GET",
                               path=f"/v1/runs/{run_id}",
                               message=f"等待运行结束超时（{timeout}s）")
            time.sleep(interval)

    def stream(self, run_id: str) -> Iterator[Dict[str, Any]]:
        """订阅 SSE。收到 ``[DONE]`` 或连接关闭即结束。"""
        response = self.http.stream("GET", f"/v1/runs/{_path(run_id)}/events",
                                    headers={"Accept": "text/event-stream"})
        data_lines: List[str] = []
        try:
            for raw in response:
                line = raw.decode("utf-8", "replace").rstrip("\r\n")
                if line.startswith("data:"):
                    data_lines.append(line[5:].lstrip())
                    continue
                if line == "" and data_lines:
                    chunk = "\n".join(data_lines).strip()
                    data_lines = []
                    if chunk == "[DONE]":
                        return
                    try:
                        yield json.loads(chunk)
                    except json.JSONDecodeError:
                        yield {"type": "raw", "data": chunk}
            if data_lines:
                chunk = "\n".join(data_lines).strip()
                if chunk and chunk != "[DONE]":
                    try:
                        yield json.loads(chunk)
                    except json.JSONDecodeError:
                        yield {"type": "raw", "data": chunk}
        finally:
            response.close()


# ---------------------------------------------------------------- retrieval

class RetrievalClient:
    def __init__(self, base_url: str, api_key: Optional[str] = None, **options: Any):
        options.setdefault("base_url", base_url)
        self.http = HttpClient(api_key=api_key, **options)

    def query(self, question: str, mode: str = "hybrid", top_k: int = 5,
              doc_type: Optional[str] = None) -> Dict[str, Any]:
        body: Dict[str, Any] = {"question": question, "mode": mode, "top_k": top_k}
        if doc_type:
            body["doc_type"] = doc_type
        return self.http.request("POST", "/v1/query", body=body)

    def internal_query(self, question: str, tenant: str, dept: str,
                       mode: str = "hybrid", top_k: int = 5) -> Dict[str, Any]:
        """内部通道：用 X-Tenant / X-Dept 说明身份，只应在服务网格内使用。"""
        return self.http.request("POST", "/internal/query",
                                 body={"question": question, "mode": mode, "top_k": top_k},
                                 headers={"X-Tenant": tenant, "X-Dept": dept})


# ---------------------------------------------------------------- eval

class EvalClient:
    def __init__(self, base_url: str, api_key: Optional[str] = None, **options: Any):
        options.setdefault("base_url", base_url)
        self.http = HttpClient(api_key=api_key, **options)

    def state(self) -> Dict[str, Any]:
        return self.http.request("GET", "/api/state")

    def cost(self) -> Dict[str, Any]:
        return self.http.request("GET", "/api/cost")

    def save_task(self, task: Dict[str, Any]) -> Dict[str, Any]:
        return self.http.request("POST", "/api/tasks", body=task)

    def import_tasks(self, tasks: Sequence[Dict[str, Any]]) -> Dict[str, Any]:
        return self.http.request("POST", "/api/tasks/import", body={"tasks": list(tasks)})

    def export_tasks(self) -> Dict[str, Any]:
        return self.http.request("GET", "/api/tasks/export")

    def delete_task(self, task_id: str) -> Dict[str, Any]:
        return self.http.request("DELETE", f"/api/tasks/{_path(task_id)}")

    def save_strategy(self, strategy: Dict[str, Any]) -> Dict[str, Any]:
        return self.http.request("POST", "/api/strategies", body=strategy)

    def delete_strategy(self, strategy_id: str) -> Dict[str, Any]:
        return self.http.request("DELETE", f"/api/strategies/{_path(strategy_id)}")

    def start_experiment(self, experiment: Dict[str, Any]) -> Dict[str, Any]:
        return self.http.request("POST", "/api/experiments", body=experiment)

    def cancel_experiment(self, experiment_id: str) -> Dict[str, Any]:
        return self.http.request("POST", f"/api/experiments/{_path(experiment_id)}/cancel",
                                 body={})

    def get_run(self, run_id: str) -> Dict[str, Any]:
        return self.http.request("GET", f"/api/runs/{_path(run_id)}")

    def judge(self, run_id: str) -> Dict[str, Any]:
        return self.http.request("POST", f"/api/runs/{_path(run_id)}/judge")

    def review(self, run_id: str, review: Dict[str, Any]) -> Dict[str, Any]:
        return self.http.request("POST", f"/api/runs/{_path(run_id)}/reviews", body=review)

    def compare(self, baseline: Optional[str] = None, candidate: Optional[str] = None,
                experiment: Optional[str] = None) -> Dict[str, Any]:
        return self.http.request("GET", "/api/compare",
                                 query={"baseline": baseline, "candidate": candidate,
                                        "experiment": experiment})

    def report(self, baseline: Optional[str] = None, candidate: Optional[str] = None,
               experiment: Optional[str] = None, fmt: str = "json") -> Any:
        query = {"baseline": baseline, "candidate": candidate,
                 "experiment": experiment, "format": fmt}
        if fmt == "md":
            return self.http.text("GET", "/api/reports", query=query)
        return self.http.request("GET", "/api/reports", query=query)
