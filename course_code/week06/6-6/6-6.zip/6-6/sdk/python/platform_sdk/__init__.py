"""阶段六平台 Python 薄客户端。

只做序列化、鉴权头、重试、错误归一、SSE 解析；版本号怎么算、预算怎么扣、
脱敏怎么做都在服务端。与 `sdk/ts/src/index.ts` 接口同构，便于两边对照。
"""
from .client import (AgentClient, ApiError, EvalClient, HttpClient, PlatformClient,
                     RetrievalClient)

__all__ = ["AgentClient", "ApiError", "EvalClient", "HttpClient", "PlatformClient",
           "RetrievalClient"]
