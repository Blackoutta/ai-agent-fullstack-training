/**
 * SDK 契约测试。两条线：
 *  1. 路径表 —— 每个方法真的打到契约里的那个方法+路径（不是靠读代码确认）；
 *  2. 错误归一 —— 四种历史形状（嵌套/平铺/字符串/非 JSON）都收敛成同一个 ApiError。
 */
import assert from "node:assert/strict";
import { test } from "node:test";

import {
  AgentClient,
  ApiError,
  EvalClient,
  PlatformClient,
  RetrievalClient,
} from "../src/index.ts";

const BASE = "http://platform.test";

interface Call {
  method: string;
  path: string;
}

function recorder(): { calls: Call[]; fetchImpl: typeof fetch } {
  const calls: Call[] = [];
  const fetchImpl = (async (input: string | URL | Request, init?: RequestInit) => {
    const url = new URL(String(input));
    calls.push({ method: init?.method ?? "GET", path: url.pathname });
    return new Response("{}", { status: 200, headers: { "content-type": "application/json" } });
  }) as typeof fetch;
  return { calls, fetchImpl };
}

function canonical(path: string): string {
  // 实际发出的路径里是真实 id；把它们归回契约里的 `{...}` 占位符。
  const ids = ["rel-2026.11.09.1", "6f1c2a54-9e3b-4f0a-8d7c-1b2e3f4a5b6c", "run-1", "tsk-1", "stg-1", "exp-1"];
  let out = path;
  for (const id of ids) out = out.split(encodeURIComponent(id)).join("{}").split(id).join("{}");
  return out.replace(/\{[^/}]+\}/g, "{}");
}

test("路径表：SDK 覆盖契约里全部非探针端点", async () => {
  const { calls, fetchImpl } = recorder();
  const options = { baseUrl: BASE, apiKey: "key:tenant_a:platform:admin", fetchImpl };

  const platform = new PlatformClient(options);
  const agent = new AgentClient(options);
  const retrieval = new RetrievalClient(options);
  const evalClient = new EvalClient(options);

  await platform.identity();
  await platform.listReleases();
  await platform.draftRelease();
  await platform.getRelease("rel-2026.11.09.1");
  await platform.check("rel-2026.11.09.1");
  await platform.publish("rel-2026.11.09.1", { track: "pilot", pilot_ratio: 10 });
  await platform.rollback({ reason: "5xx 上升" });
  await platform.route();
  await platform.previewRoute("6f1c2a54-9e3b-4f0a-8d7c-1b2e3f4a5b6c");
  await platform.recordUsage({ source: "test" });
  await platform.costReport({ days: 7 });
  await platform.listBudgets();
  await platform.setBudget({ scope: "tenant:tenant_a", limit_usd: 1 });
  await platform.checkBudget(["tenant:tenant_a"]);
  await platform.audit({ limit: 5 });
  await platform.listReplays();
  await platform.replay("6f1c2a54-9e3b-4f0a-8d7c-1b2e3f4a5b6c");

  await agent.run({ prompt: "ping" });
  await agent.list();
  await agent.get("run-1");
  await agent.replay("run-1");

  await retrieval.query({ question: "登录失败先查哪张表" });
  await retrieval.internalQuery({ question: "q" }, { tenant: "tenant_a", dept: "platform" });

  await evalClient.state();
  await evalClient.cost();
  await evalClient.saveTask({ name: "t" });
  await evalClient.importTasks([{ name: "t" }]);
  await evalClient.exportTasks();
  await evalClient.deleteTask("tsk-1");
  await evalClient.saveStrategy({ name: "s" });
  await evalClient.deleteStrategy("stg-1");
  await evalClient.startExperiment({ name: "e" });
  await evalClient.cancelExperiment("exp-1");
  await evalClient.getRun("run-1");
  await evalClient.judge("run-1");
  await evalClient.review("run-1", { verdict: "ok" });
  await evalClient.compare({ baseline: "a", candidate: "b" });
  await evalClient.report({ format: "json" });

  const actual = new Set(calls.map((call) => `${call.method} ${canonical(call.path)}`));
  const expected = new Set([
    "GET /v1/identities",
    "GET /v1/releases", "POST /v1/releases",
    "GET /v1/releases/{}", "POST /v1/releases/{}/check", "POST /v1/releases/{}/publish",
    "POST /v1/releases/rollback", "GET /v1/releases/route", "GET /v1/releases/route/preview",
    "POST /v1/usage", "GET /v1/cost/report",
    "GET /v1/budgets", "POST /v1/budgets", "GET /v1/budgets/check",
    "GET /v1/audit", "GET /v1/replays", "POST /v1/replays",
    "POST /v1/runs", "GET /v1/runs", "GET /v1/runs/{}", "POST /v1/runs/{}/replay",
    "POST /v1/query", "POST /internal/query",
    "GET /api/state", "GET /api/cost",
    "POST /api/tasks", "POST /api/tasks/import", "GET /api/tasks/export", "DELETE /api/tasks/{}",
    "POST /api/strategies", "DELETE /api/strategies/{}",
    "POST /api/experiments", "POST /api/experiments/{}/cancel",
    "GET /api/runs/{}", "POST /api/runs/{}/judge", "POST /api/runs/{}/reviews",
    "GET /api/compare", "GET /api/reports",
  ]);

  assert.deepEqual([...actual].sort(), [...expected].sort());
});

test("请求头：Bearer 与 X-Request-Id 都会带上，且调用方可覆盖请求号", async () => {
  const seen: Headers[] = [];
  const fetchImpl = (async (_input: string | URL | Request, init?: RequestInit) => {
    seen.push(new Headers(init?.headers));
    return new Response("{}", { status: 200, headers: { "content-type": "application/json" } });
  }) as typeof fetch;

  const client = new PlatformClient({
    baseUrl: BASE, apiKey: "sk-demo:tenant_a:platform:admin", fetchImpl, requestId: "req-fixed",
  });
  await client.route();

  assert.equal(seen[0].get("authorization"), "Bearer sk-demo:tenant_a:platform:admin");
  assert.equal(seen[0].get("x-request-id"), "req-fixed");
});

test("多值 query：scope 重复追加而不是拼成逗号串", async () => {
  let query = "";
  const fetchImpl = (async (input: string | URL | Request) => {
    query = new URL(String(input)).search;
    return new Response("{}", { status: 200, headers: { "content-type": "application/json" } });
  }) as typeof fetch;

  const client = new PlatformClient({ baseUrl: BASE, fetchImpl });
  await client.checkBudget(["tenant:a", "dept:a/b"]);

  assert.deepEqual(new URLSearchParams(query).getAll("scope"), ["tenant:a", "dept:a/b"]);
});

test("错误归一：嵌套、平铺、字符串、非 JSON 都变成同一个 ApiError", async () => {
  const cases: Array<{ body: string; status: number; code: string; message: string }> = [
    {
      status: 409,
      body: JSON.stringify({
        error: { code: "RELEASE_NOT_CHECKED", message: "先 check" },
        code: "RELEASE_NOT_CHECKED", details: [], request_id: "req-1",
      }),
      code: "RELEASE_NOT_CHECKED",
      message: "先 check",
    },
    {
      status: 429,
      body: JSON.stringify({ error: { code: "BUDGET_EXCEEDED", message: "超了" }, code: "BUDGET_EXCEEDED" }),
      code: "BUDGET_EXCEEDED",
      message: "超了",
    },
    {
      status: 400,
      body: JSON.stringify({ error: "旧形状的字符串错误", code: "INVALID_ARGUMENT" }),
      code: "INVALID_ARGUMENT",
      message: "旧形状的字符串错误",
    },
    { status: 502, body: "upstream exploded", code: "HTTP_502", message: "HTTP 502" },
  ];

  for (const item of cases) {
    const fetchImpl = (async () => new Response(item.body, {
      status: item.status,
      headers: { "content-type": "text/plain" },
    })) as typeof fetch;
    const client = new PlatformClient({ baseUrl: BASE, fetchImpl, maxRetries: 0 });
    await assert.rejects(
      () => client.route(),
      (error: unknown) => {
        assert.ok(error instanceof ApiError);
        assert.equal(error.status, item.status);
        assert.equal(error.code, item.code);
        assert.equal(error.message, item.message);
        assert.deepEqual(error.details, []);
        return true;
      },
    );
  }
});

test("错误详情：details 数组与 request_id 原样暴露给调用方", async () => {
  const fetchImpl = (async () => new Response(JSON.stringify({
    error: { code: "REPLAY_VERSION_MISMATCH", message: "版本不一致" },
    code: "REPLAY_VERSION_MISMATCH",
    details: [{ diffs: [{ field: "tools", archived: "v12", current: "v13" }] }],
    request_id: "req-abc",
  }), { status: 409, headers: { "content-type": "application/json", "X-Request-Id": "req-abc" } })) as typeof fetch;

  const client = new PlatformClient({ baseUrl: BASE, fetchImpl, maxRetries: 0 });
  await assert.rejects(() => client.replay("run-1"), (error: unknown) => {
    assert.ok(error instanceof ApiError);
    assert.equal(error.code, "REPLAY_VERSION_MISMATCH");
    assert.equal(error.requestId, "req-abc");
    assert.equal(error.details.length, 1);
    assert.deepEqual((error.details[0] as { diffs: unknown[] }).diffs.length, 1);
    return true;
  });
});

test("重试：503 之后成功，调用方只看到最终结果", async () => {
  let attempts = 0;
  const fetchImpl = (async () => {
    attempts += 1;
    if (attempts === 1) {
      return new Response(JSON.stringify({ error: { code: "UNAVAILABLE", message: "reloading" } }), {
        status: 503, headers: { "content-type": "application/json" },
      });
    }
    return new Response(JSON.stringify({ stable: "rel-1" }), {
      status: 200, headers: { "content-type": "application/json" },
    });
  }) as typeof fetch;

  const client = new PlatformClient({ baseUrl: BASE, fetchImpl, maxRetries: 1 });
  const route = await client.route();
  assert.equal(attempts, 2);
  assert.equal((route as unknown as { stable: string }).stable, "rel-1");
});

test("重试：4xx 不重试，避免放大错误", async () => {
  let attempts = 0;
  const fetchImpl = (async () => {
    attempts += 1;
    return new Response(JSON.stringify({ error: { code: "FORBIDDEN", message: "no" } }), {
      status: 403, headers: { "content-type": "application/json" },
    });
  }) as typeof fetch;

  const client = new PlatformClient({ baseUrl: BASE, fetchImpl, maxRetries: 3 });
  await assert.rejects(() => client.route(), (error: unknown) => error instanceof ApiError);
  assert.equal(attempts, 1);
});

test("SSE：按 \\n\\n 切块，[DONE] 结束生成器", async () => {
  const frames = [
    'data: {"type":"step","index":1}\n\n',
    'data: {"type":"step","index":2}\n\n',
    "data: [DONE]\n\n",
  ];
  const fetchImpl = (async () => {
    const stream = new ReadableStream<Uint8Array>({
      start(controller) {
        const encoder = new TextEncoder();
        for (const frame of frames) controller.enqueue(encoder.encode(frame));
        controller.close();
      },
    });
    return new Response(stream, { status: 200, headers: { "content-type": "text/event-stream" } });
  }) as typeof fetch;

  const client = new AgentClient({ baseUrl: "http://agent.test", fetchImpl });
  const events = [];
  for await (const event of client.stream("run-1")) events.push(event);

  assert.deepEqual(events.map((event) => event.index), [1, 2]);
});

test("SSE：跨 chunk 的半条消息会被拼回来", async () => {
  const encoder = new TextEncoder();
  const fetchImpl = (async () => {
    const stream = new ReadableStream<Uint8Array>({
      start(controller) {
        controller.enqueue(encoder.encode('data: {"type":"step","ind'));
        controller.enqueue(encoder.encode('ex":7}\n\ndata: [DONE]\n\n'));
        controller.close();
      },
    });
    return new Response(stream, { status: 200, headers: { "content-type": "text/event-stream" } });
  }) as typeof fetch;

  const client = new AgentClient({ baseUrl: "http://agent.test", fetchImpl });
  const events = [];
  for await (const event of client.stream("run-1")) events.push(event);

  assert.equal(events.length, 1);
  assert.equal(events[0].index, 7);
});

test("wait：running 时轮询，终态即返回", async () => {
  const statuses = ["running", "running", "done"];
  let index = 0;
  const fetchImpl = (async () => {
    const status = statuses[Math.min(index, statuses.length - 1)];
    index += 1;
    return new Response(JSON.stringify({ run_id: "run-1", status }), {
      status: 200, headers: { "content-type": "application/json" },
    });
  }) as typeof fetch;

  const client = new AgentClient({ baseUrl: "http://agent.test", fetchImpl });
  const run = await client.wait("run-1", { intervalMs: 1, timeoutMs: 5_000 });

  assert.equal(run.status, "done");
  assert.equal(index, 3);
});
