/**
 * 阶段六平台 TS 薄客户端。
 *
 * 三条纪律：
 *  1. 不放业务逻辑。版本号怎么算、预算怎么扣、脱敏怎么做，都在服务端；SDK 只搬运。
 *  2. 不用第三方依赖。内置 `fetch` 已经够用，多一个包就多一次供应链风险。
 *  3. 错误只有一种形状。所有非 2xx 统一抛 `ApiError`，调用方按 `status` + `code` 分支，
 *     不需要再看各服务历史上不同的响应体。
 */

export type Json = Record<string, unknown>;

/** 统一错误详情。不同端点给的键不同，键名即语义。 */
export interface ErrorDetail {
  [key: string]: unknown;
}

export interface ApiErrorInit {
  status: number;
  code: string;
  message: string;
  details?: ErrorDetail[];
  requestId?: string;
  method?: string;
  path?: string;
  retryAfter?: number | null;
  body?: unknown;
}

/**
 * 所有非 2xx 响应的统一出口。
 *
 * `status` 是 HTTP 语义（401/403/409/429...），`code` 是业务语义
 * （`RELEASE_NOT_CHECKED` / `BUDGET_EXCEEDED` ...）。两者都要暴露：
 * 只看状态码会把「预算耗尽」和「限流」混为一谈，只看 code 又会丢掉重试提示。
 */
export class ApiError extends Error {
  readonly status: number;
  readonly code: string;
  readonly details: ErrorDetail[];
  readonly requestId: string;
  readonly method: string;
  readonly path: string;
  readonly retryAfter: number | null;
  readonly body: unknown;

  constructor(init: ApiErrorInit) {
    super(init.message);
    this.name = "ApiError";
    this.status = init.status;
    this.code = init.code;
    this.details = init.details ?? [];
    this.requestId = init.requestId ?? "";
    this.method = init.method ?? "";
    this.path = init.path ?? "";
    this.retryAfter = init.retryAfter ?? null;
    this.body = init.body;
  }

  /** 429 且带 Retry-After 时可以用它做退避；没有就退回指数退避。 */
  get retryable(): boolean {
    return this.status === 429 || this.status === 502 || this.status === 503 || this.status === 504;
  }
}

export interface ClientOptions {
  baseUrl: string;
  apiKey?: string;
  /** 单次请求超时，毫秒。默认 30s——回放要跑子进程，给得比普通接口宽松。 */
  timeoutMs?: number;
  /** 额外重试次数（不含首次）。默认 2。 */
  maxRetries?: number;
  /** 注入用（测试与自定义运行时）；默认用全局 fetch。 */
  fetchImpl?: typeof fetch;
  /** 请求号；不传则每次现生成。传固定值便于在日志里对齐一次业务链路。 */
  requestId?: string;
  defaultHeaders?: Record<string, string>;
}

interface RequestOptions {
  query?: Record<string, QueryValue>;
  body?: unknown;
  headers?: Record<string, string>;
  signal?: AbortSignal;
  /** 直接返回 response，供 SSE 使用。 */
  raw?: boolean;
}

/** 数组值会重复追加同名参数（`?scope=a&scope=b`），与 platform 的多 scope 语义一致。 */
export type QueryValue = string | number | boolean | undefined | null | Array<string | number>;

const RETRY_BASE_MS = 250;

function newRequestId(): string {
  return `req-${Math.random().toString(16).slice(2, 10)}${Date.now().toString(16).slice(-4)}`;
}

function parseRetryAfter(value: string | null): number | null {
  if (!value) return null;
  const seconds = Number(value);
  return Number.isFinite(seconds) ? seconds * 1000 : null;
}

/** 归一错误体：新形状 `{error:{code,message}, code, details[], request_id}`，旧形状也认。 */
function normalizeError(status: number, method: string, path: string, payload: unknown,
                        requestIdHeader: string | null, retryAfter: string | null): ApiError {
  const record = (payload && typeof payload === "object" ? payload : {}) as Json;
  const nested = (record.error && typeof record.error === "object" ? record.error : {}) as Json;
  const legacyMessage = typeof record.error === "string" ? record.error : "";
  const code = String(record.code ?? nested.code ?? `HTTP_${status}`);
  // 用 || 而不是 ??：旧形状里 error 可能是空字符串，空串要退化到状态码描述。
  const message = String(nested.message || legacyMessage || `HTTP ${status}`);
  const details = Array.isArray(record.details)
    ? (record.details as ErrorDetail[])
    : record.details && typeof record.details === "object" ? [record.details as ErrorDetail] : [];
  return new ApiError({
    status, code, message, details,
    requestId: String(record.request_id ?? requestIdHeader ?? ""),
    method, path,
    retryAfter: parseRetryAfter(retryAfter),
    body: payload,
  });
}

async function decodeBody(response: Response): Promise<unknown> {
  const text = await response.text();
  if (!text.trim()) return null;
  try {
    return JSON.parse(text);
  } catch {
    return text;
  }
}

class HttpClient {
  readonly baseUrl: string;
  private readonly apiKey?: string;
  private readonly timeoutMs: number;
  private readonly maxRetries: number;
  private readonly fetchImpl: typeof fetch;
  private readonly fixedRequestId?: string;
  private readonly defaultHeaders: Record<string, string>;

  constructor(options: ClientOptions) {
    if (!options.baseUrl) throw new Error("baseUrl 必填");
    this.baseUrl = options.baseUrl.replace(/\/+$/, "");
    this.apiKey = options.apiKey;
    this.timeoutMs = options.timeoutMs ?? 30_000;
    this.maxRetries = Math.max(0, options.maxRetries ?? 2);
    this.fetchImpl = options.fetchImpl ?? globalThis.fetch;
    this.fixedRequestId = options.requestId;
    this.defaultHeaders = options.defaultHeaders ?? {};
  }

  private buildUrl(path: string, query?: RequestOptions["query"]): string {
    const url = new URL(this.baseUrl + path);
    for (const [key, value] of Object.entries(query ?? {})) {
      if (value === undefined || value === null || value === "") continue;
      if (Array.isArray(value)) {
        for (const item of value) url.searchParams.append(key, String(item));
        continue;
      }
      url.searchParams.append(key, String(value));
    }
    return url.toString();
  }

  async request<T>(method: string, path: string, options: RequestOptions = {}): Promise<T> {
    const response = await this.send(method, path, options);
    if (options.raw) return response as unknown as T;
    const payload = await decodeBody(response);
    return payload as T;
  }

  /** 供 SSE 使用：返回已确认 2xx 的 Response，由调用方消费 body 流。 */
  async stream(method: string, path: string, options: RequestOptions = {}): Promise<Response> {
    return this.send(method, path, options);
  }

  private async send(method: string, path: string, options: RequestOptions): Promise<Response> {
    const url = this.buildUrl(path, options.query);
    const headers: Record<string, string> = {
      Accept: "application/json",
      ...this.defaultHeaders,
      ...(options.headers ?? {}),
    };
    if (options.body !== undefined) headers["Content-Type"] = "application/json";
    if (this.apiKey) headers.Authorization = `Bearer ${this.apiKey}`;
    const requestId = options.headers?.["X-Request-Id"] ?? this.fixedRequestId ?? newRequestId();
    headers["X-Request-Id"] = requestId;

    let attempt = 0;
    for (;;) {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), this.timeoutMs);
      const abort = () => controller.abort();
      options.signal?.addEventListener("abort", abort, { once: true });
      let response: Response;
      try {
        response = await this.fetchImpl(url, {
          method,
          headers,
          body: options.body === undefined ? undefined : JSON.stringify(options.body),
          signal: controller.signal,
        });
      } catch (cause) {
        clearTimeout(timer);
        options.signal?.removeEventListener("abort", abort);
        // 网络层失败（DNS/连接重置/超时）值得重试：多半是服务刚重启或网关在切上游。
        if (attempt < this.maxRetries && !options.signal?.aborted) {
          await sleep(RETRY_BASE_MS * 2 ** attempt);
          attempt += 1;
          continue;
        }
        throw new ApiError({
          status: 0, code: "NETWORK_ERROR", method, path,
          message: `请求失败：${cause instanceof Error ? cause.message : String(cause)}`,
          requestId,
        });
      }
      clearTimeout(timer);
      options.signal?.removeEventListener("abort", abort);

      if (response.ok) return response;

      const payload = await decodeBody(response);
      const error = normalizeError(response.status, method, path, payload,
                                  response.headers.get("X-Request-Id"),
                                  response.headers.get("Retry-After"));
      // 只重试「服务端没处理完」的状态：429 与 5xx。4xx 重试没有意义，只会放大错误。
      const retryable = response.status === 429 || response.status >= 500;
      if (retryable && attempt < this.maxRetries) {
        const wait = error.retryAfter ?? RETRY_BASE_MS * 2 ** attempt;
        await sleep(Math.min(wait, 5_000));
        attempt += 1;
        continue;
      }
      throw error;
    }
  }
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// ---------------------------------------------------------------- 通用类型

export interface IdentityView {
  tenant: string;
  dept: string;
  role: string;
  key_prefix?: string;
}

export interface RouteTable {
  stable: string | null;
  pilot: string | null;
  pilot_ratio: number;
  updated_at: string | null;
}

export interface RouteChoice {
  version: string | null;
  track: "stable" | "pilot" | "unreleased";
  reason: string;
}

export interface Release {
  version: string;
  status: "draft" | "checked" | "published" | "failed" | "rolled_back";
  config_hash?: string;
  manifest?: Json;
  created_at?: string;
  checked_at?: string | null;
  published_at?: string | null;
  track?: string | null;
  pilot_ratio?: number | null;
}

export interface CheckCase {
  id: string;
  probe: string;
  ok: boolean;
  detail: string;
  duration_ms?: number;
}

export interface CheckResult {
  version: string;
  status: "checked" | "failed";
  ok: boolean;
  checked_at: string;
  cases: CheckCase[];
}

export interface BudgetState {
  allowed: boolean;
  scope: string | null;
  scopes: Json[];
  code?: string;
  error?: { code: string; message: string };
}

export interface RunSummary {
  run_id: string;
  status: string;
  tenant?: string;
  dept?: string;
  release_version?: string | null;
  track?: string;
  steps?: number;
  final_answer?: string | null;
  cost_usd?: number | null;
  [key: string]: unknown;
}

export interface QueryRequest {
  question: string;
  mode?: "vector" | "bm25" | "hybrid";
  top_k?: number;
  doc_type?: "doc" | "code" | "web" | "table" | "pdf";
}

export interface QueryResponse {
  question: string;
  mode: string;
  retrieval_mode: string;
  degraded: boolean;
  degrade_reason: string | null;
  filters_applied: { tenant: string; dept: string; doc_type: string | null };
  citations: Array<{ index: number; file: string; heading: string; score: number; snippet: string }>;
}

export interface RunEvent {
  type: string;
  [key: string]: unknown;
}

// ---------------------------------------------------------------- platform

export interface PlatformClientOptions extends ClientOptions {}

/** 控制面客户端。方法名对着动作走，不逐字翻译路径。 */
export class PlatformClient {
  private readonly http: HttpClient;

  constructor(options: PlatformClientOptions) {
    this.http = new HttpClient(options);
  }

  identity(): Promise<{ identity: IdentityView; service: boolean }> {
    return this.http.request("GET", "/v1/identities");
  }

  listReleases(): Promise<{ items: Release[] }> {
    return this.http.request("GET", "/v1/releases");
  }

  draftRelease(input: { version?: string; auto_check?: boolean; components?: Json; cases?: Json[] } = {}):
    Promise<{ release: Release; files: Json; check?: CheckResult }> {
    return this.http.request("POST", "/v1/releases", { body: input });
  }

  getRelease(version: string): Promise<Release & { checks: CheckCase[] }> {
    return this.http.request("GET", `/v1/releases/${encodeURIComponent(version)}`);
  }

  check(version: string): Promise<CheckResult> {
    return this.http.request("POST", `/v1/releases/${encodeURIComponent(version)}/check`);
  }

  publish(version: string, input: { track?: "stable" | "pilot"; pilot_ratio?: number } = {}):
    Promise<{ version: string; track: string; pilot_ratio: number; route: RouteTable }> {
    return this.http.request("POST", `/v1/releases/${encodeURIComponent(version)}/publish`, { body: input });
  }

  rollback(input: { reason?: string; version?: string } = {}):
    Promise<{ rolled_back: string; stable: string | null; route: RouteTable }> {
    return this.http.request("POST", "/v1/releases/rollback", { body: input });
  }

  route(): Promise<RouteTable> {
    return this.http.request("GET", "/v1/releases/route");
  }

  previewRoute(runId: string, group?: "stable" | "pilot"): Promise<{ choice: RouteChoice; route: RouteTable }> {
    return this.http.request("GET", "/v1/releases/route/preview", { query: { run_id: runId, group } });
  }

  recordUsage(input: Json): Promise<{ recorded: boolean; usage: Json }> {
    return this.http.request("POST", "/v1/usage", { body: input });
  }

  costReport(query: { groupBy?: string; days?: number; tenant?: string; format?: "json" | "md" } = {}):
    Promise<Json> {
    // format=md 时服务端回 text/markdown；这里只在 JSON 模式下使用。
    return this.http.request("GET", "/v1/cost/report", { query: { ...query, format: "json" } });
  }

  /** Markdown 报表，直接可用于贴到周报或落地成文件。 */
  costReportMarkdown(query: { groupBy?: string; days?: number; tenant?: string } = {}): Promise<string> {
    return this.http.request("GET", "/v1/cost/report", { query: { ...query, format: "md" } });
  }

  listBudgets(): Promise<{ items: Json[] }> {
    return this.http.request("GET", "/v1/budgets");
  }

  setBudget(input: { scope: string; period?: "daily" | "monthly"; limit_usd: number; warn_ratio?: number }):
    Promise<Json> {
    return this.http.request("POST", "/v1/budgets", { body: input });
  }

  /**
   * 预算检查。429 时服务端仍返回 `allowed=false` 的完整状态，但 SDK 会抛 `ApiError`——
   * 想区分「预算拦住」与「服务坏了」，看 `error.code === "BUDGET_EXCEEDED"`。
   */
  checkBudget(scopes: string[]): Promise<BudgetState> {
    return this.http.request("GET", "/v1/budgets/check", { query: { scope: scopes } });
  }

  audit(query: { tenant?: string; limit?: number; action?: string } = {}): Promise<{ items: Json[] }> {
    return this.http.request("GET", "/v1/audit", { query });
  }

  listReplays(query: { tenant?: string; limit?: number } = {}): Promise<{ items: Json[] }> {
    return this.http.request("GET", "/v1/replays", { query });
  }

  replay(runId: string): Promise<{ replay: Json; ok?: boolean; status?: string }> {
    return this.http.request("POST", "/v1/replays", { body: { run_id: runId } });
  }
}

// ---------------------------------------------------------------- agent

export class AgentClient {
  private readonly http: HttpClient;

  constructor(options: ClientOptions) {
    this.http = new HttpClient(options);
  }

  async run(input: {
    prompt: string;
    task?: string | null;
    goal?: string | null;
    user?: string | null;
    model_alias?: string;
    release_group?: "stable" | "pilot";
  }): Promise<{ run_id: string; status: string; release?: Json; model_alias?: string }> {
    return this.http.request("POST", "/v1/runs", { body: input });
  }

  get(runId: string): Promise<RunSummary> {
    return this.http.request("GET", `/v1/runs/${encodeURIComponent(runId)}`);
  }

  list(): Promise<{ items: RunSummary[] }> {
    return this.http.request("GET", "/v1/runs");
  }

  replay(runId: string): Promise<Json> {
    return this.http.request("POST", `/v1/runs/${encodeURIComponent(runId)}/replay`);
  }

  /**
   * 等到终态。轮询 GET 而不是依赖 SSE：SSE 适合展示进度，等待结果用轮询更省连接，
   * 断开重连的语义也不用在调用方重复实现。
   */
  async wait(runId: string, options: { timeoutMs?: number; intervalMs?: number } = {}): Promise<RunSummary> {
    const timeoutMs = options.timeoutMs ?? 120_000;
    const intervalMs = options.intervalMs ?? 500;
    const deadline = Date.now() + timeoutMs;
    for (;;) {
      const run = await this.get(runId);
      if (run.status !== "running") return run;
      if (Date.now() > deadline) {
        throw new ApiError({
          status: 408, code: "WAIT_TIMEOUT", method: "GET", path: `/v1/runs/${runId}`,
          message: `等待运行结束超时（${timeoutMs}ms）`,
        });
      }
      await sleep(intervalMs);
    }
  }

  /** 订阅 SSE。生成器结束时流已收到 `[DONE]` 或连接关闭。 */
  async *stream(runId: string, options: { signal?: AbortSignal } = {}): AsyncGenerator<RunEvent> {
    const response = await this.http.stream("GET", `/v1/runs/${encodeURIComponent(runId)}/events`, {
      headers: { Accept: "text/event-stream" },
      signal: options.signal,
    });
    if (!response.body) throw new Error("响应没有 body，无法解析 SSE");
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";
    try {
      for (;;) {
        const { value, done } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        let boundary = buffer.indexOf("\n\n");
        while (boundary >= 0) {
          const chunk = buffer.slice(0, boundary);
          buffer = buffer.slice(boundary + 2);
          const event = parseSseChunk(chunk);
          if (event === DONE) return;
          if (event) yield event;
          boundary = buffer.indexOf("\n\n");
        }
      }
      const tail = parseSseChunk(buffer);
      if (tail && tail !== DONE) yield tail;
    } finally {
      reader.releaseLock();
    }
  }
}

const DONE = Symbol("done");

function parseSseChunk(chunk: string): RunEvent | typeof DONE | null {
  const data = chunk
    .split("\n")
    .filter((line) => line.startsWith("data:"))
    .map((line) => line.slice(5).trimStart())
    .join("\n")
    .trim();
  if (!data) return null;
  if (data === "[DONE]") return DONE;
  try {
    return JSON.parse(data) as RunEvent;
  } catch {
    return { type: "raw", data };
  }
}

// ---------------------------------------------------------------- retrieval

export class RetrievalClient {
  private readonly http: HttpClient;

  constructor(options: ClientOptions) {
    this.http = new HttpClient(options);
  }

  query(input: QueryRequest): Promise<QueryResponse> {
    return this.http.request("POST", "/v1/query", { body: input });
  }

  /** 内部通道：用 X-Tenant / X-Dept 说明身份，只应在服务网格内使用。 */
  internalQuery(input: QueryRequest, identity: { tenant: string; dept: string }): Promise<QueryResponse> {
    return this.http.request("POST", "/internal/query", {
      body: input,
      headers: { "X-Tenant": identity.tenant, "X-Dept": identity.dept },
    });
  }
}

// ---------------------------------------------------------------- eval

export class EvalClient {
  private readonly http: HttpClient;

  constructor(options: ClientOptions) {
    this.http = new HttpClient(options);
  }

  state(): Promise<Json> {
    return this.http.request("GET", "/api/state");
  }

  cost(): Promise<Json> {
    return this.http.request("GET", "/api/cost");
  }

  saveTask(task: Json): Promise<Json> {
    return this.http.request("POST", "/api/tasks", { body: task });
  }

  importTasks(tasks: Json[]): Promise<Json> {
    return this.http.request("POST", "/api/tasks/import", { body: { tasks } });
  }

  exportTasks(): Promise<{ tasks: Json[] }> {
    return this.http.request("GET", "/api/tasks/export");
  }

  deleteTask(taskId: string): Promise<{ deleted: boolean }> {
    return this.http.request("DELETE", `/api/tasks/${encodeURIComponent(taskId)}`);
  }

  saveStrategy(strategy: Json): Promise<Json> {
    return this.http.request("POST", "/api/strategies", { body: strategy });
  }

  deleteStrategy(strategyId: string): Promise<{ deleted: boolean }> {
    return this.http.request("DELETE", `/api/strategies/${encodeURIComponent(strategyId)}`);
  }

  startExperiment(input: Json): Promise<Json> {
    return this.http.request("POST", "/api/experiments", { body: input });
  }

  cancelExperiment(experimentId: string): Promise<Json> {
    return this.http.request("POST", `/api/experiments/${encodeURIComponent(experimentId)}/cancel`, { body: {} });
  }

  getRun(runId: string): Promise<Json> {
    return this.http.request("GET", `/api/runs/${encodeURIComponent(runId)}`);
  }

  judge(runId: string): Promise<Json> {
    return this.http.request("POST", `/api/runs/${encodeURIComponent(runId)}/judge`);
  }

  review(runId: string, review: Json): Promise<Json> {
    return this.http.request("POST", `/api/runs/${encodeURIComponent(runId)}/reviews`, { body: review });
  }

  compare(query: { baseline?: string; candidate?: string; experiment?: string } = {}): Promise<Json> {
    return this.http.request("GET", "/api/compare", { query });
  }

  report(query: { baseline?: string; candidate?: string; experiment?: string; format?: "json" | "md" } = {}):
    Promise<Json | string> {
    return this.http.request("GET", "/api/reports", { query });
  }
}

export { HttpClient };
