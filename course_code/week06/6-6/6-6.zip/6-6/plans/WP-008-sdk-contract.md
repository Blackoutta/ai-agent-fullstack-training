# WP-008 OpenAPI 契约与 SDK

## 目标

用一份 `docs/openapi.yaml` 描述五个服务的对外接口，并提供 TS 与 Python 薄客户端，统一错误体、重试与 SSE。

## 约束

- 契约是单一真源：路径、方法、错误码必须与实现一致，由 `scripts/check_contract.py` 断言。
- 客户端不重复业务逻辑：只做序列化、鉴权头、重试、错误归一、SSE 解析。
- 错误体会统一成 `{error, code, details[], request_id}`，客户端把 HTTP 状态与 `code` 一起暴露。
- 不引入第三方依赖：TS 用内置 `fetch`，Python 用 `urllib`。

## 设计对应

`design/architecture.md` §3 §10

## 实现

- `docs/openapi.yaml`：tags 按服务分组；每个端点含 `operationId`、错误响应、示例。
- `sdk/ts/src/index.ts`：`PlatformClient`（`releases`、`replay`、`cost`、`budget`、`audit`）、`AgentClient`（`run`、`wait`、`stream`）、`RetrievalClient`、`EvalClient`。
- `sdk/python/platform_sdk/client.py`：同构接口。
- `sdk/ts/tests/contract.test.ts`、`tests/test_sdk_python.py`：路径表与错误归一。

## 验收

- `node --test sdk/ts/tests/*.test.ts` 通过。
- `python3 -m unittest tests.test_sdk_python` 通过。
- `python3 scripts/check_contract.py` 断言 OpenAPI 路径覆盖全部服务路由常量。
