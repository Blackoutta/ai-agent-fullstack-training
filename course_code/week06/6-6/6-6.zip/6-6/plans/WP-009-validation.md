# WP-009 验收与交付

## 目标

把「能跑」证成「可核查」：离线自验全绿，端到端脚本可重放，未覆盖项写清楚。

## 约束

- 只把实际执行过的结果写进 `check/validation.md`；未执行的必须标注原因，不用「应该可以」代替。
- 离线与在线结果分开记录；离线不进真实成功率分母。
- 端到端脚本必须幂等：`scripts/smoke.py` 可重复执行，重复发布同版本不产生重复记录。

## 设计对应

`design/architecture.md` 全文；`requirements/platform.md` R1–R12

## 实现

- `scripts/check_contract.py`：OpenAPI ↔ 实现路由一致性。
- `scripts/smoke.py`：发布单 → 检查 → 发布 → 回滚 → 回放，`--offline` 只排练路径。
- `scripts/cost_report.py`：调用报表端点并落盘 Markdown。
- `tests/`：脱敏双语言一致性、发布单状态机、租户过滤、SDK。
- `check/validation.md`：逐条记录 R1–R12 的验证方式与结果。

## 验收

- `make verify-offline` 全绿。
- `docker compose config` 通过。
- `check/validation.md` 含「未覆盖项」一节，列明 Docker 未启动、真实密钥缺失、向量写入未执行。
