# WP-005 Eval 平台容器化与租户补丁

## 目标

保留 5-5 评测工作台全部能力，同时满足容器内同源访问、租户分区、脱敏与成本回传。

## 约束

- 镜像内必须同时有 node 22（跑 bridge worker）与 python 3.11（跑后端）；
  `/app/codebase` 与 `/app/codebaseEval` 必须同级。
- 只改必要的四处（见 `design/vendor-patches.md`），不重写评测逻辑。
- 金额脱敏后评测所需的百分比与结构化数值必须保留，否则评测不成立。

## 设计对应

`design/architecture.md` §6 §7 §8 §10

## 实现

- `services/eval/Dockerfile`：node22 + python3.11 双运行时；`npm ci` 装 codebase、frontend、bridge 依赖；构建前端。
- `codebaseEval/backend/server.py`：Host 白名单（`EVAL_ALLOWED_HOSTS`）、身份解析、`/api/health`、`/api/cost`。
- `codebaseEval/backend/tenancy.py`：身份与租户过滤的单一入口。
- `codebaseEval/backend/common.py`：`scrub()` 接分类分级脱敏。
- `codebaseEval/backend/store.py`：`entities`/`reviews` 增 `tenant` 列与索引。

## 验收

- `python -m unittest codebaseEval/tests`（5-5 原有测试）仍全绿。
- 同源校验：`Host: eval:8765` 放行，`Host: evil.example` 拒绝。
- 跨租户：tenant_b 的 key 读 tenant_a 的实验返回 403 且写审计。
- 双语言脱敏一致性由 `tests/test_redaction_parity.py` 断言。
