# TASK-001 阶段六平台开发任务计划

关联需求：`requirements/platform.md`（R1–R12）
架构：`design/architecture.md`
角色：PM（拆分）→ 架构（设计/框架）→ 后端 + 前端（编码）→ 测试（验收）→ 运维（编排/监控）

## 目标

在 `week06/6-6` 交付一套可用 `docker compose` 一键启动的 Agent 平台，覆盖：七组件容器化、发布单灰度/回滚/回放、成本预算与报表、租户隔离与脱敏、TS/Python SDK。

## 工作包与顺序

| 顺序 | 工作包 | 负责角色 | 依赖 | 验收 |
|---|---|---|---|---|
| 1 | `WP-001` 骨架与四件套 | PM + 架构 | — | 目录齐全；`docker compose config` 通过 |
| 2 | `WP-002` 网关 | 运维 + 后端 | WP-001 | 配置解析出 `deepseek-flash`；离线可验证路由表 |
| 3 | `WP-003` Agent 服务化 | 后端（Node） | WP-001, WP-002 | `/health`、`POST /v1/runs`、SSE、归档、回放、`/metrics` |
| 4 | `WP-004` 检索服务 | 后端（Python） | WP-001 | 强制 filter、BM25 降级、ingest 作业 |
| 5 | `WP-005` Eval 容器化 | 后端 + 前端 | WP-003 | 容器内同源访问、租户分区、脱敏、成本回传 |
| 6 | `WP-006` 平台控制面 | 后端（Python） | WP-002..005 | 发布单状态机、路由、预算、报表、审计 |
| 7 | `WP-007` 可观测编排 | 运维 | WP-003, WP-006 | Langfuse trace 可见；Grafana 有成本与发布看板 |
| 8 | `WP-008` SDK 与契约 | 后端 + 前端 | WP-003..006 | OpenAPI 与实现一致；双语言客户端通过契约测试 |
| 9 | `WP-009` 验收 | 测试 | 全部 | `make verify-offline` 全绿；`check/validation.md` 记录实测 |

## 风险与阻塞

| 风险 | 影响 | 缓解 |
|---|---|---|
| Docker daemon 未运行 | 无法端到端拉起 | 交付离线自验 + 一键脚本；完整栈由使用者执行 `make up` |
| Milvus Lite 单写者 | 不能多副本 | ingest 一次性作业；`make seed` 停-写-起；降级 BM25 |
| pi 0.87.1 与 Langfuse 官方插件版本不匹配 | trace 接入崩溃 | 自建 exporter 走 `/api/public/ingestion` |
| 端口 3000 冲突 | 两个 UI 抢端口 | Grafana 改 3001；Prometheus 9092 |
| 无模型密钥 | 真实成绩不可得 | 双模式：`decider=mock` 离线 + 录制回放，结果标 `offline` |

## 交付判定

1. `make verify-offline` 全绿（脱敏、成本、发布单、租户、回放、SSE、契约、compose 语法）。
2. `make up` 后六个 HTTP 入口全部 `/health` 200。
3. `make smoke` 完整走通 发布单 → 检查 → 灰度 → 回滚 → 回放。
4. `check/validation.md` 记录实际执行结果与未覆盖项，未覆盖项必须显式列出。
