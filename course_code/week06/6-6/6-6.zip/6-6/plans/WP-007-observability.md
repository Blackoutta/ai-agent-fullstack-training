# WP-007 可观测编排

## 目标

Langfuse 六服务 + Prometheus + Grafana 与平台一起起停；agent 的 trace 与指标可查；Grafana 有成本与发布看板。

## 约束

- 复用 6-3 的 Langfuse 编排与 6-4 的监控口径，不重新发明指标语义。
- Grafana 宿主端口 3001（3000 归 Langfuse）；Prometheus 9092。
- 不使用 `@langfuse/pi-observability-plugin`（面向 pi 1.5.0，本项目是 0.87.1），改自建 exporter 调 `/api/public/ingestion`。
- Trace 只写脱敏内容；不写思维链、不写完整供应商请求。

## 设计对应

`design/architecture.md` §9 §10

## 实现

- `deploy/langfuse/docker-compose.langfuse.yml`：六服务，端口全部绑 127.0.0.1。
- `deploy/prometheus/docker-compose.yml`：Prometheus + Grafana，`prometheus.yml` 抓 `gateway`、`platform`、`agent`、`retrieval`、`eval`。
- `deploy/prometheus/grafana/provisioning/`：datasource 与 dashboard provider 自动装载。
- `deploy/prometheus/grafana/dashboards/agent-platform.json`：三层指标 + 成本 + 发布。
- `services/agent/src/core/langfuse.ts`：ingestion 客户端，失败只记日志不影响运行。

## 验收

- `make up` 后 Langfuse `http://localhost:3000/api/public/health` 200，Grafana 3001 可见数据源。
- Prometheus targets 页五个 job 全 UP（app 服务未起时对应 job DOWN，属预期）。
- 跑一次运行后 Langfuse 出现 trace，Grafana 的 `agent_runs_total` 有增量。
