# WP-001 工程骨架与四件套

## 目标

建立 `week06/6-6` 的目录、文档与编排骨架，使后续工作包有稳定的落点。

## 约束

- `week05/5-5` 只读；快照放 `codebase/` 与 `codebaseEval/`，保持同级（`bridge/client.py` 依赖 `parents[2]`）。
- 快照不含 `node_modules`、`dist`、`data`、`runs`、`artifacts`。
- 端口与 `design/architecture.md` 第 2 节一致，占用 3000 的只能是 Langfuse。

## 设计对应

`design/architecture.md` §1 §2 §10

## 实现

`docker-compose.yml`（五个应用服务 + 健康检查）、`Makefile`（up/down/seed/smoke/verify-offline）、`.env.example`、`.gitignore`、`requirements/platform.md`、`design/*`、`plans/*`、`check/00-env/pipeline-status.md`、`docs/ops.md`、`README.md`。

## 验收

- `docker compose config` 可解析（多 `-f` 合并）。
- 目录与 `README.md` 的结构图一致。
- 四件套文件齐全且互相指路。
