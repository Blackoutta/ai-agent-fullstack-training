# WP-002 网关：litellm + DeepSeek-flash

## 目标

应用侧只发逻辑模型名 `deepseek-flash`，由 litellm 解析到上游 `deepseek-v4-flash`；网关持有厂商密钥，并提供故障切换路径。

## 约束

- 只有 gateway 容器拿到 `DEEPSEEK_API_KEY`；agent 容器里的同名变量装的是网关密钥。
- 未接独立 Postgres 时 `LITELLM_VIRTUAL_KEY` 必须等于 `LITELLM_MASTER_KEY`，否则应用 401。
- `/health/liveliness` 用于 compose 健康检查。

## 设计对应

`design/architecture.md` §2 §3 §10（`GATEWAY_UNAVAILABLE`）

## 实现

`services/gateway/litellm.config.yaml`：两个同名部署（主/备）、`router_settings` 的 retries/cooldown/fallbacks、`general_settings.master_key`。

## 验收

- 配置文件可被 YAML 解析，且 `model_list[].model_name` 恒为 `deepseek-flash`（契约测试断言）。
- 离线：`scripts/smoke.py --offline` 校验别名与上游映射；不发起真实调用。
- 在线：`curl localhost:4000/v1/chat/completions -d '{"model":"deepseek-flash",...}'` 返回 `deepseek-v4-flash` 代次。
