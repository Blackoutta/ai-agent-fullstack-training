# WP-004 检索服务（LlamaIndex + Milvus Lite）

## 目标

把 week04/4-4 的检索能力封成服务：`POST /v1/query` 支持 `vector | bm25 | hybrid`，租户与部门过滤由服务端强制注入。

## 约束

- Milvus Lite 是嵌入式文件、单写者：ingest 为一次性作业，retrieval 单副本；不支持多副本。
- 请求体出现 `tenant`/`dept` 字段直接 400 `TENANT_FIELD_FORBIDDEN`。
- `llama_index` / `pymilvus` / 嵌入密钥任一缺失即降级 BM25，并把 `retrieval_mode` 如实写进响应。
- 无嵌入密钥时 `ingest` 拒绝写入向量，不放宽维度假装成功。

## 设计对应

`design/architecture.md` §2 §3 §7 §9

## 实现

- `services/retrieval/app/server.py`：标准库 HTTP，`/health`、`/v1/query`、`/metrics`。
- `services/retrieval/app/bm25.py`：纯标准库 BM25（中文按字 bigram 切分），保证无依赖可跑。
- `services/retrieval/app/vector.py`：惰性导入 LlamaIndex + Milvus，失败即抛 `VectorUnavailable`。
- `services/retrieval/app/ingest.py`：一次性作业，读写 `data/milvus/milvus_login_demo.db`。
- `corpus/`：从 `week04/4-4/corpus` 原样复制。

## 验收

- `python -m unittest services/retrieval/tests`：强制过滤注入、越权字段拒绝、BM25 命中与排序、降级标注。
- 容器内：`make seed` 后 `POST /v1/query` 返回 `retrieval_mode` 与 `filters_applied`。
