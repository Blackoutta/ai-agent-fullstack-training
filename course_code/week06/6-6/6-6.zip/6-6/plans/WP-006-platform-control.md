# WP-006 平台控制面

## 目标

一个服务承担平台治理：发布单与状态机、stable/pilot 路由、回放调度、预算与成本报表、审计、身份回显、密钥自检。

## 约束

- 只用 Python 标准库（`http.server` + `sqlite3`），与会话课程一致，也便于离线自测。
- 状态机严格：`draft → checked → published`；未 `checked` 或 `check` 失败一律拒绝 publish（409）。
- 回滚只改路由表；每次 publish/rollback/自动回滚都写审计。
- 密钥只在环境变量；启动扫描产物目录，命中疑似密钥即 `SECRET_IN_ARTIFACT` 退出。

## 设计对应

`design/architecture.md` §4 §5 §6 §7 §8 §10

## 实现

- `app/store.py`：SQLite 表 `releases`、`release_checks`、`routes`、`usage`、`budgets`、`audit`、`replays`。
- `app/releases.py`：草稿生成、指纹计算、离线探针、publish/rollback、路由选择。
- `app/cost.py`：用量聚合、预算判定、JSON/Markdown 报表。
- `app/redaction.py`：分类分级脱敏规则表（真源副本）。
- `app/identity.py`：`PLATFORM_API_KEYS` 解析与鉴权。
- `app/server.py`：HTTP 路由与统一错误体。

## 验收

- `python -m unittest services/platform/tests`：状态机、未检查发布拒绝、比例路由、预算 429、成本聚合与报表、审计写入、密钥自检。
- `POST /v1/releases` 生成 manifest 并落盘 `releases/<version>/manifest.yaml`。
- `GET /v1/cost/report?format=md` 输出含缺失成本计数的报表。
