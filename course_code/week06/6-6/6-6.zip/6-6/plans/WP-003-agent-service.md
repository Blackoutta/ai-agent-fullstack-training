# WP-003 Agent 服务化

## 目标

把 CLI 形态的 codebase agent 升级为 HTTP 服务：创建运行、查询运行、订阅事件流；每次运行归档可回放材料；出站内容统一脱敏；暴露指标并上报 Langfuse。

## 约束

- 不复制 Agent Loop：每次运行 spawn worker 子进程，worker 内 `buildPlatform → runManagedAgent`。
- 模型只经网关：worker 用 `GATEWAY_BASE_URL`、`GATEWAY_MODEL_ID` 覆盖 codebase 配置。
- 无密钥时用 `decider=mock`（codebase 原生能力），结果标 `offline`。
- 金额/证件/手机号/地址在写归档与发 SSE 之前脱敏；金额映射只在本次运行内存。

## 设计对应

`design/architecture.md` §3 §5 §6 §7 §8 §9

## 实现

- `services/agent/src/core/*.ts`：`redact`、`release`（路由选择）、`events`（事件归一）、`archive`（归档与版本比对）、`usage`（成本）、`sse`、`metrics`。
- `services/agent/src/server.ts`：`http` 服务，路由 `/health`、`/v1/runs`、`/v1/runs/{id}`、`/v1/runs/{id}/events`、`/v1/runs/{id}/replay`、`/metrics`。
- `services/agent/src/worker.ts`：子进程入口，读 stdin 的 JSON，按行输出事件。

## 验收

- `node --test services/agent/tests/*.test.ts`：路由选择、脱敏、事件映射、归档版本比对、SSE 帧格式、成本计算。
- 容器内：`POST /v1/runs` 202；`GET .../events` 收到 `message`/`tool`/`outcome` 且无敏感原文。
- `POST /v1/runs/{id}/replay` 在版本不一致时 409 且列出差异项。
