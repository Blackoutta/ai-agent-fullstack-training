"""SQLite transactions keep API threads and evaluation workers consistent.

租户分区在这里落地：

- 每条实体都带 `tenant` 列，索引 `(kind, tenant)`。
- `public` 是平台内置基准（种子任务与基线策略）：任何租户可读，但不可写、不可删。
- 租户自建实体（实验、运行、人工评审）只在本租户可见。
- 越权读抛 `TenantViolation`（→ 403 + 审计），而不是返回空：
  返回空会让调用方以为「数据不存在」，把越权尝试藏起来。
"""
import json
from pathlib import Path
import sqlite3
import threading
import uuid

from .common import now, scrub
from .tenancy import PUBLIC, TenantViolation


class Store:
    def __init__(self, directory, default_tenant=PUBLIC):
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True)
        self.default_tenant = default_tenant
        self.lock = threading.RLock()
        self.db = sqlite3.connect(self.directory / "platform.sqlite", check_same_thread=False)
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.executescript("""
            CREATE TABLE IF NOT EXISTS entities (
                kind TEXT NOT NULL, id TEXT NOT NULL, data TEXT NOT NULL,
                tenant TEXT NOT NULL DEFAULT 'public',
                PRIMARY KEY(kind,id));
            CREATE TABLE IF NOT EXISTS reviews (
                id TEXT PRIMARY KEY, run_id TEXT NOT NULL, data TEXT NOT NULL,
                tenant TEXT NOT NULL DEFAULT 'public');
            CREATE INDEX IF NOT EXISTS review_run ON reviews(run_id);
        """)
        # 建索引必须等迁移完成：5-5 的旧表没有 tenant 列，先加列再建复合索引。
        self._migrate()
        self.db.commit()

    def _migrate(self):
        """5-5 的库没有 tenant 列：就地加列，历史数据归 public，不删库。"""
        for table in ("entities", "reviews"):
            columns = {row[1] for row in self.db.execute(f"PRAGMA table_info({table})")}
            if "tenant" not in columns:
                self.db.execute(f"ALTER TABLE {table} ADD COLUMN tenant TEXT NOT NULL DEFAULT 'public'")
        self.db.execute("CREATE INDEX IF NOT EXISTS entity_tenant ON entities(kind, tenant)")
        self.db.execute("CREATE INDEX IF NOT EXISTS review_tenant ON reviews(run_id, tenant)")

    # ------------------------------------------------------------ 可见性

    @staticmethod
    def _visible(owner, tenant):
        return owner == tenant or owner == PUBLIC

    def _check(self, kind, ident, owner, tenant):
        if tenant is not None and not self._visible(owner, tenant):
            raise TenantViolation(f"{kind} 属于其他租户，当前身份不可访问", owner=owner)

    # ------------------------------------------------------------ 实体

    def put(self, kind, value, tenant=None):
        value = scrub(dict(value))
        tenant = tenant or value.get("tenant") or self.default_tenant
        value.setdefault("id", uuid.uuid4().hex[:16])
        value["tenant"] = tenant
        with self.lock, self.db:
            self.db.execute(
                "INSERT INTO entities(kind,id,data,tenant) VALUES (?,?,?,?) "
                "ON CONFLICT(kind,id) DO UPDATE SET data=excluded.data, tenant=excluded.tenant",
                (kind, value["id"], json.dumps(value, ensure_ascii=False), tenant),
            )
        return value

    def get(self, kind, ident, tenant=None):
        with self.lock:
            row = self.db.execute("SELECT data, tenant FROM entities WHERE kind=? AND id=?", (kind, ident)).fetchone()
        if not row:
            raise KeyError(f"{kind} 不存在：{ident}")
        self._check(kind, ident, row[1], tenant)
        return json.loads(row[0])

    def list(self, kind, tenant=None):
        with self.lock:
            if tenant is None:
                rows = self.db.execute(
                    "SELECT data FROM entities WHERE kind=? ORDER BY rowid DESC", (kind,)
                ).fetchall()
            else:
                rows = self.db.execute(
                    "SELECT data FROM entities WHERE kind=? AND (tenant=? OR tenant=?) ORDER BY rowid DESC",
                    (kind, tenant, PUBLIC),
                ).fetchall()
        return [json.loads(row[0]) for row in rows]

    def delete(self, kind, ident, tenant=None):
        owner = self.get(kind, ident, tenant)
        if tenant is not None and owner.get("tenant") == PUBLIC:
            raise TenantViolation("public 基准实体不允许删除", owner=PUBLIC)
        with self.lock, self.db:
            self.db.execute("DELETE FROM entities WHERE kind=? AND id=?", (kind, ident))

    # ------------------------------------------------------------ 评审

    def add_review(self, run_id, data, tenant=None):
        value = scrub({**data, "id": uuid.uuid4().hex, "created_at": now()})
        tenant = tenant or self.default_tenant
        value["tenant"] = tenant
        with self.lock, self.db:
            self.db.execute(
                "INSERT INTO reviews(id,run_id,data,tenant) VALUES (?,?,?,?)",
                (value["id"], run_id, json.dumps(value, ensure_ascii=False), tenant),
            )
        return value

    def reviews(self, run_id, tenant=None):
        with self.lock:
            if tenant is None:
                rows = self.db.execute(
                    "SELECT data FROM reviews WHERE run_id=? ORDER BY rowid", (run_id,)
                ).fetchall()
            else:
                rows = self.db.execute(
                    "SELECT data FROM reviews WHERE run_id=? AND (tenant=? OR tenant=?) ORDER BY rowid",
                    (run_id, tenant, PUBLIC),
                ).fetchall()
        return [json.loads(row[0]) for row in rows]

    def close(self):
        self.db.close()
