"""Local same-origin API and static Vue application server.

相对 5-5 的四处必要补丁（见 `design/vendor-patches.md`）：

1. Host 白名单从「写死 localhost」改成 `EVAL_ALLOWED_HOSTS`，容器里以 `eval:8765` 提供服务；
   不在白名单的 Host 一律 403，防 DNS rebinding。
2. 每个 `/api/*` 请求先解析身份（`PLATFORM_API_KEYS`），把 `identity.tenant` 透传给 Engine：
   越权读抛 `TenantViolation` → 403 + 审计，而不是返回空（返回空会把越权藏起来）。
3. `GET /api/health` 不带凭据：容器健康检查不能先有密钥，且它只回状态不回数据。
4. `GET /api/cost`：评测侧本地成本视图；跨服务汇总在 platform 的 `/v1/cost/report`。
"""
import argparse
from collections import defaultdict
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import mimetypes
import os
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse
import uuid

from .analysis import markdown_report
from .common import ROOT, load_env, scrub
from .engine import Engine
from .tenancy import (PUBLIC, Identity, TenantViolation, Unauthenticated, audit,
                      parse_api_keys, resolve_identity)

SERVICE = "eval"
VERSION = "1.1"
ANONYMOUS = Identity(tenant=PUBLIC, dept="anonymous", role="none", key_prefix="")


class HostRejected(PermissionError):
    """Host/Origin 不在白名单 → 403，但和租户越权不是一回事，审计动作也不同。"""


def host_whitelist(port):
    raw = os.environ.get("EVAL_ALLOWED_HOSTS", "")
    names = [name.strip() for name in raw.split(",") if name.strip()] or ["localhost", "127.0.0.1"]
    allowed = set()
    for name in names:
        allowed.add(name)
        if ":" not in name:
            allowed.add(f"{name}:{port}")
    return {name.lower() for name in allowed}


def handler_for(engine, keys=None):
    keys = keys or {}

    class Handler(BaseHTTPRequestHandler):
        server_version = "CodebaseEval/1.1"

        def log_message(self, *_args):
            pass

        def send(self, status, value, content_type="application/json; charset=utf-8", attachment=None):
            payload = json.dumps(scrub(value), ensure_ascii=False, allow_nan=False).encode() if content_type.startswith("application/json") else value
            if isinstance(payload, str):
                payload = payload.encode()
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(payload)))
            # 请求号在错误体里也有，这里再回一个头，方便前端和网关把日志串起来。
            if getattr(self, "request_id", None):
                self.send_header("X-Request-Id", self.request_id)
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Cache-Control", "no-store" if content_type.startswith("application/json") else "no-cache")
            self.send_header("Content-Security-Policy", "default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'")
            if attachment:
                self.send_header("Content-Disposition", f'attachment; filename="{attachment}"')
            self.end_headers()
            self.wfile.write(payload)

        def fail(self, status, code, message, **extra):
            """统一错误体（见 docs/openapi.yaml#/components/schemas/Error）。

            `error` 保留嵌套对象是为了不破坏既有调用方（前端与测试都读 `body["code"]`）；
            `code` 再平铺一份，方便日志与告警直接按字段过滤。
            """
            self.send(status, {"error": {"code": code, "message": message},
                               "code": code,
                               "details": [extra] if extra else [],
                               "request_id": getattr(self, "request_id", ""),
                               **extra})

        # ---------------------------------------------------------- 入站校验

        def allowlist(self):
            cached = getattr(self.server, "allowed_hosts", None)
            if cached is None:
                cached = host_whitelist(self.server.server_port)
                self.server.allowed_hosts = cached
            return cached

        def safe_request(self):
            allowed = self.allowlist()
            host = (self.headers.get("Host") or "").strip().lower()
            if host not in allowed:
                raise HostRejected(f"Host 不在白名单：{host or '(空)'}")
            origin = (self.headers.get("Origin") or "").strip()
            if origin and urlparse(origin).netloc.lower() not in allowed:
                raise HostRejected("拒绝跨站请求")

        def identity(self):
            self.identity_value = resolve_identity(self.headers.get("Authorization"), keys)
            return self.identity_value

        def body(self):
            if self.headers.get_content_type() != "application/json":
                raise ValueError("请求必须使用 application/json")
            length = int(self.headers.get("Content-Length", "0"))
            if not 0 < length <= 1_000_000:
                raise ValueError("请求大小必须为 1 到 1000000 字节")
            self.connection.settimeout(10)
            raw = self.rfile.read(length)
            if len(raw) != length:
                raise ValueError("请求体不完整")
            value = json.loads(raw)
            if not isinstance(value, dict):
                raise ValueError("JSON 必须为对象")
            return value

        # ---------------------------------------------------------- 分发

        def dispatch(self):
            # 同一连接会复用 handler 实例，身份与请求号必须逐请求重置。
            self.identity_value = None
            self.request_id = (self.headers.get("X-Request-Id") or "").strip() or f"req-{uuid.uuid4().hex[:12]}"
            try:
                self.safe_request()
                if self.is_health():
                    return self.health()
                if self.is_metrics():
                    return self.metrics()
                self.route(self.identity())
            except HostRejected as exc:
                self.fail(403, "HOST_REJECTED", str(exc))
            except Unauthenticated as exc:
                audit(engine.store, "auth_denied", ANONYMOUS,
                      {"path": self.path.split("?")[0], "reason": str(exc)})
                self.fail(401, "UNAUTHENTICATED", str(exc))
            except TenantViolation as exc:
                identity = self.identity_value or ANONYMOUS
                audit(engine.store, "tenant_violation", identity,
                      {"path": self.path.split("?")[0], "reason": str(exc), "owner": exc.owner})
                self.fail(403, "FORBIDDEN_TENANT", str(exc))
            except KeyError as exc:
                self.fail(404, "NOT_FOUND", str(exc))
            except (ValueError, TypeError, json.JSONDecodeError) as exc:
                self.fail(400, "BAD_REQUEST", str(exc))
            except (BrokenPipeError, ConnectionResetError):
                pass
            except Exception:
                self.fail(500, "INTERNAL", "平台内部错误，请查看本机服务状态")

        def is_health(self):
            return self.command == "GET" and urlparse(self.path).path.rstrip("/") == "/api/health"

        def health(self):
            return self.send(200, {"status": "ok", "service": SERVICE, "version": VERSION,
                                   "tenant_mode": "strict" if keys else "local",
                                   "auth_required": bool(keys)})

        def is_metrics(self):
            return self.command == "GET" and urlparse(self.path).path.rstrip("/") == "/metrics"

        def metrics(self):
            """Prometheus 抓取点：公开、只读、不带租户标签。

            指标给的是平台整体健康，不是某个租户的账：按租户拆成 label 会把租户
            名单泄给任何能访问 8090 的人（Prometheus 本身不鉴权）。租户级成本只走
            `/api/cost`（要密钥）。
            """
            runs = engine.store.list("run")
            lines = ["# HELP eval_up 评测服务存活", "# TYPE eval_up gauge", "eval_up 1",
                     "# HELP eval_runs_total 运行数（按模式与结果）",
                     "# TYPE eval_runs_total gauge"]
            counts = {}
            known_cost = 0.0
            unknown_cost = 0
            for run in runs:
                key = (run.get("mode") or "unknown", run.get("outcome") or "unknown")
                counts[key] = counts.get(key, 0) + 1
                metrics = run.get("metrics") or {}
                if metrics.get("cost_usd") is None:
                    unknown_cost += 1
                else:
                    known_cost += metrics.get("cost_usd") or 0
            for (mode, outcome), count in sorted(counts.items()):
                lines.append(f'eval_runs_total{{mode="{mode}",outcome="{outcome}"}} {count}')
            lines += ["# HELP eval_known_cost_usd 已知成本合计",
                      "# TYPE eval_known_cost_usd gauge",
                      f"eval_known_cost_usd {known_cost:.6f}",
                      "# HELP eval_unknown_cost_runs 没报成本的运行数",
                      "# TYPE eval_unknown_cost_runs gauge",
                      f"eval_unknown_cost_runs {unknown_cost}",
                      "# HELP eval_experiments_total 实验数",
                      "# TYPE eval_experiments_total gauge",
                      f"eval_experiments_total {len(engine.store.list('experiment'))}"]
            return self.send(200, "\n".join(lines) + "\n", "text/plain; version=0.0.4; charset=utf-8")

        # ---------------------------------------------------------- 业务

        def route(self, identity):
            parsed = urlparse(self.path)
            parts = [unquote(p) for p in parsed.path.split("/") if p]
            method = self.command
            if not parts or parts[0] != "api":
                if method != "GET":
                    return self.fail(405, "METHOD_NOT_ALLOWED", "方法不支持")
                return self.static(parsed.path)
            route = parts[1:]
            tenant = identity.tenant
            if method == "GET" and route == ["state"]:
                return self.send(200, engine.state(tenant))
            if method == "GET" and route == ["cost"]:
                return self.send(200, self.cost(tenant))
            if method == "GET" and route == ["tasks", "export"]:
                return self.send(200, {"tasks": engine.store.list("task", tenant=tenant)},
                                 attachment="benchmark.json")
            if method == "POST" and route == ["tasks", "import"]:
                return self.send(201, engine.import_tasks(self.body(), tenant))
            if method == "POST" and route == ["tasks"]:
                return self.send(201, engine.save_task(self.body(), tenant))
            if method == "POST" and route == ["strategies"]:
                return self.send(201, engine.save_strategy(self.body(), tenant))
            if method == "DELETE" and len(route) == 2 and route[0] in {"tasks", "strategies"}:
                engine.store.delete("task" if route[0] == "tasks" else "strategy", route[1], tenant)
                return self.send(200, {"deleted": True})
            if method == "POST" and route == ["experiments"]:
                return self.send(201, engine.start(self.body(), tenant, identity.dept))
            if method == "POST" and len(route) == 3 and route[0] == "experiments" and route[2] == "cancel":
                self.body()
                return self.send(200, engine.cancel(route[1], tenant))
            if method == "GET" and len(route) == 2 and route[0] == "runs":
                return self.send(200, engine.get_run(route[1], tenant))
            if method == "POST" and len(route) == 3 and route[0] == "runs":
                data = self.body()
                if route[2] == "judge":
                    return self.send(200, engine.run_judge(route[1], tenant))
                if route[2] == "reviews":
                    return self.send(201, engine.review(route[1], data, tenant))
            if method == "GET" and route in [["compare"], ["reports"]]:
                query = parse_qs(parsed.query)
                report = engine.comparison(query.get("baseline", [""])[0], query.get("candidate", [""])[0],
                                           query.get("experiment", [""])[0], tenant)
                if route == ["compare"]:
                    return self.send(200, report)
                if query.get("format", ["json"])[0] == "md":
                    return self.send(200, markdown_report(report), "text/markdown; charset=utf-8", "regression.md")
                return self.send(200, report, attachment="regression.json")
            self.fail(404, "NOT_FOUND", "API 路径不存在")

        def cost(self, tenant):
            """本地成本视图：只算 live 运行，缺失成本单独计数，不按 0 合并。"""
            runs = engine.store.list("run", tenant=tenant)
            live = [run for run in runs if run.get("mode") == "live"]
            total = {"known_cost_usd": 0.0, "known_tokens": 0, "unknown_cost_runs": 0,
                     "unknown_token_runs": 0}
            groups = defaultdict(lambda: {"runs": 0, "known_cost_usd": 0.0, "known_tokens": 0,
                                          "unknown_cost_runs": 0})
            for run in live:
                metrics = run.get("metrics") or {}
                total["known_cost_usd"] += metrics.get("known_cost_usd") or 0
                total["known_tokens"] += metrics.get("known_tokens") or 0
                total["unknown_cost_runs"] += 1 if metrics.get("cost_usd") is None else 0
                total["unknown_token_runs"] += 1 if metrics.get("total_tokens") is None else 0
                name = (run.get("strategy") or {}).get("name") or "unknown"
                group = groups[name]
                group["runs"] += 1
                group["known_cost_usd"] += metrics.get("known_cost_usd") or 0
                group["known_tokens"] += metrics.get("known_tokens") or 0
                group["unknown_cost_runs"] += 1 if metrics.get("cost_usd") is None else 0
            return {"tenant": tenant, "source": SERVICE, "runs": len(live),
                    "offline_runs": len(runs) - len(live),
                    "known_cost_usd": round(total["known_cost_usd"], 8),
                    "known_tokens": total["known_tokens"],
                    "unknown_cost_runs": total["unknown_cost_runs"],
                    "unknown_token_runs": total["unknown_token_runs"],
                    "by_strategy": [{"strategy": name, "runs": group["runs"],
                                     "known_cost_usd": round(group["known_cost_usd"], 8),
                                     "known_tokens": group["known_tokens"],
                                     "unknown_cost_runs": group["unknown_cost_runs"]}
                                    for name, group in sorted(groups.items())],
                    "note": "按策略配置的单价估算，不是账单；null 表示价格缺失或用量不完整"}

        def static(self, url):
            base = (ROOT / "frontend/dist").resolve()
            path = (base / unquote(url).lstrip("/")).resolve()
            if not path.is_relative_to(base):
                return self.fail(403, "BAD_PATH", "非法路径")
            if not path.is_file():
                path = base / "index.html"
            if not path.is_file():
                return self.send(503, "请先执行 npm run setup 构建前端", "text/plain; charset=utf-8")
            self.send(200, path.read_bytes(), mimetypes.guess_type(str(path))[0] or "application/octet-stream")

        do_GET = dispatch
        do_POST = dispatch
        do_DELETE = dispatch

    return Handler


def main():
    load_env()
    parser = argparse.ArgumentParser(description="本地 Codebase Eval 平台")
    parser.add_argument("--port", type=int, default=int(os.environ.get("EVAL_PORT", "8765")))
    parser.add_argument("--data-dir", default=os.environ.get("EVAL_DATA_DIR", str(Path.home() / ".codebase-eval")))
    parser.add_argument("--bind", default=os.environ.get("EVAL_BIND", "127.0.0.1"))
    args = parser.parse_args()
    keys = parse_api_keys(os.environ.get("PLATFORM_API_KEYS"))
    engine = Engine(args.data_dir)
    server = ThreadingHTTPServer((args.bind, args.port), handler_for(engine, keys))
    mode = "strict" if keys else "local"
    print(f"Codebase Eval: http://{args.bind}:{server.server_port} ({mode}, "
          f"tenants={len({k.tenant for k in keys.values()}) if keys else 1})", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
        engine.close()


if __name__ == "__main__":
    main()
