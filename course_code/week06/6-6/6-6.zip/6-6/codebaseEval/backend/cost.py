"""成本回传（评测侧）：只上报，不写库、不改运行结果。

三条约定，和 `design/architecture.md` §8 对齐：

1. 只上报 `live` 运行。离线脚本决策器的成本恒为 0，混进报表会把「本来免费」
   和「忘配价格」搅成同一个数，报表就失去意义。
2. 后台线程 + 2 秒超时。platform 不可达时这条运行在平台侧计 `unknown_cost_runs`，
   评测本身照常完成——成本链路永远不是评测的前置条件。
3. `cost_usd` 由评测侧按策略里配置的单价算出，platform 只聚合不重算，
   避免「一份用量两套价格」。价格为 null 时如实上报 null，不写 0。
"""
from __future__ import annotations

import json
import os
import sys
import threading
from urllib.request import Request, urlopen

TIMEOUT_SECONDS = 2


def base_url() -> str:
    return (os.environ.get("PLATFORM_BASE_URL") or "").rstrip("/")


def enabled() -> bool:
    """没配 platform 地址就静默关闭；`EVAL_USAGE_REPORT=0` 可显式关掉。"""
    return bool(base_url()) and os.environ.get("EVAL_USAGE_REPORT", "1").strip() != "0"


def payload(run: dict) -> dict:
    strategy = run.get("strategy") or {}
    metrics = run.get("metrics") or {}
    return {
        "run_id": run.get("id"),
        "experiment_id": run.get("experiment_id"),
        "tenant": run.get("tenant") or "public",
        "dept": run.get("dept") or os.environ.get("EVAL_DEPT", ""),
        "source": "eval",
        "model": strategy.get("model"),
        "strategy": strategy.get("name") or strategy.get("id"),
        "strategy_id": strategy.get("id"),
        "mode": run.get("mode"),
        "outcome": run.get("outcome") or "unknown",
        "trial": run.get("trial"),
        "task_id": run.get("task_id"),
        "input_tokens": metrics.get("input_tokens"),
        "output_tokens": metrics.get("output_tokens"),
        "cache_tokens": metrics.get("cache_tokens"),
        "total_tokens": metrics.get("total_tokens"),
        "cost_usd": metrics.get("cost_usd"),
        "seconds": metrics.get("seconds"),
    }


def post(value: dict) -> bool:
    """同步发一次，返回 platform 是否接受。测试直接调它，生产走 report_usage。"""
    base = base_url()
    if not base:
        return False
    key = os.environ.get("PLATFORM_INTERNAL_KEY") or os.environ.get("PLATFORM_API_KEY") or ""
    request = Request(
        f"{base}/v1/usage",
        data=json.dumps(value, ensure_ascii=False).encode(),
        headers={"Content-Type": "application/json", "Authorization": f"Bearer {key}"},
        method="POST",
    )
    with urlopen(request, timeout=TIMEOUT_SECONDS) as response:
        return 200 <= response.status < 300


def report_usage(run: dict) -> None:
    """把一次运行的用量丢进后台线程。任何异常都只写 stderr。"""
    if not enabled() or run.get("mode") != "live":
        return
    # 现在取快照：调用方随后可能继续改 run（例如补写 judge），
    # 但这条用量属于「跑完那一刻」，不该再漂移。
    value = payload(run)

    def send() -> None:
        try:
            post(value)
        except Exception as exc:  # 报表少一条，比运行被拖死好
            print(f"[cost] 成本回传失败 {value.get('run_id')}: "
                  f"{type(exc).__name__}: {exc}", file=sys.stderr, flush=True)

    threading.Thread(target=send, name="eval-cost-report", daemon=True).start()
