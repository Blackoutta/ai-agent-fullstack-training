"""身份与租户过滤的单一入口（评测后端）。

三件事只在文件里做，不要在 server.py 里散开：

1. `PLATFORM_API_KEYS` → 身份表。格式与 agent / retrieval 一致：`key:tenant:dept:role`。
2. 没配密钥 = 本机单租户模式（`tenant=public`），这样 5-5 的本地开发与原有测试不受影响；
   配了密钥就必须带 Bearer，缺了直接 401。
3. 越权读不是「返回空」，而是 `TenantViolation` → 403 + 审计：返回空会让调用方以为数据不存在，
   而 403 能让越权尝试在审计里留下痕迹。
"""
from __future__ import annotations

import re
from dataclasses import dataclass

PUBLIC = "public"
_SAFE = re.compile(r"^[A-Za-z0-9_.-]{1,64}$")


@dataclass(frozen=True)
class Identity:
    tenant: str
    dept: str
    role: str
    key_prefix: str


class TenantViolation(PermissionError):
    """跨租户访问 → 403。"""

    def __init__(self, message: str, owner: str = "") -> None:
        super().__init__(message)
        self.owner = owner


class Unauthenticated(PermissionError):
    """身份缺失或无效 → 401。和 403 分开，否则调用方分不清「该带凭据」和「没权限」。"""


def parse_api_keys(raw: str | None) -> dict[str, Identity]:
    out: dict[str, Identity] = {}
    for entry in (raw or "").split(","):
        trimmed = entry.strip()
        if not trimmed:
            continue
        parts = trimmed.split(":")
        if len(parts) < 4:
            continue
        role, dept, tenant = parts[-1].strip(), parts[-2].strip(), parts[-3].strip()
        key = ":".join(parts[:-3])
        if not key or not role or not (_SAFE.match(tenant) and _SAFE.match(dept)):
            continue
        out[key] = Identity(tenant=tenant, dept=dept, role=role, key_prefix=key[:6])
    return out


def authenticate(header: str | None, keys: dict[str, Identity]) -> Identity | None:
    if not header:
        return None
    match = re.match(r"^Bearer\s+(.+)$", header.strip(), re.IGNORECASE)
    token = match.group(1).strip() if match else header.strip()
    return keys.get(token)


def resolve_identity(header: str | None, keys: dict[str, Identity]) -> Identity:
    """配了密钥就必须带；没配就是本机单租户。"""
    if not keys:
        return Identity(tenant=PUBLIC, dept="local", role="admin", key_prefix="local")
    identity = authenticate(header, keys)
    if identity is None:
        # 不要在这条文案里写 "Bearer x"：scrub() 会把任何 Bearer 后面的内容当成密钥抹掉。
        raise Unauthenticated("缺少或无效的平台密钥（Authorization 请求头）")
    return identity


def audit(store, action: str, identity: Identity, detail: dict | None = None) -> dict:
    """审计写进 entities(kind=audit)，跟业务数据同一套事务与 scrubbing。"""
    return store.put(
        "audit",
        {"action": action, "tenant": identity.tenant, "dept": identity.dept,
         "role": identity.role, "key_prefix": identity.key_prefix, **(detail or {})},
        tenant=identity.tenant,
    )
