"""Codebase evaluation platform backend."""
