"""`services/platform/app/redaction.py` 的镜像实现。

为什么不直接跨服务 import：评测镜像里只保证有 `/app/codebase` 与 `/app/codebaseEval`，
把 platform 的应用代码也拉进来会让镜像边界变模糊。两份实现由
`tests/test_redaction_parity.py` 对同一批样例断言输出完全一致——
重复的是代码，不是规则的所有权。
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

ID_CARD = re.compile(r"\b(\d{3})\d{11}(\d{3}[\dXx])\b")
PHONE = re.compile(r"(?<!\d)(1[3-9]\d)\d{4}(\d{4})(?!\d)")
AMOUNT = re.compile(
    r"(?<![\d.])(?:[¥￥$]\s*)?\d{1,3}(?:,\d{3})+(?:\.\d+)?(?:\s*(?:元|万元|美元))?"
    r"|(?<![\d.])\d+(?:\.\d+)?\s*(?:万元|美元|元)"
)
ADDRESS = re.compile(
    r"[\u4e00-\u9fa5]{2,10}(?:省|自治区|市)[\u4e00-\u9fa5]{0,12}(?:路|街|道|巷|区|县|镇)"
    r"[\u4e00-\u9fa5A-Za-z0-9#\-]{0,20}\d*号?"
)
_ADDRESS_HEAD = re.compile(r"^.*(?:省|自治区|市)")


def mask_address(value: str) -> str:
    head = _ADDRESS_HEAD.match(value)
    return f"{head.group(0) if head else ''}***"


@dataclass
class Redactor:
    amounts: dict[str, str] = field(default_factory=dict)
    hits: dict[str, int] = field(default_factory=dict)

    def _record(self, category: str, count: int = 1) -> None:
        self.hits[category] = self.hits.get(category, 0) + count

    def _token_of(self, raw: str) -> str:
        key = re.sub(r"\s+", "", raw)
        if key in self.amounts:
            return self.amounts[key]
        token = f"AMOUNT_{len(self.amounts) + 1}"
        self.amounts[key] = token
        return token

    def scrub_text(self, text: str) -> str:
        def replace_id(match: re.Match[str]) -> str:
            self._record("id_card")
            return f"{match.group(1)}{'*' * 11}{match.group(2)}"

        out = ID_CARD.sub(replace_id, text)

        def replace_phone(match: re.Match[str]) -> str:
            self._record("phone")
            return f"{match.group(1)}****{match.group(2)}"

        out = PHONE.sub(replace_phone, out)

        def replace_amount(match: re.Match[str]) -> str:
            self._record("amount")
            return self._token_of(match.group(0))

        out = AMOUNT.sub(replace_amount, out)

        def replace_address(match: re.Match[str]) -> str:
            self._record("address")
            return mask_address(match.group(0))

        return ADDRESS.sub(replace_address, out)

    def scrub_value(self, value: object) -> object:
        if isinstance(value, str):
            return self.scrub_text(value)
        if isinstance(value, list):
            return [self.scrub_value(item) for item in value]
        if isinstance(value, dict):
            return {key: self.scrub_value(item) for key, item in value.items()}
        return value

    def summary(self) -> list[dict]:
        return [{"category": key, "count": self.hits[key]} for key in sorted(self.hits)]

    def amount_map(self) -> dict[str, str]:
        return dict(self.amounts)

    def borrow_map_from(self, other: "Redactor") -> None:
        """把上层作用域已有的 token 接过来，保证同一份数据里 AMOUNT_1 指同一笔金额。"""
        for key, token in other.amounts.items():
            self.amounts.setdefault(key, token)
