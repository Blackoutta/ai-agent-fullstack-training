"""租户分区、越权 403 与审计（WP-005 验收项）。

三条在产品上会被人质疑的规则，测试逐条钉住：

1. `public` 是平台基准：谁都能读，谁都不能删。
2. 越权读是 403 + 审计，不是空列表——空列表会让调用方以为「数据不存在」。
3. 配了 `PLATFORM_API_KEYS` 就必须带密钥；不带是 401，带错也是 401。
"""
import http.client
import json
import os
import sqlite3
import tempfile
import threading
import unittest
from http.server import ThreadingHTTPServer
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

from backend.engine import Engine
from backend.server import handler_for
from backend.store import Store
from backend.tenancy import PUBLIC, TenantViolation, parse_api_keys
from test_platform import fake_worker

KEYS = "key-a:tenant_a:platform:admin,key-b:tenant_b:engineering:reviewer"


def run_value(tenant, cost=0.5, strategy="基线 · 直接审查"):
    return {"tenant": tenant, "mode": "live", "execution_status": "completed",
            "outcome": "pass", "answer": "policy.ts:12", "trace": [], "audit": [], "checks": [],
            "judge": {}, "strategy": {"id": "s1", "name": strategy, "model": "test-model"},
            "metrics": {"seconds": 1, "total_tokens": 12, "cost_usd": cost,
                        "known_cost_usd": cost or 0, "known_tokens": 12,
                        "tool_calls": 1, "tool_errors": 0}}


class StoreTenantTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.store = Store(Path(self.temp.name) / "data")

    def tearDown(self):
        self.store.close()
        self.temp.cleanup()

    def test_cross_tenant_read_raises_instead_of_empty(self):
        value = self.store.put("run", run_value("tenant_a"), tenant="tenant_a")
        with self.assertRaises(TenantViolation):
            self.store.get("run", value["id"], tenant="tenant_b")
        self.assertEqual(self.store.get("run", value["id"], tenant="tenant_a")["id"], value["id"])
        self.assertEqual(self.store.list("run", tenant="tenant_b"), [])

    def test_public_baseline_readable_everywhere_but_not_deletable(self):
        value = self.store.put("task", {"name": "种子任务"}, tenant=PUBLIC)
        self.assertEqual(self.store.get("task", value["id"], tenant="tenant_b")["name"], "种子任务")
        with self.assertRaises(TenantViolation):
            self.store.delete("task", value["id"], tenant="tenant_b")

    def test_legacy_database_is_migrated_to_public(self):
        legacy = Path(self.temp.name) / "legacy"
        legacy.mkdir()
        db = sqlite3.connect(legacy / "platform.sqlite")
        db.executescript("""
            CREATE TABLE entities (kind TEXT NOT NULL, id TEXT NOT NULL, data TEXT NOT NULL,
                                   PRIMARY KEY(kind,id));
            CREATE TABLE reviews (id TEXT PRIMARY KEY, run_id TEXT NOT NULL, data TEXT NOT NULL);
            INSERT INTO entities VALUES ('task','old','{"id":"old","name":"旧任务"}');
        """)
        db.commit()
        db.close()
        migrated = Store(legacy)
        try:
            self.assertEqual(migrated.get("task", "old", tenant="tenant_b")["name"], "旧任务")
            self.assertEqual(migrated.db.execute(
                "SELECT tenant FROM entities WHERE id='old'").fetchone()[0], PUBLIC)
        finally:
            migrated.close()


class ExperimentDeptTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        root = Path(self.temp.name)
        source = root / "source"
        (source / "src").mkdir(parents=True)
        (source / "src/policy.ts").write_text("policy rules", encoding="utf-8")
        self.engine = Engine(root / "data", source=source, worker=fake_worker)

    def tearDown(self):
        self.engine.close()
        self.temp.cleanup()

    def test_experiment_and_runs_carry_tenant_and_dept(self):
        experiment = self.engine.start({
            "name": "隔离实验", "mode": "offline",
            "task_ids": [self.engine.store.list("task")[0]["id"]],
            "strategy_ids": [s["id"] for s in self.engine.store.list("strategy")],
            "trials": 1, "timeout": 10, "max_tokens": 256}, tenant="tenant_a", dept="platform")
        self.engine.pool.shutdown(wait=True)
        stored = self.engine.store.get("experiment", experiment["id"], tenant="tenant_a")
        self.assertEqual((stored["tenant"], stored["dept"]), ("tenant_a", "platform"))
        runs = self.engine.store.list("run", tenant="tenant_a")
        self.assertTrue(runs)
        self.assertTrue(all((r["tenant"], r["dept"]) == ("tenant_a", "platform") for r in runs))
        # 另一个租户既看不到实验，也看不到运行
        self.assertEqual(self.engine.store.list("experiment", tenant="tenant_b"), [])
        self.assertEqual([r for r in self.engine.store.list("run", tenant="tenant_b")
                          if r.get("tenant") == "tenant_a"], [])


class HttpTenantTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.engine = Engine(self.temp.name, worker=fake_worker)
        self.keys = parse_api_keys(KEYS)
        self.server = ThreadingHTTPServer(("127.0.0.1", 0), handler_for(self.engine, self.keys))
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.port = self.server.server_port
        self.url = f"http://127.0.0.1:{self.port}/api"
        previous = os.environ.get("EVAL_ALLOWED_HOSTS")
        os.environ["EVAL_ALLOWED_HOSTS"] = "eval,localhost,127.0.0.1"
        self.addCleanup(self.restore_hosts, previous)

    def restore_hosts(self, previous):
        if previous is None:
            os.environ.pop("EVAL_ALLOWED_HOSTS", None)
        else:
            os.environ["EVAL_ALLOWED_HOSTS"] = previous

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.engine.close()
        self.temp.cleanup()

    def call(self, path, key=None, method="GET", body=None):
        headers, data = {}, None
        if key:
            headers["Authorization"] = f"Bearer {key}"
        if body is not None:
            data = json.dumps(body).encode()
            headers["Content-Type"] = "application/json"
        request = Request(self.url + path, data=data, headers=headers, method=method)
        try:
            with urlopen(request) as response:
                return response.status, json.load(response)
        except HTTPError as exc:
            return exc.code, json.load(exc)

    def raw_get(self, path, host, key=None):
        """注入任意 Host：urllib 会自己补 Host，拿 http.client 并关掉自动 host 才能测白名单。"""
        connection = http.client.HTTPConnection("127.0.0.1", self.port, timeout=10)
        connection.putrequest("GET", path, skip_host=True)
        connection.putheader("Host", host)
        if key:
            connection.putheader("Authorization", f"Bearer {key}")
        connection.endheaders()
        response = connection.getresponse()
        status, body = response.status, response.read()
        connection.close()
        return status, json.loads(body)

    def audits(self):
        return [row for row in self.engine.store.list("audit") if "action" in row]

    def test_health_needs_no_key(self):
        status, body = self.call("/health")
        self.assertEqual(status, 200)
        self.assertEqual(body["status"], "ok")
        self.assertTrue(body["auth_required"])

    def test_missing_key_is_401_and_audited(self):
        status, body = self.call("/state")
        self.assertEqual((status, body["code"]), (401, "UNAUTHENTICATED"))
        self.assertIn("auth_denied", [row["action"] for row in self.audits()])

    def test_wrong_key_is_401(self):
        status, body = self.call("/state", key="not-a-key")
        self.assertEqual((status, body["code"]), (401, "UNAUTHENTICATED"))

    def test_cross_tenant_read_is_403_and_audited(self):
        value = self.engine.store.put("run", run_value("tenant_a"), tenant="tenant_a")
        status, body = self.call(f"/runs/{value['id']}", key="key-b")
        self.assertEqual((status, body["code"]), (403, "FORBIDDEN_TENANT"))
        violations = [row for row in self.audits() if row["action"] == "tenant_violation"]
        self.assertEqual(violations[0]["tenant"], "tenant_b")

    def test_state_is_partitioned_by_key(self):
        status, created = self.call("/tasks", key="key-a", method="POST",
                                    body={"name": "A 的任务", "prompt": "说明权限",
                                          "tags": [], "required": False,
                                          "checks": [{"id": "t", "type": "contains", "value": "policy.ts"}],
                                          "rubric": "证据"})
        self.assertEqual(status, 201)
        _, mine = self.call("/state", key="key-a")
        _, theirs = self.call("/state", key="key-b")
        self.assertIn("A 的任务", [task["name"] for task in mine["tasks"]])
        self.assertNotIn("A 的任务", [task["name"] for task in theirs["tasks"]])
        self.assertEqual(mine["health"]["tenant"], "tenant_a")

    def test_host_not_in_whitelist_is_rejected(self):
        status, body = self.raw_get("/api/state", "evil.example", "key-a")
        self.assertEqual((status, body["code"]), (403, "HOST_REJECTED"))
        status, _ = self.raw_get("/api/state", f"eval:{self.port}", "key-a")
        self.assertEqual(status, 200)
        status, _ = self.raw_get("/api/state", "127.0.0.1:%d" % self.port, "key-a")
        self.assertEqual(status, 200)

    def test_cost_view_counts_unknown_separately(self):
        self.engine.store.put("run", run_value("tenant_a", cost=0.25), tenant="tenant_a")
        self.engine.store.put("run", run_value("tenant_a", cost=None), tenant="tenant_a")
        self.engine.store.put("run", {**run_value("tenant_b"), "mode": "live"}, tenant="tenant_b")
        status, body = self.call("/cost", key="key-a")
        self.assertEqual(status, 200)
        self.assertEqual(body["runs"], 2)
        self.assertAlmostEqual(body["known_cost_usd"], 0.25)
        self.assertEqual(body["unknown_cost_runs"], 1)
        self.assertEqual(body["by_strategy"][0]["strategy"], "基线 · 直接审查")


if __name__ == "__main__":
    unittest.main()
