"""双语言脱敏一致性：同一批样例，三份实现输出必须逐字节相同。

三份实现的分工：

- `services/agent/src/core/redact.ts`：TypeScript 真源，运行链路上的每一次调用都走它；
- `services/platform/app/redaction.py`：平台汇入成本/审计时的 Python 侧真源；
- `codebaseEval/backend/redaction.py`：评测镜像里的镜像实现。

规则只能有一份「意思」，所以这里不比较代码结构，只比较输出：
同一输入 → 同一脱敏文本、同一 `AMOUNT_n` 映射、同一命中计数。
不一致就说明某一侧漂移了，必须当场修，而不是等报表里出现半脱敏的数据。
"""
import importlib.util
import json
import shutil
import subprocess
import sys
import tempfile
import textwrap
import unittest
from pathlib import Path

from backend.redaction import Redactor as EvalRedactor

ROOT = Path(__file__).resolve().parents[2]
TS_SOURCE = ROOT / "services/agent/src/core/redact.ts"
PLATFORM_SOURCE = ROOT / "services/platform/app/redaction.py"

SAMPLES = [
    "身份证 110101199003071234",
    "身份证 11010119900307123X 与 110101199003071234 两条",
    "手机号 13812345678，备用 19900001111",
    "收货地址 浙江省杭州市西湖区文三路100号 3 幢",
    "北京市朝阳区建国路88号",
    "合同金额 1,250,000.00 元，预付款 250,000 元",
    "报价 ¥88,000 与 12 万元",
    "毛利率 8%，同比 +3.5%，数量 1200 件",
    "同一笔金额 1,250,000.00 元 出现两次：1,250,000.00 元",
    "普通说明，没有任何敏感信息",
    "混合：张三 13812345678 住上海市浦东新区世纪大道1号，签了 3,000,000.00 元的合同",
]
STRUCTURED = {"percent": 8.5, "count": 1200, "ok": True, "note": "手机 13812345678",
              "items": ["地址 浙江省杭州市西湖区文三路100号", 3.5]}

NODE_SCRIPT = textwrap.dedent("""
    import { Redactor } from %(module)s;

    const chunks = [];
    for await (const chunk of process.stdin) chunks.push(chunk);
    const payload = JSON.parse(Buffer.concat(chunks).toString("utf8"));
    const out = payload.samples.map((text) => {
      const redactor = new Redactor();
      return { text: redactor.scrubText(text), map: redactor.amountMap(),
               summary: redactor.summary() };
    });
    const structured = new Redactor().scrubValue(payload.structured);
    console.log(JSON.stringify({ out, structured }));
""")


def load_platform_redactor():
    spec = importlib.util.spec_from_file_location("platform_redaction", PLATFORM_SOURCE)
    module = importlib.util.module_from_spec(spec)
    # 必须先注册再 exec：dataclass 在 3.9 下要回查 sys.modules[cls.__module__] 解析字符串注解。
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module.Redactor


def python_view(redactor_class):
    out, mapped, summary = [], [], []
    for text in SAMPLES:
        redactor = redactor_class()
        out.append(redactor.scrub_text(text))
        mapped.append(redactor.amount_map())
        summary.append([{"category": item["category"], "count": item["count"]}
                        for item in redactor.summary()])
    structured = redactor_class().scrub_value(STRUCTURED)
    return {"out": out, "map": mapped, "summary": summary, "structured": structured}


@unittest.skipUnless(TS_SOURCE.is_file() and PLATFORM_SOURCE.is_file(), "缺少脱敏实现源文件")
class RedactionParityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.node = shutil.which("node")
        cls.ts = None
        if cls.node is None:
            return
        with tempfile.TemporaryDirectory() as directory:
            script = Path(directory) / "parity.mjs"
            module = json.dumps(TS_SOURCE.as_posix())
            script.write_text(NODE_SCRIPT % {"module": module}, encoding="utf-8")
            payload = json.dumps({"samples": SAMPLES, "structured": STRUCTURED})
            try:
                result = subprocess.run([cls.node, str(script)], input=payload.encode(),
                                        capture_output=True, timeout=60)
            except (OSError, subprocess.TimeoutExpired) as exc:  # 环境问题，不算规则漂移
                cls.skip_reason = f"node 无法运行 TypeScript：{exc}"
                return
            if result.returncode != 0:
                cls.skip_reason = (result.stderr.decode("utf-8", "replace").strip().splitlines()
                                   or ["node 退出码非 0"])[-1]
                return
            cls.ts = json.loads(result.stdout.decode("utf-8"))

    def setUp(self):
        if self.ts is None:
            self.skipTest(getattr(self, "skip_reason", "未获取 TypeScript 侧输出"))

    def test_platform_and_eval_mirror_agree(self):
        self.assertEqual(python_view(load_platform_redactor()), python_view(EvalRedactor))

    def test_typescript_and_python_agree_on_text(self):
        python = python_view(load_platform_redactor())
        self.assertEqual([item["text"] for item in self.ts["out"]], python["out"])

    def test_typescript_and_python_agree_on_amount_tokens(self):
        python = python_view(load_platform_redactor())
        # 同一笔金额在不同文本里编号一致，且同一文本内复用同一 token。
        self.assertEqual([item["map"] for item in self.ts["out"]], python["map"])

    def test_typescript_and_python_agree_on_hits(self):
        python = python_view(load_platform_redactor())
        self.assertEqual([item["summary"] for item in self.ts["out"]], python["summary"])

    def test_structured_numbers_survive(self):
        """百分比与结构化数字必须保留，否则评测与报表失去意义。"""
        python = python_view(load_platform_redactor())
        self.assertEqual(self.ts["structured"], python["structured"])
        self.assertEqual(python["structured"]["percent"], 8.5)
        self.assertEqual(python["structured"]["count"], 1200)
        self.assertIs(python["structured"]["ok"], True)
        self.assertEqual(python["structured"]["items"][1], 3.5)
        self.assertEqual(python["structured"]["note"], "手机 138****5678")


if __name__ == "__main__":
    unittest.main(sys.argv[1:])
