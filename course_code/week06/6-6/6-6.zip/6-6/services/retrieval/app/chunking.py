"""语料解析与分块。只用标准库；PDF 需要 pypdf，装不上就跳过并如实记录。

每个分块都带 `file_path / doc_type / heading / chunk_index`，
引用追溯靠这四个字段就能定位到「哪个文件的哪一节」。
"""
from __future__ import annotations

import csv
import hashlib
import io
import re
from html.parser import HTMLParser
from pathlib import Path

from .grants import Grants

EXT_TO_TYPE = {
    ".md": "doc",
    ".py": "code",
    ".html": "web",
    ".csv": "table",
    ".pdf": "pdf",
}

CHUNK_CHARS = 700
_HEADING = re.compile(r"^(#{1,6})\s+(.*)$")


# ---------------------------------------------------------------- 解析

def parse_front_matter(text: str) -> tuple[dict[str, str], str]:
    """Markdown 顶部的 `--- key: value ---` 头信息，正文里不留这段（与 week04/4-4 同法）。"""
    if not text.startswith("---"):
        return {}, text
    lines = text.split("\n")
    end = None
    for index in range(1, len(lines)):
        if lines[index].strip() == "---":
            end = index
            break
    if end is None:
        return {}, text
    meta: dict[str, str] = {}
    for line in lines[1:end]:
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        meta[key.strip()] = value.strip()
    return meta, "\n".join(lines[end + 1 :]).lstrip("\n")


class _HtmlText(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.lines: list[str] = []
        self._tag_stack: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        self._tag_stack.append(tag)

    def handle_endtag(self, tag: str) -> None:
        if self._tag_stack and self._tag_stack[-1] == tag:
            self._tag_stack.pop()

    def handle_data(self, data: str) -> None:
        text = data.strip()
        if not text:
            return
        tag = self._tag_stack[-1] if self._tag_stack else ""
        if tag in {"h1", "h2", "h3"}:
            self.lines.append(f"\n{'#' * int(tag[1])} {text}\n")
        else:
            self.lines.append(text)


def html_to_text(raw: str) -> str:
    parser = _HtmlText()
    parser.feed(raw)
    return "\n".join(parser.lines)


def csv_to_text(raw: str) -> str:
    """每行变成「列名=值；…」，让一行就是一句可检索的话。"""
    rows = list(csv.DictReader(io.StringIO(raw)))
    lines: list[str] = []
    for row in rows:
        pairs = [f"{key}={value}" for key, value in row.items() if key and value]
        if pairs:
            lines.append("；".join(pairs))
    return "\n".join(lines)


def pdf_to_text(path: Path) -> tuple[str, str]:
    """返回 (文本, 跳过原因)。pypdf 不可用时宁可缺席，也不假装解析成功。"""
    try:
        from pypdf import PdfReader  # type: ignore
    except Exception as error:  # noqa: BLE001 - 任何导入失败都按不可用处理
        return "", f"pypdf 不可用：{error}"
    try:
        reader = PdfReader(str(path))  # type: ignore[attr-defined]
        pages = [page.extract_text() or "" for page in reader.pages]
    except Exception as error:  # noqa: BLE001
        return "", f"PDF 解析失败：{error}"
    return "\n\n".join(pages), ""


def read_sections(path: Path) -> tuple[list[tuple[str, str]], str]:
    """把文件读成 [(标题, 正文)]，标题用于引用追溯。第二个返回值非空表示跳过原因。"""
    suffix = path.suffix
    if suffix in {".md", ".py"}:
        raw, skip = path.read_text(encoding="utf-8"), ""
    elif suffix == ".html":
        raw, skip = html_to_text(path.read_text(encoding="utf-8")), ""
    elif suffix == ".csv":
        raw, skip = csv_to_text(path.read_text(encoding="utf-8")), ""
    elif suffix == ".pdf":
        raw, skip = pdf_to_text(path)
    else:
        return [], f"不支持的类型 {suffix}"

    if skip:
        return [], skip
    if suffix == ".md":
        _meta, body = parse_front_matter(raw)
        raw = body
    if not raw.strip():
        return [], "正文为空"

    sections: list[tuple[str, str]] = []
    heading = ""
    buffer: list[str] = []
    for line in raw.split("\n"):
        match = _HEADING.match(line)
        if match:
            if buffer:
                sections.append((heading, "\n".join(buffer)))
                buffer = []
            heading = match.group(2).strip()
            continue
        buffer.append(line)
    if buffer:
        sections.append((heading, "\n".join(buffer)))
    return [(h, body) for h, body in sections if body.strip()], ""


# ---------------------------------------------------------------- 分块

def split_text(text: str, limit: int = CHUNK_CHARS) -> list[str]:
    """按空行分段再装箱；超长段落硬切，保证单块不超过 limit。"""
    blocks = [block.strip() for block in re.split(r"\n\s*\n", text) if block.strip()]
    chunks: list[str] = []
    buffer = ""
    for block in blocks:
        if len(block) > limit:
            if buffer:
                chunks.append(buffer)
                buffer = ""
            for start in range(0, len(block), limit):
                chunks.append(block[start : start + limit])
            continue
        if buffer and len(buffer) + 2 + len(block) > limit:
            chunks.append(buffer)
            buffer = block
        else:
            buffer = f"{buffer}\n\n{block}" if buffer else block
    if buffer:
        chunks.append(buffer)
    return chunks


def build_chunks(corpus_dir: Path, grants: Grants) -> tuple[list[dict], list[dict], str]:
    """返回 (chunks, unindexed, corpus_hash)。

    一个文件可能命中多个 (tenant, dept) 授权，这里在入库时展开成多行；
    查询侧因此只需要等值过滤，不需要任何通配或 OR 表达式。
    """
    chunks: list[dict] = []
    unindexed: list[dict] = []
    digest = hashlib.sha256()

    paths = sorted(
        path
        for path in corpus_dir.rglob("*")
        if path.is_file() and not path.name.startswith(".")
    )
    for path in paths:
        rel = path.relative_to(corpus_dir).as_posix()
        payload = path.read_bytes()
        digest.update(rel.encode("utf-8"))
        digest.update(hashlib.sha256(payload).hexdigest().encode("ascii"))

        doc_type = EXT_TO_TYPE.get(path.suffix)
        if doc_type is None:
            unindexed.append({"file_path": rel, "reason": f"不支持的类型 {path.suffix}"})
            continue

        scopes = grants.scopes_for(rel)
        if not scopes:
            unindexed.append({"file_path": rel, "reason": "no_grant"})
            continue

        sections, skip = read_sections(path)
        if skip:
            unindexed.append({"file_path": rel, "reason": skip})
            continue

        for tenant, dept in scopes:
            index = 0
            for heading, body in sections:
                for piece in split_text(body):
                    chunks.append(
                        {
                            "id": f"{tenant}:{dept}:{rel}#{index}",
                            "tenant": tenant,
                            "dept": dept,
                            "file_path": rel,
                            "doc_type": doc_type,
                            "heading": heading,
                            "chunk_index": index,
                            "text": piece,
                        }
                    )
                    index += 1

    return chunks, unindexed, f"sha256:{digest.hexdigest()}"
