"""身份解析，与 services/agent/src/core/identity.ts 同一套规则。

格式：`key:tenant:dept:role,key2:tenant2:dept:role`。key 本身可以含冒号，
所以右侧三个字段是固定位，左边整段才是 key。

另外做一件 TS 侧不必做的事：租户/部门会被拼进 Milvus 的过滤表达式，
所以这里只接受 `[A-Za-z0-9_.-]`，格式不对的条目直接丢弃——不留半条身份，
也不给过滤表达式留注入缝。
"""
from __future__ import annotations

import re
from dataclasses import dataclass

_SAFE_FIELD = re.compile(r"^[A-Za-z0-9_.-]{1,64}$")


@dataclass(frozen=True)
class Identity:
    tenant: str
    dept: str
    role: str
    key_prefix: str


def parse_api_keys(raw: str) -> dict[str, Identity]:
    out: dict[str, Identity] = {}
    for entry in (raw or "").split(","):
        trimmed = entry.strip()
        if not trimmed:
            continue
        parts = trimmed.split(":")
        if len(parts) < 4:
            continue
        role = parts[-1].strip()
        dept = parts[-2].strip()
        tenant = parts[-3].strip()
        key = ":".join(parts[:-3])
        if not key or not role:
            continue
        if not (_SAFE_FIELD.match(tenant) and _SAFE_FIELD.match(dept)):
            continue
        out[key] = Identity(tenant=tenant, dept=dept, role=role, key_prefix=key[:6])
    return out


def authenticate(header: str | None, keys: dict[str, Identity]) -> Identity | None:
    if not header:
        return None
    match = re.match(r"^Bearer\s+(.+)$", header.strip(), re.IGNORECASE)
    token = match.group(1).strip() if match else header.strip()
    return keys.get(token)


def internal_identity(headers: object) -> Identity | None:
    """内部调用方（agent 的 rag-shim）用 X-Tenant / X-Dept 说明身份。

    这条通道只在 compose 内部网络使用：agent 每次运行从自己的身份里取租户写进头里，
    模型无法指定。字段同样要过白名单校验，非法字符一律不认。
    """
    tenant = (headers.get("X-Tenant") or "").strip()  # type: ignore[attr-defined]
    dept = (headers.get("X-Dept") or "").strip()  # type: ignore[attr-defined]
    if not (_SAFE_FIELD.match(tenant) and _SAFE_FIELD.match(dept)):
        return None
    return Identity(tenant=tenant, dept=dept, role="internal", key_prefix="internal")
