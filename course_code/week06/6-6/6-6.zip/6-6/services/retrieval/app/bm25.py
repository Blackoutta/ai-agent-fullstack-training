"""纯标准库 BM25。

为什么不用 rank_bm25 / jieba：检索服务要在「没有任何第三方依赖」的机器上可测，
而本仓库的语料以中文短文档为主。中文按字 bigram 切分（「会话有效期」→
会话/话有/有效/效期），不做词性分析也够用；英文、代码符号、路径按原样保留。

分词函数是纯函数，测试直接断言它，不依赖索引状态。
"""
from __future__ import annotations

import math
import re
from typing import Iterable, Sequence

_ASCII_TOKEN = re.compile(r"[a-z0-9_][a-z0-9_.\-/]{0,63}")
_CJK_RUN = re.compile(r"[\u4e00-\u9fff]+")
_CJK_STOP_BIGRAM = {"的了", "一个", "什么", "多少", "怎么", "如何", "是否", "可以", "这个", "那个"}


def tokenize(text: str) -> list[str]:
    lowered = (text or "").lower()
    tokens: list[str] = []

    for match in _ASCII_TOKEN.finditer(lowered):
        tokens.append(match.group(0))

    for run in _CJK_RUN.findall(lowered):
        if len(run) == 1:
            tokens.append(run)
            continue
        for i in range(len(run) - 1):
            bigram = run[i : i + 2]
            if bigram not in _CJK_STOP_BIGRAM:
                tokens.append(bigram)

    return tokens


class BM25:
    """Okapi BM25。语料量很小（几十个分块），所以在「已过滤的子集」上现建索引：

    过滤发生在算分之前，IDF 也只由本租户能看见的文档统计出来，
    不会通过词频分布把别的租户的内容侧面暴露出去。
    """

    def __init__(self, documents: Sequence[str], k1: float = 1.5, b: float = 0.75) -> None:
        self.k1 = k1
        self.b = b
        self.tokens: list[list[str]] = [tokenize(doc) for doc in documents]
        self.lengths = [len(tokens) for tokens in self.tokens]
        self.avg_length = (sum(self.lengths) / len(self.lengths)) if self.lengths else 0.0
        self.doc_freq: dict[str, int] = {}
        for tokens in self.tokens:
            for token in set(tokens):
                self.doc_freq[token] = self.doc_freq.get(token, 0) + 1

    def _idf(self, token: str) -> float:
        total = len(self.tokens)
        freq = self.doc_freq.get(token, 0)
        return math.log(1 + (total - freq + 0.5) / (freq + 0.5))

    def scores(self, query: str) -> list[float]:
        query_tokens = tokenize(query)
        if not query_tokens or not self.tokens:
            return [0.0] * len(self.tokens)
        per_doc: list[float] = []
        for index, tokens in enumerate(self.tokens):
            counts: dict[str, int] = {}
            for token in tokens:
                counts[token] = counts.get(token, 0) + 1
            length = self.lengths[index] or 1
            score = 0.0
            for token in set(query_tokens):
                freq = counts.get(token, 0)
                if freq == 0:
                    continue
                denom = freq + self.k1 * (1 - self.b + self.b * length / (self.avg_length or 1))
                score += self._idf(token) * freq * (self.k1 + 1) / denom
            per_doc.append(score)
        return per_doc

    def rank(self, query: str, top_k: int) -> list[tuple[int, float]]:
        scores = self.scores(query)
        order = sorted(range(len(scores)), key=lambda i: (-scores[i], i))
        return [(i, scores[i]) for i in order[:top_k] if scores[i] > 0]


def fuse_rrf(result_lists: Iterable[Sequence[tuple[str, float]]], top_k: int, k: int = 60) -> list[tuple[str, float]]:
    """倒数排名融合：向量分与 BM25 分不同量纲，只按名次合并（与 week04/4-4 同法）。"""
    fused: dict[str, float] = {}
    for results in result_lists:
        for rank, (chunk_id, _score) in enumerate(results, 1):
            fused[chunk_id] = fused.get(chunk_id, 0.0) + 1.0 / (k + rank)
    order = sorted(fused.items(), key=lambda kv: (-kv[1], kv[0]))
    return order[:top_k]
