"""分块索引：进程启动时读一次 chunks.json（ingest 的产物），之后只在内存里查。

BM25 在「已按 (tenant, dept, doc_type) 过滤后的子集」上现建，语料小，成本可忽略；
换来的是统计量也按租户隔离，不会通过词频侧面泄漏别人的内容。
"""
from __future__ import annotations

import json
from pathlib import Path

from .bm25 import BM25


class IndexUnavailable(RuntimeError):
    """索引文件不存在或损坏。服务照常启动，但查询返回 503，不返回空结果冒充「没查到」。"""


class ChunkIndex:
    def __init__(self, payload: dict) -> None:
        self.payload = payload
        self.chunks: list[dict] = list(payload.get("chunks") or [])
        self.by_id: dict[str, dict] = {chunk["id"]: chunk for chunk in self.chunks}
        self.corpus_hash: str = payload.get("corpus_hash", "")
        self.built_at: str = payload.get("built_at", "")
        self.collection: str = payload.get("collection", "")
        self.tenants: tuple[str, ...] = tuple(payload.get("tenants") or [])
        self.depts: tuple[str, ...] = tuple(payload.get("depts") or [])

    # ------------------------------------------------------------ 装载

    @classmethod
    def load(cls, path: Path) -> "ChunkIndex":
        if not path.is_file():
            raise IndexUnavailable(f"索引文件不存在：{path}（先执行 make seed 或 python -m app.ingest）")
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as error:
            raise IndexUnavailable(f"索引文件不是合法 JSON：{path}（{error}）") from error
        if not isinstance(payload.get("chunks"), list):
            raise IndexUnavailable(f"索引文件缺少 chunks 字段：{path}")
        return cls(payload)

    def health(self) -> dict:
        return {
            "chunks": len(self.chunks),
            "collection": self.collection,
            "corpus_hash": self.corpus_hash,
            "built_at": self.built_at,
            "tenants": list(self.tenants),
            "depts": list(self.depts),
        }

    # ------------------------------------------------------------ 查询

    def visible_chunks(self, tenant: str, dept: str, doc_type: str | None = None) -> list[dict]:
        return [
            chunk
            for chunk in self.chunks
            if chunk.get("tenant") == tenant
            and chunk.get("dept") == dept
            and (doc_type is None or chunk.get("doc_type") == doc_type)
        ]

    def bm25_search(
        self,
        question: str,
        tenant: str,
        dept: str,
        top_k: int,
        doc_type: str | None = None,
    ) -> list[dict]:
        subset = self.visible_chunks(tenant, dept, doc_type)
        if not subset:
            return []
        engine = BM25([chunk.get("text", "") for chunk in subset])
        results: list[dict] = []
        for index, score in engine.rank(question, top_k):
            chunk = subset[index]
            results.append(
                {
                    "id": chunk["id"],
                    "file_path": chunk.get("file_path", ""),
                    "doc_type": chunk.get("doc_type", ""),
                    "heading": chunk.get("heading", ""),
                    "chunk_index": chunk.get("chunk_index", 0),
                    "text": chunk.get("text", ""),
                    "score": round(float(score), 6),
                }
            )
        return results
