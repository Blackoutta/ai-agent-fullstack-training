"""向量检索（Milvus Lite + MiniMax embo-01）。惰性导入：缺依赖或缺密钥就抛 VectorUnavailable。

为什么直接写 pymilvus 而不是套 LlamaIndex 的 VectorStoreIndex：
租户/部门必须落成 Milvus 的标量字段并参与服务端过滤，而 LlamaIndex 把 metadata
存成 JSON 字段，过滤表达式要按 JSON 路径写、且不同版本支持不一。这里用显式 schema
（tenant / dept / doc_type 都是 VARCHAR），过滤条件就是两个等值比较，没有通配符。
分块与嵌入请求的形状沿用 week04/4-4（`texts` + `type=db|query`，返回 `vectors`）。
"""
from __future__ import annotations

import json
import re
import urllib.error
import urllib.request

from . import config

_SAFE = re.compile(r"^[A-Za-z0-9_.-]{1,64}$")
MAX_TEXT_CHARS = 4000


class VectorUnavailable(RuntimeError):
    """向量路径不可用：依赖缺失、密钥缺失或嵌入服务不可达。调用方应降级 BM25 并如实标注。"""


def availability() -> tuple[bool, str]:
    if not config.EMBED_API_KEY:
        return False, "MINIMAX_CN_API_KEY 未配置"
    try:
        import pymilvus  # noqa: F401
    except Exception as error:  # noqa: BLE001
        return False, f"pymilvus 不可用：{error}"
    return True, ""


def _client():
    ok, reason = availability()
    if not ok:
        raise VectorUnavailable(reason)
    from pymilvus import MilvusClient

    return MilvusClient(uri=config.MILVUS_URI)


def _post(url: str, payload: dict, timeout: float = 60.0) -> dict:
    request = urllib.request.Request(
        url,
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {config.EMBED_API_KEY}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return json.loads(response.read().decode("utf-8"))
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as error:
        raise VectorUnavailable(f"嵌入服务调用失败：{error}") from error


def embed(texts: list[str], kind: str, batch_size: int = 8) -> list[list[float]]:
    """kind=db 用于入库，kind=query 用于查询（MiniMax 的两种用途分开计费与优化）。"""
    if not config.EMBED_API_KEY:
        raise VectorUnavailable("MINIMAX_CN_API_KEY 未配置")
    vectors: list[list[float]] = []
    for start in range(0, len(texts), batch_size):
        batch = [text[:MAX_TEXT_CHARS] for text in texts[start : start + batch_size]]
        body = _post(
            f"{config.EMBED_API_BASE}/embeddings",
            {"model": config.EMBED_MODEL, "texts": batch, "type": kind},
        )
        status = (body.get("base_resp") or {}).get("status_code", 0)
        if status != 0:
            raise VectorUnavailable(f"嵌入服务返回错误：{body.get('base_resp')}")
        vectors.extend(body.get("vectors") or [])
    if len(vectors) != len(texts):
        raise VectorUnavailable(f"嵌入条数不匹配：期望 {len(texts)}，实际 {len(vectors)}")
    return vectors


def _filter(tenant: str, dept: str, doc_type: str | None) -> str:
    if not (_SAFE.match(tenant) and _SAFE.match(dept)):
        raise ValueError("tenant/dept 含非法字符")
    expr = f'tenant == "{tenant}" and dept == "{dept}"'
    if doc_type:
        if not _SAFE.match(doc_type):
            raise ValueError("doc_type 含非法字符")
        expr += f' and doc_type == "{doc_type}"'
    return expr


def rebuild(chunks: list[dict]) -> int:
    """重建集合并写入向量。ingest 是一次性作业，重建比增量去重更不容易留下脏行。"""
    client = _client()
    from pymilvus import DataType

    if client.has_collection(config.COLLECTION):
        client.drop_collection(config.COLLECTION)

    schema = client.create_schema(auto_id=False, enable_dynamic_field=False)
    schema.add_field("id", DataType.VARCHAR, is_primary=True, max_length=512)
    schema.add_field("vector", DataType.FLOAT_VECTOR, dim=config.EMBED_DIM)
    schema.add_field("tenant", DataType.VARCHAR, max_length=64)
    schema.add_field("dept", DataType.VARCHAR, max_length=64)
    schema.add_field("file_path", DataType.VARCHAR, max_length=512)
    schema.add_field("doc_type", DataType.VARCHAR, max_length=32)
    schema.add_field("heading", DataType.VARCHAR, max_length=256)
    schema.add_field("text", DataType.VARCHAR, max_length=8192)

    index_params = client.prepare_index_params()
    index_params.add_index(field_name="vector", index_type="FLAT", metric_type="COSINE")
    client.create_collection(config.COLLECTION, schema=schema, index_params=index_params)

    vectors = embed([chunk["text"] for chunk in chunks], kind="db")
    rows = []
    for chunk, vector in zip(chunks, vectors):
        rows.append(
            {
                "id": chunk["id"],
                "vector": vector,
                "tenant": chunk["tenant"],
                "dept": chunk["dept"],
                "file_path": chunk["file_path"],
                "doc_type": chunk["doc_type"],
                "heading": chunk.get("heading", "")[:256],
                "text": chunk["text"][:MAX_TEXT_CHARS],
            }
        )
    for start in range(0, len(rows), 64):
        client.insert(config.COLLECTION, rows[start : start + 64])
    return len(rows)


def search(
    question: str,
    tenant: str,
    dept: str,
    top_k: int,
    doc_type: str | None = None,
) -> list[dict]:
    client = _client()
    if not client.has_collection(config.COLLECTION):
        raise VectorUnavailable(f"集合不存在：{config.COLLECTION}（先执行 make seed）")
    vector = embed([question], kind="query")[0]
    hits = client.search(
        collection_name=config.COLLECTION,
        data=[vector],
        limit=top_k,
        filter=_filter(tenant, dept, doc_type),
        output_fields=["file_path", "doc_type", "heading", "text"],
        search_params={"metric_type": "COSINE"},
    )
    results: list[dict] = []
    for hit in hits[0] if hits else []:
        entity = hit.get("entity") or {}
        chunk_id = str(hit.get("id"))
        # 分块序号编码在 id 尾部（`tenant:dept:file#N`），不必为了引用追溯多存一个标量字段。
        suffix = chunk_id.rsplit("#", 1)[-1]
        results.append(
            {
                "id": chunk_id,
                "file_path": entity.get("file_path", ""),
                "doc_type": entity.get("doc_type", ""),
                "heading": entity.get("heading", ""),
                "chunk_index": int(suffix) if suffix.isdigit() else 0,
                "text": entity.get("text", ""),
                "score": round(float(hit.get("distance", 0.0)), 6),
            }
        )
    return results
