"""语料授权：谁（tenant, dept）能看见哪些文件。

规则来自 `config/grants.json`，语义只有三条：

1. 默认拒绝。没有任何规则命中的文件不进索引，也不进 BM25。
2. 最长前缀胜出。`docs/private/` 可以覆盖 `docs/`，不需要写排除规则。
3. `*` 在入库时展开成具体部门列表。于是查询侧永远只有
   `tenant == x AND dept == y` 两个等值条件，没有通配符表达式，
   也就没有「表达式写错一个括号就跨租户」的可能。
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Rule:
    prefix: str
    tenants: tuple[str, ...]
    depts: tuple[str, ...]


class Grants:
    def __init__(self, version: int, depts_registry: tuple[str, ...], rules: list[Rule]) -> None:
        self.version = version
        self.depts_registry = depts_registry
        self.rules = sorted(rules, key=lambda rule: len(rule.prefix), reverse=True)

    @property
    def tenants(self) -> tuple[str, ...]:
        seen: list[str] = []
        for rule in self.rules:
            for tenant in rule.tenants:
                if tenant not in seen:
                    seen.append(tenant)
        return tuple(seen)

    def scopes_for(self, rel_path: str) -> list[tuple[str, str]]:
        for rule in self.rules:
            if not rel_path.startswith(rule.prefix):
                continue
            return [(tenant, dept) for tenant in rule.tenants for dept in rule.depts]
        return []

    def to_json(self) -> dict:
        return {
            "version": self.version,
            "depts_registry": list(self.depts_registry),
            "rules": [
                {"prefix": rule.prefix, "tenants": list(rule.tenants), "depts": list(rule.depts)}
                for rule in self.rules
            ],
        }


def load_grants(path: Path) -> Grants:
    raw = json.loads(path.read_text(encoding="utf-8"))
    registry = tuple(str(item).strip() for item in raw.get("depts_registry", []) if str(item).strip())
    if not registry:
        raise ValueError(f"grants 缺少 depts_registry：{path}")

    rules: list[Rule] = []
    for item in raw.get("rules", []):
        prefix = str(item.get("prefix", "")).strip()
        tenants = tuple(str(t).strip() for t in item.get("tenants", []) if str(t).strip())
        depts_raw = [str(d).strip() for d in item.get("depts", []) if str(d).strip()]
        if not prefix or not tenants or not depts_raw:
            continue
        depts = registry if "*" in depts_raw else tuple(d for d in depts_raw if d in registry)
        if not depts:
            continue
        rules.append(Rule(prefix=prefix, tenants=tenants, depts=tuple(dict.fromkeys(depts))))

    if not rules:
        raise ValueError(f"grants 没有任何有效规则（默认拒绝会让检索永远为空）：{path}")
    return Grants(version=int(raw.get("version", 1)), depts_registry=registry, rules=rules)
