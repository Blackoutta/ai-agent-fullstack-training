"""检索服务配置。全部来自环境变量，默认值保证「本机零依赖也能跑 BM25」。

路径口径：SERVICE_DIR 是 services/retrieval，SERVICE_DIR.parents[1] 是 6-6 根目录。
容器里用卷挂载覆盖 CORPUS_DIR / MILVUS_URI / RETRIEVAL_DATA_DIR，代码里不出现 /app 之类的绝对路径。
"""
from __future__ import annotations

import os
from pathlib import Path

SERVICE_DIR = Path(__file__).resolve().parents[1]
# 容器里代码在 /app，SERVICE_DIR.parents 只有 [/]：越界时退回上一级，
# 避免 IndexError；容器内的数据路径本来都由环境变量指向挂载卷。
ROOT_DIR = SERVICE_DIR.parents[1] if len(SERVICE_DIR.parents) > 1 else SERVICE_DIR.parent


def _env(name: str, default: str = "") -> str:
    return os.environ.get(name, default).strip()


PORT = int(_env("RETRIEVAL_PORT", "8770"))
DEFAULT_MODE = _env("RETRIEVAL_DEFAULT_MODE", "hybrid")
MAX_TOP_K = int(_env("RETRIEVAL_MAX_TOP_K", "20"))

DATA_DIR = Path(_env("RETRIEVAL_DATA_DIR", str(SERVICE_DIR / "data")))
INDEX_PATH = Path(_env("RETRIEVAL_INDEX", str(DATA_DIR / "chunks.json")))
CORPUS_DIR = Path(_env("CORPUS_DIR", str(ROOT_DIR / "corpus")))
GRANTS_PATH = Path(_env("RETRIEVAL_GRANTS", str(SERVICE_DIR / "config" / "grants.json")))

# 向量部分：Milvus Lite 是嵌入式文件（单写者），embedding 走 MiniMax embo-01（与 week04/4-4 同口径）。
COLLECTION = _env("COLLECTION", "login_demo_chunks")
EMBED_DIM = int(_env("EMBED_DIM", "1536"))
EMBED_MODEL = _env("EMBED_MODEL", "embo-01")
EMBED_API_BASE = _env("MINIMAX_API_BASE", "https://api.minimaxi.com/v1").rstrip("/")
EMBED_API_KEY = _env("MINIMAX_CN_API_KEY")
MILVUS_URI = _env("MILVUS_URI", str(DATA_DIR / "milvus_login_demo.db"))

# 身份：key:tenant:dept:role,... 只从环境变量读，服务本地解析。
API_KEYS_RAW = _env("PLATFORM_API_KEYS")
