"""检索服务的 HTTP 面。标准库 http.server，四个端点：

    GET  /health          进程与索引状态（含向量路径可用性）
    GET  /metrics         Prometheus 文本
    POST /v1/query        外部调用：Bearer 鉴权，身份只来自密钥
    POST /internal/query  内部调用：agent 的 rag-shim 用 X-Tenant / X-Dept 说明身份

租户与部门只有一个来源：身份。请求体里出现 tenant / dept 之类的字段直接 400，
不是为了「防止用户填错」，而是为了让越权尝试在日志里留下明确的一条记录，
而不是悄悄被服务端覆盖掉。
"""
from __future__ import annotations

import json
import os
import sys
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

from . import config, vector
from .bm25 import fuse_rrf
from .identity import Identity, authenticate, internal_identity, parse_api_keys
from .index import ChunkIndex, IndexUnavailable

VALID_MODES = {"vector", "bm25", "hybrid"}
VALID_DOC_TYPES = {"doc", "code", "web", "table", "pdf"}
FORBIDDEN_FIELDS = ("tenant", "dept", "tenant_id", "dept_id", "scope", "scopes", "filters")
MAX_BODY_BYTES = 64 * 1024
MAX_QUESTION_CHARS = 1000
SNIPPET_CHARS = 200


class QueryError(Exception):
    def __init__(self, status: int, code: str, message: str) -> None:
        super().__init__(message)
        self.status = status
        self.code = code
        self.message = message


class Metrics:
    """只用 counter 与 gauge：命中率这类比值交给 Prometheus 侧用两个计数器算，不在这里变成会漂的瞬时值。"""

    def __init__(self) -> None:
        self.counters: dict[tuple[str, tuple[tuple[str, str], ...]], float] = {}
        self.gauges: dict[tuple[str, tuple[tuple[str, str], ...]], float] = {}

    def inc(self, name: str, labels: dict[str, str] | None = None, value: float = 1.0) -> None:
        key = (name, tuple(sorted((labels or {}).items())))
        self.counters[key] = self.counters.get(key, 0.0) + value

    def set(self, name: str, labels: dict[str, str] | None, value: float) -> None:
        self.gauges[(name, tuple(sorted((labels or {}).items())))] = float(value)

    def render(self) -> str:
        kinds: dict[str, str] = {}
        for name, _labels in list(self.counters) + list(self.gauges):
            kinds.setdefault(name, "counter" if any(k[0] == name for k in self.counters) else "gauge")
        lines: list[str] = []
        for name in sorted(kinds):
            kind = kinds[name]
            lines.append(f"# HELP {name} retrieval service metric")
            lines.append(f"# TYPE {name} {kind}")
            source = self.counters if kind == "counter" else self.gauges
            for (metric, labels), value in sorted(source.items()):
                if metric != name:
                    continue
                rendered = ",".join(f'{k}="{v}"' for k, v in labels)
                suffix = f"{{{rendered}}}" if rendered else ""
                shown = int(value) if float(value).is_integer() else value
                lines.append(f"{name}{suffix} {shown}")
        return "\n".join(lines) + "\n"


class Application:
    def __init__(
        self,
        index: ChunkIndex | None,
        identities: dict[str, Identity],
        metrics: Metrics | None = None,
        vector_ok: bool | None = None,
        vector_reason: str = "",
    ) -> None:
        self.index = index
        self.identities = identities
        self.metrics = metrics or Metrics()
        if vector_ok is None:
            vector_ok, reason = vector.availability()
            vector_reason = vector_reason or reason
        self.vector_ok = vector_ok
        self.vector_reason = vector_reason
        self.metrics.set("retrieval_vector_available", None, 1 if vector_ok else 0)
        if index is not None:
            self.metrics.set("retrieval_index_chunks", None, len(index.chunks))

    # ------------------------------------------------------------ 健康与指标

    def health(self) -> dict:
        payload = {
            "status": "ok" if self.index is not None else "degraded",
            "service": "retrieval",
            "vector": {"available": self.vector_ok, "reason": self.vector_reason or None},
        }
        if self.index is None:
            payload["index"] = {"available": False, "reason": "索引未装载，先执行 make seed"}
        else:
            payload["index"] = {"available": True, **self.index.health()}
        return payload

    # ------------------------------------------------------------ 查询

    def query(self, payload: dict, identity: Identity, internal: bool = False) -> dict:
        started = time.monotonic()
        question, mode, top_k, doc_type = _validate(payload)
        if self.index is None:
            raise QueryError(
                503,
                "INDEX_UNAVAILABLE",
                "检索索引未装载：先执行 make seed（或 python -m app.ingest）再启动服务",
            )

        results, retrieval_mode, degraded, degrade_reason = self._search(
            question, identity, mode, top_k, doc_type
        )
        took_ms = int((time.monotonic() - started) * 1000)

        self.metrics.inc("retrieval_queries_total", {"mode": retrieval_mode, "outcome": "ok"})
        if results:
            self.metrics.inc("retrieval_hits_total", {"mode": retrieval_mode})
        if degraded:
            self.metrics.inc("retrieval_degraded_total", {"requested": mode})

        return {
            "question": question,
            "mode": mode,
            "retrieval_mode": retrieval_mode,
            "degraded": degraded,
            "degrade_reason": degrade_reason,
            "filters_applied": {
                "tenant": identity.tenant,
                "dept": identity.dept,
                "doc_type": doc_type,
                "source": "internal" if internal else "api_key",
            },
            "top_k": top_k,
            "hits": len(results),
            "answer": None,
            "results": results,
            "citations": _citations(results),
            "took_ms": took_ms,
        }

    def _search(
        self,
        question: str,
        identity: Identity,
        mode: str,
        top_k: int,
        doc_type: str | None,
    ) -> tuple[list[dict], str, bool, str | None]:
        assert self.index is not None  # query() 已拦掉 None
        vector_results: list[dict] = []
        retrieval_mode = mode
        degraded = False
        degrade_reason: str | None = None

        if mode in {"vector", "hybrid"}:
            if not self.vector_ok:
                retrieval_mode, degraded = "bm25", True
                degrade_reason = self.vector_reason or "向量依赖不可用"
            else:
                try:
                    vector_results = vector.search(question, identity.tenant, identity.dept, top_k * 2, doc_type)
                except Exception as error:  # noqa: BLE001 - 向量失败一律降级，不让整个查询 500
                    retrieval_mode, degraded = "bm25", True
                    degrade_reason = f"{type(error).__name__}: {error}"

        if retrieval_mode == "vector":
            return vector_results[:top_k], "vector", degraded, degrade_reason

        bm25_results = self.index.bm25_search(
            question,
            identity.tenant,
            identity.dept,
            top_k if retrieval_mode == "bm25" else top_k * 2,
            doc_type,
        )
        if retrieval_mode == "bm25":
            return bm25_results, "bm25", degraded, degrade_reason

        lookup = {
            chunk["id"]: {
                "id": chunk["id"],
                "file_path": chunk.get("file_path", ""),
                "doc_type": chunk.get("doc_type", ""),
                "heading": chunk.get("heading", ""),
                "chunk_index": chunk.get("chunk_index", 0),
                "text": chunk.get("text", ""),
            }
            for chunk in self.index.visible_chunks(identity.tenant, identity.dept, doc_type)
        }
        for item in vector_results:
            lookup[item["id"]] = item
        fused = fuse_rrf(
            [
                [(item["id"], item["score"]) for item in vector_results],
                [(item["id"], item["score"]) for item in bm25_results],
            ],
            top_k,
        )
        results = [dict(lookup[chunk_id], score=round(score, 6)) for chunk_id, score in fused if chunk_id in lookup]
        return results, "hybrid", degraded, degrade_reason


# ---------------------------------------------------------------- 校验与装配

def _validate(payload: dict) -> tuple[str, str, int, str | None]:
    if not isinstance(payload, dict):
        raise QueryError(400, "INVALID_BODY", "请求体必须是 JSON 对象")

    leaked = [field for field in FORBIDDEN_FIELDS if field in payload]
    if leaked:
        raise QueryError(
            400,
            "TENANT_FIELD_FORBIDDEN",
            f"请求体不得指定身份字段 {leaked}：租户与部门只来自鉴权身份",
        )

    question = payload.get("question")
    if not isinstance(question, str) or not question.strip():
        raise QueryError(400, "INVALID_QUESTION", "question 必须是非空字符串")
    question = question.strip()
    if len(question) > MAX_QUESTION_CHARS:
        raise QueryError(400, "INVALID_QUESTION", f"question 超过 {MAX_QUESTION_CHARS} 字")

    mode = payload.get("mode", config.DEFAULT_MODE)
    if not isinstance(mode, str) or mode not in VALID_MODES:
        raise QueryError(400, "INVALID_MODE", f"mode 必须是 {sorted(VALID_MODES)} 之一")

    raw_top_k = payload.get("top_k", 5)
    if isinstance(raw_top_k, bool) or not isinstance(raw_top_k, int):
        raise QueryError(400, "INVALID_TOP_K", "top_k 必须是整数")
    top_k = max(1, min(raw_top_k, config.MAX_TOP_K))

    doc_type = payload.get("doc_type")
    if doc_type is not None:
        if not isinstance(doc_type, str) or doc_type not in VALID_DOC_TYPES:
            raise QueryError(400, "INVALID_DOC_TYPE", f"doc_type 必须是 {sorted(VALID_DOC_TYPES)} 之一或省略")

    return question, mode, top_k, doc_type


def _citations(results: list[dict]) -> list[dict]:
    citations: list[dict] = []
    for index, item in enumerate(results, 1):
        snippet = " ".join((item.get("text") or "").split())[:SNIPPET_CHARS]
        citations.append(
            {
                "index": index,
                "file": item.get("file_path", ""),
                "heading": item.get("heading", ""),
                "score": item.get("score", 0.0),
                "snippet": snippet,
            }
        )
    return citations


# ---------------------------------------------------------------- HTTP

class Handler(BaseHTTPRequestHandler):
    server_version = "RetrievalService/1.0"
    protocol_version = "HTTP/1.1"

    # make_server 会把 Application 挂到子类的 app_class 上
    app_class: Application

    def log_message(self, fmt: str, *args: object) -> None:
        if os.environ.get("RETRIEVAL_ACCESS_LOG") == "1":
            super().log_message(fmt, *args)

    def do_GET(self) -> None:  # noqa: N802 - BaseHTTPRequestHandler 的命名契约
        self._start()
        path = urlparse(self.path).path
        app = self.app_class
        if path == "/health":
            self._json(200, app.health())
            return
        if path == "/metrics":
            self._text(200, app.metrics.render())
            return
        self._fail(404, "NOT_FOUND", f"未知路径 {path}")

    def do_POST(self) -> None:  # noqa: N802
        self._start()
        path = urlparse(self.path).path
        if path not in {"/v1/query", "/internal/query"}:
            self._fail(404, "NOT_FOUND", f"未知路径 {path}")
            return
        try:
            payload = self._read_json()
        except QueryError as error:
            self._json(error.status, _error_body(error, getattr(self, "request_id", "")))
            return

        app = self.app_class
        internal = path == "/internal/query"
        identity = internal_identity(self.headers) if internal else authenticate(self.headers.get("Authorization"), app.identities)
        if identity is None:
            code = "UNAUTHENTICATED_INTERNAL" if internal else "UNAUTHENTICATED"
            message = "内部通道需要 X-Tenant / X-Dept" if internal else "需要有效的 Bearer 密钥"
            app.metrics.inc("retrieval_queries_total", {"mode": "unknown", "outcome": "unauthorized"})
            self._fail(401, code, message)
            return

        try:
            body = app.query(payload, identity, internal=internal)
        except QueryError as error:
            app.metrics.inc("retrieval_queries_total", {"mode": "unknown", "outcome": error.code.lower()})
            self._json(error.status, _error_body(error, getattr(self, "request_id", "")))
            return
        self._json(200, body)

    # ------------------------------------------------------------ 底层

    def _start(self) -> None:
        """每个请求一个请求号：回写响应头，也写进错误体，日志能串起来。"""
        self.request_id = (self.headers.get("X-Request-Id") or "").strip() \
            or f"req-{uuid.uuid4().hex[:12]}"

    def _fail(self, status: int, code: str, message: str) -> None:
        self._json(status, {"error": {"code": code, "message": message}, "code": code,
                            "details": [], "request_id": self.request_id})

    def _read_json(self) -> dict:
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError as error:
            raise QueryError(400, "INVALID_BODY", "Content-Length 不合法") from error
        if length <= 0:
            raise QueryError(400, "INVALID_BODY", "请求体为空")
        if length > MAX_BODY_BYTES:
            raise QueryError(413, "BODY_TOO_LARGE", f"请求体超过 {MAX_BODY_BYTES} 字节")
        raw = self.rfile.read(length)
        try:
            return json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as error:
            raise QueryError(400, "INVALID_JSON", f"请求体不是合法 JSON：{error}") from error

    def _json(self, status: int, payload: dict) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        if getattr(self, "request_id", None):
            self.send_header("X-Request-Id", self.request_id)
        self.end_headers()
        self.wfile.write(body)

    def _text(self, status: int, text: str) -> None:
        body = text.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/plain; version=0.0.4; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


def _error_body(error: QueryError, request_id: str = "") -> dict:
    return {"error": {"code": error.code, "message": error.message},
            "code": error.code, "details": [], "request_id": request_id}


def make_server(app: Application, host: str = "0.0.0.0", port: int | None = None) -> ThreadingHTTPServer:
    handler = type("BoundHandler", (Handler,), {"app_class": app})
    return ThreadingHTTPServer((host, config.PORT if port is None else port), handler)


def main() -> int:
    identities = parse_api_keys(config.API_KEYS_RAW)
    if not identities:
        print("警告：PLATFORM_API_KEYS 为空，所有外部查询都会 401", file=sys.stderr)

    try:
        index: ChunkIndex | None = ChunkIndex.load(config.INDEX_PATH)
    except IndexUnavailable as error:
        print(f"警告：{error}", file=sys.stderr)
        index = None

    app = Application(index=index, identities=identities)
    server = make_server(app)
    print(
        f"retrieval 已启动 :{config.PORT} · index={len(index.chunks) if index else 0} chunks"
        f" · vector={'on' if app.vector_ok else 'off'}"
        + (f"（{app.vector_reason}）" if not app.vector_ok else ""),
        file=sys.stderr,
    )
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
