"""入库作业：解析 corpus → 写分块索引（BM25 的数据源）→ 有向量能力时再写 Milvus Lite。

用法（容器里，先停 retrieval 再跑）：

    docker compose stop retrieval
    docker compose run --rm --no-deps retrieval python -m app.ingest
    docker compose start retrieval

设计取舍：
- 分块索引永远生成。没有嵌入密钥时 BM25 照常可用，服务如实标注 `retrieval_mode=bm25`。
- 向量写入是「全有或全无」：`--require-vector` 时拿不到嵌入服务就失败退出，
  绝不写入半套向量靠维度或占位符蒙混过关。
"""
from __future__ import annotations

import argparse
import json
import sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

from . import config, vector
from .chunking import build_chunks
from .grants import load_grants


def build_payload(corpus_dir: Path, grants_path: Path) -> dict:
    grants = load_grants(grants_path)
    chunks, unindexed, corpus_hash = build_chunks(corpus_dir, grants)
    by_doc_type = Counter(chunk["doc_type"] for chunk in chunks)
    by_tenant = Counter(chunk["tenant"] for chunk in chunks)
    by_scope = Counter(f"{chunk['tenant']}/{chunk['dept']}" for chunk in chunks)
    return {
        "version": 1,
        "built_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "corpus_hash": corpus_hash,
        "collection": config.COLLECTION,
        "embed_model": config.EMBED_MODEL,
        "embed_dim": config.EMBED_DIM,
        "grants": grants.to_json(),
        "tenants": list(grants.tenants),
        "depts": list(grants.depts_registry),
        "counts": {
            "files": len({chunk["file_path"] for chunk in chunks}),
            "chunks": len(chunks),
            "by_doc_type": dict(sorted(by_doc_type.items())),
            "by_tenant": dict(sorted(by_tenant.items())),
            "by_scope": dict(sorted(by_scope.items())),
            "unindexed": len(unindexed),
        },
        "unindexed": unindexed,
        "chunks": chunks,
    }


def write_index(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="python -m app.ingest", description="检索语料入库")
    parser.add_argument("--corpus", default=str(config.CORPUS_DIR), help="语料根目录")
    parser.add_argument("--grants", default=str(config.GRANTS_PATH), help="授权矩阵 JSON")
    parser.add_argument("--index", default=str(config.INDEX_PATH), help="分块索引输出路径")
    parser.add_argument("--no-vector", action="store_true", help="只写分块索引，不写 Milvus")
    parser.add_argument("--require-vector", action="store_true", help="向量不可用时失败退出")
    args = parser.parse_args(argv)

    corpus_dir = Path(args.corpus)
    if not corpus_dir.is_dir():
        print(f"语料目录不存在：{corpus_dir}", file=sys.stderr)
        return 2

    payload = build_payload(corpus_dir, Path(args.grants))
    write_index(Path(args.index), payload)

    summary = {
        "index": args.index,
        "corpus_hash": payload["corpus_hash"],
        "counts": payload["counts"],
        "unindexed": payload["unindexed"],
        "vector": "skipped (--no-vector)",
    }
    exit_code = 0

    if not args.no_vector:
        ok, reason = vector.availability()
        if not ok:
            summary["vector"] = f"skipped: {reason}"
            exit_code = 1 if args.require_vector else 0
        else:
            try:
                summary["vector"] = f"written: {vector.rebuild(payload['chunks'])} rows → {config.COLLECTION}"
            except vector.VectorUnavailable as error:
                summary["vector"] = f"skipped: {error}"
                exit_code = 1 if args.require_vector else 0

    print(json.dumps(summary, ensure_ascii=False, indent=2))
    if exit_code != 0:
        print("向量写入失败（--require-vector），未写入任何向量行", file=sys.stderr)
    return exit_code


if __name__ == "__main__":
    sys.exit(main())
