"""检索服务的离线测试：不起容器、不联网、不需要 Milvus。

覆盖四件事：
1. 授权矩阵的默认拒绝与 `*` 展开；
2. 过滤发生在算分之前——跨租户的字面命中必须拿不到；
3. 请求体带身份字段一律 400；
4. 向量不可用时降级 BM25 且如实标注，而不是返回空结果。
"""
from __future__ import annotations

import json
import sys
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from pathlib import Path

SERVICE_DIR = Path(__file__).resolve().parents[1]
if str(SERVICE_DIR) not in sys.path:
    sys.path.insert(0, str(SERVICE_DIR))

from app.bm25 import fuse_rrf, tokenize  # noqa: E402
from app.chunking import build_chunks, split_text  # noqa: E402
from app.grants import load_grants  # noqa: E402
from app.identity import Identity, authenticate, parse_api_keys  # noqa: E402
from app.index import ChunkIndex  # noqa: E402
from app.ingest import build_payload  # noqa: E402
from app.server import Application, QueryError, make_server  # noqa: E402

CORPUS = {
    "docs/session-rules.md": (
        "---\nservice: login_demo\nowner: 认证组\n---\n\n"
        "# 登录会话有效期规则\n\n管理后台的登录会话有效期为 30 分钟。\n\n"
        "## 到期边界\n\n当前时刻恰好等于到期时刻时，会话判定为无效。\n"
    ),
    "docs/faq.md": "# 常见问题\n\n忘记密码怎么办？走找回密码流程。\n",
    "app/auth.py": "def verify_session(token):\n    \"\"\"校验会话是否仍然有效。\"\"\"\n    return token is not None\n",
    "secret/private.md": "# 内部审计\n\n这段内容没有授权，不允许进入任何租户的索引。\n",
}

GRANTS = {
    "version": 1,
    "depts_registry": ["platform", "engineering"],
    "rules": [
        {"prefix": "docs/", "tenants": ["tenant_a", "tenant_b"], "depts": ["*"]},
        {"prefix": "app/", "tenants": ["tenant_a"], "depts": ["platform"]},
    ],
}

IDENTITY_A = Identity(tenant="tenant_a", dept="platform", role="admin", key_prefix="key-a")
IDENTITY_B = Identity(tenant="tenant_b", dept="engineering", role="reviewer", key_prefix="key-b")


class Fixture:
    """一份临时语料 + 授权 + 索引 + Application。两个测试类各建一份，互不共享状态。"""

    def __init__(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        root = Path(self.tmp.name)
        self.corpus = root / "corpus"
        for rel, text in CORPUS.items():
            path = self.corpus / rel
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(text, encoding="utf-8")
        self.grants_path = root / "grants.json"
        self.grants_path.write_text(json.dumps(GRANTS, ensure_ascii=False), encoding="utf-8")
        self.payload = build_payload(self.corpus, self.grants_path)
        self.index = ChunkIndex(self.payload)
        self.app = Application(
            index=self.index,
            identities=parse_api_keys("key-a:tenant_a:platform:admin,key-b:tenant_b:engineering:reviewer"),
            vector_ok=False,
            vector_reason="MINIMAX_CN_API_KEY 未配置",
        )

    def close(self) -> None:
        self.tmp.cleanup()


class RetrievalCase(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.fx = Fixture()
        cls.corpus = cls.fx.corpus
        cls.grants_path = cls.fx.grants_path
        cls.index = cls.fx.index
        cls.app = cls.fx.app

    @classmethod
    def tearDownClass(cls) -> None:
        cls.fx.close()

    # ------------------------------------------------------------ 授权矩阵

    def test_grants_default_deny_and_expand_star(self) -> None:
        grants = load_grants(self.grants_path)
        self.assertEqual(grants.scopes_for("secret/private.md"), [])
        self.assertEqual(
            sorted(grants.scopes_for("docs/faq.md")),
            [("tenant_a", "engineering"), ("tenant_a", "platform"), ("tenant_b", "engineering"), ("tenant_b", "platform")],
        )
        self.assertEqual(grants.scopes_for("app/auth.py"), [("tenant_a", "platform")])
        self.assertEqual(sorted(grants.tenants), ["tenant_a", "tenant_b"])

    def test_chunks_carry_scope_and_heading(self) -> None:
        chunks, unindexed, corpus_hash = build_chunks(self.corpus, load_grants(self.grants_path))
        self.assertTrue(corpus_hash.startswith("sha256:"))
        self.assertEqual([item["file_path"] for item in unindexed], ["secret/private.md"])
        self.assertEqual(unindexed[0]["reason"], "no_grant")

        rules_chunk = next(chunk for chunk in chunks if chunk["file_path"] == "docs/session-rules.md")
        self.assertEqual(rules_chunk["heading"], "登录会话有效期规则")
        self.assertEqual(rules_chunk["doc_type"], "doc")
        self.assertIn("30 分钟", rules_chunk["text"])
        self.assertNotIn("service:", rules_chunk["text"])  # front matter 不进正文

        scopes = {(chunk["tenant"], chunk["dept"]) for chunk in chunks if chunk["file_path"] == "app/auth.py"}
        self.assertEqual(scopes, {("tenant_a", "platform")})
        self.assertFalse(any("secret/private.md" == chunk["file_path"] for chunk in chunks))

    def test_split_text_never_exceeds_limit(self) -> None:
        text = "\n\n".join(["甲" * 200, "乙" * 200, "丙" * 900])
        pieces = split_text(text, limit=700)
        self.assertTrue(all(len(piece) <= 700 for piece in pieces))
        self.assertGreaterEqual(len(pieces), 3)

    # ------------------------------------------------------------ 强制过滤

    def test_cross_tenant_query_cannot_see_other_tenant_chunks(self) -> None:
        body = self.app.query({"question": "verify_session 校验会话", "top_k": 10}, IDENTITY_B)
        files = {item["file_path"] for item in body["results"]}
        self.assertNotIn("app/auth.py", files)
        self.assertIn("docs/session-rules.md", files)
        self.assertEqual(body["filters_applied"]["tenant"], "tenant_b")

        body_a = self.app.query({"question": "verify_session 校验会话", "top_k": 10}, IDENTITY_A)
        self.assertIn("app/auth.py", {item["file_path"] for item in body_a["results"]})

    def test_bm25_hits_and_ranks_expected_document(self) -> None:
        body = self.app.query({"question": "登录会话有效期是多少分钟？"}, IDENTITY_A)
        self.assertEqual(body["retrieval_mode"], "bm25")
        self.assertTrue(body["results"])
        self.assertEqual(body["results"][0]["file_path"], "docs/session-rules.md")
        self.assertEqual(body["citations"][0]["index"], 1)
        self.assertIsNone(body["answer"])

    def test_doc_type_filter_applies_inside_scope(self) -> None:
        code = self.app.query({"question": "会话", "doc_type": "code"}, IDENTITY_A)
        self.assertEqual({item["doc_type"] for item in code["results"]}, {"code"})
        docs = self.app.query({"question": "会话", "doc_type": "doc"}, IDENTITY_A)
        self.assertEqual({item["doc_type"] for item in docs["results"]}, {"doc"})

    def test_tenant_field_in_body_is_rejected(self) -> None:
        for field in ("tenant", "dept", "scope", "filters"):
            with self.assertRaises(QueryError) as ctx:
                self.app.query({"question": "会话", field: "tenant_b"}, IDENTITY_A)
            self.assertEqual(ctx.exception.status, 400)
            self.assertEqual(ctx.exception.code, "TENANT_FIELD_FORBIDDEN")

    def test_degraded_vector_is_labelled(self) -> None:
        body = self.app.query({"question": "会话有效期", "mode": "hybrid"}, IDENTITY_A)
        self.assertEqual(body["retrieval_mode"], "bm25")
        self.assertTrue(body["degraded"])
        self.assertIn("MINIMAX_CN_API_KEY", body["degrade_reason"])

        direct = self.app.query({"question": "会话有效期", "mode": "vector"}, IDENTITY_A)
        self.assertEqual(direct["retrieval_mode"], "bm25")
        self.assertTrue(direct["degraded"])

    def test_invalid_requests_are_rejected(self) -> None:
        cases = [
            ({"question": ""}, "INVALID_QUESTION"),
            ({"question": "会话", "mode": "magic"}, "INVALID_MODE"),
            ({"question": "会话", "top_k": "5"}, "INVALID_TOP_K"),
            ({"question": "会话", "doc_type": "video"}, "INVALID_DOC_TYPE"),
        ]
        for payload, code in cases:
            with self.assertRaises(QueryError) as ctx:
                self.app.query(payload, IDENTITY_A)
            self.assertEqual(ctx.exception.code, code)

    def test_missing_index_returns_503_not_empty_list(self) -> None:
        app = Application(index=None, identities={}, vector_ok=False, vector_reason="no")
        with self.assertRaises(QueryError) as ctx:
            app.query({"question": "会话"}, IDENTITY_A)
        self.assertEqual(ctx.exception.status, 503)
        self.assertEqual(app.health()["status"], "degraded")

    # ------------------------------------------------------------ 分词与融合

    def test_tokenize_keeps_code_symbols_and_cjk_bigrams(self) -> None:
        tokens = tokenize("verify_session 校验会话有效期")
        self.assertIn("verify_session", tokens)
        self.assertIn("会话", tokens)
        self.assertIn("有效", tokens)

    def test_rrf_prefers_documents_hit_by_both_lists(self) -> None:
        fused = fuse_rrf([[("a", 0.9), ("b", 0.8)], [("b", 12.0), ("c", 5.0)]], top_k=3)
        self.assertEqual(fused[0][0], "b")


class HttpCase(unittest.TestCase):
    """真实起一个 HTTP 服务（端口 0），验证鉴权与身份通道。"""

    @classmethod
    def setUpClass(cls) -> None:
        cls.fx = Fixture()
        cls.server = make_server(cls.fx.app, host="127.0.0.1", port=0)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.base = f"http://127.0.0.1:{cls.server.server_address[1]}"

    @classmethod
    def tearDownClass(cls) -> None:
        cls.server.shutdown()
        cls.server.server_close()
        cls.fx.close()

    def _post(self, path: str, payload: dict, headers: dict[str, str] | None = None) -> tuple[int, dict]:
        request = urllib.request.Request(
            f"{self.base}{path}",
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json", **(headers or {})},
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=5) as response:
                return response.status, json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as error:
            return error.code, json.loads(error.read().decode("utf-8"))

    def test_health_is_public(self) -> None:
        with urllib.request.urlopen(f"{self.base}/health", timeout=5) as response:
            body = json.loads(response.read().decode("utf-8"))
        self.assertEqual(response.status, 200)
        self.assertEqual(body["service"], "retrieval")
        self.assertFalse(body["vector"]["available"])

    def test_metrics_exposes_counters(self) -> None:
        self._post("/v1/query", {"question": "会话有效期"}, {"Authorization": "Bearer key-a"})
        with urllib.request.urlopen(f"{self.base}/metrics", timeout=5) as response:
            text = response.read().decode("utf-8")
        self.assertIn("retrieval_queries_total", text)
        self.assertIn('outcome="ok"', text)
        self.assertIn("retrieval_vector_available 0", text)

    def test_query_requires_bearer(self) -> None:
        status, body = self._post("/v1/query", {"question": "会话"})
        self.assertEqual(status, 401)
        self.assertEqual(body["error"]["code"], "UNAUTHENTICATED")

        status, body = self._post("/v1/query", {"question": "会话"}, {"Authorization": "Bearer nope"})
        self.assertEqual(status, 401)

    def test_query_with_key_is_scoped_by_identity(self) -> None:
        status, body = self._post(
            "/v1/query", {"question": "verify_session 校验会话", "top_k": 10}, {"Authorization": "Bearer key-b"}
        )
        self.assertEqual(status, 200)
        self.assertEqual(body["filters_applied"]["tenant"], "tenant_b")
        self.assertEqual(body["filters_applied"]["source"], "api_key")
        self.assertNotIn("app/auth.py", {item["file_path"] for item in body["results"]})

    def test_tenant_field_over_http_is_400(self) -> None:
        status, body = self._post(
            "/v1/query", {"question": "会话", "tenant": "tenant_b"}, {"Authorization": "Bearer key-a"}
        )
        self.assertEqual(status, 400)
        self.assertEqual(body["error"]["code"], "TENANT_FIELD_FORBIDDEN")

    def test_internal_channel_uses_headers(self) -> None:
        status, body = self._post("/internal/query", {"question": "会话有效期"}, {"X-Tenant": "tenant_a", "X-Dept": "platform"})
        self.assertEqual(status, 200)
        self.assertEqual(body["filters_applied"]["source"], "internal")
        self.assertEqual(body["filters_applied"]["dept"], "platform")

        status, body = self._post("/internal/query", {"question": "会话有效期"}, {"X-Tenant": "tenant_a'; drop"})
        self.assertEqual(status, 401)
        self.assertEqual(body["error"]["code"], "UNAUTHENTICATED_INTERNAL")

    def test_identity_parsing_rejects_unsafe_fields(self) -> None:
        keys = parse_api_keys("sk:with:colon:tenant_a:platform:admin,bad:tenant b:platform:admin")
        self.assertIn("sk:with:colon", keys)
        self.assertEqual(len(keys), 1)
        self.assertEqual(authenticate("Bearer sk:with:colon", keys).tenant, "tenant_a")  # type: ignore[union-attr]


if __name__ == "__main__":
    unittest.main()
