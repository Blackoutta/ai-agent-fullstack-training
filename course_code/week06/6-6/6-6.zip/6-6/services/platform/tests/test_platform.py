"""平台控制面验收（WP-006）：状态机、比例路由、预算、报表、审计、密钥自检。

测试全部离线：探针读仓库里的真实配置，HTTP 用回环端口，不依赖 gateway / agent 在线。
"""
from __future__ import annotations

import dataclasses
import http.client
import json
import os
import tempfile
import threading
import unittest
from http.server import ThreadingHTTPServer
from pathlib import Path
from unittest import mock

from services.platform.app import cost, releases
from services.platform.app.identity import (Forbidden, Unauthenticated, parse_api_keys,
                                            resolve_identity)
from services.platform.app.server import handler_for
from services.platform.app.settings import Settings
from services.platform.app.store import Store

ROOT = Path(__file__).resolve().parents[3]
KEYS = ("key-a:tenant_a:platform:admin,key-b:tenant_b:engineering:reviewer,"
        "key-service:platform:platform:service")


def base_env(tmp: Path) -> dict:
    return {
        "PLATFORM_DB": str(tmp / "data" / "platform.db"),
        "PLATFORM_RUNS_DIR": str(tmp / "runs"),
        "PLATFORM_RELEASES_DIR": str(tmp / "releases"),
        "PLATFORM_CORPUS_DIR": str(ROOT / "corpus"),
        "PLATFORM_GATEWAY_CONFIG": str(ROOT / "services/gateway/litellm.config.yaml"),
        "PLATFORM_AGENT_CONFIG": str(ROOT / "services/agent/config/platform.yaml"),
        "PLATFORM_PROMPTS": str(ROOT / "services/agent/config/prompts.yaml"),
        "PLATFORM_GRANTS": str(ROOT / "services/retrieval/config/grants.json"),
        "PLATFORM_EVAL_SOURCE": str(ROOT / "codebaseEval/backend"),
        "PLATFORM_API_KEYS": KEYS,
        "PLATFORM_ALLOWED_HOSTS": "localhost,127.0.0.1",
        "PLATFORM_SECRET_SCAN": "0",
        "PLATFORM_AGENT_URL": "",
        "DEMO_TENANT": "tenant_a",
        "BUDGET_TENANT_DAILY_USD": "1.00",
        "BUDGET_DEPT_DAILY_USD": "1.00",
        "BUDGET_WARN_RATIO": "0.8",
    }


class PlatformCase(unittest.TestCase):
    """每个用例一套临时 data/runs/releases：发布单与账本不能互相污染。"""

    def setUp(self) -> None:
        self.tmp = Path(tempfile.mkdtemp(prefix="platform-test-"))
        self.addCleanup(lambda: _rm(self.tmp))
        self.settings = self.make_settings()
        self.store = Store(self.settings.db_path)
        self.addCleanup(self.store.close)

    def make_settings(self, **overrides) -> Settings:
        env = base_env(self.tmp)
        env.update(overrides)
        patcher = mock.patch.dict(os.environ, env, clear=False)
        patcher.start()
        self.addCleanup(patcher.stop)
        return Settings.load()

    def draft(self, version: str | None = None) -> dict:
        manifest = releases.draft(self.store, self.settings, version=version)
        releases.write_manifest(self.settings.releases_dir, manifest)
        return self.store.put_release(manifest["version"], releases.DRAFT, manifest,
                                      manifest["components"]["gateway"]["config_hash"])

    def checked(self, version: str | None = None) -> str:
        release = self.draft(version)
        result = releases.check(self.store, self.settings, release["version"])
        self.assertEqual(result["status"], releases.CHECKED, result)
        return release["version"]


class ReleaseStateMachineTests(PlatformCase):
    def test_draft_writes_json_and_yaml_manifest(self):
        release = self.draft("rel-test-1")
        root = Path(self.settings.releases_dir) / "rel-test-1"
        self.assertTrue((root / "manifest.json").is_file())
        self.assertTrue((root / "manifest.yaml").is_file())
        manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
        self.assertEqual(manifest["version"], "rel-test-1")
        for part in ("gateway", "agent", "eval", "retrieval"):
            self.assertIn(part, manifest["components"])
        self.assertEqual([item["id"] for item in manifest["acceptance"]["cases"]],
                         ["gateway-config", "agent-config", "retrieval-grants", "redaction-sample"])
        self.assertEqual(release["status"], releases.DRAFT)

    def test_publish_rejected_until_checked(self):
        version = self.draft("rel-test-2")["version"]
        with self.assertRaises(releases.ReleaseNotChecked):
            releases.publish(self.store, self.settings, version, None)
        result = releases.check(self.store, self.settings, version)
        self.assertTrue(result["ok"], result)
        published = releases.publish(self.store, self.settings, version, None)
        self.assertEqual(published["track"], "stable")
        self.assertEqual(published["route"]["stable"], version)
        route_file = json.loads((Path(self.settings.releases_dir) / "route.json")
                                .read_text(encoding="utf-8"))
        self.assertEqual(route_file["stable"], version)
        self.assertEqual(self.store.release(version)["status"], releases.PUBLISHED)

    def test_check_failure_blocks_publish(self):
        broken = self.tmp / "litellm.broken.yaml"
        broken.write_text("model_list:\n  - model_name: deepseek-flash\n"
                          "    api_key: sk-inline-secret-should-fail\n", encoding="utf-8")
        self.settings = self.make_settings(PLATFORM_GATEWAY_CONFIG=str(broken))
        version = self.draft("rel-test-3")["version"]
        result = releases.check(self.store, self.settings, version)
        self.assertEqual(result["status"], releases.FAILED)
        failed = [item["id"] for item in result["cases"] if not item["ok"]]
        self.assertIn("gateway-config", failed)
        self.assertEqual(self.store.release(version)["status"], releases.FAILED)
        with self.assertRaises(releases.ReleaseNotChecked):
            releases.publish(self.store, self.settings, version, None)

    def test_pilot_ratio_split_and_explicit_group(self):
        stable = self.checked("rel-test-4")
        releases.publish(self.store, self.settings, stable, None)
        pilot = self.checked("rel-test-5")
        result = releases.publish(self.store, self.settings, pilot, None,
                                  track="pilot", pilot_ratio=25)
        self.assertEqual(result["track"], "pilot")
        self.assertEqual(result["route"]["pilot"], pilot)
        self.assertEqual(result["route"]["stable"], stable)

        tracks = [releases.choose(self.store.route(), f"run-{i}")["track"] for i in range(200)]
        self.assertIn("pilot", tracks)
        self.assertIn("stable", tracks)
        ratio = tracks.count("pilot") / len(tracks)
        self.assertGreater(ratio, 0.08)
        self.assertLess(ratio, 0.45)

        forced = releases.choose(self.store.route(), "run-x", "pilot")
        self.assertEqual((forced["version"], forced["track"]), (pilot, "pilot"))
        skipped = releases.choose(self.store.route(), "run-x", "stable")
        self.assertEqual(skipped["version"], stable)

    def test_rollback_clears_pilot_and_marks_version(self):
        stable = self.checked("rel-test-6")
        releases.publish(self.store, self.settings, stable, None)
        pilot = self.checked("rel-test-7")
        releases.publish(self.store, self.settings, pilot, None, track="pilot", pilot_ratio=50)
        result = releases.rollback(self.store, self.settings, None, reason="演练")
        self.assertEqual(result["rolled_back"], pilot)
        self.assertIsNone(result["route"]["pilot"])
        self.assertEqual(result["route"]["pilot_ratio"], 0.0)
        self.assertEqual(self.store.release(pilot)["status"], releases.ROLLED_BACK)
        self.assertEqual(self.store.release(stable)["status"], releases.PUBLISHED)
        self.assertTrue(any(item["action"] == "release_rolled_back"
                            for item in self.store.audits(limit=20)))

    def test_first_publish_always_becomes_stable(self):
        version = self.checked("rel-test-8")
        # 没有 stable 时请求 pilot 也没有意义：路由必须留一条所有人都能命中的轨道。
        result = releases.publish(self.store, self.settings, version, None,
                                  track="pilot", pilot_ratio=10)
        self.assertEqual(result["track"], "stable")
        self.assertEqual(result["route"]["stable"], version)


class BudgetAndCostTests(PlatformCase):
    def usage(self, **overrides) -> dict:
        payload = {"run_id": "run-1", "source": "agent", "model": "deepseek-flash",
                   "strategy": "direct", "outcome": "success", "input_tokens": 1000,
                   "output_tokens": 500, "cache_tokens": 0, "total_tokens": 1500,
                   "cost_usd": 0.4, "seconds": 12.5}
        payload.update(overrides)
        return cost.record(self.store, payload, resolve_identity("Bearer key-a", parse_api_keys(KEYS)))

    def test_budget_exceeded_is_reported_with_scope(self):
        self.usage(cost_usd=1.4)
        state = cost.budget_state(self.store, self.settings, ["tenant:tenant_a"])
        self.assertFalse(state["allowed"])
        self.assertEqual(state["scope"], "tenant:tenant_a")
        self.assertEqual(state["scopes"][0]["state"], "exceeded")
        self.assertAlmostEqual(state["scopes"][0]["spent_usd"], 1.4, places=6)

    def test_warning_threshold_does_not_block(self):
        self.usage(cost_usd=0.85)
        state = cost.budget_state(self.store, self.settings, ["tenant:tenant_a"])
        self.assertTrue(state["allowed"])
        self.assertTrue(state["warning"])
        self.assertEqual(state["scopes"][0]["state"], "warning")

    def test_dept_scope_only_counts_that_dept(self):
        self.usage(cost_usd=0.6)
        self.store.set_budget("dept:tenant_a/platform", "daily", 0.5, 0.8)
        state = cost.budget_state(self.store, self.settings,
                                  ["dept:tenant_a/platform", "dept:tenant_a/engineering"])
        self.assertFalse(state["allowed"])
        self.assertEqual(state["scope"], "dept:tenant_a/platform")
        self.assertEqual(state["scopes"][1]["runs"], 0)

    def test_unknown_cost_counted_separately(self):
        self.usage(cost_usd=None, total_tokens=None)
        self.usage(run_id="run-2", cost_usd=0.25)
        report = cost.report(self.store, group_by="tenant")
        self.assertEqual(report["totals"]["runs"], 2)
        self.assertEqual(report["totals"]["unknown_cost_runs"], 1)
        self.assertEqual(report["totals"]["unknown_token_runs"], 1)
        self.assertAlmostEqual(report["totals"]["known_cost_usd"], 0.25, places=6)
        text = cost.markdown(report)
        self.assertIn("未知成本运行", text)
        self.assertIn("cost_usd 为 null", text)

    def test_non_service_identity_cannot_report_for_other_tenant(self):
        reviewer = resolve_identity("Bearer key-b", parse_api_keys(KEYS))
        row = cost.record(self.store, {"tenant": "tenant_a", "source": "agent", "cost_usd": 1.0},
                          reviewer)
        self.assertEqual(row["tenant"], "tenant_b")
        self.assertEqual(row["dept"], "engineering")

    def test_negative_cost_is_rejected(self):
        with self.assertRaises(ValueError):
            cost.record(self.store, {"source": "agent", "cost_usd": -1}, resolve_identity(None, {}))


class SecretScanTests(PlatformCase):
    def test_secret_in_artifact_blocks_startup(self):
        settings = self.make_settings(PLATFORM_SECRET_SCAN="1")
        runs = Path(settings.runs_dir)
        runs.mkdir(parents=True, exist_ok=True)
        (runs / "run-1.json").write_text('{"authorization": "Bearer abcdefghijklmnop"}',
                                         encoding="utf-8")
        findings = releases.scan_for_secrets(settings)
        self.assertTrue(findings)
        self.assertEqual(findings[0]["rule"], "bearer_token")
        self.assertNotIn("abcdefghijklmnop", findings[0]["preview"])
        with self.assertRaises(releases.SecretInArtifact):
            releases.ensure_no_secrets(settings)

    def test_redacted_placeholder_and_clean_artifacts_pass(self):
        settings = self.make_settings(PLATFORM_SECRET_SCAN="1")
        runs = Path(settings.runs_dir)
        runs.mkdir(parents=True, exist_ok=True)
        (runs / "run-2.json").write_text('{"authorization": "Bearer [REDACTED]"}', encoding="utf-8")
        self.assertEqual(releases.scan_for_secrets(settings), [])
        releases.ensure_no_secrets(settings)


class IdentityTests(unittest.TestCase):
    def test_key_may_contain_colons(self):
        keys = parse_api_keys("svc:with:colons:tenant_z:ops:service")
        self.assertIn("svc:with:colons", keys)
        self.assertEqual(keys["svc:with:colons"].tenant, "tenant_z")
        self.assertTrue(keys["svc:with:colons"].is_service)

    def test_missing_key_is_401_when_keys_configured(self):
        with self.assertRaises(Unauthenticated):
            resolve_identity(None, parse_api_keys(KEYS))

    def test_no_keys_means_local_admin(self):
        identity = resolve_identity(None, {}, "tenant_local")
        self.assertEqual((identity.tenant, identity.role), ("tenant_local", "admin"))


# ---------------------------------------------------------------- HTTP


class HttpFixture:
    def __init__(self, store: Store, settings: Settings):
        self.httpd = ThreadingHTTPServer(("127.0.0.1", 0), handler_for(store, settings))
        self.httpd.daemon_threads = True
        self.port = self.httpd.server_address[1]
        self.thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)
        self.thread.start()

    def close(self):
        self.httpd.shutdown()
        self.httpd.server_close()

    def request(self, method: str, path: str, body=None, key: str | None = None,
                host: str | None = None):
        payload = None if body is None else json.dumps(body).encode("utf-8")
        headers = {"Content-Type": "application/json"} if payload is not None else {}
        if key:
            headers["Authorization"] = f"Bearer {key}"
        conn = http.client.HTTPConnection("127.0.0.1", self.port, timeout=10)
        if host is None:
            conn.request(method, path, body=payload, headers=headers)
        else:
            # Host 必须显式注入（skip_host），否则 http.client 会先写自己的 Host。
            conn.putrequest(method, path, skip_host=True, skip_accept_encoding=True)
            conn.putheader("Host", host)
            for name, value in headers.items():
                conn.putheader(name, value)
            if payload is not None:
                conn.putheader("Content-Length", str(len(payload)))
            conn.endheaders(payload)
        response = conn.getresponse()
        raw = response.read()
        conn.close()
        return response.status, raw, dict(response.getheaders())


class HttpTests(PlatformCase):
    def setUp(self):
        super().setUp()
        self.http = HttpFixture(self.store, self.settings)
        self.addCleanup(self.http.close)

    def json(self, status_body) -> dict:
        status, raw, _ = status_body
        self.assertIn(status, range(200, 300), raw)
        return json.loads(raw.decode("utf-8"))

    def test_health_and_metrics_are_public(self):
        status, raw, _ = self.http.request("GET", "/health")
        self.assertEqual(status, 200)
        self.assertEqual(json.loads(raw)["service"], "platform")
        status, raw, _ = self.http.request("GET", "/metrics")
        self.assertEqual(status, 200)
        self.assertIn("platform_pilot_ratio", raw.decode("utf-8"))

    def test_missing_key_is_401_and_audited(self):
        status, raw, _ = self.http.request("GET", "/v1/identities")
        self.assertEqual(status, 401)
        self.assertEqual(json.loads(raw)["error"]["code"], "UNAUTHENTICATED")
        actions = [item["action"] for item in self.store.audits(limit=10)]
        self.assertIn("auth_denied", actions)

    def test_identity_echo_never_leaks_full_key(self):
        data = self.json(self.http.request("GET", "/v1/identities", key="key-a"))
        self.assertEqual(data["identity"]["tenant"], "tenant_a")
        self.assertEqual(data["identity"]["key_prefix"], "key-a")
        self.assertNotIn("key-a:tenant_a", json.dumps(data))

    def test_release_flow_over_http(self):
        created = self.json(self.http.request("POST", "/v1/releases", {"version": "rel-http-1"}, key="key-a"))
        self.assertEqual(created["release"]["status"], "draft")
        status, raw, _ = self.http.request("POST", "/v1/releases/rel-http-1/publish", {}, key="key-a")
        self.assertEqual(status, 409)
        self.assertEqual(json.loads(raw)["error"]["code"], "RELEASE_NOT_CHECKED")

        checked = self.json(self.http.request("POST", "/v1/releases/rel-http-1/check", {}, key="key-a"))
        self.assertEqual(checked["status"], "checked")
        published = self.json(self.http.request("POST", "/v1/releases/rel-http-1/publish", {}, key="key-a"))
        self.assertEqual(published["route"]["stable"], "rel-http-1")

        # agent 读的就是这个端点：字段名必须与 RouteTable 一致。
        route = self.json(self.http.request("GET", "/v1/releases/route", key="key-service"))
        self.assertEqual(set(route) >= {"stable", "pilot", "pilot_ratio"}, True)

    def test_non_admin_cannot_publish_or_rollback(self):
        status, raw, _ = self.http.request("POST", "/v1/releases", {}, key="key-b")
        self.assertEqual(status, 403)
        status, raw, _ = self.http.request("POST", "/v1/releases/rollback", {}, key="key-b")
        self.assertEqual(status, 403)

    def test_budget_block_returns_429_with_retry_after(self):
        self.store.set_budget("tenant:tenant_a", "daily", 0.5, 0.8)
        self.json(self.http.request("POST", "/v1/usage",
                                    {"source": "agent", "cost_usd": 0.9}, key="key-a"))
        status, raw, headers = self.http.request(
            "GET", "/v1/budgets/check?scope=tenant:tenant_a", key="key-a")
        self.assertEqual(status, 429)
        body = json.loads(raw)
        self.assertFalse(body["allowed"])
        self.assertEqual(body["error"]["code"], "BUDGET_EXCEEDED")
        self.assertEqual(headers.get("Retry-After"), "600")
        actions = [item["action"] for item in self.store.audits(limit=20)]
        self.assertIn("budget_blocked", actions)

    def test_service_identity_may_check_other_tenants(self):
        self.store.set_budget("tenant:tenant_a", "daily", 0.5, 0.8)
        data = self.json(self.http.request(
            "GET", "/v1/budgets/check?scope=tenant:tenant_a", key="key-service"))
        self.assertTrue(data["allowed"])

    def test_cross_tenant_report_is_forbidden(self):
        status, raw, _ = self.http.request("GET", "/v1/cost/report?tenant=tenant_b", key="key-a")
        self.assertEqual(status, 403)
        self.assertEqual(json.loads(raw)["error"]["code"], "FORBIDDEN")
        actions = [item["action"] for item in self.store.audits(limit=10)]
        self.assertIn("tenant_violation", actions)

    def test_cost_report_markdown(self):
        self.json(self.http.request("POST", "/v1/usage",
                                    {"source": "agent", "cost_usd": None, "outcome": "unknown"},
                                    key="key-a"))
        status, raw, headers = self.http.request(
            "GET", "/v1/cost/report?format=md&groupBy=tenant", key="key-a")
        self.assertEqual(status, 200)
        self.assertIn("text/markdown", headers.get("Content-Type", ""))
        text = raw.decode("utf-8")
        self.assertIn("成本报表", text)
        self.assertIn("未知成本运行", text)

    def test_host_not_in_whitelist_is_rejected(self):
        status, raw, _ = self.http.request("GET", "/v1/identities", key="key-a",
                                           host="evil.example.com")
        self.assertEqual(status, 403)
        self.assertEqual(json.loads(raw)["error"]["code"], "HOST_REJECTED")

    def test_audit_endpoint_is_tenant_scoped(self):
        self.json(self.http.request("POST", "/v1/releases", {"version": "rel-http-2"}, key="key-a"))
        own = self.json(self.http.request("GET", "/v1/audit?limit=10", key="key-a"))
        self.assertTrue(own["items"])
        self.assertTrue(all(item["tenant"] == "tenant_a" for item in own["items"] if item["tenant"]))
        status, _, _ = self.http.request("GET", "/v1/audit?tenant=tenant_a", key="key-b")
        self.assertEqual(status, 403)

    def test_replay_requires_run_id(self):
        status, raw, _ = self.http.request("POST", "/v1/replays", {}, key="key-a")
        self.assertEqual(status, 400)


def _rm(path: Path) -> None:
    if not path.exists():
        return
    for item in sorted(path.rglob("*"), reverse=True):
        if item.is_file():
            item.unlink()
        elif item.is_dir():
            item.rmdir()
    path.rmdir()


if __name__ == "__main__":
    unittest.main()
