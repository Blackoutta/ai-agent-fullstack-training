"""平台状态：一个 SQLite 文件装发布单、路由、用量、预算、审计与回放。

为什么不用内存字典：发布单和用量是「重启之后还要算账」的东西。
容器随时可能被重建，而这些数据决定了下次启动时 agent 跑哪个版本、预算还剩多少。

两张表的口径要记住：

- `usage.cost_usd` 允许 NULL —— NULL 表示「上报方也说不清」，聚合时单独计数，
  绝不当 0 合并（否则预算永远不触发、报表永远漂亮）。
- `audit` 只追加（append-only）：不提供 update/delete 方法，回滚和越权都要留痕。
"""
from __future__ import annotations

import json
import sqlite3
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path

from .identity import Identity

SCHEMA = """
CREATE TABLE IF NOT EXISTS releases (
    version TEXT PRIMARY KEY, status TEXT NOT NULL, manifest TEXT NOT NULL,
    fingerprint TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL);

CREATE TABLE IF NOT EXISTS release_checks (
    version TEXT NOT NULL, case_id TEXT NOT NULL, ok INTEGER NOT NULL,
    detail TEXT, duration_ms REAL, created_at TEXT NOT NULL,
    PRIMARY KEY(version, case_id));

CREATE TABLE IF NOT EXISTS routes (
    id TEXT PRIMARY KEY, stable TEXT, pilot TEXT, pilot_ratio REAL NOT NULL DEFAULT 0,
    updated_at TEXT NOT NULL);

CREATE TABLE IF NOT EXISTS usage (
    id TEXT PRIMARY KEY, run_id TEXT, experiment_id TEXT,
    tenant TEXT NOT NULL, dept TEXT NOT NULL DEFAULT '',
    model TEXT, strategy TEXT, source TEXT NOT NULL, mode TEXT, outcome TEXT,
    input_tokens INTEGER, output_tokens INTEGER, cache_tokens INTEGER, total_tokens INTEGER,
    cost_usd REAL, seconds REAL, occurred_at TEXT NOT NULL, day TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS usage_day_tenant ON usage(day, tenant);
CREATE INDEX IF NOT EXISTS usage_dept ON usage(tenant, dept, day);

CREATE TABLE IF NOT EXISTS budgets (
    scope TEXT PRIMARY KEY, period TEXT NOT NULL, limit_usd REAL, warn_ratio REAL,
    updated_at TEXT NOT NULL);

CREATE TABLE IF NOT EXISTS audit (
    id INTEGER PRIMARY KEY AUTOINCREMENT, action TEXT NOT NULL,
    tenant TEXT, dept TEXT, role TEXT, key_prefix TEXT,
    detail TEXT, created_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS audit_created ON audit(created_at);

CREATE TABLE IF NOT EXISTS replays (
    id TEXT PRIMARY KEY, run_id TEXT NOT NULL, tenant TEXT NOT NULL,
    ok INTEGER NOT NULL, status TEXT, report TEXT, created_at TEXT NOT NULL);
"""

ROUTE_ID = "current"


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def utc_day() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")


class Store:
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock()
        self.db = sqlite3.connect(self.path, check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.executescript(SCHEMA)
        self.db.commit()

    # ------------------------------------------------------------ 通用

    def _write(self, sql: str, params: tuple = ()) -> None:
        with self.lock, self.db:
            self.db.execute(sql, params)

    def _rows(self, sql: str, params: tuple = ()) -> list[sqlite3.Row]:
        with self.lock:
            return self.db.execute(sql, params).fetchall()

    def _one(self, sql: str, params: tuple = ()):
        rows = self._rows(sql, params)
        return rows[0] if rows else None

    # ------------------------------------------------------------ 发布单

    def put_release(self, version: str, status: str, manifest: dict, fingerprint: str | None) -> dict:
        now = utc_now()
        payload = json.dumps(manifest, ensure_ascii=False, sort_keys=True)
        with self.lock, self.db:
            existing = self.db.execute("SELECT version FROM releases WHERE version=?", (version,)).fetchone()
            if existing:
                self.db.execute("UPDATE releases SET status=?, manifest=?, fingerprint=?, updated_at=? "
                                "WHERE version=?", (status, payload, fingerprint, now, version))
            else:
                self.db.execute("INSERT INTO releases(version,status,manifest,fingerprint,created_at,updated_at) "
                                "VALUES (?,?,?,?,?,?)", (version, status, payload, fingerprint, now, now))
        return {"version": version, "status": status, "manifest": manifest,
                "fingerprint": fingerprint, "created_at": now, "updated_at": now}

    def release(self, version: str) -> dict:
        row = self._one("SELECT * FROM releases WHERE version=?", (version,))
        if not row:
            raise KeyError(f"发布单不存在：{version}")
        return {"version": row["version"], "status": row["status"],
                "manifest": json.loads(row["manifest"]), "fingerprint": row["fingerprint"],
                "created_at": row["created_at"], "updated_at": row["updated_at"]}

    def releases(self) -> list[dict]:
        return [{"version": row["version"], "status": row["status"],
                 "fingerprint": row["fingerprint"], "created_at": row["created_at"],
                 "updated_at": row["updated_at"]}
                for row in self._rows("SELECT * FROM releases ORDER BY created_at DESC, version DESC")]

    def set_release_status(self, version: str, status: str) -> None:
        self._write("UPDATE releases SET status=?, updated_at=? WHERE version=?", (status, utc_now(), version))

    # ------------------------------------------------------------ 验收探针

    def clear_checks(self, version: str) -> None:
        self._write("DELETE FROM release_checks WHERE version=?", (version,))

    def put_check(self, version: str, case_id: str, ok: bool, detail: str, duration_ms: float) -> dict:
        self._write("INSERT INTO release_checks(version,case_id,ok,detail,duration_ms,created_at) "
                    "VALUES (?,?,?,?,?,?) ON CONFLICT(version,case_id) DO UPDATE SET "
                    "ok=excluded.ok, detail=excluded.detail, duration_ms=excluded.duration_ms, "
                    "created_at=excluded.created_at",
                    (version, case_id, 1 if ok else 0, detail, duration_ms, utc_now()))
        return {"id": case_id, "ok": ok, "detail": detail, "duration_ms": duration_ms}

    def checks(self, version: str) -> list[dict]:
        return [{"id": row["case_id"], "ok": bool(row["ok"]), "detail": row["detail"],
                 "duration_ms": row["duration_ms"], "created_at": row["created_at"]}
                for row in self._rows("SELECT * FROM release_checks WHERE version=? ORDER BY case_id", (version,))]

    # ------------------------------------------------------------ 路由

    def route(self) -> dict:
        row = self._one("SELECT * FROM routes WHERE id=?", (ROUTE_ID,))
        if not row:
            # 还没发布过：路由为空，agent 会用自己的兜底（unreleased）。
            return {"stable": None, "pilot": None, "pilot_ratio": 0.0, "updated_at": None}
        return {"stable": row["stable"], "pilot": row["pilot"],
                "pilot_ratio": row["pilot_ratio"] or 0.0, "updated_at": row["updated_at"]}

    def set_route(self, stable: str | None, pilot: str | None, pilot_ratio: float) -> dict:
        now = utc_now()
        self._write("INSERT INTO routes(id,stable,pilot,pilot_ratio,updated_at) VALUES (?,?,?,?,?) "
                    "ON CONFLICT(id) DO UPDATE SET stable=excluded.stable, pilot=excluded.pilot, "
                    "pilot_ratio=excluded.pilot_ratio, updated_at=excluded.updated_at",
                    (ROUTE_ID, stable, pilot, bubble_ratio(pilot_ratio), now))
        return self.route()

    # ------------------------------------------------------------ 用量

    def add_usage(self, row: dict) -> dict:
        value = {"id": uuid.uuid4().hex[:16], "occurred_at": utc_now(),
                 "day": row.get("day") or utc_day(), **row}
        self._write("INSERT INTO usage(id,run_id,experiment_id,tenant,dept,model,strategy,source,mode,"
                    "outcome,input_tokens,output_tokens,cache_tokens,total_tokens,cost_usd,seconds,"
                    "occurred_at,day) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (value.get("id"), value.get("run_id"), value.get("experiment_id"),
                     value["tenant"], value.get("dept") or "", value.get("model"), value.get("strategy"),
                     value["source"], value.get("mode"), value.get("outcome"),
                     value.get("input_tokens"), value.get("output_tokens"), value.get("cache_tokens"),
                     value.get("total_tokens"), value.get("cost_usd"), value.get("seconds"),
                     value["occurred_at"], value["day"]))
        return value

    def usage(self, tenant: str | None = None, since: str | None = None) -> list[dict]:
        clauses, params = [], []
        if tenant:
            clauses.append("tenant=?")
            params.append(tenant)
        if since:
            clauses.append("day>=?")
            params.append(since)
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        return [dict(row) for row in self._rows(
            f"SELECT * FROM usage {where} ORDER BY occurred_at", tuple(params))]

    # ------------------------------------------------------------ 预算

    def set_budget(self, scope: str, period: str, limit_usd: float | None, warn_ratio: float | None) -> dict:
        self._write("INSERT INTO budgets(scope,period,limit_usd,warn_ratio,updated_at) VALUES (?,?,?,?,?) "
                    "ON CONFLICT(scope) DO UPDATE SET period=excluded.period, limit_usd=excluded.limit_usd, "
                    "warn_ratio=excluded.warn_ratio, updated_at=excluded.updated_at",
                    (scope, period, limit_usd, warn_ratio, utc_now()))
        return {"scope": scope, "period": period, "limit_usd": limit_usd, "warn_ratio": warn_ratio}

    def budget(self, scope: str) -> dict | None:
        row = self._one("SELECT * FROM budgets WHERE scope=?", (scope,))
        if not row:
            return None
        return {"scope": row["scope"], "period": row["period"],
                "limit_usd": row["limit_usd"], "warn_ratio": row["warn_ratio"],
                "updated_at": row["updated_at"]}

    def budgets(self) -> list[dict]:
        return [{"scope": row["scope"], "period": row["period"], "limit_usd": row["limit_usd"],
                 "warn_ratio": row["warn_ratio"], "updated_at": row["updated_at"]}
                for row in self._rows("SELECT * FROM budgets ORDER BY scope")]

    # ------------------------------------------------------------ 审计

    def audit(self, action: str, identity: Identity | None, detail: dict | None = None) -> dict:
        value = {"action": action, "tenant": identity.tenant if identity else None,
                 "dept": identity.dept if identity else None,
                 "role": identity.role if identity else None,
                 "key_prefix": identity.key_prefix if identity else None,
                 "detail": json.dumps(detail or {}, ensure_ascii=False, sort_keys=True),
                 "created_at": utc_now()}
        self._write("INSERT INTO audit(action,tenant,dept,role,key_prefix,detail,created_at) "
                    "VALUES (?,?,?,?,?,?,?)",
                    (value["action"], value["tenant"], value["dept"], value["role"],
                     value["key_prefix"], value["detail"], value["created_at"]))
        return value

    def audits(self, limit: int = 50, tenant: str | None = None, action: str | None = None) -> list[dict]:
        clauses, params = [], []
        if tenant:
            clauses.append("tenant=?")
            params.append(tenant)
        if action:
            clauses.append("action=?")
            params.append(action)
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        params.append(max(1, min(int(limit), 500)))
        rows = self._rows(f"SELECT * FROM audit {where} ORDER BY id DESC LIMIT ?", tuple(params))
        return [{"action": row["action"], "tenant": row["tenant"], "dept": row["dept"],
                 "role": row["role"], "key_prefix": row["key_prefix"],
                 "detail": json.loads(row["detail"] or "{}"), "created_at": row["created_at"]}
                for row in rows]

    # ------------------------------------------------------------ 回放

    def add_replay(self, run_id: str, tenant: str, ok: bool, status: str, report: dict) -> dict:
        value = {"id": uuid.uuid4().hex[:16], "run_id": run_id, "tenant": tenant, "ok": ok,
                 "status": status, "report": report, "created_at": utc_now()}
        self._write("INSERT INTO replays(id,run_id,tenant,ok,status,report,created_at) VALUES (?,?,?,?,?,?,?)",
                    (value["id"], run_id, tenant, 1 if ok else 0, status,
                     json.dumps(report, ensure_ascii=False, sort_keys=True), value["created_at"]))
        return value

    def replays(self, tenant: str | None = None, limit: int = 20) -> list[dict]:
        clauses, params = [], []
        if tenant:
            clauses.append("tenant=?")
            params.append(tenant)
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        params.append(max(1, min(int(limit), 200)))
        rows = self._rows(f"SELECT * FROM replays {where} ORDER BY created_at DESC LIMIT ?", tuple(params))
        return [{"id": row["id"], "run_id": row["run_id"], "tenant": row["tenant"],
                 "ok": bool(row["ok"]), "status": row["status"],
                 "report": json.loads(row["report"] or "{}"), "created_at": row["created_at"]}
                for row in rows]

    def close(self) -> None:
        with self.lock:
            self.db.close()


def bubble_ratio(value) -> float:
    """比例只接受 0..100，越界就夹住——路由不该因为一个手滑的 120 把流量全切走。"""
    try:
        number = float(value)
    except (TypeError, ValueError):
        return 0.0
    if number != number:  # NaN
        return 0.0
    return max(0.0, min(100.0, number))
