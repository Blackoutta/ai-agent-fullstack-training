"""平台配置：只从环境变量读，不读 .env、不落库。

配置里没有一件「可推导」的东西：路径、端口、模型别名、预算上限都由编排注入。
这样做的好处是容器里看到的行为等于 compose 里的声明，不会出现「本地能跑、容器里
悄悄用了另一份配置」。
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


def _path(key: str, default: str) -> Path:
    return Path(os.environ.get(key, default) or default)


def _number(key: str, default: float | None) -> float | None:
    raw = os.environ.get(key)
    if raw is None or raw.strip() == "":
        return default
    try:
        value = float(raw)
    except ValueError:
        return default
    return value if value >= 0 else default


def _flag(key: str, default: bool) -> bool:
    raw = os.environ.get(key)
    if raw is None or raw.strip() == "":
        return default
    return raw.strip().lower() not in {"0", "false", "no", "off"}


@dataclass(frozen=True)
class Settings:
    port: int
    db_path: Path
    runs_dir: Path
    releases_dir: Path
    corpus_dir: Path
    gateway_config: Path
    agent_config: Path
    prompts_config: Path
    grants_path: Path
    eval_source: Path
    gateway_model: str
    gateway_upstream: str
    collection: str
    embed_model: str
    agent_url: str
    retrieval_url: str
    eval_url: str
    api_keys: str
    local_tenant: str
    budget_tenant_daily: float | None
    budget_dept_daily: float | None
    budget_warn_ratio: float
    secret_scan: bool
    allowed_hosts: str

    @classmethod
    def load(cls) -> "Settings":
        return cls(
            port=int(os.environ.get("PLATFORM_PORT", "8090")),
            db_path=_path("PLATFORM_DB", "data/platform.db"),
            runs_dir=_path("PLATFORM_RUNS_DIR", "runs"),
            releases_dir=_path("PLATFORM_RELEASES_DIR", "releases"),
            corpus_dir=_path("PLATFORM_CORPUS_DIR", "corpus"),
            gateway_config=_path("PLATFORM_GATEWAY_CONFIG", "services/gateway/litellm.config.yaml"),
            agent_config=_path("PLATFORM_AGENT_CONFIG", "services/agent/config/platform.yaml"),
            prompts_config=_path("PLATFORM_PROMPTS", "services/agent/config/prompts.yaml"),
            grants_path=_path("PLATFORM_GRANTS", "services/retrieval/config/grants.json"),
            eval_source=_path("PLATFORM_EVAL_SOURCE", "codebaseEval/backend"),
            gateway_model=os.environ.get("PLATFORM_GATEWAY_MODEL", "deepseek-flash"),
            gateway_upstream=os.environ.get("GATEWAY_UPSTREAM_MODEL", "deepseek-v4-flash"),
            collection=os.environ.get("COLLECTION", "login_demo_chunks"),
            embed_model=os.environ.get("EMBED_MODEL", "embo-01"),
            agent_url=(os.environ.get("PLATFORM_AGENT_URL") or "").rstrip("/"),
            retrieval_url=(os.environ.get("PLATFORM_RETRIEVAL_URL") or "").rstrip("/"),
            eval_url=(os.environ.get("PLATFORM_EVAL_URL") or "").rstrip("/"),
            api_keys=os.environ.get("PLATFORM_API_KEYS", ""),
            local_tenant=os.environ.get("DEMO_TENANT", "public") or "public",
            budget_tenant_daily=_number("BUDGET_TENANT_DAILY_USD", 5.0),
            budget_dept_daily=_number("BUDGET_DEPT_DAILY_USD", 3.0),
            budget_warn_ratio=min(1.0, max(0.0, _number("BUDGET_WARN_RATIO", 0.8) or 0.8)),
            secret_scan=_flag("PLATFORM_SECRET_SCAN", True),
            allowed_hosts=os.environ.get("PLATFORM_ALLOWED_HOSTS", "localhost,127.0.0.1,platform"),
        )
