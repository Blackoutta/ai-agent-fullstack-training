"""成本与预算：只用上报来的事实算账，缺的单独计数，不当 0。

三个口径问题在这里被钉死，因为它们最容易在报表里骗人：

1. **未知不等于免费**。`cost_usd = NULL` 的运行计入 `unknown_cost_runs`，
   不进 `known_cost_usd`；如果按 0 合并，预算永远不触发。
2. **平台不算价**。单价在发布单与策略里，上报方按它算好再上报；
   平台重算就会出现「两份价格、两个数」。
3. **预算按天/按月取当期用量**。`daily` 从当天 0 点（UTC）起算，
   `monthly` 从当月 1 日起算；范围之外的用量不参与判定。
"""
from __future__ import annotations

from datetime import date, datetime, timezone

from .identity import Identity
from .store import Store, utc_day

GROUP_FIELDS = {
    "tenant": ("tenant",),
    "dept": ("tenant", "dept"),
    "model": ("model",),
    "strategy": ("strategy",),
    "day": ("day",),
}
BUDGET_KINDS = ("tenant", "dept", "experiment")


def _int_or_none(value, field: str):
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError(f"{field} 必须为非负整数或 null")
    return value


def _float_or_none(value, field: str):
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, (int, float)) or value < 0 or value != value:
        raise ValueError(f"{field} 必须为非负数或 null")
    return float(value)


def record(store: Store, payload: dict, identity: Identity) -> dict:
    """把一条用量落库。只有 service 身份能代表别的租户/部门上报。"""
    if not isinstance(payload, dict):
        raise ValueError("用量必须是 JSON 对象")
    source = str(payload.get("source") or "unknown")[:32]
    if identity.is_service:
        tenant = str(payload.get("tenant") or identity.tenant).strip()
        dept = str(payload.get("dept") or "").strip()
    else:
        # 普通调用方只能记自己的账：否则任何人都能把成本甩到别的租户头上。
        tenant = identity.tenant
        dept = identity.dept
    if not tenant:
        raise ValueError("tenant 不能为空")
    row = {
        "run_id": str(payload.get("run_id") or "")[:64] or None,
        "experiment_id": str(payload.get("experiment_id") or "")[:64] or None,
        "tenant": tenant, "dept": dept[:64],
        "model": str(payload.get("model") or "")[:64] or None,
        "strategy": str(payload.get("strategy") or "")[:120] or None,
        "source": source,
        "mode": str(payload.get("mode") or "")[:16] or None,
        "outcome": str(payload.get("outcome") or "unknown")[:16],
        "input_tokens": _int_or_none(payload.get("input_tokens"), "input_tokens"),
        "output_tokens": _int_or_none(payload.get("output_tokens"), "output_tokens"),
        "cache_tokens": _int_or_none(payload.get("cache_tokens"), "cache_tokens"),
        "total_tokens": _int_or_none(payload.get("total_tokens"), "total_tokens"),
        "cost_usd": _float_or_none(payload.get("cost_usd"), "cost_usd"),
        "seconds": _float_or_none(payload.get("seconds"), "seconds"),
    }
    return store.add_usage(row)


def summarize(rows: list[dict]) -> dict:
    known_cost = 0.0
    unknown_cost = 0
    known_tokens = 0
    unknown_tokens = 0
    seconds = []
    for row in rows:
        if row.get("cost_usd") is None:
            unknown_cost += 1
        else:
            known_cost += row["cost_usd"]
        if row.get("total_tokens") is None:
            unknown_tokens += 1
        else:
            known_tokens += row["total_tokens"]
        if row.get("seconds") is not None:
            seconds.append(row["seconds"])
    return {"runs": len(rows), "known_cost_usd": round(known_cost, 8),
            "unknown_cost_runs": unknown_cost,
            "known_tokens": known_tokens, "unknown_token_runs": unknown_tokens,
            "mean_seconds": round(sum(seconds) / len(seconds), 4) if seconds else None}


def report(store: Store, group_by: str = "tenant", tenant: str | None = None,
           days: int | None = None) -> dict:
    if group_by not in GROUP_FIELDS:
        raise ValueError(f"groupBy 只能是 {', '.join(GROUP_FIELDS)}")
    since = _since(days)
    rows = store.usage(tenant=tenant, since=since)
    groups: dict[tuple, list[dict]] = {}
    for row in rows:
        key = tuple(row.get(field) or ("(未标注)" if field != "day" else "") for field in GROUP_FIELDS[group_by])
        groups.setdefault(key, []).append(row)
    items = []
    for key, subset in groups.items():
        summary = summarize(subset)
        label = " / ".join(str(part) for part in key if part != "") or "(空)"
        items.append({"group": label, **{field: value for field, value in zip(GROUP_FIELDS[group_by], key)},
                      **summary})
    items.sort(key=lambda item: (-item["known_cost_usd"], item["group"]))
    return {"generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "group_by": group_by, "tenant_filter": tenant, "since_day": since,
            "totals": summarize(rows), "groups": items,
            "budgets": store.budgets(),
            "note": "cost_usd 为 null 的运行计入 unknown_cost_runs；成本由上报方按发布单价格计算，平台只聚合"}


def markdown(report_value: dict) -> str:
    totals = report_value["totals"]
    lines = [
        "# 成本报表",
        "",
        f"- 生成时间：{report_value['generated_at']}",
        f"- 分组维度：`{report_value['group_by']}`"
        + (f"（租户过滤：{report_value['tenant_filter']}）" if report_value.get("tenant_filter") else ""),
        f"- 统计范围：{report_value.get('since_day') or '全部'} 起",
        "",
        "## 汇总",
        "",
        "| 运行数 | 已知成本 USD | 未知成本运行 | 已知 tokens | 未知 token 运行 |",
        "|---|---|---|---|---|",
        f"| {totals['runs']} | {totals['known_cost_usd']:.6f} | {totals['unknown_cost_runs']} | "
        f"{totals['known_tokens']} | {totals['unknown_token_runs']} |",
        "",
        "## 分组明细",
        "",
        "| 分组 | 运行数 | 已知成本 USD | 未知成本运行 | 已知 tokens |",
        "|---|---|---|---|---|",
    ]
    for item in report_value["groups"]:
        lines.append(f"| {item['group']} | {item['runs']} | {item['known_cost_usd']:.6f} | "
                     f"{item['unknown_cost_runs']} | {item['known_tokens']} |")
    if not report_value["groups"]:
        lines.append("| （无用量） | 0 | 0.000000 | 0 | 0 |")
    lines += ["", f"> {report_value['note']}", ""]
    return "\n".join(lines)


def budget_state(store: Store, settings, scopes: list[str]) -> dict:
    """逐个 scope 判定；任一超限即不允许，并把第一个超限的 scope 回给调用方。"""
    results, allowed, blocked, warning = [], True, None, False
    for scope in scopes:
        kind, _, ident = scope.partition(":")
        if kind not in BUDGET_KINDS or not ident:
            raise ValueError(f"未知预算 scope：{scope}（支持 {', '.join(BUDGET_KINDS)}）")
        override = store.budget(scope)
        period = (override or {}).get("period") or "daily"
        limit = (override or {}).get("limit_usd")
        if limit is None:
            limit = settings.budget_tenant_daily if kind == "tenant" else \
                settings.budget_dept_daily if kind == "dept" else None
        warn_ratio = (override or {}).get("warn_ratio")
        if warn_ratio is None:
            warn_ratio = settings.budget_warn_ratio
        rows = _scope_rows(store, scope, period)
        summary = summarize(rows)
        spent = summary["known_cost_usd"]
        if limit is None:
            state, ratio = "unlimited", None
        else:
            ratio = round(spent / limit, 4) if limit > 0 else None
            if spent >= limit:
                state = "exceeded"
            elif limit > 0 and spent / limit >= warn_ratio:
                state = "warning"
            else:
                state = "ok"
        if state == "exceeded":
            allowed = False
            blocked = blocked or scope
        if state == "warning":
            warning = True
        results.append({"scope": scope, "period": period, "state": state,
                        "spent_usd": spent, "limit_usd": limit, "ratio": ratio,
                        "unknown_cost_runs": summary["unknown_cost_runs"],
                        "runs": summary["runs"]})
    return {"allowed": allowed, "scope": blocked, "warning": warning, "scopes": results,
            "note": "spent_usd 只含已知成本；unknown_cost_runs 表示这段时间里有运行没报成本"}


def _scope_rows(store: Store, scope: str, period: str) -> list[dict]:
    since = _period_start(period)
    kind, _, ident = scope.partition(":")
    if kind == "tenant":
        return store.usage(tenant=ident, since=since)
    if kind == "dept":
        tenant, _, dept = ident.partition("/")
        if not tenant or not dept:
            raise ValueError("dept scope 必须形如 dept:<tenant>/<dept>")
        return [row for row in store.usage(tenant=tenant, since=since) if (row.get("dept") or "") == dept]
    return [row for row in store.usage(since=since) if (row.get("experiment_id") or "") == ident]


def _period_start(period: str) -> str:
    today = date.today()
    if period == "daily":
        return today.isoformat()
    if period == "monthly":
        return today.replace(day=1).isoformat()
    raise ValueError("period 只能是 daily 或 monthly")


def _since(days: int | None) -> str | None:
    if not days:
        return None
    if isinstance(days, bool) or not isinstance(days, int) or days < 1 or days > 366:
        raise ValueError("days 必须是 1 到 366 的整数")
    from datetime import timedelta
    return (date.today() - timedelta(days=days - 1)).isoformat()


def today() -> str:
    return utc_day()
