"""发布单、离线探针与灰度路由（`design/architecture.md` §4）。

三件事必须留在控制面，而不是散在各服务里：

1. **发布单是一个事实，不是一份文档**。`draft` 把「这次要上线的到底是什么」固化成
   manifest：模型别名、prompt 哈希、评测策略、检索与语料指纹。任何一项变了，哈希就变，
   回放才有意义。
2. **探针全离线**。`check` 不碰网络：读配置、算哈希、跑一遍脱敏样例。发布门禁如果依赖
   gateway 在线，就会在最需要发布的时候被网络挡住。
3. **路由只有一列真值**。`stable` / `pilot` / `pilot_ratio` 存 SQLite 并落盘
   `releases/route.json`：控制面挂了，agent 读文件也能选对版本。

状态机：`draft → checked → published`；检查失败落 `failed`，回滚把被撤下的版本标
`rolled_back`。`publish` 只接受 `checked`——没跑过探针的版本不能让流量进来。
"""
from __future__ import annotations

import hashlib
import json
import re
import time
from datetime import datetime, timezone
from pathlib import Path

from .identity import Identity
from .redaction import Redactor
from .store import Store, utc_now

DRAFT = "draft"
CHECKED = "checked"
PUBLISHED = "published"
FAILED = "failed"
ROLLED_BACK = "rolled_back"

DEFAULT_CASES = (
    {"id": "gateway-config", "probe": "offline"},
    {"id": "agent-config", "probe": "offline"},
    {"id": "retrieval-grants", "probe": "offline"},
    {"id": "redaction-sample", "probe": "offline"},
)

SECRET_RULES = (
    ("openai_key", re.compile(r"sk-[A-Za-z0-9]{12,}")),
    ("bearer_token", re.compile(r"\bBearer\s+(?!\[REDACTED\])([A-Za-z0-9._\-]{8,})")),
)
SCAN_DIRS = ("runs_dir", "releases_dir")
SCAN_MAX_BYTES = 2 * 1024 * 1024


class ReleaseNotChecked(Exception):
    """状态机拒绝：只有跑过探针且全部通过的版本才能发布 → 409。"""


class ReleaseUnknown(KeyError):
    """版本不存在 → 404（KeyError 子类，复用统一错误映射）。"""


class SecretInArtifact(RuntimeError):
    """产物目录里出现了疑似密钥 → 拒绝启动。"""


# ---------------------------------------------------------------- 指纹


def sha256_bytes(data: bytes) -> str:
    return "sha256:" + hashlib.sha256(data).hexdigest()


def file_hash(path) -> dict:
    path = Path(path)
    if not path.is_file():
        return {"path": str(path), "exists": False, "sha256": None}
    return {"path": str(path), "exists": True, "sha256": sha256_bytes(path.read_bytes())}


def dir_fingerprint(path, suffixes=(".py",)) -> str:
    """对目录做稳定指纹：按相对路径排序后逐个 hash，文件名算进摘要。"""
    root = Path(path)
    if not root.is_dir():
        return "missing"
    digest = hashlib.sha256()
    for item in sorted(root.rglob("*")):
        if not item.is_file() or item.suffix not in suffixes:
            continue
        digest.update(str(item.relative_to(root)).encode("utf-8"))
        digest.update(b"\0")
        digest.update(item.read_bytes())
        digest.update(b"\0")
    return "sha256:" + digest.hexdigest()


def corpus_fingerprint(corpus_dir) -> str:
    """语料指纹只覆盖内容与相对路径，不看 mtime——否则重新挂载一次卷就全量漂移。"""
    return dir_fingerprint(corpus_dir, suffixes=(".md", ".txt", ".py", ".json", ".yaml", ".yml", ".pdf"))


def _agent_tools_version(agent_config_text: str) -> str:
    """从 allowlist 里数工具个数：工具集是 agent 行为契约的一部分，变了要能看出来。"""
    index = agent_config_text.find("agent_tool_allowlist:")
    if index < 0:
        return "tools-unknown"
    block = agent_config_text[index:].split("sandbox:")[0]
    count = len(re.findall(r"^\s{4,}-\s+\S+", block, re.MULTILINE))
    digest = hashlib.sha256(block.encode("utf-8")).hexdigest()[:12]
    return f"tools-v{count}-{digest}"


# ---------------------------------------------------------------- 草稿


def default_version(store: Store) -> str:
    """`rel-YYYY.MM.DD.N`：同日递增，不依赖外部时钟之外的任何状态。"""
    day = datetime.now(timezone.utc).strftime("%Y.%m.%d")
    prefix = f"rel-{day}."
    used = {item["version"] for item in store.releases() if item["version"].startswith(prefix)}
    n = 1
    while f"{prefix}{n}" in used:
        n += 1
    return f"{prefix}{n}"


def draft(store: Store, settings, version: str | None = None,
          components: dict | None = None, cases: list | None = None) -> dict:
    agent_text = _read(settings.agent_config)
    manifest = {
        "version": version or default_version(store),
        "created_at": utc_now(),
        "components": {
            "gateway": {
                "model_alias": settings.gateway_model,
                "upstream": settings.gateway_upstream,
                "config_hash": file_hash(settings.gateway_config)["sha256"],
            },
            "agent": {
                "prompt_name": "codebase.agent",
                "prompt_version": "v1",
                "prompt_hash": file_hash(settings.prompts_config)["sha256"],
                "config_hash": file_hash(settings.agent_config)["sha256"],
                "model_alias": settings.gateway_model,
                "tools_version": _agent_tools_version(agent_text),
            },
            "eval": {
                "strategy_ids": _eval_strategies(),
                "strategy_hash": dir_fingerprint(settings.eval_source),
            },
            "retrieval": {
                "collection": settings.collection,
                "corpus_hash": corpus_fingerprint(settings.corpus_dir),
                "embed_model": settings.embed_model,
                "grants_hash": file_hash(settings.grants_path)["sha256"],
            },
        },
        "acceptance": {"cases": _normalize_cases(cases)},
        # 探针只读配置，把「发布时看到的内容」也留一份摘要，方便事后追查飘移。
        "sources": {
            "gateway_config": str(settings.gateway_config),
            "agent_config": str(settings.agent_config),
            "prompts_config": str(settings.prompts_config),
            "grants": str(settings.grants_path),
            "corpus_dir": str(settings.corpus_dir),
        },
    }
    if components:
        for key, value in components.items():
            if isinstance(value, dict):
                manifest["components"].setdefault(key, {}).update(value)
    # 配置读不到不在这里拒绝：草稿允许存在，check 会用探针明确报出缺哪个文件。
    return manifest


def _normalize_cases(cases: list | None) -> list:
    if not cases:
        return [dict(item) for item in DEFAULT_CASES]
    normalized = []
    for item in cases:
        if isinstance(item, str):
            normalized.append({"id": item, "probe": "offline"})
        elif isinstance(item, dict) and item.get("id"):
            normalized.append({"id": str(item["id"]), "probe": str(item.get("probe") or "offline"),
                               **{k: v for k, v in item.items() if k not in {"id", "probe"}}})
        else:
            raise ValueError("acceptance.cases 每项必须是字符串或含 id 的对象")
    return normalized


def _eval_strategies() -> list:
    import os

    raw = os.environ.get("EVAL_STRATEGY_IDS", "direct,rag")
    return [item.strip() for item in raw.split(",") if item.strip()]


def _read(path) -> str:
    try:
        return Path(path).read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return ""


def write_manifest(releases_dir, manifest: dict) -> dict:
    """同时写 json 与 yaml：agent 读 json（快），人读 yaml（git diff 好看）。

    JSON 是 YAML 1.2 的子集，所以 yaml 文件直接写同一份 JSON 文本仍然是合法 YAML，
    不需要引入 PyYAML——冲突时以 json 为准，yaml 只是给人看的镜像。
    """
    root = Path(releases_dir) / manifest["version"]
    root.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    json_path = root / "manifest.json"
    yaml_path = root / "manifest.yaml"
    json_path.write_text(payload, encoding="utf-8")
    yaml_path.write_text(payload, encoding="utf-8")
    return {"dir": str(root), "json": str(json_path), "yaml": str(yaml_path)}


def write_route(releases_dir, route_table: dict) -> str:
    """落盘给 agent 兜底：控制面不可达时读这个文件，不猜。"""
    root = Path(releases_dir)
    root.mkdir(parents=True, exist_ok=True)
    path = root / "route.json"
    path.write_text(json.dumps(route_table, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
                    encoding="utf-8")
    return str(path)


# ---------------------------------------------------------------- 探针


def run_probes(manifest: dict, settings) -> list:
    probes = {
        "gateway-config": _probe_gateway,
        "agent-config": _probe_agent,
        "retrieval-grants": _probe_grants,
        "redaction-sample": _probe_redaction,
    }
    results = []
    for case in manifest.get("acceptance", {}).get("cases", []):
        case_id = case.get("id")
        started = time.perf_counter()
        handler = probes.get(case_id)
        if handler is None:
            ok, detail = False, f"未知探针：{case_id}"
        else:
            try:
                ok, detail = handler(manifest, settings, case)
            except Exception as exc:  # 探针自身炸了也是「不通过」，不能把发布放过去
                ok, detail = False, f"{type(exc).__name__}: {exc}"
        results.append({"id": case_id, "ok": bool(ok), "detail": detail,
                        "duration_ms": round((time.perf_counter() - started) * 1000, 2)})
    return results


def _probe_gateway(manifest: dict, settings, case: dict) -> tuple:
    text = _read(settings.gateway_config)
    if not text:
        return False, f"读不到网关配置：{settings.gateway_config}"
    alias = manifest["components"]["gateway"]["model_alias"]
    upstream = manifest["components"]["gateway"]["upstream"]
    missing = [item for item in (alias, upstream) if item not in text]
    if missing:
        return False, f"网关配置缺少模型声明：{', '.join(missing)}"
    if not re.search(r"api_key:\s*os\.environ/", text):
        # 密钥必须由环境注入；内联密钥会跟着镜像和 git 一起扩散。
        return False, "网关 api_key 不是 os.environ/ 形式"
    if re.search(r"sk-[A-Za-z0-9]{12,}", text):
        return False, "网关配置里出现疑似内联密钥"
    return True, f"{alias} → {upstream}，密钥来自环境"


def _probe_agent(manifest: dict, settings, case: dict) -> tuple:
    text = _read(settings.agent_config)
    if not text:
        return False, f"读不到 agent 配置：{settings.agent_config}"
    for token in ("base_url:", "prompt_name:", "sandbox:", "deny_write:"):
        if token not in text:
            return False, f"agent 配置缺少 {token}"
    expected = manifest["components"]["agent"]["prompt_hash"]
    actual = file_hash(settings.prompts_config)["sha256"]
    if expected and actual and expected != actual:
        return False, "prompt 内容与发布单不一致（manifest 已过期）"
    return True, f"prompt {expected or '(缺失)'} 与发布单一致"


def _probe_grants(manifest: dict, settings, case: dict) -> tuple:
    try:
        value = json.loads(Path(settings.grants_path).read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        return False, f"授权矩阵不可读：{exc}"
    rules = value.get("rules") or []
    if not rules:
        return False, "授权矩阵没有任何规则（检索会全空）"
    for rule in rules:
        if not rule.get("prefix") or not rule.get("tenants") or not rule.get("depts"):
            return False, f"规则不完整：{rule}"
        if "*" in rule["tenants"]:
            # 默认拒绝是隔离的前提：允许所有租户等于没有隔离。
            return False, f"规则 {rule['prefix']} 对全部租户开放"
    if not value.get("depts_registry"):
        return False, "缺少 depts_registry（* 无法展开）"
    expected = manifest["components"]["retrieval"]["grants_hash"]
    actual = file_hash(settings.grants_path)["sha256"]
    if expected and actual and expected != actual:
        return False, "授权矩阵与发布单不一致（manifest 已过期）"
    return True, f"{len(rules)} 条规则，默认拒绝"


def _probe_redaction(manifest: dict, settings, case: dict) -> tuple:
    sample = ("身份证 110101199003071234 手机 13812345678 "
              "地址 浙江省杭州市西湖区文三路100号 合同金额 1,250,000.00 元 占比 8.5%")
    redactor = Redactor()
    out = redactor.scrub_text(sample)
    checks = {
        "身份证保留前 3 后 4": "110***********1234" in out,
        "手机号保留前 3 后 4": "138****5678" in out,
        "地址只留省市级": "浙江省杭州市***" in out,
        "金额已 token 化": "AMOUNT_1" in out and "1,250,000.00" not in out,
        "百分比保留": "8.5%" in out,
    }
    failed = [name for name, ok in checks.items() if not ok]
    if failed:
        return False, "脱敏样例不通过：" + "、".join(failed)
    hits = ", ".join(f"{item['category']}={item['count']}" for item in redactor.summary())
    return True, f"四类命中已脱敏（{hits}），百分比保留"


# ---------------------------------------------------------------- 状态机


def check(store: Store, settings, version: str) -> dict:
    release = _release(store, version)
    store.clear_checks(version)
    results = run_probes(release["manifest"], settings)
    for item in results:
        store.put_check(version, item["id"], item["ok"], item["detail"], item["duration_ms"])
    ok = bool(results) and all(item["ok"] for item in results)
    status = CHECKED if ok else FAILED
    store.set_release_status(version, status)
    return {"version": version, "status": status, "ok": ok,
            "cases": results, "checked_at": utc_now()}


def publish(store: Store, settings, version: str, identity: Identity | None,
            track: str = "stable", pilot_ratio: float = 0.0) -> dict:
    release = _release(store, version)
    if release["status"] not in {CHECKED, PUBLISHED}:
        raise ReleaseNotChecked(
            f"版本 {version} 当前状态是 {release['status']}，只有 checked 才能发布（先 POST /v1/releases/{version}/check）")
    current = store.route()
    note = None
    if not current["stable"] or track != "pilot":
        # 第一次发布、或明确要求 stable：没有 stable 就不存在「只发灰度」这回事。
        next_route = {"stable": version, "pilot": None, "pilot_ratio": 0.0}
        track = "stable"
    else:
        next_route = {"stable": current["stable"], "pilot": version, "pilot_ratio": pilot_ratio}
        if next_route["stable"] == version:
            note = "stable 与 pilot 指向同一版本，灰度没有意义"
            next_route["pilot"] = None
            next_route["pilot_ratio"] = 0.0
    saved = store.set_route(next_route["stable"], next_route["pilot"], next_route["pilot_ratio"])
    path = write_route(settings.releases_dir, saved)
    store.set_release_status(version, PUBLISHED)
    store.audit("release_published", identity,
                {"version": version, "track": track, "route": saved, "route_file": path,
                 "fingerprint": release["fingerprint"]})
    return {"version": version, "status": PUBLISHED, "track": track,
            "route": saved, "route_file": path, "note": note}


def rollback(store: Store, settings, identity: Identity | None, reason: str = "",
             target: str | None = None) -> dict:
    """回滚只动路由：被撤下的版本留痕，镜像和发布单都不销毁。"""
    current = store.route()
    pilot = current["pilot"]
    if target and target != current["stable"]:
        # 指定目标时必须是曾经发布过的版本，避免把没检查过的草稿顶上流量。
        candidate = _release(store, target)
        if candidate["status"] not in {PUBLISHED, ROLLED_BACK, CHECKED}:
            raise ReleaseNotChecked(f"版本 {target} 当前状态是 {candidate['status']}，不能作为回滚目标")
    stable = target or current["stable"]
    if pilot:
        store.set_release_status(pilot, ROLLED_BACK)
    saved = store.set_route(stable, None, 0.0)
    path = write_route(settings.releases_dir, saved)
    store.audit("release_rolled_back", identity,
                {"from_pilot": pilot, "stable": stable, "reason": reason, "route": saved,
                 "route_file": path})
    return {"route": saved, "route_file": path, "rolled_back": pilot, "stable": stable,
            "reason": reason or None}


def route_table(store: Store) -> dict:
    return store.route()


def choose(route: dict, run_id: str | None, group: str | None = None) -> dict:
    """按比例切流：`sha256(runId) % 100 < pilot_ratio` 走 pilot，否则 stable。

    用 runId 的哈希而不是计数器：同一个 run 重试时落在同一条轨道上，
    灰度期间的对比才不会被「随机重投」污染。
    """
    stable = route.get("stable")
    pilot = route.get("pilot")
    ratio = float(route.get("pilot_ratio") or 0.0)
    if group == "stable":
        return {"version": stable, "track": "stable", "reason": "显式 x-release-group=stable"}
    if not pilot or ratio <= 0:
        return {"version": stable, "track": "stable",
                "reason": "没有可用的 pilot（未发布灰度或比例归零）"}
    if group == "pilot":
        return {"version": pilot, "track": "pilot", "reason": "显式 x-release-group=pilot"}
    bucket = int(hashlib.sha256((run_id or "").encode("utf-8")).hexdigest()[:8], 16) % 100
    if bucket < ratio:
        return {"version": pilot, "track": "pilot",
                "reason": f"sha256(runId)%100={bucket} < {ratio:g}"}
    return {"version": stable, "track": "stable",
            "reason": f"sha256(runId)%100={bucket} >= {ratio:g}"}


# ---------------------------------------------------------------- 密钥自检


def scan_for_secrets(settings) -> list:
    """扫描产物目录。命中即返回，由启动流程决定拒绝启动（fail fast）。

    只看 `runs/` `releases/` 与数据库所在目录：这三处是「会被打包、会被挂卷、
    会被别人拿到」的地方，密钥一旦进去就收不回来。
    """
    findings = []
    roots = [Path(getattr(settings, name)) for name in SCAN_DIRS]
    roots.append(Path(settings.db_path).parent)
    seen = set()
    for root in roots:
        if not root.exists():
            continue
        for path in sorted(root.rglob("*")):
            if not path.is_file() or path in seen:
                continue
            seen.add(path)
            if path.stat().st_size > SCAN_MAX_BYTES:
                continue
            try:
                text = path.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            for rule, pattern in SECRET_RULES:
                for match in pattern.finditer(text):
                    findings.append({"path": str(path), "rule": rule,
                                     "preview": _mask(match.group(0))})
    return findings


def ensure_no_secrets(settings) -> None:
    if not settings.secret_scan:
        return
    findings = scan_for_secrets(settings)
    if findings:
        sample = "; ".join(f"{item['rule']}@{item['path']}" for item in findings[:3])
        raise SecretInArtifact(f"SECRET_IN_ARTIFACT: 产物目录疑似包含密钥 → {sample}")


def _mask(value: str) -> str:
    if len(value) <= 10:
        return value[:2] + "***"
    return value[:6] + "***" + value[-2:]


# ---------------------------------------------------------------- 内部


def _release(store: Store, version: str) -> dict:
    try:
        return store.release(version)
    except KeyError:
        raise ReleaseUnknown(f"发布单不存在：{version}")
