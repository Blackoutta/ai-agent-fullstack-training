"""分类分级脱敏的唯一真源（Python 侧）。

规则与 `services/agent/src/core/redact.ts` 一一对应，由 `codebaseEval/tests/test_redaction_parity.py`
对同一批样例做双向断言；`codebaseEval/backend/redaction.py` 是同一实现的镜像，供评测后端直接调用。

为什么金额要 token 化而不是打码：报表要能算「同一笔金额出现了几次」，
但原文不能落库。于是同一金额在一次作用域内复用一个 `AMOUNT_n`，
映射只活在调用方持有的 Redactor 实例里，不写盘、不跨租户。
百分比与结构化数字（float/int）不脱敏，否则评测与报表失去意义。
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

ID_CARD = re.compile(r"\b(\d{3})\d{11}(\d{3}[\dXx])\b")
PHONE = re.compile(r"(?<!\d)(1[3-9]\d)\d{4}(\d{4})(?!\d)")
AMOUNT = re.compile(
    r"(?<![\d.])(?:[¥￥$]\s*)?\d{1,3}(?:,\d{3})+(?:\.\d+)?(?:\s*(?:元|万元|美元))?"
    r"|(?<![\d.])\d+(?:\.\d+)?\s*(?:万元|美元|元)"
)
ADDRESS = re.compile(
    r"[\u4e00-\u9fa5]{2,10}(?:省|自治区|市)[\u4e00-\u9fa5]{0,12}(?:路|街|道|巷|区|县|镇)"
    r"[\u4e00-\u9fa5A-Za-z0-9#\-]{0,20}\d*号?"
)
_ADDRESS_HEAD = re.compile(r"^.*(?:省|自治区|市)")


def mask_address(value: str) -> str:
    """地址只留到省/市级，其余一律 ***。"""
    head = _ADDRESS_HEAD.match(value)
    return f"{head.group(0) if head else ''}***"


@dataclass
class Redactor:
    amounts: dict[str, str] = field(default_factory=dict)
    hits: dict[str, int] = field(default_factory=dict)

    def _record(self, category: str, count: int = 1) -> None:
        self.hits[category] = self.hits.get(category, 0) + count

    def _token_of(self, raw: str) -> str:
        key = re.sub(r"\s+", "", raw)
        existing = self.amounts.get(key)
        if existing:
            return existing
        token = f"AMOUNT_{len(self.amounts) + 1}"
        self.amounts[key] = token
        return token

    def scrub_text(self, text: str) -> str:
        def replace_id(match: re.Match[str]) -> str:
            self._record("id_card")
            return f"{match.group(1)}{'*' * 11}{match.group(2)}"

        out = ID_CARD.sub(replace_id, text)

        def replace_phone(match: re.Match[str]) -> str:
            self._record("phone")
            return f"{match.group(1)}****{match.group(2)}"

        out = PHONE.sub(replace_phone, out)

        def replace_amount(match: re.Match[str]) -> str:
            self._record("amount")
            return self._token_of(match.group(0))

        out = AMOUNT.sub(replace_amount, out)

        def replace_address(match: re.Match[str]) -> str:
            self._record("address")
            return mask_address(match.group(0))

        return ADDRESS.sub(replace_address, out)

    def scrub_value(self, value: object) -> object:
        if isinstance(value, str):
            return self.scrub_text(value)
        if isinstance(value, list):
            return [self.scrub_value(item) for item in value]
        if isinstance(value, dict):
            return {key: self.scrub_value(item) for key, item in value.items()}
        return value

    def summary(self) -> list[dict]:
        return [{"category": key, "count": self.hits[key]} for key in sorted(self.hits)]

    def amount_map(self) -> dict[str, str]:
        """仅供测试断言 token 复用；生产路径不导出映射。"""
        return dict(self.amounts)
