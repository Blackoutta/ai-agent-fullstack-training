"""身份解析：`key:tenant:dept:role`，只从环境变量读，每个服务本地解析。

和 agent / eval / retrieval 三处保持同一套语义（`design/architecture.md` §7）：

- 密钥可以含冒号，所以从右往左取 tenant / dept / role 三个固定位；
- 没配密钥 = 本机单租户模式，用 `DEMO_TENANT` 造一个本地管理员，
  这样离线自验不需要先造密钥；
- 配了密钥就必须带，缺了或错了都是 401（不是 403——403 留给「有身份但没权限」）。

`role=service` 是内部服务标识：只有它能代表别的租户上报用量，
否则任何调用方都能把自己的账记到别人头上。
"""
from __future__ import annotations

import re
from dataclasses import dataclass

SAFE = re.compile(r"^[A-Za-z0-9_.-]{1,64}$")
SERVICE_ROLE = "service"


class Unauthenticated(PermissionError):
    """身份缺失或无效 → 401。"""


class Forbidden(PermissionError):
    """有身份但没有权限（角色不足）→ 403。"""


@dataclass(frozen=True)
class Identity:
    tenant: str
    dept: str
    role: str
    key_prefix: str

    @property
    def is_service(self) -> bool:
        return self.role == SERVICE_ROLE

    def public(self) -> dict:
        """回显给调用方的身份视图：永不包含完整密钥。"""
        return {"tenant": self.tenant, "dept": self.dept, "role": self.role,
                "key_prefix": self.key_prefix, "service": self.is_service}


def parse_api_keys(raw: str | None) -> dict[str, Identity]:
    keys: dict[str, Identity] = {}
    for entry in (raw or "").split(","):
        trimmed = entry.strip()
        if not trimmed:
            continue
        parts = trimmed.split(":")
        if len(parts) < 4:
            continue
        role, dept, tenant = parts[-1].strip(), parts[-2].strip(), parts[-3].strip()
        key = ":".join(parts[:-3])
        if not key or not role or not (SAFE.match(tenant) and SAFE.match(dept)):
            continue
        keys[key] = Identity(tenant=tenant, dept=dept, role=role, key_prefix=key[:6])
    return keys


def authenticate(header: str | None, keys: dict[str, Identity]) -> Identity | None:
    if not header:
        return None
    match = re.match(r"^Bearer\s+(.+)$", header.strip(), re.IGNORECASE)
    token = match.group(1).strip() if match else header.strip()
    return keys.get(token)


def resolve_identity(header: str | None, keys: dict[str, Identity], local_tenant: str = "public") -> Identity:
    if not keys:
        return Identity(tenant=local_tenant, dept="local", role="admin", key_prefix="local")
    identity = authenticate(header, keys)
    if identity is None:
        raise Unauthenticated("缺少或无效的平台密钥（Authorization 请求头）")
    return identity


def require_admin(identity: Identity) -> Identity:
    """发布、回滚、改预算都只给 admin：服务身份 run 的是流量，不是治理动作。"""
    if identity.role in {"admin", SERVICE_ROLE}:
        return identity
    raise Forbidden(f"角色 {identity.role} 没有治理权限（需要 admin）")
