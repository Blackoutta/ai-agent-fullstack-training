"""平台控制面 HTTP 服务：发布、路由、预算、成本、审计、回放。

一条原则贯穿所有路由：**控制面只做治理动作与事实聚合**。它不跑模型、不算价、
不替业务服务判定内容，只回答「现在该发哪个版本、还能不能花钱、这条账是谁的」。

失败语义按 `design/architecture.md` §10 一一对应：
401 无身份、403 越权 / Host 不认、409 状态机拒绝、429 预算耗尽、404 不存在、400 参数错。
预算返回 429 但响应体仍带 `allowed=false`：调用方既能按状态码拦截，也能读字段解释原因。
"""
from __future__ import annotations

import json
import os
import re
import sys
import threading
import urllib.error
import urllib.request
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, quote, unquote, urlparse

from . import cost, releases
from .identity import (Forbidden, Identity, Unauthenticated, parse_api_keys,
                       require_admin, resolve_identity)
from .settings import Settings
from .store import Store, utc_now

SERVICE = "platform"
VERSION = "1.0"
MAX_BODY = 1024 * 1024
LOOPBACK = {"localhost", "127.0.0.1", "::1"}


class HostRejected(PermissionError):
    """Host / Origin 不在白名单 → 403（DNS rebinding 与跨站调用）。"""


class ApiError(Exception):
    def __init__(self, status: int, code: str, message: str, details: dict | list | None = None):
        super().__init__(message)
        self.status = status
        self.code = code
        self.message = message
        self.details = details or {}


def details_list(details) -> list:
    """错误详情统一成数组（契约 `details[]`）：字典包成单元素，避免丢信息。"""
    if not details:
        return []
    if isinstance(details, list):
        return details
    return [details]


def host_whitelist(port: int, raw: str) -> set:
    names = [item.strip().lower() for item in (raw or "").split(",") if item.strip()]
    if not names:
        names = list(LOOPBACK)
    allowed = set()
    for name in names:
        allowed.add(name)
        allowed.add(f"{name}:{port}")
    return allowed


def response_json(handler: BaseHTTPRequestHandler, status: int, body: dict,
                  headers: dict | None = None) -> None:
    payload = (json.dumps(body, ensure_ascii=False, indent=2, sort_keys=False) + "\n").encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Content-Length", str(len(payload)))
    handler.send_header("Cache-Control", "no-store")
    request_id = getattr(handler, "request_id", None)
    if request_id:
        handler.send_header("X-Request-Id", request_id)
    for key, value in (headers or {}).items():
        handler.send_header(key, value)
    handler.end_headers()
    handler.wfile.write(payload)


def response_text(handler: BaseHTTPRequestHandler, status: int, text: str, content_type: str) -> None:
    payload = text.encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", content_type)
    handler.send_header("Content-Length", str(len(payload)))
    handler.send_header("Cache-Control", "no-store")
    handler.end_headers()
    handler.wfile.write(payload)


def handler_for(store: Store, settings: Settings, keys: dict | None = None):
    keys = parse_api_keys(settings.api_keys) if keys is None else keys

    class PlatformHandler(BaseHTTPRequestHandler):
        server_version = f"{SERVICE}/{VERSION}"
        protocol_version = "HTTP/1.1"

        # ------------------------------------------------------------ 基础设施

        def log_message(self, fmt, *args):  # 用 stderr 单行日志，交给容器采集
            sys.stderr.write("[platform] %s %s\n" % (self.address_string(), fmt % args))

        def allowed_hosts(self) -> set:
            cached = getattr(self.server, "allowed_hosts", None)
            if cached is None:
                cached = host_whitelist(self.server.server_address[1], settings.allowed_hosts)
                self.server.allowed_hosts = cached
            return cached

        def safe_request(self) -> None:
            host = (self.headers.get("Host") or "").strip().lower()
            if host and host not in self.allowed_hosts():
                raise HostRejected(f"Host 不在白名单：{host}")
            origin = (self.headers.get("Origin") or "").strip()
            if origin:
                netloc = urlparse(origin).netloc.lower()
                if netloc and netloc not in self.allowed_hosts():
                    raise HostRejected(f"Origin 不在白名单：{netloc}")

        def _read_raw(self) -> bytes:
            try:
                length = int(self.headers.get("Content-Length") or 0)
            except ValueError:
                raise ApiError(400, "INVALID_ARGUMENT", "Content-Length 不合法")
            if length > MAX_BODY:
                raise ApiError(413, "BODY_TOO_LARGE", "请求体超过 1MB")
            return self.rfile.read(length) if length else b""

        def read_body(self) -> dict:
            # body 在 dispatch 入口就一次读完：早退的分支（403/404）不清空连接里的
            # 残留字节，HTTP/1.1 复用时会被当成下一条请求。
            raw = getattr(self, "raw_body", None)
            if raw is None:
                raw = self._read_raw()
                self.raw_body = raw
            if not raw.strip():
                return {}
            try:
                value = json.loads(raw.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                raise ApiError(400, "INVALID_JSON", f"请求体不是合法 JSON：{exc}")
            if not isinstance(value, dict):
                raise ApiError(400, "INVALID_ARGUMENT", "请求体必须是 JSON 对象")
            return value

        # ------------------------------------------------------------ 统一错误

        def dispatch(self) -> None:
            identity = None
            self.raw_body = None
            self.request_id = (self.headers.get("X-Request-Id") or "").strip() \
                or f"req-{uuid.uuid4().hex[:12]}"
            try:
                self.safe_request()
                if self.command in {"POST", "PUT", "PATCH", "DELETE"}:
                    self.raw_body = self._read_raw()
                if self.path_only == "/health" and self.command == "GET":
                    return self.health()
                if self.path_only == "/metrics" and self.command == "GET":
                    return self.metrics()
                identity = resolve_identity(self.headers.get("Authorization"), keys, settings.local_tenant)
                return self.route(identity)
            except HostRejected as exc:
                self.fail(403, "HOST_REJECTED", str(exc))
            except Unauthenticated as exc:
                store.audit("auth_denied", None, {"path": self.path_only, "reason": str(exc)})
                self.fail(401, "UNAUTHENTICATED", str(exc))
            except Forbidden as exc:
                store.audit("auth_denied", identity, {"path": self.path_only, "reason": str(exc)})
                self.fail(403, "FORBIDDEN", str(exc))
            except releases.ReleaseNotChecked as exc:
                store.audit("release_rejected", identity,
                            {"path": self.path_only, "reason": str(exc)})
                self.fail(409, "RELEASE_NOT_CHECKED", str(exc))
            except (releases.ReleaseUnknown, KeyError) as exc:
                self.fail(404, "NOT_FOUND", str(exc).strip("'\""))
            except ValueError as exc:
                self.fail(400, "INVALID_ARGUMENT", str(exc))
            except ApiError as exc:
                self.fail(exc.status, exc.code, exc.message, exc.details)
            except Exception as exc:  # 兜底：不能把堆栈回给调用方，但必须留在日志里
                sys.stderr.write(f"[platform] {self.command} {self.path_only} failed: "
                                 f"{type(exc).__name__}: {exc}\n")
                self.fail(500, "INTERNAL", "服务内部错误")

        def fail(self, status: int, code: str, message: str, details=None,
                 headers: dict | None = None) -> None:
            # 契约形状：{error:{code,message}, code, details[], request_id}。
            # `error` 是嵌套对象（与 retrieval/eval/agent 一致），顶层 `code` 是给日志用的平铺副本。
            body = {"error": {"code": code, "message": message}, "code": code,
                    "details": details_list(details), "request_id": self.request_id}
            # 早退时请求体可能还没读：HTTP/1.1 复用连接会把残留字节当成下一条请求，
            # 所以错误响应一律关闭连接。控制面的错误不是高频路径，不值得为此做 drain。
            self.close_connection = True
            merged = {"Connection": "close", **(headers or {})}
            response_json(self, status, body, merged)

        # ------------------------------------------------------------ 公开端点

        def health(self) -> None:
            route = store.route()
            response_json(self, 200, {
                "status": "ok", "service": SERVICE, "version": VERSION,
                "time": utc_now(), "route": route,
                "releases": len(store.releases()),
            })

        def metrics(self) -> None:
            lines = [
                "# HELP platform_releases_total 发布单数量（按状态）",
                "# TYPE platform_releases_total gauge",
            ]
            counts: dict[str, int] = {}
            for item in store.releases():
                counts[item["status"]] = counts.get(item["status"], 0) + 1
            for status, count in sorted(counts.items()):
                lines.append(f'platform_releases_total{{status="{status}"}} {count}')
            route = store.route()
            lines += [
                "# HELP platform_pilot_ratio 灰度分流比例（0-100）",
                "# TYPE platform_pilot_ratio gauge",
                f"platform_pilot_ratio {float(route.get('pilot_ratio') or 0):g}",
                "# HELP platform_usage_cost_usd 已知成本合计（按租户）",
                "# TYPE platform_usage_cost_usd gauge",
            ]
            totals: dict[str, float] = {}
            unknown: dict[str, int] = {}
            for row in store.usage():
                tenant = row.get("tenant") or "unknown"
                if row.get("cost_usd") is None:
                    unknown[tenant] = unknown.get(tenant, 0) + 1
                else:
                    totals[tenant] = totals.get(tenant, 0.0) + row["cost_usd"]
            for tenant, value in sorted(totals.items()):
                lines.append(f'platform_usage_cost_usd{{tenant="{tenant}"}} {value:.6f}')
            for tenant, count in sorted(unknown.items()):
                lines.append(f'platform_usage_unknown_cost_runs{{tenant="{tenant}"}} {count}')
            lines += [
                "# HELP platform_audit_total 审计条数（按动作）",
                "# TYPE platform_audit_total gauge",
            ]
            actions: dict[str, int] = {}
            for item in store.audits(limit=500):
                actions[item["action"]] = actions.get(item["action"], 0) + 1
            for action, count in sorted(actions.items()):
                lines.append(f'platform_audit_total{{action="{action}"}} {count}')
            response_text(self, 200, "\n".join(lines) + "\n", "text/plain; version=0.0.4; charset=utf-8")

        # ------------------------------------------------------------ 路由分发

        def route(self, identity: Identity) -> None:
            path, method = self.path_only, self.command
            parsed = urlparse(self.path)
            query = parse_qs(parsed.query)

            if path == "/v1/identities" and method == "GET":
                return response_json(self, 200, {"identity": identity.public(),
                                                 "service": identity.is_service})

            if path == "/v1/releases":
                if method == "GET":
                    return response_json(self, 200, {"items": store.releases()})
                if method == "POST":
                    return self.create_release(identity)
            if path == "/v1/releases/route" and method == "GET":
                return response_json(self, 200, store.route())
            if path == "/v1/releases/route/preview" and method == "GET":
                run_id = (query.get("run_id") or query.get("runId") or [""])[0]
                group = (query.get("group") or [None])[0]
                choice = releases.choose(store.route(), run_id, group)
                return response_json(self, 200, {"choice": choice, "route": store.route()})
            if path == "/v1/releases/rollback" and method == "POST":
                require_admin(identity)
                body = self.read_body()
                return response_json(self, 200, releases.rollback(
                    store, settings, identity, str(body.get("reason") or ""),
                    str(body.get("version") or "") or None))

            match = re.match(r"^/v1/releases/([^/]+)(/check|/publish)?$", path)
            if match:
                version = unquote(match.group(1))
                action = match.group(2)
                if method == "GET" and not action:
                    release = store.release(version)
                    return response_json(self, 200, {**release, "checks": store.checks(version)})
                if method == "POST" and action == "/check":
                    require_admin(identity)
                    result = releases.check(store, settings, version)
                    store.audit("release_checked", identity,
                                {"version": version, "status": result["status"],
                                 "failed": [item["id"] for item in result["cases"] if not item["ok"]]})
                    return response_json(self, 200, result)
                if method == "POST" and action == "/publish":
                    require_admin(identity)
                    body = self.read_body()
                    result = releases.publish(
                        store, settings, version, identity,
                        track=str(body.get("track") or "stable"),
                        pilot_ratio=float(body.get("pilot_ratio") or body.get("pilotRatio") or 0))
                    return response_json(self, 200, result)

            if path == "/v1/usage" and method == "POST":
                body = self.read_body()
                row = cost.record(store, body, identity)
                return response_json(self, 201, {"recorded": True, "usage": row})

            if path == "/v1/cost/report" and method == "GET":
                tenant = self.scoped_tenant(identity, (query.get("tenant") or [None])[0])
                group_by = (query.get("groupBy") or query.get("group_by") or ["tenant"])[0]
                days = (query.get("days") or [None])[0]
                report = cost.report(store, group_by=group_by, tenant=tenant,
                                     days=int(days) if days else None)
                fmt = (query.get("format") or ["json"])[0].lower()
                if fmt == "md":
                    return response_text(self, 200, cost.markdown(report), "text/markdown; charset=utf-8")
                return response_json(self, 200, report)

            if path == "/v1/budgets":
                if method == "GET":
                    return response_json(self, 200, {"items": store.budgets()})
                if method == "POST":
                    require_admin(identity)
                    body = self.read_body()
                    scope = str(body.get("scope") or "").strip()
                    kind = scope.partition(":")[0]
                    if kind not in cost.BUDGET_KINDS or not scope.partition(":")[2]:
                        raise ValueError(f"scope 必须形如 tenant:<id> / dept:<tenant>/<dept> / experiment:<id>")
                    period = str(body.get("period") or "daily")
                    if period not in {"daily", "monthly"}:
                        raise ValueError("period 只能是 daily 或 monthly")
                    saved = store.set_budget(scope, period, body.get("limit_usd"), body.get("warn_ratio"))
                    store.audit("budget_set", identity, saved)
                    return response_json(self, 201, saved)

            if path == "/v1/budgets/check" and method == "GET":
                scopes = [item for item in (query.get("scope") or []) if item.strip()]
                if not scopes:
                    raise ValueError("至少给一个 scope，例如 ?scope=tenant:tenant_a")
                self.guard_scopes(identity, scopes)
                state = cost.budget_state(store, settings, scopes)
                if not state["allowed"]:
                    store.audit("budget_blocked", identity,
                                {"scope": state["scope"], "scopes": state["scopes"]})
                    return response_json(self, 429, {
                        **state, "code": "BUDGET_EXCEEDED", "request_id": self.request_id,
                        "error": {"code": "BUDGET_EXCEEDED",
                                  "message": f"预算已耗尽：{state['scope']}"}},
                        {"Retry-After": "600"})
                return response_json(self, 200, state)

            if path == "/v1/audit" and method == "GET":
                tenant = self.scoped_tenant(identity, (query.get("tenant") or [None])[0])
                limit = int((query.get("limit") or ["50"])[0])
                action = (query.get("action") or [None])[0]
                return response_json(self, 200, {
                    "items": store.audits(limit=limit, tenant=tenant, action=action)})

            if path == "/v1/replays":
                if method == "GET":
                    tenant = self.scoped_tenant(identity, (query.get("tenant") or [None])[0])
                    limit = int((query.get("limit") or ["20"])[0])
                    return response_json(self, 200, {"items": store.replays(tenant, limit)})
                if method == "POST":
                    return self.schedule_replay(identity)

            raise ApiError(404, "NOT_FOUND", f"没有这个路由：{method} {path}")

        # ------------------------------------------------------------ 具体动作

        def create_release(self, identity: Identity) -> None:
            require_admin(identity)
            body = self.read_body()
            manifest = releases.draft(
                store, settings,
                version=str(body.get("version") or "").strip() or None,
                components=body.get("components") if isinstance(body.get("components"), dict) else None,
                cases=body.get("cases") if isinstance(body.get("cases"), list) else None,
            )
            files = releases.write_manifest(settings.releases_dir, manifest)
            release = store.put_release(manifest["version"], releases.DRAFT, manifest,
                                        manifest["components"]["gateway"]["config_hash"])
            store.audit("release_drafted", identity,
                        {"version": manifest["version"], "files": files,
                         "cases": [item["id"] for item in manifest["acceptance"]["cases"]]})
            payload = {"release": release, "files": files}
            if body.get("auto_check"):
                checked = releases.check(store, settings, manifest["version"])
                store.audit("release_checked", identity,
                            {"version": manifest["version"], "status": checked["status"],
                             "failed": [item["id"] for item in checked["cases"] if not item["ok"]]})
                payload["check"] = checked
            return response_json(self, 201, payload)

        def schedule_replay(self, identity: Identity) -> None:
            body = self.read_body()
            run_id = str(body.get("run_id") or body.get("runId") or "").strip()
            if not run_id:
                raise ValueError("run_id 必填")
            if not settings.agent_url:
                raise ApiError(503, "AGENT_UNAVAILABLE", "PLATFORM_AGENT_URL 未配置，无法调度回放")
            status, payload = self.call_agent(f"/v1/runs/{quote(run_id, safe='')}/replay")
            if status == 404:
                raise ApiError(404, "RUN_NOT_FOUND", f"agent 没有这次运行：{run_id}")
            if status == 403:
                raise ApiError(403, "FORBIDDEN_TENANT", "跨租户回放被拒绝")
            if status == 409:
                # agent 的 409 走统一错误体，details 恒为数组（可能直接就是 diffs，也可能包了一层 {}）。
                raw = payload.get("details")
                diffs = raw.get("diffs") if isinstance(raw, dict) else raw
                diffs = diffs or payload.get("diffs")
                store.audit("replay_mismatch", identity,
                            {"run_id": run_id, "diffs": diffs, "detail": payload})
                return response_json(self, 409, {
                    "error": {"code": "REPLAY_VERSION_MISMATCH",
                              "message": "归档版本与当前生效版本不一致，回放会得出无意义的结论"},
                    "code": "REPLAY_VERSION_MISMATCH",
                    "details": details_list(payload.get("details") or payload),
                    "request_id": self.request_id})
            if status != 200:
                raise ApiError(502, "AGENT_ERROR", f"agent 回放失败：HTTP {status}", {"body": payload})
            ok = bool(payload.get("ok"))
            saved = store.add_replay(run_id, identity.tenant, ok,
                                     str(payload.get("status") or "unknown"), payload)
            store.audit("replay_scheduled", identity,
                        {"run_id": run_id, "status": payload.get("status"), "ok": ok})
            return response_json(self, 200, {"replay": saved, **payload})

        def call_agent(self, path: str) -> tuple:
            """回放是把调用方的身份原样转发给 agent：平台不持有别人的密钥。"""
            request = urllib.request.Request(
                f"{settings.agent_url}{path}", data=b"{}", method="POST",
                headers={"Content-Type": "application/json",
                         "Authorization": self.headers.get("Authorization") or ""})
            try:
                with urllib.request.urlopen(request, timeout=30) as response:
                    return response.status, _loads(response.read())
            except urllib.error.HTTPError as exc:
                return exc.code, _loads(exc.read())
            except (urllib.error.URLError, TimeoutError, OSError) as exc:
                raise ApiError(503, "AGENT_UNAVAILABLE", f"agent 不可达：{exc}")

        # ------------------------------------------------------------ 作用域

        def scoped_tenant(self, identity: Identity, requested: str | None) -> str | None:
            """服务身份可看全量；普通身份只能看自己，跨租户查询直接 403 并留痕。"""
            if identity.is_service:
                return requested or None
            if requested and requested != identity.tenant:
                store.audit("tenant_violation", identity,
                            {"path": self.path_only, "requested": requested})
                raise Forbidden(f"租户 {identity.tenant} 不能查看 {requested} 的数据")
            return identity.tenant

        def guard_scopes(self, identity: Identity, scopes: list) -> None:
            if identity.is_service:
                return
            for scope in scopes:
                kind, _, ident = scope.partition(":")
                if kind == "tenant" and ident != identity.tenant:
                    store.audit("tenant_violation", identity,
                                {"path": self.path_only, "scope": scope})
                    raise Forbidden(f"不能查询其他租户的预算：{scope}")
                if kind == "dept":
                    tenant, _, dept = ident.partition("/")
                    if tenant != identity.tenant or dept != identity.dept:
                        store.audit("tenant_violation", identity,
                                    {"path": self.path_only, "scope": scope})
                        raise Forbidden(f"不能查询其他部门的预算：{scope}")

        # ------------------------------------------------------------ HTTP 入口

        @property
        def path_only(self) -> str:
            return urlparse(self.path).path

        def do_GET(self):
            self.dispatch()

        def do_POST(self):
            self.dispatch()

        def do_PUT(self):
            self.dispatch()

        def do_DELETE(self):
            self.dispatch()

    return PlatformHandler


def _loads(raw: bytes) -> dict:
    try:
        value = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        return {"raw": raw.decode("utf-8", "replace")[:400]}
    return value if isinstance(value, dict) else {"value": value}


def serve(settings: Settings | None = None) -> None:
    settings = settings or Settings.load()
    store = Store(settings.db_path)
    releases.ensure_no_secrets(settings)
    # 启动就把路由文件对齐一次：agent 可能比控制面先起来，读到旧文件也得是这台机器的事实。
    releases.write_route(settings.releases_dir, store.route())
    handler = handler_for(store, settings)
    httpd = ThreadingHTTPServer(("0.0.0.0", settings.port), handler)
    httpd.daemon_threads = True
    sys.stderr.write(f"[platform] listening on :{settings.port} db={settings.db_path} "
                     f"releases={settings.releases_dir}\n")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        sys.stderr.write("[platform] interrupted\n")
    finally:
        httpd.server_close()
        store.close()


def main() -> None:
    try:
        serve()
    except releases.SecretInArtifact as exc:
        sys.stderr.write(f"[platform] 拒绝启动：{exc}\n")
        raise SystemExit(2)


if __name__ == "__main__":
    main()
