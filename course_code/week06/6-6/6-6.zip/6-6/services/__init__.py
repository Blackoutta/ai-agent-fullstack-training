"""阶段六平台的服务目录。放一个 __init__.py，让 `python -m unittest services.<svc>.tests` 可发现。"""
