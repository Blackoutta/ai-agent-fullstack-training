/**
 * Langfuse 上报。
 *
 * 不走官方 SDK：pi 0.87.1 的观察器事件和 langfuse 官方集成版本对不上，
 * 直接调 `/api/public/ingestion` 更稳，也少一个依赖。
 * 上报是旁路：失败只记一条日志，绝不影响运行结果。
 */

const INGEST_PATH = "/api/public/ingestion";

export interface LangfuseConfig {
  baseUrl: string;
  publicKey: string;
  secretKey: string;
  release: string;
  environment: string;
}

export interface TracePayload {
  runId: string;
  tenant: string;
  dept: string;
  task: string;
  delayMs: number;
  model: string;
  usage: Record<string, number>;
  costUsd: number | null;
  outcome: string;
  startedAt: string;
  endedAt: string;
}

export interface Exporter {
  trace(payload: TracePayload): void;
  flush(): Promise<void>;
}

export function langfuseConfigFromEnv(env: NodeJS.ProcessEnv = process.env): LangfuseConfig | null {
  const baseUrl = (env.LANGFUSE_HOST ?? env.LANGFUSE_BASE_URL ?? "").trim();
  const publicKey = (env.LANGFUSE_PUBLIC_KEY ?? "").trim();
  const secretKey = (env.LANGFUSE_SECRET_KEY ?? "").trim();
  if (!baseUrl || !publicKey || !secretKey) return null;
  return {
    baseUrl: baseUrl.replace(/\/+$/, ""),
    publicKey,
    secretKey,
    release: env.LANGFUSE_RELEASE ?? "6-6",
    environment: env.LANGFUSE_ENVIRONMENT ?? (env.NODE_ENV ?? "local"),
  };
}

const TRACE_ID = (runId: string): string => runId.replace(/[^a-zA-Z0-9]/g, "").slice(0, 32).padEnd(8, "0");

class NoopExporter implements Exporter {
  trace(): void {}
  async flush(): Promise<void> {}
}

class HttpExporter implements Exporter {
  private readonly pending = new Set<Promise<void>>();
  private readonly config: LangfuseConfig;
  private readonly timeoutMs: number;

  // 不用参数属性：Node 的 strip-only 类型擦除不支持它，本地 node --test 会直接拒绝加载。
  constructor(config: LangfuseConfig, timeoutMs = 2000) {
    this.config = config;
    this.timeoutMs = timeoutMs;
  }

  trace(payload: TracePayload): void {
    const task = this.send(this.build(payload));
    this.pending.add(task);
    void task.finally(() => this.pending.delete(task));
    // 兜底：不让 pending 无限增长。
    if (this.pending.size > 256) this.pending.clear();
  }

  async flush(): Promise<void> {
    if (!this.pending.size) return;
    await Promise.allSettled([...this.pending]);
  }

  private build(payload: TracePayload): Array<Record<string, unknown>> {
    const traceId = TRACE_ID(payload.runId);
    const metadata = {
      tenant: payload.tenant,
      dept: payload.dept,
      latency_ms: payload.delayMs,
      release: this.config.release,
      outcome: payload.outcome,
    };
    return [
      {
        id: `${payload.runId}-trace`,
        type: "trace-create",
        timestamp: payload.endedAt,
        body: {
          id: traceId,
          name: "agent.run",
          userId: payload.tenant,
          sessionId: payload.runId,
          input: payload.task,
          output: payload.outcome,
          release: this.config.release,
          environment: this.config.environment,
          metadata,
          tags: [`tenant:${payload.tenant}`, `dept:${payload.dept}`],
        },
      },
      {
        id: `${payload.runId}-generation`,
        type: "generation-create",
        timestamp: payload.endedAt,
        body: {
          id: `${traceId}-gen`,
          traceId,
          name: "agent.loop",
          model: payload.model,
          startTime: payload.startedAt,
          endTime: payload.endedAt,
          usageDetails: {
            input: Number(payload.usage.input_tokens ?? payload.usage.prompt_tokens ?? 0) || 0,
            output: Number(payload.usage.output_tokens ?? payload.usage.completion_tokens ?? 0) || 0,
            total: Number(payload.usage.total_tokens ?? 0) || 0,
          },
          costDetails: payload.costUsd === null ? undefined : { total: payload.costUsd },
          metadata,
        },
      },
    ];
  }

  private async send(batch: Array<Record<string, unknown>>): Promise<void> {
    const auth = Buffer.from(`${this.config.publicKey}:${this.config.secretKey}`).toString("base64");
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this.timeoutMs);
    try {
      const response = await fetch(`${this.config.baseUrl}${INGEST_PATH}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Basic ${auth}`,
        },
        body: JSON.stringify({ batch }),
        signal: controller.signal,
      });
      if (!response.ok) {
        process.stderr.write(`[langfuse] ingest ${response.status}\n`);
      }
    } catch (error) {
      process.stderr.write(`[langfuse] ingest failed: ${(error as Error).message}\n`);
    } finally {
      clearTimeout(timer);
    }
  }
}

export function createExporter(env: NodeJS.ProcessEnv = process.env): Exporter {
  const config = langfuseConfigFromEnv(env);
  if (!config) {
    process.stderr.write("[langfuse] 未配置密钥，跳过上报（本地事件流与归档仍然完整）\n");
    return new NoopExporter();
  }
  return new HttpExporter(config);
}
