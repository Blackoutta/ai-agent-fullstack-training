/**
 * 运行状态与归档。
 *
 * 一个运行在内存里是一份 RunState，在磁盘上是一个目录：
 *   input.json / versions.json / messages.jsonl / steps.json / raw/NNNN.json / result.json
 * 内存丢了（进程重启）就从目录重建，归档是唯一的真源。
 */
import { appendFileSync, existsSync, mkdirSync, readFileSync, readdirSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import type { Versions } from "./archive.ts";
import type { NormalizedEvent, Outcome, Step } from "./events.ts";
import { Redactor, type RedactionHit } from "./redact.ts";
import { addUsage, emptyUsage, type Usage } from "./usage.ts";
import type { Track } from "./release.ts";

export interface RunInput {
  run_id: string;
  prompt: string;
  task: string | null;
  goal: string | null;
  tenant: string;
  dept: string;
  user: string;
  roles: string[];
  release_version: string;
  track: Track;
  model_alias: string;
  created_at: string;
}

export interface RunState {
  input: RunInput;
  versions: Versions;
  status: "running" | "finished";
  outcome: Outcome | null;
  events: NormalizedEvent[];
  steps: Step[];
  usage: Usage;
  cost_usd: number | null;
  final_answer: string;
  error: string | null;
  started_at: string;
  ended_at: string | null;
  redaction: RedactionHit[];
  model: string | null;
}

/** 对外摘要：不含事件本体，列表与详情都用它。 */
export interface RunSummary {
  run_id: string;
  tenant: string;
  dept: string;
  user: string;
  task: string | null;
  status: "running" | "finished";
  outcome: Outcome | null;
  release_version: string;
  track: Track;
  model_alias: string;
  model: string | null;
  cost_usd: number | null;
  usage: Usage;
  redaction: RedactionHit[];
  started_at: string;
  ended_at: string | null;
  error: string | null;
}

export function summarize(state: RunState): RunSummary {
  return {
    run_id: state.input.run_id,
    tenant: state.input.tenant,
    dept: state.input.dept,
    user: state.input.user,
    task: state.input.task,
    status: state.status,
    outcome: state.outcome,
    release_version: state.input.release_version,
    track: state.input.track,
    model_alias: state.input.model_alias,
    model: state.model,
    cost_usd: state.cost_usd,
    usage: state.usage,
    redaction: state.redaction,
    started_at: state.started_at,
    ended_at: state.ended_at,
    error: state.error,
  };
}

type Listener = (event: NormalizedEvent) => void;

export class Run {
  readonly redactor = new Redactor();
  readonly dir: string;
  readonly state: RunState;
  private readonly listeners = new Set<Listener>();
  private rawIndex = 0;

  // 显式赋值而不是参数属性：Node 的 strip-only 类型擦除不支持参数属性。
  constructor(dir: string, state: RunState) {
    this.dir = dir;
    this.state = state;
  }

  get id(): string {
    return this.state.input.run_id;
  }

  /** 事件先落盘再广播：订阅方挂了不影响归档，归档坏了订阅方也看得见。 */
  push(event: NormalizedEvent): void {
    this.state.events.push(event);
    if (event.type !== "delta") {
      appendFileSync(join(this.dir, "messages.jsonl"), `${JSON.stringify(event)}\n`);
    }
    if (event.type === "message") {
      this.rawIndex += 1;
      const name = String(this.rawIndex).padStart(4, "0");
      writeFileSync(
        join(this.dir, "raw", `${name}.json`),
        `${JSON.stringify({ index: this.rawIndex, ...event }, null, 2)}\n`,
      );
      if (event.usage) this.state.usage = addUsage(this.state.usage, event.usage);
      if (event.model) this.state.model = event.model;
    }
    if (event.type === "outcome") {
      this.state.outcome = event.outcome;
      this.state.final_answer = event.final_answer;
      this.state.error = event.error;
    }
    for (const listener of this.listeners) listener(event);
  }

  subscribe(listener: Listener): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  finish(input: { cost_usd: number | null; redaction: RedactionHit[] }): void {
    this.state.status = "finished";
    this.state.ended_at = new Date().toISOString();
    this.state.cost_usd = input.cost_usd;
    this.state.redaction = input.redaction;
    writeFileSync(join(this.dir, "steps.json"), `${JSON.stringify(this.state.steps, null, 2)}\n`);
    writeFileSync(
      join(this.dir, "result.json"),
      `${JSON.stringify(
        {
          ...summarize(this.state),
          final_answer: this.state.final_answer,
          steps: this.state.steps.length,
        },
        null,
        2,
      )}\n`,
    );
  }

  /** 收口事件没来（worker 崩了）时要有一条明确结局，不能停在 running。 */
  fail(error: string): void {
    this.state.status = "finished";
    this.state.ended_at = new Date().toISOString();
    this.state.outcome = "error";
    this.state.error = error;
    this.state.redaction = this.redactor.summary();
    writeFileSync(join(this.dir, "steps.json"), `${JSON.stringify(this.state.steps, null, 2)}\n`);
    writeFileSync(join(this.dir, "result.json"), `${JSON.stringify({ ...summarize(this.state), final_answer: "" }, null, 2)}\n`);
  }
}

export class RunStore {
  private readonly runs = new Map<string, Run>();
  private readonly root: string;

  constructor(root: string) {
    this.root = root;
    mkdirSync(root, { recursive: true });
  }

  create(input: RunInput, versions: Versions): Run {
    const dir = join(this.root, input.run_id);
    mkdirSync(join(dir, "raw"), { recursive: true });
    writeFileSync(join(dir, "input.json"), `${JSON.stringify(input, null, 2)}\n`);
    writeFileSync(join(dir, "versions.json"), `${JSON.stringify(versions, null, 2)}\n`);
    writeFileSync(join(dir, "messages.jsonl"), "");
    const state: RunState = {
      input,
      versions,
      status: "running",
      outcome: null,
      events: [],
      steps: [],
      usage: emptyUsage(),
      cost_usd: null,
      final_answer: "",
      error: null,
      started_at: input.created_at,
      ended_at: null,
      redaction: [],
      model: null,
    };
    const run = new Run(dir, state);
    this.runs.set(input.run_id, run);
    return run;
  }

  get(runId: string): Run | undefined {
    return this.runs.get(runId) ?? this.load(runId);
  }

  list(tenant: string, limit = 50): RunSummary[] {
    const seen = new Map<string, RunSummary>();
    if (existsSync(this.root)) {
      for (const entry of readdirSync(this.root, { withFileTypes: true })) {
        if (!entry.isDirectory()) continue;
        const run = this.get(entry.name);
        if (run && run.state.input.tenant === tenant) seen.set(run.id, summarize(run.state));
      }
    }
    return [...seen.values()]
      .sort((a, b) => b.started_at.localeCompare(a.started_at))
      .slice(0, limit);
  }

  /** 从归档目录重建：进程重启后老运行仍然可查、可回放。 */
  private load(runId: string): Run | undefined {
    const dir = join(this.root, runId);
    const inputPath = join(dir, "input.json");
    if (!existsSync(inputPath)) return undefined;
    try {
      const input = JSON.parse(readFileSync(inputPath, "utf8")) as RunInput;
      const versions = existsSync(join(dir, "versions.json"))
        ? (JSON.parse(readFileSync(join(dir, "versions.json"), "utf8")) as Versions)
        : null;
      if (!versions) return undefined;
      const state: RunState = {
        input,
        versions,
        status: "finished",
        outcome: null,
        events: [],
        steps: existsSync(join(dir, "steps.json"))
          ? (JSON.parse(readFileSync(join(dir, "steps.json"), "utf8")) as Step[])
          : [],
        usage: emptyUsage(),
        cost_usd: null,
        final_answer: "",
        error: null,
        started_at: input.created_at,
        ended_at: null,
        redaction: [],
        model: null,
      };
      const run = new Run(dir, state);
      const messagesPath = join(dir, "messages.jsonl");
      if (existsSync(messagesPath)) {
        for (const line of readFileSync(messagesPath, "utf8").split("\n")) {
          if (!line.trim()) continue;
          const event = JSON.parse(line) as NormalizedEvent;
          state.events.push(event);
          if (event.type === "message") {
            if (event.usage) state.usage = addUsage(state.usage, event.usage);
            if (event.model) state.model = event.model;
          }
          if (event.type === "outcome") {
            state.outcome = event.outcome;
            state.final_answer = event.final_answer;
            state.error = event.error;
          }
        }
      }
      const resultPath = join(dir, "result.json");
      if (existsSync(resultPath)) {
        const result = JSON.parse(readFileSync(resultPath, "utf8")) as Partial<RunSummary>;
        state.cost_usd = result.cost_usd ?? null;
        state.redaction = result.redaction ?? [];
        state.ended_at = result.ended_at ?? null;
        state.status = result.status === "running" ? "finished" : (result.status ?? "finished");
        if (typeof result.final_answer === "string") state.final_answer = result.final_answer;
      }
      this.runs.set(runId, run);
      return run;
    } catch {
      return undefined;
    }
  }
}
