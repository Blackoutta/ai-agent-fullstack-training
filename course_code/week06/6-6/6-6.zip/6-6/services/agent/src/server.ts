/**
 * Agent 服务入口。只做编排，不做决策：
 *   创建运行 → spawn worker 子进程 → 归一/脱敏事件 → 广播 SSE + 写归档 → 上报用量与 trace。
 *
 * 选 worker 子进程而不是进程内调用，是为了让"每次运行的模型别名"成为进程级环境变量：
 * 灰度两轨同时跑两个模型时，全局 env 表达不了这个差异。
 */
import { spawn } from "node:child_process";
import { randomUUID } from "node:crypto";
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { createServer, type IncomingMessage, type ServerResponse } from "node:http";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

import {
  buildReplayScript,
  diffVersions,
  versionsHash,
  type Versions,
  type VersionDiff,
} from "./core/archive.ts";
import { normalizeEvent, stepOf, type NormalizedEvent, type Step } from "./core/events.ts";
import { authenticate, parseApiKeys, type Identity } from "./core/identity.ts";
import { createExporter } from "./core/langfuse.ts";
import { Metrics } from "./core/metrics.ts";
import { chooseRelease, readRouteFile, UNRELEASED_ROUTE, type RouteTable } from "./core/release.ts";
import { Run, RunStore, summarize, type RunInput } from "./core/runs.ts";
import { formatSse, SSE_DONE, sseHeaders } from "./core/sse.ts";
import { costUsd, rawCostUsd } from "./core/usage.ts";
import type { Redactor } from "./core/redact.ts";

const HERE = dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.AGENT_PORT ?? 8080);
const RUNS_DIR = process.env.AGENT_RUNS_DIR ?? resolve(HERE, "../runs");
const RELEASES_DIR = process.env.AGENT_RELEASES_DIR ?? resolve(HERE, "../releases");
const PLATFORM_BASE = (process.env.PLATFORM_BASE_URL ?? "").replace(/\/+$/, "");
const CONFIG_PATH = process.env.PLATFORM_CONFIG ?? resolve(HERE, "../config/platform.yaml");
const CODEBASE_DIR = process.env.CODEBASE_DIR ?? resolve(HERE, "../../../codebase");
const WORKER = resolve(HERE, "worker.ts");
/** tsx 从 codebase 的 devDependencies 来；用绝对 loader 路径，不依赖 cwd 下的 node_modules。 */
const TSX_LOADER = pathToFileURL(
  process.env.TSX_LOADER ?? join(CODEBASE_DIR, "node_modules/tsx/dist/esm/index.mjs"),
).href;
const MODE = (process.env.AGENT_MODE ?? "auto") as "auto" | "mock" | "real";
const RUN_TIMEOUT_MS = Number(process.env.AGENT_RUN_TIMEOUT_MS ?? 180_000);
const MAX_BODY = 1 << 20;
const PRICE = {
  input_per_million: Number(process.env.MODEL_INPUT_PER_MILLION ?? 0.3),
  output_per_million: Number(process.env.MODEL_OUTPUT_PER_MILLION ?? 1.2),
  cache_read_per_million: Number(process.env.MODEL_CACHE_READ_PER_MILLION ?? 0.006),
};

const keys = parseApiKeys(process.env.PLATFORM_API_KEYS);
const store = new RunStore(RUNS_DIR);
const metrics = new Metrics();
const exporter = createExporter();
const busy = new Set<string>();
/** ServerResponse → request id。响应对象生命周期与一次请求一致，不用手动清理。 */
const REQUEST_IDS = new WeakMap<ServerResponse, string>();
metrics.set("agent_up", 1, { service: "agent" });

// ---------------------------------------------------------------- 工具函数

function json(res: ServerResponse, status: number, body: unknown, headers: Record<string, string> = {}): void {
  const payload = `${JSON.stringify(body, null, 2)}\n`;
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Content-Length": Buffer.byteLength(payload),
    "Cache-Control": "no-store",
    "X-Request-Id": requestId(res),
    ...headers,
  });
  res.end(payload);
}

/** 请求号：沿用调用方传来的，没有就现生成一个；同一响应里 body 与 header 用同一个值。 */
function requestId(res: ServerResponse): string {
  let id = REQUEST_IDS.get(res);
  if (!id) {
    id = `req-${randomUUID().replace(/-/g, "").slice(0, 12)}`;
    REQUEST_IDS.set(res, id);
  }
  return id;
}

function fail(res: ServerResponse, status: number, code: string, message: string, extra: Record<string, unknown> = {}): void {
  // 契约形状：{error:{code,message}, code, details[], request_id}。
  // extra 保留在顶层（回放 409 的 archived/current/diffs 是既有调用方依赖的字段），
  // 同时放进 details[]，让「所有错误详情都从 details 读」的新调用方也能只认一个位置。
  json(res, status, {
    error: { code, message },
    code,
    details: Object.keys(extra).length ? [extra] : [],
    request_id: requestId(res),
    ...extra,
  });
}

async function readBody(req: IncomingMessage): Promise<unknown> {
  const chunks: Buffer[] = [];
  let size = 0;
  for await (const chunk of req) {
    size += (chunk as Buffer).length;
    if (size > MAX_BODY) throw new Error("BODY_TOO_LARGE");
    chunks.push(chunk as Buffer);
  }
  if (!size) return {};
  return JSON.parse(Buffer.concat(chunks).toString("utf8"));
}

/** 平台调用一律短超时：控制面慢不能把数据面拖住。 */
async function platformCall<T>(path: string, init?: { method?: string; body?: unknown }): Promise<T | null> {
  if (!PLATFORM_BASE) return null;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 1500);
  try {
    const response = await fetch(`${PLATFORM_BASE}${path}`, {
      method: init?.method ?? "GET",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${process.env.PLATFORM_INTERNAL_KEY ?? ""}`,
      },
      body: init?.body === undefined ? undefined : JSON.stringify(init.body),
      signal: controller.signal,
    });
    if (!response.ok) {
      // 预算拦截是「有意义的拒绝」而不是「不可用」：429 的响应体里带着 allowed=false
      // 与 blocked scope，必须交给调用方判断，否则预算耗尽反而会把运行放过去。
      if (response.status === 429) {
        try {
          return (await response.json()) as T;
        } catch {
          return null;
        }
      }
      return null;
    }
    return (await response.json()) as T;
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

async function loadRoute(): Promise<RouteTable> {
  const remote = await platformCall<RouteTable>("/v1/releases/route");
  if (remote && typeof remote.stable === "string") return remote;
  return readRouteFile(join(RELEASES_DIR, "route.json")) ?? UNRELEASED_ROUTE;
}

interface ManifestView {
  agent?: Record<string, unknown>;
  retrieval?: Record<string, unknown>;
}

function loadManifest(version: string): ManifestView | null {
  const path = join(RELEASES_DIR, version, "manifest.json");
  if (!existsSync(path)) return null;
  try {
    const raw = JSON.parse(readFileSync(path, "utf8")) as { components?: ManifestView };
    return raw.components ?? null;
  } catch {
    return null;
  }
}

function text(value: unknown): string | undefined {
  return typeof value === "string" && value.trim() ? value.trim() : undefined;
}

function versionsFor(release: string, modelAlias: string): Versions {
  const manifest = loadManifest(release);
  const agent = (manifest?.agent ?? {}) as Record<string, unknown>;
  const retrieval = (manifest?.retrieval ?? {}) as Record<string, unknown>;
  return {
    prompt_name: text(agent.prompt_name) ?? "codebase.agent",
    prompt_version: text(agent.prompt_version) ?? "v1",
    prompt_hash: text(agent.prompt_hash) ?? "sha256:local",
    model_alias: modelAlias,
    tools_version: text(agent.tools_version) ?? "codebase-tools-v2",
    retrieval_collection: text(retrieval.collection) ?? "login_demo_chunks",
    corpus_hash: text(retrieval.corpus_hash) ?? "sha256:unknown",
    release_version: release,
  };
}

// ---------------------------------------------------------------- 运行编排

interface WorkerOutput {
  events: NormalizedEvent[];
  steps: Step[];
  result: Record<string, unknown> | null;
  exitCode: number | null;
  timedOut: boolean;
  stderr: string;
}

interface WorkerOptions {
  tenant: string;
  dept: string;
  redactor: Redactor;
  payload: Record<string, unknown>;
}

/**
 * 拉起一次 worker。stdout 是协议行、stderr 是自由的——两者分开读，
 * 所以 worker 里任何一句 console.log 都不会把事件流弄坏（它只可能弄脏日志）。
 */
function runWorker(input: WorkerOptions, modelAlias: string): Promise<WorkerOutput> {
  return new Promise((resolvePromise) => {
    const child = spawn(process.execPath, ["--import", TSX_LOADER, WORKER], {
      cwd: CODEBASE_DIR,
      env: {
        ...process.env,
        PLATFORM_CONFIG: CONFIG_PATH,
        GATEWAY_MODEL_ID: modelAlias,
        RUN_TENANT: input.tenant,
        RUN_DEPT: input.dept,
      },
      stdio: ["pipe", "pipe", "pipe"],
    });

    let stderr = "";
    let timedOut = false;
    const timer = setTimeout(() => {
      timedOut = true;
      child.kill("SIGKILL");
    }, RUN_TIMEOUT_MS);

    child.stderr.on("data", (chunk: Buffer) => {
      stderr = `${stderr}${chunk.toString("utf8")}`.slice(-8_000);
    });

    const collected: NormalizedEvent[] = [];
    const steps: Step[] = [];
    let result: Record<string, unknown> | null = null;
    let buffer = "";

    child.stdout.on("data", (chunk: Buffer) => {
      buffer += chunk.toString("utf8");
      let index = buffer.indexOf("\n");
      while (index >= 0) {
        const line = buffer.slice(0, index).trim();
        buffer = buffer.slice(index + 1);
        index = buffer.indexOf("\n");
        if (!line) continue;
        let raw: Record<string, unknown>;
        try {
          raw = JSON.parse(line) as Record<string, unknown>;
        } catch {
          continue;
        }
        if (raw.type === "result") {
          result = (raw.result as Record<string, unknown>) ?? {};
        }
        const step = stepOf(raw);
        if (step) steps.push(step);
        const event = normalizeEvent(raw, input.redactor);
        if (event) collected.push(event);
      }
    });

    child.on("close", (code) => {
      clearTimeout(timer);
      resolvePromise({ events: collected, steps, result, exitCode: code, timedOut, stderr });
    });

    child.stdin.end(JSON.stringify(input.payload));
  });
}

async function startRun(body: Record<string, unknown>, identity: Identity, res: ServerResponse): Promise<void> {
  const prompt = text(body.prompt);
  if (!prompt) {
    fail(res, 400, "INVALID_ARGUMENT", "prompt 必填");
    return;
  }
  const task = text(body.task) ?? null;
  const goal = text(body.goal) ?? null;
  const runId = randomUUID();
  const group = text(body.release_group) ?? null;
  const route = await loadRoute();
  const choice = chooseRelease(route, runId, group);
  const modelAlias = text(body.model_alias) ?? text(process.env.GATEWAY_MODEL_ID) ?? "deepseek-flash";
  const versions = versionsFor(choice.version, modelAlias);

  // 预算：控制面说不允许就不开跑；控制面联系不上则继续，但留一条明确的跳过记录。
  const budget = await platformCall<{ allowed?: boolean; scope?: string }>(
    `/v1/budgets/check?scope=tenant:${encodeURIComponent(identity.tenant)}&scope=dept:${encodeURIComponent(`${identity.tenant}/${identity.dept}`)}`,
  );
  if (budget && budget.allowed === false) {
    metrics.inc("agent_budget_blocked_total", { tenant: identity.tenant, dept: identity.dept });
    fail(res, 429, "BUDGET_EXCEEDED", "预算已耗尽，本次运行被拦截", { scope: budget.scope ?? null }, { "Retry-After": "600" });
    return;
  }

  const input: RunInput = {
    run_id: runId,
    prompt,
    task,
    goal,
    tenant: identity.tenant,
    dept: identity.dept,
    user: text(body.user) ?? `${identity.tenant}:${identity.dept}`,
    roles: [identity.role],
    release_version: choice.version,
    track: choice.track,
    model_alias: modelAlias,
    created_at: new Date().toISOString(),
  };
  const run = store.create(input, versions);

  json(res, 202, {
    run_id: runId,
    status: "running",
    release: { version: choice.version, track: choice.track, reason: choice.reason },
    model_alias: modelAlias,
    events_url: `/v1/runs/${runId}/events`,
    budgets: budget === null ? "skipped" : "checked",
  });

  void execute(run, identity, prompt, task, goal, modelAlias);
}

async function execute(
  run: Run,
  identity: Identity,
  prompt: string,
  task: string | null,
  goal: string | null,
  modelAlias: string,
): Promise<void> {
  busy.add(run.id);
  const startedAt = Date.now();
  metrics.set("agent_runs_in_flight", busy.size);
  const output = await runWorker(
    {
      tenant: identity.tenant,
      dept: identity.dept,
      redactor: run.redactor,
      payload: {
        run_id: run.id,
        prompt,
        task,
        goal,
        tenant: identity.tenant,
        dept: identity.dept,
        user: run.state.input.user,
        roles: run.state.input.roles,
        decider: MODE,
        config_path: CONFIG_PATH,
      },
    },
    modelAlias,
  );

  for (const event of output.events) run.push(event);
  run.state.steps = output.steps;

  if (output.timedOut) {
    run.push({ type: "outcome", outcome: "error", final_answer: "", error: "RUN_TIMEOUT" });
  } else if (output.exitCode !== 0 || !output.events.some((event) => event.type === "outcome")) {
    run.push({ type: "outcome", outcome: "error", final_answer: "", error: summarizeWorkerFailure(output) });
  }

  const usage = run.state.usage;
  const reported = rawCostUsd(output.result);
  // 一次模型都没调过的运行没有成本可言：那时 0 是“没发生”，不是“花了 0 元”。
  const billed = usage.input_tokens + usage.output_tokens > 0;
  const cost = reported ?? (billed ? costUsd(usage, PRICE) : null);
  run.finish({ cost_usd: cost, redaction: run.redactor.summary() });
  busy.delete(run.id);
  metrics.set("agent_runs_in_flight", busy.size);

  const outcome = run.state.outcome ?? "unknown";
  metrics.inc("agent_runs_total", {
    outcome,
    release: run.state.input.release_version,
    track: run.state.input.track,
  });
  metrics.observe("agent_run_duration_ms", Date.now() - startedAt, { outcome });
  if (cost !== null) {
    metrics.inc("platform_cost_usd_total", { tenant: identity.tenant, model: modelAlias }, cost);
  }

  await reportUsage(run, identity, cost);
  exporter.trace({
    runId: run.id,
    tenant: identity.tenant,
    dept: identity.dept,
    task: run.state.input.prompt.slice(0, 500),
    delayMs: Date.now() - startedAt,
    model: run.state.model ?? modelAlias,
    usage: {
      input_tokens: usage.input_tokens,
      output_tokens: usage.output_tokens,
      cache_tokens: usage.cache_tokens,
    },
    costUsd: cost,
    outcome,
    startedAt: run.state.started_at,
    endedAt: run.state.ended_at ?? new Date().toISOString(),
  });
}

/** 从 worker 的 stderr 里挑出最像“真正的错”的那一行：整段堆栈进账本没人看得下去。 */
function summarizeWorkerFailure(output: WorkerOutput): string {
  const lines = output.stderr
    .split("\n")
    .map((line) => line.trim())
    .filter(Boolean);
  const marked = lines.find((line) => /(Error|error:|Cannot find|failed)/.test(line));
  if (marked) return marked.slice(0, 400);
  const tail = lines.slice(-2).join(" | ");
  return (tail || "WORKER_EXIT").slice(0, 400);
}

async function reportUsage(run: Run, identity: Identity, cost: number | null): Promise<void> {
  const usage = run.state.usage;
  await platformCall("/v1/usage", {
    method: "POST",
    body: {
      run_id: run.id,
      tenant: identity.tenant,
      dept: identity.dept,
      source: "agent",
      model: run.state.model ?? run.state.input.model_alias,
      model_alias: run.state.input.model_alias,
      task: run.state.input.task,
      release_version: run.state.input.release_version,
      track: run.state.input.track,
      outcome: run.state.outcome ?? "unknown",
      input_tokens: usage.input_tokens,
      output_tokens: usage.output_tokens,
      cache_tokens: usage.cache_tokens,
      // 平台报表按 total_tokens 聚合；不传就等于「说不清」，会被算成未知 token 运行。
      // 三者互不重叠（成本也是三项分别计价后相加），所以直接求和。
      total_tokens: usage.input_tokens + usage.output_tokens + usage.cache_tokens,
      cost_usd: cost,
    },
  });
}

// ---------------------------------------------------------------- 回放

interface ReplayCompare {
  ok: boolean;
  answer_equal: boolean;
  tool_sequence_equal: boolean;
  outcome_equal: boolean;
  expected: { answer: string; tools: string[]; outcome: string | null };
  actual: { answer: string; tools: string[]; outcome: string | null };
}

async function replay(run: Run, identity: Identity, res: ServerResponse): Promise<void> {
  if (!run.state.steps.length) {
    fail(res, 422, "REPLAY_NO_STEPS", "这次运行没有可回放的决策步骤（模型一次都没回复）");
    return;
  }
  const route = await loadRoute();
  const target = versionsFor(route.stable, run.state.input.model_alias);
  const diffs: VersionDiff[] = diffVersions(run.state.versions, target);
  if (diffs.length) {
    fail(res, 409, "REPLAY_VERSION_MISMATCH", "当前生效版本与归档版本不一致，回放会得出无意义的结论", {
      archived: run.state.versions,
      current: target,
      diffs,
    });
    return;
  }

  const dir = join(run.dir, "replay");
  mkdirSync(dir, { recursive: true });
  const scriptPath = join(dir, "replay-script.yaml");
  writeFileSync(scriptPath, buildReplayScript(run.state.steps));

  const startedAt = Date.now();
  const output = await runWorker(
    {
      tenant: identity.tenant,
      dept: identity.dept,
      redactor: run.redactor,
      payload: {
        run_id: `${run.id}-replay`,
        prompt: run.state.input.prompt,
        task: run.state.input.task,
        goal: run.state.input.goal,
        tenant: identity.tenant,
        dept: identity.dept,
        user: run.state.input.user,
        roles: run.state.input.roles,
        decider: "mock",
        script_path: scriptPath,
        config_path: CONFIG_PATH,
      },
    },
    run.state.input.model_alias,
  );

  const actualOutcome = output.events.find((event) => event.type === "outcome");
  const actualAnswer = actualOutcome && actualOutcome.type === "outcome" ? actualOutcome.final_answer : "";
  const expectedTools = run.state.events
    .filter((event): event is Extract<NormalizedEvent, { type: "tool" }> => event.type === "tool" && event.status === "start")
    .map((event) => event.tool);
  const actualTools = output.events
    .filter((event): event is Extract<NormalizedEvent, { type: "tool" }> => event.type === "tool" && event.status === "start")
    .map((event) => event.tool);

  const normalize = (value: string): string => value.replace(/\s+/g, " ").trim();
  const compare: ReplayCompare = {
    ok: false,
    answer_equal: normalize(actualAnswer) === normalize(run.state.final_answer),
    tool_sequence_equal: expectedTools.join(">") === actualTools.join(">"),
    outcome_equal:
      (actualOutcome && actualOutcome.type === "outcome" ? actualOutcome.outcome : null) === run.state.outcome,
    expected: { answer: run.state.final_answer, tools: expectedTools, outcome: run.state.outcome },
    actual: {
      answer: actualAnswer,
      tools: actualTools,
      outcome: actualOutcome && actualOutcome.type === "outcome" ? actualOutcome.outcome : null,
    },
  };
  compare.ok = compare.answer_equal && compare.tool_sequence_equal && compare.outcome_equal;

  const report = {
    run_id: run.id,
    mode: "recorded-script",
    status: compare.ok ? "match" : "differs",
    archived_versions_hash: versionsHash(run.state.versions),
    elapsed_ms: Date.now() - startedAt,
    steps: run.state.steps.length,
    ...compare,
  };
  writeFileSync(join(dir, "report.json"), `${JSON.stringify(report, null, 2)}\n`);
  writeFileSync(join(dir, "report.md"), renderReplayReport(report));
  metrics.inc("agent_replays_total", { status: report.status });
  json(res, 200, report);
}

function renderReplayReport(report: { run_id: string; status: string; steps: number; elapsed_ms: number } & ReplayCompare): string {
  const mark = (value: boolean): string => (value ? "一致" : "不一致");
  return [
    `# 回放报告 ${report.run_id}`,
    "",
    `- 结论：**${report.status}**（${report.elapsed_ms}ms，${report.steps} 步）`,
    `- 最终答案：${mark(report.answer_equal)}`,
    `- 工具调用序列：${mark(report.tool_sequence_equal)}`,
    `- 运行结局：${mark(report.outcome_equal)}`,
    "",
    "## 工具序列",
    "",
    `- 归档：${report.expected.tools.join(" → ") || "（无）"}`,
    `- 回放：${report.actual.tools.join(" → ") || "（无）"}`,
    "",
    "## 最终答案",
    "",
    "归档：",
    "",
    "```",
    report.expected.answer || "（空）",
    "```",
    "",
    "回放：",
    "",
    "```",
    report.actual.answer || "（空）",
    "```",
    "",
  ].join("\n");
}

// ---------------------------------------------------------------- SSE

function streamEvents(run: Run, res: ServerResponse): void {
  res.writeHead(200, sseHeaders());
  let closed = false;
  const send = (event: NormalizedEvent): void => {
    if (closed) return;
    res.write(formatSse({ event: event.type, data: event }));
    if (event.type === "outcome") finish();
  };

  for (const event of run.state.events) {
    res.write(formatSse({ event: event.type, data: event }));
  }
  if (run.state.status === "finished") {
    res.write(SSE_DONE);
    res.end();
    closed = true;
    return;
  }

  const unsubscribe = run.subscribe(send);
  const ping = setInterval(() => {
    if (closed) return;
    res.write(": ping\n\n");
  }, 15_000);

  const finish = (): void => {
    if (closed) return;
    closed = true;
    clearInterval(ping);
    unsubscribe();
    res.write(SSE_DONE);
    res.end();
  };

  res.on("close", () => {
    closed = true;
    clearInterval(ping);
    unsubscribe();
  });
}

// ---------------------------------------------------------------- 路由

async function route(req: IncomingMessage, res: ServerResponse): Promise<void> {
  const incomingId = req.headers["x-request-id"];
  if (incomingId) REQUEST_IDS.set(res, String(incomingId));
  const url = new URL(req.url ?? "/", `http://${req.headers.host ?? "localhost"}`);
  const path = url.pathname;

  if (req.method === "GET" && path === "/health") {
    json(res, 200, {
      status: "ok",
      service: "agent",
      mode: MODE,
      runs_dir: RUNS_DIR,
      in_flight: busy.size,
      platform: PLATFORM_BASE || null,
    });
    return;
  }
  if (req.method === "GET" && path === "/metrics") {
    const body = metrics.render();
    res.writeHead(200, { "Content-Type": "text/plain; version=0.0.4; charset=utf-8" });
    res.end(body);
    return;
  }

  const identity = authenticate(req.headers.authorization, keys);
  if (!identity) {
    fail(res, 401, "UNAUTHENTICATED", "缺少或无效的 API Key");
    return;
  }

  if (req.method === "POST" && path === "/v1/runs") {
    const body = (await readBody(req)) as Record<string, unknown>;
    await startRun(body, identity, res);
    return;
  }
  if (req.method === "GET" && path === "/v1/runs") {
    json(res, 200, { items: store.list(identity.tenant) });
    return;
  }
  const match = /^\/v1\/runs\/([^/]+)(\/events|\/replay)?$/.exec(path);
  if (match) {
    const run = store.get(decodeURIComponent(match[1]));
    if (!run) {
      fail(res, 404, "RUN_NOT_FOUND", "没有这次运行");
      return;
    }
    if (run.state.input.tenant !== identity.tenant) {
      metrics.inc("tenant_violations_total", { service: "agent" });
      fail(res, 403, "FORBIDDEN_TENANT", "跨租户访问被拒绝");
      return;
    }
    const action = match[2];
    if (req.method === "GET" && action === "/events") {
      streamEvents(run, res);
      return;
    }
    if (req.method === "POST" && action === "/replay") {
      await replay(run, identity, res);
      return;
    }
    if (req.method === "GET" && !action) {
      json(res, 200, { ...summarize(run.state), final_answer: run.state.final_answer, steps: run.state.steps.length });
      return;
    }
  }

  fail(res, 404, "NOT_FOUND", `没有这个路由：${req.method} ${path}`);
}

const server = createServer((req, res) => {
  route(req, res).catch((error: unknown) => {
    const message = error instanceof Error ? error.message : String(error);
    if (message === "BODY_TOO_LARGE") {
      fail(res, 413, "BODY_TOO_LARGE", "请求体超过 1MB");
      return;
    }
    process.stderr.write(`[agent] ${req.method} ${req.url} failed: ${message}\n`);
    fail(res, 500, "INTERNAL", "服务内部错误");
  });
});

server.listen(PORT, "0.0.0.0", () => {
  process.stdout.write(`[agent] listening on :${PORT} · runs=${RUNS_DIR} · mode=${MODE} · platform=${PLATFORM_BASE || "(未配置)"}\n`);
});

for (const signal of ["SIGTERM", "SIGINT"] as const) {
  process.on(signal, () => {
    void exporter.flush().finally(() => process.exit(0));
  });
}
