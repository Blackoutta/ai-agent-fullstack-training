/** 成本计算：价格缺失就是未知，不按 0 计。 */
export interface Price {
  input_per_million?: number | null;
  output_per_million?: number | null;
  cache_read_per_million?: number | null;
}

export interface Usage {
  input_tokens: number;
  output_tokens: number;
  cache_tokens: number;
}

const MILLION = 1_000_000;

export function emptyUsage(): Usage {
  return { input_tokens: 0, output_tokens: 0, cache_tokens: 0 };
}

export function addUsage(total: Usage, part: Partial<Usage>): Usage {
  return {
    input_tokens: total.input_tokens + Number(part.input_tokens ?? 0),
    output_tokens: total.output_tokens + Number(part.output_tokens ?? 0),
    cache_tokens: total.cache_tokens + Number(part.cache_tokens ?? 0),
  };
}

/** 三个价格都齐全才算得出已知成本；任何一个缺失返回 null（未知）。 */
export function costUsd(usage: Usage, price: Price): number | null {
  const input = price.input_per_million;
  const output = price.output_per_million;
  const cache = price.cache_read_per_million;
  if (typeof input !== "number" || typeof output !== "number" || typeof cache !== "number") return null;
  const cost =
    (usage.input_tokens * input + usage.output_tokens * output + usage.cache_tokens * cache) / MILLION;
  return Math.round(cost * 1e6) / 1e6;
}

/** codebase 的 usage 字段与 pi 的命名不同，这里只认三种：input/output/cacheRead。 */
export function usageOf(raw: unknown): Usage {
  const item = (raw && typeof raw === "object" ? raw : {}) as Record<string, unknown>;
  const pick = (keys: string[]): number => {
    for (const key of keys) {
      const value = item[key];
      if (typeof value === "number" && Number.isFinite(value)) return value;
    }
    return 0;
  };
  return {
    input_tokens: pick(["input", "input_tokens", "prompt_tokens"]),
    output_tokens: pick(["output", "output_tokens", "completion_tokens"]),
    cache_tokens: pick(["cacheRead", "cache_read", "cache_read_tokens", "cache_tokens"]),
  };
}

/**
 * 模型侧报的成本。0 视为"没报"：离线脚本决策器恒为 0，
 * 这种情况下由 server 按单价折算，否则 MAX_COST 预算永远不会触发。
 */
export function rawCostUsd(raw: unknown): number | null {
  const item = (raw && typeof raw === "object" ? raw : {}) as Record<string, unknown>;
  const direct = item.cost_usd;
  if (typeof direct === "number" && direct > 0) return direct;
  const nested = item.cost as Record<string, unknown> | undefined;
  const total = nested && typeof nested === "object" ? nested.total : undefined;
  if (typeof total === "number" && total > 0) return total;
  return null;
}
