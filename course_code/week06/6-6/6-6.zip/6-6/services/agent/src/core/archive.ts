/** 运行归档与回放版本核对。 */
import { createHash } from "node:crypto";

export interface Versions {
  prompt_name: string;
  prompt_version: string;
  prompt_hash: string;
  model_alias: string;
  tools_version: string;
  retrieval_collection: string;
  corpus_hash: string;
  release_version: string;
}

export interface VersionDiff {
  field: string;
  expected: string;
  actual: string;
}

/** 逐字段比对，缺字段也算差异；不做「差不多就行」的模糊匹配。 */
export function diffVersions(expected: Versions, actual: Versions): VersionDiff[] {
  const fields: Array<keyof Versions> = [
    "prompt_name",
    "prompt_version",
    "prompt_hash",
    "model_alias",
    "tools_version",
    "retrieval_collection",
    "corpus_hash",
    "release_version",
  ];
  const diffs: VersionDiff[] = [];
  for (const field of fields) {
    const left = String(expected[field] ?? "");
    const right = String(actual[field] ?? "");
    if (left !== right) diffs.push({ field, expected: left, actual: right });
  }
  return diffs;
}

export function canonicalVersions(versions: Versions): string {
  const ordered = Object.keys(versions)
    .sort()
    .map((key) => [key, (versions as unknown as Record<string, unknown>)[key]]);
  return JSON.stringify(ordered);
}

export function versionsHash(versions: Versions): string {
  return `sha256:${createHash("sha256").update(canonicalVersions(versions)).digest("hex")}`;
}

/** 回放脚本：YAML 是 JSON 的超集，直接写 JSON 就不会有转义问题。 */
export function buildReplayScript(steps: Array<{ text: string; tool_calls: Array<{ name: string; args: Record<string, unknown> }> }>): string {
  const payload = {
    steps: steps.map((step) => ({
      text: step.text,
      ...(step.tool_calls.length ? { tool_calls: step.tool_calls } : {}),
    })),
  };
  return `${JSON.stringify(payload, null, 2)}\n`;
}
