/** 发布路由：stable / pilot 双轨，按比例或显式分组切流。 */
import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";

export interface RouteTable {
  stable: string;
  pilot: string | null;
  pilot_ratio: number;
}

/** 还没发布过任何版本时的兜底路由：跑的是镜像里自带的配置。 */
export const UNRELEASED_ROUTE: RouteTable = { stable: "unreleased", pilot: null, pilot_ratio: 0 };

export type Track = "stable" | "pilot";

export interface ReleaseChoice {
  version: string;
  track: Track;
  reason: string;
}

/** 0..99 的稳定桶：同一 runId 永远落在同一桶，重试不会在两轨间来回跳。 */
export function hashBucket(runId: string): number {
  const digest = createHash("sha256").update(runId).digest();
  return digest.readUInt32BE(0) % 100;
}

/** 路由表来自平台写入的 route.json；字段不全就当作没发布，绝不猜。 */
export function parseRoute(raw: unknown): RouteTable | null {
  if (!raw || typeof raw !== "object") return null;
  const item = raw as Record<string, unknown>;
  const stable = typeof item.stable === "string" ? item.stable : "";
  if (!stable) return null;
  const pilot = typeof item.pilot === "string" && item.pilot ? item.pilot : null;
  const ratio = Number(item.pilot_ratio);
  return { stable, pilot, pilot_ratio: Number.isFinite(ratio) ? ratio : 0 };
}

export function readRouteFile(path: string): RouteTable | null {
  try {
    return parseRoute(JSON.parse(readFileSync(path, "utf8")));
  } catch {
    return null;
  }
}

export function chooseRelease(
  table: RouteTable,
  runId: string,
  group?: string | null,
): ReleaseChoice {
  const ratio = Number.isFinite(table.pilot_ratio) ? Math.max(0, Math.min(100, table.pilot_ratio)) : 0;
  if (table.pilot && group === "pilot") {
    return { version: table.pilot, track: "pilot", reason: "explicit_group" };
  }
  if (table.pilot && group === "stable") {
    return { version: table.stable, track: "stable", reason: "explicit_group" };
  }
  if (table.pilot && ratio > 0) {
    const bucket = hashBucket(runId);
    if (bucket < ratio) {
      return { version: table.pilot, track: "pilot", reason: `ratio:${bucket}<${ratio}` };
    }
    return { version: table.stable, track: "stable", reason: `ratio:${bucket}>=${ratio}` };
  }
  return { version: table.stable, track: "stable", reason: table.pilot ? "ratio:0" : "no_pilot" };
}
