/** 把 worker 的原始行归一成对外事件，并在出口统一脱敏。 */
import type { Redactor } from "./redact.ts";

export type NormalizedEvent =
  | { type: "delta"; text: string }
  | { type: "message"; role: string; text: string; model: string | null; usage: Record<string, number> | null }
  | { type: "tool"; tool: string; status: "start" | "end"; tool_call_id: string; failed: boolean }
  | { type: "deliverable"; line: string }
  | { type: "log"; line: string }
  | { type: "outcome"; outcome: Outcome; final_answer: string; error: string | null };

export type Outcome = "pass" | "fail" | "error" | "unknown";

export interface Step {
  text: string;
  tool_calls: Array<{ name: string; args: Record<string, unknown> }>;
}

interface RawLine {
  type?: string;
  [key: string]: unknown;
}

const asRecord = (value: unknown): Record<string, unknown> =>
  value && typeof value === "object" ? (value as Record<string, unknown>) : {};

/** 从 assistant 消息里抽出可回放的决策步骤：文本 + 工具调用。 */
export function stepOf(raw: RawLine): Step | null {
  if (raw.type !== "message") return null;
  if (String(raw.role ?? "") !== "assistant") return null;
  const calls = Array.isArray(raw.tool_calls) ? raw.tool_calls : [];
  return {
    text: String(raw.text ?? ""),
    tool_calls: calls.map((call) => {
      const item = asRecord(call);
      return { name: String(item.name ?? ""), args: asRecord(item.args) };
    }),
  };
}

export function outcomeOf(raw: RawLine): { outcome: Outcome; error: string | null } {
  const result = asRecord(raw.result);
  const stop = asRecord(result.stop);
  const error = typeof result.error === "string" ? result.error : null;
  if (error) return { outcome: "error", error };
  if (stop.code === "ABORTED" || stop.code === "MODEL_ERROR" || stop.code === "GATE_BLOCKED") {
    return { outcome: "error", error: String(stop.reason ?? stop.code) };
  }
  const answer = String(result.final_answer ?? "").trim();
  if (!answer) return { outcome: "unknown", error: stop.code ? String(stop.code) : "EMPTY_ANSWER" };
  if (stop.stop === false) return { outcome: "unknown", error: String(stop.code ?? "UNFINISHED") };
  return { outcome: "pass", error: null };
}

export function normalizeEvent(raw: RawLine, redactor: Redactor): NormalizedEvent | null {
  switch (raw.type) {
    // 增量只走 SSE，不进归档：完整消息会以 message 事件再来一遍，存两遍是浪费。
    case "delta":
      return { type: "delta", text: redactor.scrubText(String(raw.text ?? "")) };
    case "message": {
      const usage = raw.usage ? (redactor.scrubValue(raw.usage) as Record<string, number>) : null;
      return {
        type: "message",
        role: String(raw.role ?? "assistant"),
        text: redactor.scrubText(String(raw.text ?? "")),
        model: raw.model ? String(raw.model) : null,
        usage,
      };
    }
    case "tool": {
      return {
        type: "tool",
        tool: String(raw.tool ?? "unknown"),
        status: raw.status === "end" ? "end" : "start",
        tool_call_id: String(raw.tool_call_id ?? ""),
        failed: raw.failed === true,
      };
    }
    case "deliverable":
      return { type: "deliverable", line: redactor.scrubText(String(raw.line ?? "")) };
    case "log":
      return { type: "log", line: redactor.scrubText(String(raw.line ?? "")) };
    case "result": {
      const { outcome, error } = outcomeOf(raw);
      const result = asRecord(raw.result);
      return {
        type: "outcome",
        outcome,
        final_answer: redactor.scrubText(String(result.final_answer ?? "")),
        error: error ? redactor.scrubText(error) : null,
      };
    }
    default:
      return null;
  }
}
