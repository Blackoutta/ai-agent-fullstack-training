/** SSE 帧格式：一条事件一帧，结束发 [DONE]。 */
export interface SseFrame {
  event?: string;
  data: unknown;
}

export function formatSse(frame: SseFrame): string {
  const head = frame.event ? `event: ${frame.event}\n` : "";
  const body = typeof frame.data === "string" ? frame.data : JSON.stringify(frame.data);
  return `${head}data: ${body}\n\n`;
}

export const SSE_DONE = "data: [DONE]\n\n";

export function sseHeaders(): Record<string, string> {
  return {
    "Content-Type": "text/event-stream; charset=utf-8",
    "Cache-Control": "no-store",
    Connection: "keep-alive",
    "X-Accel-Buffering": "no",
  };
}
