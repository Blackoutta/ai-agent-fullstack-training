/**
 * 身份解析。
 *
 * 平台只把密钥放在环境变量里，任何一个服务都本地解析、本地缓存，不跨服务查身份——
 * 少一条链路的可用性依赖，也少一处分发密钥的地方。
 *
 * 格式：`key:tenant:dept:role,key2:tenant2:dept:role`。key 本身可以含冒号，
 * 所以右侧三个字段是固定位，左边整段才是 key。
 */
export interface Identity {
  tenant: string;
  dept: string;
  role: string;
  /** 只用于回显与审计，永不回显完整密钥。 */
  keyPrefix: string;
}

export function parseApiKeys(raw: string | undefined): Map<string, Identity> {
  const out = new Map<string, Identity>();
  for (const entry of (raw ?? "").split(",")) {
    const trimmed = entry.trim();
    if (!trimmed) continue;
    const parts = trimmed.split(":");
    if (parts.length < 4) continue;
    const role = parts[parts.length - 1].trim();
    const dept = parts[parts.length - 2].trim();
    const tenant = parts[parts.length - 3].trim();
    const key = parts.slice(0, parts.length - 3).join(":");
    if (!key || !tenant || !dept || !role) continue;
    out.set(key, { tenant, dept, role, keyPrefix: key.slice(0, 6) });
  }
  return out;
}

export function authenticate(header: string | null | undefined, keys: Map<string, Identity>): Identity | null {
  if (!header) return null;
  const match = /^Bearer\s+(.+)$/i.exec(header.trim());
  const token = match ? match[1].trim() : header.trim();
  return keys.get(token) ?? null;
}
