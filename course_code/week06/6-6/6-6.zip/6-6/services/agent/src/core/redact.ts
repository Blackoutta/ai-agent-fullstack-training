/**
 * 分类分级脱敏。规则与 services/platform/app/redaction.py 一一对应，
 * 由 tests/test_redaction_parity.py 与 services/agent/tests/core.test.ts 双向断言。
 *
 * 不可逆原则：金额映射只活在这个实例里，运行结束即丢弃；不写盘、不跨租户。
 */

export interface RedactionHit {
  category: "id_card" | "phone" | "address" | "amount";
  count: number;
}

const ID_CARD = /\b(\d{3})\d{11}(\d{3}[\dXx])\b/g;
const PHONE = /(?<!\d)(1[3-9]\d)\d{4}(\d{4})(?!\d)/g;
const AMOUNT =
  /(?<![\d.])(?:[¥￥$]\s*)?\d{1,3}(?:,\d{3})+(?:\.\d+)?(?:\s*(?:元|万元|美元))?|(?<![\d.])\d+(?:\.\d+)?\s*(?:万元|美元|元)/g;
const ADDRESS =
  /[\u4e00-\u9fa5]{2,10}(?:省|自治区|市)[\u4e00-\u9fa5]{0,12}(?:路|街|道|巷|区|县|镇)[\u4e00-\u9fa5A-Za-z0-9#\-]{0,20}\d*号?/g;

/** 地址只留到省/市级，其余一律 ***。 */
export function maskAddress(value: string): string {
  const head = value.match(/^.*(?:省|自治区|市)/);
  return `${head ? head[0] : ""}***`;
}

export class Redactor {
  private readonly amounts = new Map<string, string>();
  private readonly hits = new Map<string, RedactionHit>();

  private record(category: RedactionHit["category"], count = 1): void {
    const current = this.hits.get(category);
    this.hits.set(category, { category, count: (current?.count ?? 0) + count });
  }

  /** 金额原文换成 AMOUNT_n；同一金额在一次运行里复用同一个 token。 */
  private tokenOf(raw: string): string {
    const key = raw.replace(/\s+/g, "");
    const existing = this.amounts.get(key);
    if (existing) return existing;
    const token = `AMOUNT_${this.amounts.size + 1}`;
    this.amounts.set(key, token);
    return token;
  }

  scrubText(text: string): string {
    let out = text.replace(ID_CARD, (_m, head: string, tail: string) => {
      this.record("id_card");
      return `${head}${"*".repeat(11)}${tail}`;
    });
    out = out.replace(PHONE, (_m, head: string, tail: string) => {
      this.record("phone");
      return `${head}****${tail}`;
    });
    out = out.replace(AMOUNT, (match) => {
      this.record("amount");
      return this.tokenOf(match);
    });
    out = out.replace(ADDRESS, (match) => {
      this.record("address");
      return maskAddress(match);
    });
    return out;
  }

  /** 数字与布尔原样保留：报表与评测需要结构化数值（含百分比）。 */
  scrubValue(value: unknown): unknown {
    if (typeof value === "string") return this.scrubText(value);
    if (Array.isArray(value)) return value.map((item) => this.scrubValue(item));
    if (value && typeof value === "object") {
      const out: Record<string, unknown> = {};
      for (const [key, item] of Object.entries(value as Record<string, unknown>)) {
        out[key] = this.scrubValue(item);
      }
      return out;
    }
    return value;
  }

  summary(): RedactionHit[] {
    return [...this.hits.values()].sort((a, b) => a.category.localeCompare(b.category));
  }

  /** 仅供测试断言 token 复用；生产路径不导出映射。 */
  amountMap(): Record<string, string> {
    return Object.fromEntries(this.amounts);
  }
}
