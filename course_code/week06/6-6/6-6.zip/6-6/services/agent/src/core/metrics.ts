/** 极简 Prometheus 指标登记簿：不引第三方依赖，输出文本格式供 /metrics 抓取。 */

type LabelPair = Record<string, string>;
type MetricKind = "counter" | "gauge" | "histogram";

interface Series {
  labels: LabelPair;
  value: number;
}

interface Metric {
  name: string;
  kind: MetricKind;
  help: string;
  buckets?: number[];
  series: Map<string, Series>;
}

/** 默认桶单位是毫秒：这个平台上观测的是 Agent 运行与模型调用，量级从几百毫秒到几分钟。 */
const DEFAULT_BUCKETS = [100, 500, 1000, 2000, 5000, 10000, 30000, 60000, 120000];

/** 标签序列化要保持稳定：同一组标签必须落到同一个 key 上。 */
function labelKey(labels: LabelPair): string {
  const keys = Object.keys(labels).sort();
  return keys.map((key) => `${key}=${labels[key]}`).join(",");
}

function renderLabels(labels: LabelPair): string {
  const keys = Object.keys(labels).sort();
  if (!keys.length) return "";
  const body = keys.map((key) => `${key}="${escapeLabel(labels[key])}"`).join(",");
  return `{${body}}`;
}

function escapeLabel(value: string): string {
  return value.replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\n/g, "\\n");
}

function sanitize(name: string): string {
  return name.replace(/[^a-zA-Z0-9_:]/g, "_");
}

export class Metrics {
  private readonly metrics = new Map<string, Metric>();

  private metric(name: string, kind: MetricKind, help: string, buckets?: number[]): Metric {
    const key = sanitize(name);
    const existing = this.metrics.get(key);
    if (existing) return existing;
    const created: Metric = {
      name: key,
      kind,
      help,
      buckets: kind === "histogram" ? (buckets ?? DEFAULT_BUCKETS) : undefined,
      series: new Map(),
    };
    this.metrics.set(key, created);
    return created;
  }

  private hit(metric: Metric, labels: LabelPair): Series {
    const key = labelKey(labels);
    const found = metric.series.get(key);
    if (found) return found;
    const created: Series = { labels, value: 0 };
    metric.series.set(key, created);
    return created;
  }

  inc(name: string, labels: LabelPair = {}, delta = 1): void {
    const metric = this.metric(name, "counter", `${name} counter`);
    this.hit(metric, labels).value += delta;
  }

  set(name: string, value: number, labels: LabelPair = {}): void {
    const metric = this.metric(name, "gauge", `${name} gauge`);
    this.hit(metric, labels).value = value;
  }

  /**
   * 观测一次耗时。bucket 序列本身也进 labels，用 le 区分，
   * 这样 render 阶段不需要再记额外结构。
   */
  observe(name: string, value: number, labels: LabelPair = {}, buckets?: number[]): void {
    const metric = this.metric(name, "histogram", `${name} histogram`, buckets);
    const all = [...(metric.buckets ?? DEFAULT_BUCKETS), Infinity];
    for (const bound of all) {
      const label = bound === Infinity ? "+Inf" : String(bound);
      // 每个桶都要出现（哪怕计数是 0）：Prometheus 的 histogram 要求桶连续。
      const series = this.hit(metric, { ...labels, le: label });
      if (value <= bound) series.value += 1;
    }
    this.hit(metric, { ...labels, le: "__sum" }).value += value;
    this.hit(metric, { ...labels, le: "__count" }).value += 1;
  }

  render(): string {
    const lines: string[] = [];
    for (const metric of [...this.metrics.values()].sort((a, b) => a.name.localeCompare(b.name))) {
      const type = metric.kind === "histogram" ? "histogram" : metric.kind;
      lines.push(`# HELP ${metric.name} ${metric.help}`);
      lines.push(`# TYPE ${metric.name} ${type}`);
      for (const series of metric.series.values()) {
        if (metric.kind === "histogram") {
          const suffix = this.histogramSuffix(series.labels);
          const labels = { ...series.labels };
          // le 只属于 bucket；_sum / _count 上带 le 会被 Prometheus 当成另一个 series。
          if (suffix !== "_bucket") delete labels.le;
          lines.push(`${metric.name}${suffix}${renderLabels(labels)} ${series.value}`);
          continue;
        }
        lines.push(`${metric.name}${renderLabels(series.labels)} ${series.value}`);
      }
    }
    return `${lines.join("\n")}\n`;
  }

  private histogramSuffix(labels: LabelPair): string {
    if (labels.le === "__sum") return "_sum";
    if (labels.le === "__count") return "_count";
    return "_bucket";
  }
}
