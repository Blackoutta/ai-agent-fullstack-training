/**
 * 一次运行的执行器。server 每次运行 spawn 一个本文件，用每进程环境变量把
 * 租户、模型别名、发布版本注入进去——全局 env 做不到"同一时刻两个轨道跑两个模型"。
 *
 * 输入：stdin 一段 JSON（WorkerInput）。
 * 输出：stdout 每行一段 JSON（WorkerLine），server 负责归一、脱敏、归档、广播。
 * 约束：stdout 只能有协议行，任何调试信息都走 stderr，否则 server 会解析失败。
 */
import { buildPlatform } from "../../../codebase/src/platform.js";
import { runManagedAgent } from "../../../codebase/src/pi/agent-runner.js";

export interface WorkerInput {
  run_id: string;
  prompt: string;
  goal?: string | null;
  task?: string | null;
  tenant: string;
  dept: string;
  user: string;
  roles: string[];
  decider: "auto" | "mock" | "real";
  script_path?: string | null;
  config_path?: string | null;
}

type WorkerLine =
  | { type: "delta"; text: string }
  | {
      type: "message";
      role: string;
      text: string;
      model: string | null;
      usage: Record<string, number> | null;
      tool_calls: Array<{ id: string; name: string; args: Record<string, unknown> }>;
    }
  | { type: "tool"; status: "start" | "end"; tool: string; tool_call_id: string; failed: boolean }
  | { type: "deliverable"; line: string }
  | { type: "log"; line: string }
  | { type: "result"; result: Record<string, unknown> };

const emit = (line: WorkerLine): void => {
  process.stdout.write(`${JSON.stringify(line)}\n`);
};

const log = (line: string): void => emit({ type: "log", line });

const asRecord = (value: unknown): Record<string, unknown> =>
  value && typeof value === "object" ? (value as Record<string, unknown>) : {};

function usageOf(message: Record<string, unknown>): Record<string, number> | null {
  const usage = message.usage;
  if (!usage || typeof usage !== "object") return null;
  const item = usage as Record<string, unknown>;
  const num = (key: string): number => (typeof item[key] === "number" ? (item[key] as number) : 0);
  const cost = asRecord(item.cost);
  return {
    input_tokens: num("input"),
    output_tokens: num("output"),
    cache_read_tokens: num("cacheRead"),
    cache_write_tokens: num("cacheWrite"),
    total_tokens: num("totalTokens"),
    cost_usd: typeof cost.total === "number" ? (cost.total as number) : 0,
  };
}

async function readStdin(): Promise<string> {
  const chunks: Buffer[] = [];
  for await (const chunk of process.stdin) chunks.push(chunk as Buffer);
  return Buffer.concat(chunks).toString("utf8");
}

async function main(): Promise<void> {
  const raw = await readStdin();
  const input = JSON.parse(raw) as WorkerInput;
  const startedAt = Date.now();
  log(`[worker] run=${input.run_id} tenant=${input.tenant} dept=${input.dept} decider=${input.decider}`);

  const platform = await buildPlatform({
    configPath: input.config_path ?? process.env.PLATFORM_CONFIG,
    task: input.task ?? undefined,
    goal: input.goal ?? undefined,
  });

  try {
    const result = await runManagedAgent(platform, {
      prompt: input.prompt,
      userId: input.user,
      tenantId: input.tenant,
      roles: input.roles,
      decider: input.decider,
      scriptPath: input.script_path ?? undefined,
      onText: (delta) => emit({ type: "delta", text: delta }),
      onDeciderSelected: (line) => log(line),
      onDeciderStep: (line) => log(line),
      onDeliverable: (line) => emit({ type: "deliverable", line }),
      onEvent: (event) => {
        if (event.type === "tool_execution_start") {
          emit({ type: "tool", status: "start", tool: event.toolName, tool_call_id: event.toolCallId, failed: false });
          return;
        }
        if (event.type === "tool_execution_end") {
          emit({ type: "tool", status: "end", tool: event.toolName, tool_call_id: event.toolCallId, failed: event.isError });
          return;
        }
        if (event.type === "message_end" && event.message.role === "assistant") {
          const message = event.message as unknown as Record<string, unknown>;
          const parts = Array.isArray(message.content) ? message.content : [];
          const text = parts
            .map((part) => asRecord(part))
            .filter((part) => part.type === "text")
            .map((part) => String(part.text ?? ""))
            .join("");
          const toolCalls = parts
            .map((part) => asRecord(part))
            .filter((part) => part.type === "toolCall")
            .map((part) => ({
              id: String(part.id ?? ""),
              name: String(part.name ?? ""),
              args: asRecord(part.arguments),
            }));
          emit({
            type: "message",
            role: "assistant",
            text,
            model: typeof message.model === "string" ? message.model : null,
            usage: usageOf(message),
            tool_calls: toolCalls,
          });
        }
      },
    });

    emit({
      type: "result",
      result: {
        ...(result as unknown as Record<string, unknown>),
        elapsed_ms: Date.now() - startedAt,
      },
    });
  } finally {
    await platform.close();
  }
}

main().catch((error: unknown) => {
  const message = error instanceof Error ? `${error.name}: ${error.message}` : String(error);
  process.stderr.write(`[worker] failed: ${message}\n`);
  emit({ type: "log", line: `[worker] 运行失败：${message}` });
  process.exitCode = 1;
});
