/**
 * core 模块的单元测试。全部离线、无网络、无第三方依赖：
 * 这些模块是"平台说得对"和"平台真的做对了"之间的那一层，必须能在任何机器上逐条断言。
 *
 * 运行：node --test services/agent/tests/*.test.ts
 */
import assert from "node:assert/strict";
import { test } from "node:test";

import { buildReplayScript, diffVersions, versionsHash, type Versions } from "../src/core/archive.ts";
import { normalizeEvent, outcomeOf, stepOf } from "../src/core/events.ts";
import { authenticate, parseApiKeys } from "../src/core/identity.ts";
import { Metrics } from "../src/core/metrics.ts";
import { Redactor } from "../src/core/redact.ts";
import { chooseRelease, hashBucket, parseRoute, UNRELEASED_ROUTE } from "../src/core/release.ts";
import { formatSse, SSE_DONE } from "../src/core/sse.ts";
import { costUsd, emptyUsage, rawCostUsd, usageOf } from "../src/core/usage.ts";

const versions = (overrides: Partial<Versions> = {}): Versions => ({
  prompt_name: "codebase.agent",
  prompt_version: "v1",
  prompt_hash: "sha256:aaa",
  model_alias: "deepseek-flash",
  tools_version: "codebase-tools-v2",
  retrieval_collection: "login_demo_chunks",
  corpus_hash: "sha256:bbb",
  release_version: "rel-1",
  ...overrides,
});

// ---------------------------------------------------------------- 路由

test("chooseRelease：显式分组优先于比例", () => {
  const table = { stable: "rel-1", pilot: "rel-2", pilot_ratio: 0 };
  assert.equal(chooseRelease(table, "run-1", "pilot").version, "rel-2");
  assert.equal(chooseRelease(table, "run-1", "stable").version, "rel-1");
  assert.equal(chooseRelease(table, "run-1", "pilot").track, "pilot");
});

test("chooseRelease：没有 pilot 时永远走 stable", () => {
  const choice = chooseRelease({ stable: "rel-1", pilot: null, pilot_ratio: 80 }, "run-1", "pilot");
  assert.equal(choice.version, "rel-1");
  assert.equal(choice.track, "stable");
  assert.equal(choice.reason, "no_pilot");
});

test("chooseRelease：比例切流对同一 runId 稳定", () => {
  const table = { stable: "rel-1", pilot: "rel-2", pilot_ratio: 50 };
  const first = chooseRelease(table, "run-abc");
  const second = chooseRelease(table, "run-abc");
  assert.deepEqual(first, second);
  assert.equal(first.track, hashBucket("run-abc") < 50 ? "pilot" : "stable");
});

test("chooseRelease：比例 0 与 100 是两端闭合", () => {
  const zero = chooseRelease({ stable: "rel-1", pilot: "rel-2", pilot_ratio: 0 }, "run-x");
  assert.equal(zero.track, "stable");
  const full = chooseRelease({ stable: "rel-1", pilot: "rel-2", pilot_ratio: 100 }, "run-x");
  assert.equal(full.track, "pilot");
});

test("parseRoute：字段缺失就当没发布，不猜", () => {
  assert.deepEqual(parseRoute({ stable: "rel-1", pilot_ratio: 10 }), {
    stable: "rel-1",
    pilot: null,
    pilot_ratio: 10,
  });
  assert.equal(parseRoute({ pilot: "rel-2" }), null);
  assert.equal(parseRoute(null), null);
  assert.equal(UNRELEASED_ROUTE.pilot, null);
});

// ---------------------------------------------------------------- 脱敏

test("脱敏：身份证保留前 3 后 4", () => {
  const redactor = new Redactor();
  const out = redactor.scrubText("证件号 110101199003071234 已核验");
  assert.equal(out, `证件号 110${"*".repeat(11)}1234 已核验`);
  assert.doesNotMatch(out, /199003/);
});

test("脱敏：手机号保留前 3 后 4", () => {
  const redactor = new Redactor();
  assert.equal(redactor.scrubText("联系 13812345678"), "联系 138****5678");
});

test("脱敏：地址只留到省市级", () => {
  const redactor = new Redactor();
  const out = redactor.scrubText("寄往浙江省杭州市西湖区文三路100号");
  assert.match(out, /^寄往浙江省杭州市\*\*\*$/);
  assert.doesNotMatch(out, /文三路/);
});

test("脱敏：金额 token 化且同额复用，百分比保留", () => {
  const redactor = new Redactor();
  const out = redactor.scrubText("合同 1,250,000.00 元，折扣 8%，追加 1,250,000.00 元");
  assert.equal(out, "合同 AMOUNT_1，折扣 8%，追加 AMOUNT_1");
  assert.deepEqual(redactor.amountMap(), { "1,250,000.00元": "AMOUNT_1" });
  assert.deepEqual(
    redactor.summary().map((hit) => hit.category),
    ["amount"],
  );
});

test("脱敏：结构化值递归处理，数字原样保留", () => {
  const redactor = new Redactor();
  const out = redactor.scrubValue({
    phone: "13812345678",
    ratio: 0.8,
    nested: { note: "合同 2,000,000 元" },
    list: ["13900001111"],
  }) as Record<string, unknown>;
  assert.equal(out.phone, "138****5678");
  assert.equal(out.ratio, 0.8);
  assert.deepEqual(out.nested, { note: "合同 AMOUNT_1" });
  assert.deepEqual(out.list, ["139****1111"]);
});

// ---------------------------------------------------------------- 事件归一

test("normalizeEvent：assistant 消息带模型与用量", () => {
  const redactor = new Redactor();
  const event = normalizeEvent(
    { type: "message", role: "assistant", text: "手机 13812345678", model: "deepseek-flash", usage: { total_tokens: 12 } },
    redactor,
  );
  assert.deepEqual(event, {
    type: "message",
    role: "assistant",
    text: "手机 138****5678",
    model: "deepseek-flash",
    usage: { total_tokens: 12 },
  });
});

test("normalizeEvent：未知类型直接丢弃，不让脏数据进归档", () => {
  const redactor = new Redactor();
  assert.equal(normalizeEvent({ type: "something-else" }, redactor), null);
});

test("normalizeEvent：result 归一成 outcome", () => {
  const redactor = new Redactor();
  const event = normalizeEvent(
    { type: "result", result: { final_answer: "完成", stop: { stop: true, code: "COMPLETED" } } },
    redactor,
  );
  assert.equal(event?.type, "outcome");
  assert.equal(event && event.type === "outcome" ? event.outcome : null, "pass");
});

test("outcomeOf：错误码与空答案都不算通过", () => {
  assert.equal(outcomeOf({ result: { stop: { code: "MODEL_ERROR" } } }).outcome, "error");
  assert.equal(outcomeOf({ result: { final_answer: "  ", stop: { code: "COMPLETED" } } }).outcome, "unknown");
  assert.equal(outcomeOf({ result: { final_answer: "ok", stop: { stop: false, code: "CONTINUE" } } }).outcome, "unknown");
  assert.equal(outcomeOf({ result: { final_answer: "ok", stop: { stop: true, code: "COMPLETED" } } }).outcome, "pass");
});

test("stepOf：只抽 assistant 消息，工具调用参数原样保留", () => {
  const step = stepOf({
    type: "message",
    role: "assistant",
    text: "读一下",
    tool_calls: [{ id: "t1", name: "read_file", args: { path: "src/app.ts" } }],
  });
  assert.deepEqual(step, { text: "读一下", tool_calls: [{ name: "read_file", args: { path: "src/app.ts" } }] });
  assert.equal(stepOf({ type: "message", role: "user", text: "hi", tool_calls: [] }), null);
  assert.equal(stepOf({ type: "tool", status: "start" }), null);
});

// ---------------------------------------------------------------- 归档与回放

test("diffVersions：逐字段比对，缺字段也算差异", () => {
  const diffs = diffVersions(versions(), versions({ prompt_hash: "sha256:zzz", model_alias: undefined as unknown as string }));
  assert.deepEqual(
    diffs.map((diff) => diff.field).sort(),
    ["model_alias", "prompt_hash"],
  );
  assert.deepEqual(diffVersions(versions(), versions()), []);
});

test("versionsHash：与字段顺序无关，与取值有关", () => {
  const a = versionsHash(versions());
  const b = versionsHash(
    Object.fromEntries(Object.entries(versions()).reverse()) as unknown as Versions,
  );
  assert.equal(a, b);
  assert.notEqual(a, versionsHash(versions({ prompt_hash: "sha256:zzz" })));
  assert.match(a, /^sha256:[0-9a-f]{64}$/);
});

test("buildReplayScript：输出可被 codebase 当作 YAML 读取的 JSON", () => {
  const script = buildReplayScript([
    { text: "读文件", tool_calls: [{ name: "read_file", args: { path: "a.ts" } }] },
    { text: "收口", tool_calls: [] },
  ]);
  const parsed = JSON.parse(script) as { steps: Array<Record<string, unknown>> };
  assert.equal(parsed.steps.length, 2);
  assert.deepEqual(parsed.steps[0].tool_calls, [{ name: "read_file", args: { path: "a.ts" } }]);
  assert.equal("tool_calls" in parsed.steps[1], false);
});

// ---------------------------------------------------------------- SSE 与指标

test("formatSse：有 event 名、data 为单行 JSON、以空行结尾", () => {
  const frame = formatSse({ event: "message", data: { text: "hi" } });
  assert.equal(frame, 'event: message\ndata: {"text":"hi"}\n\n');
  assert.equal(SSE_DONE, "data: [DONE]\n\n");
});

test("Metrics：counter/gauge/histogram 输出 Prometheus 文本", () => {
  const metrics = new Metrics();
  metrics.inc("agent_runs_total", { outcome: "pass", track: "stable" });
  metrics.inc("agent_runs_total", { outcome: "pass", track: "stable" });
  metrics.set("agent_runs_in_flight", 2);
  metrics.observe("agent_run_duration_ms", 1500, { outcome: "pass" });
  const text = metrics.render();
  assert.match(text, /# TYPE agent_runs_total counter/);
  assert.match(text, /agent_runs_total\{outcome="pass",track="stable"\} 2/);
  assert.match(text, /agent_runs_in_flight 2/);
  assert.match(text, /agent_run_duration_ms_bucket\{le="2000",outcome="pass"\} 1/);
  assert.match(text, /agent_run_duration_ms_bucket\{le="1000",outcome="pass"\} 0/);
  assert.match(text, /agent_run_duration_ms_sum\{outcome="pass"\} 1500/);
  assert.match(text, /agent_run_duration_ms_count\{outcome="pass"\} 1/);
});

// ---------------------------------------------------------------- 成本

test("costUsd：价格齐全才算得出来，缺失就是未知", () => {
  const usage = { input_tokens: 1_000_000, output_tokens: 1_000_000, cache_tokens: 0 };
  assert.equal(
    costUsd(usage, { input_per_million: 0.3, output_per_million: 1.2, cache_read_per_million: 0.006 }),
    1.5,
  );
  assert.equal(costUsd(usage, { input_per_million: 0.3, output_per_million: 1.2 }), null);
  assert.equal(costUsd(emptyUsage(), { input_per_million: 0.3, output_per_million: 1.2, cache_read_per_million: 0 }), 0);
});

test("usageOf / rawCostUsd：认三种命名，0 当作没报", () => {
  assert.deepEqual(usageOf({ input_tokens: 10, output_tokens: 5, cache_read_tokens: 3 }), {
    input_tokens: 10,
    output_tokens: 5,
    cache_tokens: 3,
  });
  assert.equal(rawCostUsd({ cost_usd: 0 }), null);
  assert.equal(rawCostUsd({ cost: { total: 0.02 } }), 0.02);
  assert.equal(rawCostUsd({}), null);
});

// ---------------------------------------------------------------- 身份

test("身份：key 里允许冒号，右侧三字段固定位", () => {
  const keys = parseApiKeys("sk:with:colon:acme:risk:developer,plain-key:beta:ops:reviewer");
  assert.equal(keys.size, 2);
  assert.deepEqual(keys.get("sk:with:colon"), {
    tenant: "acme",
    dept: "risk",
    role: "developer",
    keyPrefix: "sk:wit",
  });
  assert.equal(authenticate("Bearer plain-key", keys)?.tenant, "beta");
  assert.equal(authenticate("plain-key", keys)?.dept, "ops");
  assert.equal(authenticate("Bearer nope", keys), null);
  assert.equal(authenticate(null, keys), null);
});

test("身份：格式不对的条目直接跳过，不产生半条身份", () => {
  const keys = parseApiKeys("only-key,key:tenant:dept,:tenant2:dept2:role2,,   ");
  assert.equal(keys.size, 0);
});
