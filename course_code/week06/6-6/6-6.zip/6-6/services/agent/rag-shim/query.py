#!/usr/bin/env python3
"""codebase 的 rag_query 工具与本仓库 retrieval 服务之间的垫片。

为什么需要它：codebase 的 rag_query 用既成的形态调用
    python <rag.dir>/query.py --json -q "..." [--mode ...] --top-k N
这个契约来自 4-6 的 RAG 服务，不能为了服务化去改 codebase 的工具实现。
所以这里补一个只有转发职责的 query.py：把问题转给 retrieval 服务，把结果按原格式吐回。

租户与部门不从请求体来（模型无权指定），而是从 worker 进程环境变量里取：
agent 每次运行都会给 worker 注入 RUN_TENANT / RUN_DEPT，沙箱子进程继承同一份环境。
检索服务只信任这条内部通道，外部调用方走 /v1/query（Bearer）。
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.error
import urllib.request

DEFAULT_URL = "http://retrieval:8770"
TIMEOUT_SECONDS = 20.0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--json", action="store_true")
    parser.add_argument("-q", "--question", required=True)
    parser.add_argument("--mode", default="hybrid")
    parser.add_argument("--top-k", type=int, default=5)
    parser.add_argument("--doc-type", default=None)
    parser.add_argument("--no-llm", action="store_true")
    return parser


def main() -> int:
    args, _unknown = build_parser().parse_known_args()
    base = os.environ.get("RETRIEVAL_URL", DEFAULT_URL).rstrip("/")
    payload = {
        "question": args.question,
        "mode": args.mode,
        "top_k": args.top_k,
        "doc_type": args.doc_type,
        "no_llm": bool(args.no_llm),
    }
    headers = {
        "Content-Type": "application/json",
        "X-Tenant": os.environ.get("RUN_TENANT", ""),
        "X-Dept": os.environ.get("RUN_DEPT", ""),
    }
    request = urllib.request.Request(
        f"{base}/internal/query",
        data=json.dumps(payload).encode("utf-8"),
        headers=headers,
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=TIMEOUT_SECONDS) as response:
            body = json.loads(response.read().decode("utf-8"))
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as error:
        print(
            json.dumps(
                {
                    "question": args.question,
                    "mode": args.mode,
                    "top_k": args.top_k,
                    "answer": None,
                    "error": f"检索服务不可用：{error}",
                    "citations": [],
                },
                ensure_ascii=False,
            )
        )
        return 0

    body.setdefault("question", args.question)
    body.setdefault("mode", args.mode)
    body.setdefault("top_k", args.top_k)
    print(json.dumps(body, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
