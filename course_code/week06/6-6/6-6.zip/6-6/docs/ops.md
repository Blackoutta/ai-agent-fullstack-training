# 运维手册

## 启停

```sh
make env            # 首次：复制 .env.example
make up             # 全部组件
make up-core        # 只起应用（gateway platform agent retrieval eval）
make ps
make logs
make down           # 保留数据卷
make clean          # 删卷与 data/ runs/ releases/ 产物
```

所有端口绑 `127.0.0.1`。服务之间只走 compose 服务名：`gateway`、`platform`、`agent`、`retrieval`、`eval`、`langfuse-web`。

## 首次启动顺序

1. `make env`，填 `DEEPSEEK_API_KEY`（留空即离线）。
2. `LITELLM_MASTER_KEY` 与 `LITELLM_VIRTUAL_KEY` 未接独立 Postgres 时必须相同；接 `LITELLM_DATABASE_URL` 后才可签发独立虚拟密钥。
3. `make up`。首次会拉 litellm、langfuse 六件、prometheus、grafana 镜像（数 GB）。
4. 起平台后先建发布单再跑运行：

```sh
curl -s -XPOST localhost:8090/v1/releases \
  -H "Authorization: Bearer demo-key-tenant-a" -d '{}' | python3 -m json.tool
```

## 建立向量索引

```sh
make seed
```

先停 retrieval（Milvus Lite 单写者），`python -m app.ingest` 读 `corpus/` 写 `data/milvus/milvus_login_demo.db`，再起 retrieval。
没有 `MINIMAX_CN_API_KEY` 时 ingest 会拒绝写入向量并提示改用 BM25；此时 `RETRIEVAL_DEFAULT_MODE=bm25` 仍然可用。

## 密钥轮换

- `PLATFORM_API_KEYS`：逗号分隔，格式 `key:tenant:dept:role`。改完 `.env` 后 `make up` 重建涉及服务（platform/agent/retrieval/eval）。
- 网关密钥：改 `DEEPSEEK_API_KEY` 只影响 gateway；应用侧只看到 `LITELLM_VIRTUAL_KEY`（容器内变量名是 `DEEPSEEK_API_KEY`，避免 codebase 配置改动）。
- 平台启动自检会扫描 `data/`、`runs/`、`releases/`，发现 `sk-` 前缀或 `Bearer ` 形态的疑似密钥即以 `SECRET_IN_ARTIFACT` 拒绝启动。清理后再起。

## 常见故障

| 现象 | 原因 | 处理 |
|---|---|---|
| agent 503 `GATEWAY_UNAVAILABLE` | gateway 未就绪或密钥错 | `docker logs platform-gateway`，确认 `/health/liveliness` |
| 运行 `error` 且提示 `MODEL_UNAVAILABLE` | 无 `DEEPSEEK_API_KEY` 且未走离线 | 设 `AGENT_MODE=offline` 或补密钥 |
| retrieval 500 `MILVUS_LOCKED` | ingest 与 retrieval 同时写 | `make seed` 走 Makefile 的停-写-起流程 |
| retrieval 返回 `retrieval_mode=bm25` | 无嵌入密钥 | 属预期降级；需要向量检索时补 `MINIMAX_CN_API_KEY` 后 `make seed` |
| eval 401 `UNAUTHENTICATED` | 没带 `Authorization` | 带 `Bearer <PLATFORM_API_KEYS 里的 key>` |
| eval 403 `FORBIDDEN_TENANT` | 跨租户读取 | 用本租户 key，或由平台管理员查审计 |
| publish 409 `RELEASE_NOT_CHECKED` | 未跑 `check` 或检查失败 | `POST /v1/releases/{v}/check` 看逐条结果 |
| replay 409 `REPLAY_VERSION_MISMATCH` | 归档版本与当前不一致 | 属预期：换回对应发布单后再回放 |
| Grafana 打不开 | 3000 被 Langfuse 占用 | Grafana 在 3001 |

## 端口表

| 端口 | 用途 |
|---|---|
| 3000 | Langfuse Web |
| 3001 | Grafana |
| 3030 | Langfuse Worker |
| 4000 | gateway |
| 5432 / 6379 / 8123 / 9000 / 9090 | Langfuse 依赖（postgres/redis/clickhouse/minio） |
| 8080 | agent |
| 8090 | platform |
| 8765 | eval |
| 8770 | retrieval |
| 9092 | Prometheus |

## 数据位置

| 路径 | 内容 | 备份建议 |
|---|---|---|
| `data/agent/` | codebase 审计账本 SQLite | 需要审计留档时备份 |
| `data/platform.db` | 发布单、路由、用量、预算、审计 | 必须备份 |
| `data/eval/` | 评测 SQLite 与运行工作区 | 按需 |
| `data/milvus/` | Milvus Lite 文件 | 可用 `make seed` 重建 |
| `runs/` | 运行归档（回放依赖） | 需要回放历史时备份 |
| `releases/` | 发布单 manifest 与验收快照 | 必须备份 |
