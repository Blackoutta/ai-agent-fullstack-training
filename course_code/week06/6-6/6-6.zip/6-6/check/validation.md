# 阶段六验收记录

- 工程根：`week06/6-6`
- 执行时间：2026-11-09（UTC+8）
- 执行环境：macOS / Node v24.21.0 / Python 3.12.13（系统另有 3.9.6）/ Docker CLI 29.8.2 / Docker Compose v5.5.0
- 容器运行时：OrbStack 2.2.5（daemon 29.8.2，context `orbstack`）；Docker daemon 侧配了 HTTP 代理（见第六节）

记录口径（与 `plans/WP-009-validation.md` 一致）：

- 只写**实际执行过**的命令与输出；没跑的一律进「未覆盖项」，不用「应该可以」代替。
- 离线结果与在线结果分开记；离线不进真实成功率分母。
- 同一命令重复执行的结果（幂等性）单独列出。

## 一、命令与输出

| # | 命令 | 结果 |
|---|---|---|
| 1 | `make verify-offline` | 退出码 0，全部套件通过（明细见下） |
| 2 | `make smoke` | 6/6 步通过；重复执行复用同一批发布单，回放按 run_id 去重 |
| 3 | `make cost` | 平台在线时走 HTTP 端点（`5 runs / 已知成本 0.021549 / 未知成本 1 / 已知 tokens 16647`）；平台没起时退回本地账本，空账本 → 0 行，不伪造数据 |
| 4 | `docker compose -f … -f … -f … config --quiet` | 通过；解析出 13 个服务 |
| 5 | `python3.12 scripts/smoke.py --offline --step {release,check,publish,rollback}` | 4 个单步各自通过 |
| 6 | `python3.12 scripts/smoke.py --offline --replay-only` | 通过（按 run_id 去重） |
| 7 | `cd codebaseEval && python3.12 -m unittest tests.test_redaction_parity -v` | 5/5 通过（TS 侧由 node 真实执行，非 skip） |
| 8 | `make up`（OrbStack） | 13 个容器全部 Up；五个应用服务 + `langfuse-web` 均 healthy |
| 9 | 端点探活 8090/8080/8770/8765/4000/9092/3001/3000 | 全部 200（gateway 带 master key）；`platform/v1/releases` 无 key 正确 401 |
| 10 | `make smoke-live`（密钥自动取 `role=service`） | 6/6 通过，回放 `status=match`；连跑两次步骤逐字一致 |
| 11 | Prometheus `/api/v1/targets` | 6/6 up（agent / eval / gateway / platform / prometheus / retrieval） |
| 12 | Langfuse ingestion → `/api/public/traces` | 写入 201，查询能读到 `compose-dual-smoke`（项目 `proj-platform-demo`） |
| 13 | `scripts/cost_report.py --platform-url`（在线） | 3 runs / 已知成本 0.010771 / 未知成本 1 / 未知 token 3 |
| 14 | `make run` | 造一条新运行（`outcome=pass`，归档在当前 stable），紧随其后的 `smoke-live` 第 6 步真实回放 `status=match` |
| 15 | `make seed` | 12 个文件 → 100 chunks（tenant_a 69 / tenant_b 31）；`vector=skipped: MINIMAX_CN_API_KEY 未配置`；随后 BM25 检索 3 条命中、`retrieval_mode=bm25`、结果全在 tenant_a/platform 范围 |
| 16 | 幂等：`smoke` / `smoke-live` / `cost` 各连跑两次 | 步骤行逐字一致；`releases=2 / routes=1 / replays=1 / release_checks=8`（`audit` 按设计 append-only 累加） |
| 17 | `curl POST /v1/chat/completions`（网关 → `deepseek-flash`） | 200 且 `choices[0].message.content` 有内容；同一时刻 Prometheus：请求 4（primary 2 + standby 2）/ token 422 / 成本 0.0001884 USD，与 litellm `/metrics` 一致；Grafana 面板「网关：直连大模型的请求」6 个图已加载 |

`make verify-offline` 明细：

| 套件 | 数量 | 结果 |
|---|---|---|
| `services/platform/tests`（状态机、路由、预算、报表、审计、密钥自检） | 29 | OK |
| `services/retrieval/tests`（授权矩阵、租户过滤、BM25/Hybrid、降级标注） | 19 | OK |
| `tests/`（Python SDK：路径表、错误归一、重试、SSE） | 12 | OK |
| `codebaseEval/tests`（评测平台、租户分区、证据、脱敏双语言） | 55 | OK |
| `services/agent/tests/*.test.ts`（脱敏、事件归一、回放脚本、路由、指标） | 24 | 24 pass / 0 fail |
| `sdk/ts/tests/*.test.ts`（TS SDK 契约） | 10 | 10 pass / 0 fail |
| `scripts/check_contract.py`（OpenAPI ↔ 实现） | 49 个端点 | 5 个服务全部一致 |

## 二、需求逐条核对

### R1 容器编排
- 方式：`docker compose` 三文件合并后 `config --quiet`；再用 `config --services` 数服务。
- 结果：通过，13 个服务（gateway / agent / retrieval / eval / platform / langfuse-web / langfuse-worker / postgres / redis / clickhouse / minio / prometheus / grafana）。
- 已实测：四个应用镜像均构建成功（agent / eval / platform / retrieval，Bash 步骤含 `apt-get`、`pip install`、`npm ci`），13 个容器全部 Up，五个应用服务与 `langfuse-web` 均 `healthy`。

### R2 网关
- 方式：发布单的 `gateway-config` 离线探针（`make smoke` 第 3 步）。
- 结果：通过。`deepseek-flash` → `deepseek/deepseek-v4-flash` 两处部署（primary/standby）声明齐全；`api_key` 为 `os.environ/` 形式；配置内无 `sk-` 内联密钥。
- 未验证：真实上游转发（无 `DEEPSEEK_API_KEY`）。
- 补充：litellm 的 `/metrics` 必须开 `callbacks: ["prometheus"]` 才存在（否则 404，不是 401）；抓取用 master key 做 Bearer，token 由 `make env` 写到 `deploy/prometheus/gateway-token`（600，已 gitignore）。

### R3 Agent 服务化
- 方式：`services/agent/tests` + 契约路径核对。
- 结果：24/24 通过；契约含 `POST /v1/runs`、`GET /v1/runs`、`GET /v1/runs/{id}`、`GET /v1/runs/{id}/events`（SSE）、`POST /v1/runs/{id}/replay`、`/health`、`/metrics`。

### R4 检索服务化
- 方式：`services/retrieval/tests`。
- 结果：19/19 通过。关键用例：`cross_tenant_query_cannot_see_other_tenant_chunks`、`tenant_field_in_body_is_rejected`、`missing_index_returns_503_not_empty_list`、`degraded_vector_is_labelled`。
- 未验证：真实向量写入与向量检索（无 `MINIMAX_CN_API_KEY`，走 BM25）。

### R5 Eval 平台容器化
- 方式：`codebaseEval/tests`（55）+ compose 配置。
- 结果：55/55 通过，其中 `test_tenancy`（跨租户读 403 并审计、`public` 基线只读、成本视图未知成本单列）、`test_redaction_parity`（双语言一致）、`test_evidence`、`test_platform`。
- 已实测：`platform-eval` 容器 healthy，`8765/health` 返回 200；镜像里前端 `npm run build` 随构建成功。
- 说明：容器内不重复跑单测（单测在 `make verify-offline` 的宿主环境跑），只验证镜像能跑起来。

### R6 版本管理与发布单
- 方式：`services/platform/tests` 中 `publish_rejected_until_checked`、`check_failure_blocks_publish`、`draft_writes_json_and_yaml_manifest`；`make smoke` 第 2–4 步。
- 结果：未 `check` 的版本发布返回 409；探针失败落 `failed`；manifest 同时写 `manifest.json` 与 `manifest.yaml`。

### R7 灰度发布与回滚
- 方式：`pilot_ratio_split_and_explicit_group`、`rollback_clears_pilot_and_marks_version`、`first_publish_always_becomes_stable`；`make smoke` 第 4–5 步。
- 结果：显式 `x-release-group` 优先级与比例切流均符合预期；回滚后 pilot 清空、被撤版本标 `rolled_back`，路由文件同步落盘，审计留痕。
- 说明：`pilot 失败自动回滚` 依赖真实流量信号，本次只验证了「回滚动作」本身，未做自动触发。

### R8 回放
- 方式：`make smoke` 第 6 步（离线假 agent 返回 200）+ `make smoke-live` 第 6 步（真实平台 + 真实 agent）；agent 单测覆盖 `versionsHash` / `diffVersions` / `buildReplayScript`。
- 结果：
  - 在线真实回放：`run_id=479d0415-7890-42bd-95bd-b15fe29e4f88`，`status=match`（答案 / 工具序列 / 结局三项一致），平台落一条 `replays` 并写审计。
  - 409 真实复现：拿 `release_version=unreleased` 的归档去回放，agent 按契约返回 `REPLAY_VERSION_MISMATCH`。
  - 修了一个真 bug：platform 把统一错误体里恒为数组的 `details` 当字典取 `diffs`，409 被打成 500（见第七节）。
- 未验证：发布后版本漂移（归档 ≠ 当前）的 409 全链路；本次 409 是 unreleased 归档触发，属同类但不是同一种成因。

### R9 成本治理
- 方式：`budget_exceeded_is_reported_with_scope`、`warning_threshold_does_not_block`、`unknown_cost_counted_separately`、`dept_scope_only_counts_that_dept`、`cost_report_markdown`；另用临时平台实例调真实端点复验。
- 结果：
  - 单测 29/29 内相关用例全过；超限返回 429 + `Retry-After`，响应体仍带 `allowed=false`。
  - 实测端点（临时实例，2 条用量：`cost_usd=0.42` 与 `null`）：汇总为 `运行 2 / 已知成本 0.420000 / 未知成本 1 / 已知 tokens 1200`——未知成本单列，未按 0 合并。
  - `make cost` 在本机空账本上生成空报表（0 行），文件头为 `# 成本报表`。
  - 在线报表（`scripts/cost_report.py --platform-url`，service key）：`3 runs / 已知成本 0.010771 / 未知成本 1 / 未知 token 3`。无 key 时 agent 走 mock，没有 token 与单价，所以「未知」单列而不是补 0。

### R10 密钥与脱敏
- 方式：`test_redaction_parity`（5 个用例，node 真实执行 TS 实现）+ agent 脱敏单测（5 个）+ platform `secret_in_artifact_blocks_startup` / `redacted_placeholder_and_clean_artifacts_pass` / `identity_echo_never_leaks_full_key`。
- 结果：三份实现（agent TS、platform Python、eval Python）对同一批 11 条样例输出逐字节一致（文本、`AMOUNT_n` 映射、命中计数）；百分比 `8.5` 与结构化数字 `1200` 原样保留；产物目录出现 `sk-…` 或 `Bearer …` 时平台拒绝启动。
- 说明：密钥只从环境变量读取的约束由 `settings.py` 的实现保证（不读 `.env`、不落库），本次未做「注入假密钥后启动」的端到端复验。

### R11 租户隔离
- 方式：platform（`cross_tenant_report_is_forbidden`、`audit_endpoint_is_tenant_scoped`、`non_service_identity_cannot_report_for_other_tenant`、`service_identity_may_check_other_tenants`）+ retrieval（3 个租户/身份用例）+ eval（`test_tenancy` 6 个用例）。
- 结果：跨租户读取 403 且写审计；`role=service` 才能代报/跨租户查询；检索过滤在服务端注入，body 里的租户字段返回 400。

### R12 SDK 与契约
- 方式：`scripts/check_contract.py` + 两套 SDK 测试。
- 结果：契约 49 个端点与五个服务实现一一对应（缺一端即失败）；TS SDK 10/10、Python SDK 12/12，覆盖路径表、`Authorization` + `X-Request-Id`、多值 query、四种错误形状归一、429/5xx 重试与 4xx 不重试、SSE 切块与跨 chunk 拼接、`wait` 轮询。

## 三、幂等性核对

`make smoke` 连续执行两次后，`data/smoke/data/platform.db` 计数：

| 表 | 行数 | 说明 |
|---|---|---|
| `releases` | 2 | `.1` = published，`.2` = rolled_back；重复执行不新建 |
| `routes` | 1 | 单行 `current`，upsert |
| `replays` | 1 | 同一 run_id 只落一条 |
| `release_checks` | 8 | 每版本 4 个探针，按主键 upsert |
| `audit` | 12 | **按设计累加**：审计是 append-only 流水，重复演练会多几条，不是重复记录 |

## 四、未覆盖项

| 项 | 原因 | 影响 |
|---|---|---|
| 真实 `deepseek-flash` 调用 | 无 `DEEPSEEK_API_KEY` | agent 走 `decider=mock`；R2 只验证配置与别名；成本/tokens 全为「未知」（不补 0） |
| 向量写入与真实向量检索 | 无 `MINIMAX_CN_API_KEY`；`make seed` 未执行 | R4 只验证 BM25 路径与降级标注；检索容器只验证了 `/health` |
| 发布后版本漂移的 409 全链路 | 需要「先归档 → 再发布新版本 → 再回放」的时序 | R8 的漂移分支只实测了 unreleased 归档这一种 |
| pilot 失败自动回滚 | 需要真实流量与质量信号 | R7 只验证手动回滚动作 |
| 注入假密钥后拒绝启动的端到端复验 | 避免在产物目录留下可疑文件 | 由 `secret_in_artifact_blocks_startup` 单测覆盖 |

## 五、复现

```sh
cd week06/6-6
make env                 # 生成 .env，同时写 deploy/prometheus/gateway-token
make verify-offline      # 7 个套件 + 契约检查 + compose 语法
make smoke               # 发布单 → 探针 → 灰度 → 回滚 → 回放（离线，可重复）
make cost                # 成本报表落盘 reports/
docker compose -f docker-compose.yml -f deploy/prometheus/docker-compose.yml \
  -f deploy/langfuse/docker-compose.langfuse.yml config --quiet
```

真实环境（OrbStack + 代理，见第六节）：

```sh
export https_proxy=http://127.0.0.1:7890 http_proxy=http://127.0.0.1:7890
make up                  # 构建 4 个应用镜像 + 拉起 13 个容器
make smoke-live          # 打真实平台与 agent（密钥自动取 role=service）
make run && make smoke-live   # 连续演示：先造新 run，回放才会真的比对
```

有 `DEEPSEEK_API_KEY` / `MINIMAX_CN_API_KEY` 后补跑：`make seed`，再跑一次 `make smoke-live` 就能拿到真实成本与真实向量指标。

## 六、本机容器运行时与网络（OrbStack）

- 运行时是 OrbStack（context `orbstack`，daemon 29.8.2），不是 Docker Desktop。
- 宿主对外网络需要代理：系统 DNS 把 `auth.docker.io` 解成 `185.45.6.57`（8.8.8.8 给的是另一个地址），直连 443 被拒、`registry-1.docker.io` 超时。宿主导出的 `http_proxy/https_proxy` 对 `docker pull` **无效**：拉基础镜像是 daemon 发起的。
- 正确修法是给 dockerd 配代理：

  ```json
  // ~/.orbstack/config/docker.json
  { "proxies": { "http-proxy": "http://host.docker.internal:7890",
                 "https-proxy": "http://host.docker.internal:7890",
                 "no-proxy": "localhost,127.0.0.1,::1,host.docker.internal,*.internal" } }
  ```

  然后 `orbctl restart docker`（容器会自动恢复，实测 8 个在跑容器全部 Up）。
- 构建时的 `RUN`（apt / pip / npm）靠 Compose 把宿主 `HTTP_PROXY`/`HTTPS_PROXY` 作为 build args 注入，所以 `make up` 要带着代理变量跑。
- 本机 7890 是 Clash 混合端口，`host.docker.internal:7890` 从 VM 内可达（已用容器内 socket 连接验证）。

## 七、拉起过程中修掉的问题

| # | 现象 | 根因 | 修法 |
|---|---|---|---|
| 1 | `make up` 报 `not a directory` 挂载失败 | 多 `-f` 合并时相对路径以**项目根**为基准，`deploy/prometheus/docker-compose.yml` 的 `./prometheus.yml` 指到根目录（Docker 还建了个同名空目录） | 写成 `./deploy/prometheus/...`，删掉误建目录 |
| 2 | `platform-retrieval` 反复 Restarting，`IndexError: 1` | `config.py` 用 `SERVICE_DIR.parents[1]` 推项目根，容器里代码在 `/app`，`parents[1]` 越界 | 越界时退回 `SERVICE_DIR.parent` |
| 3 | `make smoke-live` 回放 500 | `schedule_replay` 把统一错误体里恒为数组的 `details` 当 dict 取 `diffs` | 409 分支兼容 list/dict |
| 4 | Prometheus 的 gateway target 401 | litellm `/metrics` 需要 master key | `make env` 生成 `gateway-token`（600、gitignore），用 `bearer_token_file` |
| 5 | 加 token 后变 404 | litellm 没开 `callbacks: ["prometheus"]`，`/metrics` 不存在 | litellm 配置加回调 |
| 6 | `langfuse-web` 一直 `health: starting` | 镜像里没有 python（healthcheck 用了 `python -c`），且服务监听容器 IP 而非 127.0.0.1 | 改用 `node -e` + `require('os').hostname()` |
| 7 | Langfuse 写入 400 `Event type not accepted` | v4 默认 `LANGFUSE_MIGRATION_V4_WRITE_MODE=events_only`，只收 score；agent 走旧 ingestion | 设为 `dual`（双写，UI 可查） |
| 8 | 照 README 直接 `make smoke-live` 报 401 | 该目标需要能跨租户的 `role=service` 密钥，README 里只写了命令 | Makefile 从 `.env` 的 `PLATFORM_API_KEYS` 自动取 service 密钥，可被 `PLATFORM_API_KEY` 覆盖 |
| 9 | 平台 `POST /v1/usage` 返回 201 但库里查不到 | `make cost` 在宿主另起一个平台实例打开同一个 `data/platform.db`；bind mount（OrbStack virtiofs）上两个 WAL 连接抢 `-shm`，平台后续写入丢失 | `make cost` 在平台在线时改走 HTTP 端点，只有平台没起时才读本地账本 |
| 10 | 成本报表「已知 tokens 0」 | agent 上报 usage 时没填 `total_tokens`（平台按该字段聚合，null 即「说不清」） | agent 上报补 `total_tokens = input + output + cache`；保留平台侧「null 就是未知」的口径 |
