# 快照补丁登记

`codebase/` 与 `codebaseEval/` 是 `week05/5-5` 的源码快照（排除 `node_modules`、`dist`、`data`、`runs`、`artifacts`）。
`week05/5-5` 原目录零改动。本文件登记每一处对快照的改动，便于与原版 diff。

## codebase/（快照 + 0 处逻辑补丁）

模型接入不需要改代码：`src/config.ts` 已支持 `GATEWAY_BASE_URL`、`GATEWAY_MODEL_ID` 环境变量覆盖，
`PLATFORM_CONFIG` 可指定配置文件路径，`runManagedAgent` 已提供 `onEvent` 观察器与 `decider: "mock"`。

| 文件 | 改动 | 原因 |
|---|---|---|
| `config/platform.yaml` | `gateway.base_url` 默认值保持厂商端点，容器内由 `GATEWAY_BASE_URL` 覆盖 | 避免快照里写死内网地址；离线开发仍可直连 |
| `data/` | 不随快照复制，容器内挂 `./data/agent` | 审计账本属于运行时数据 |

## codebaseEval/（3 处补丁）

| 文件 | 改动 | 原因 |
|---|---|---|
| `backend/server.py` | Host 同源校验改为「本机名或 `EVAL_ALLOWED_HOSTS` 列出的 compose 服务名」 | 原实现只认 `localhost`/`127.0.0.1`，容器内经服务名访问会被拒；仍然默认拒绝未知 Host |
| `backend/server.py` | 新增身份解析（`Authorization: Bearer` → tenant/dept/role）、`GET /api/health`、`GET /api/cost`；`/api/*` 一律按身份过滤 | R11 租户隔离、R12 服务化与健康检查 |
| `backend/common.py` | `scrub()` 接入分类分级脱敏规则（身份证/手机号/地址/金额） | R10 脱敏；金额 token 化后不入库 |
| `backend/store.py` | `entities`、`reviews` 增 `tenant` 列与索引，读写按 tenant 过滤 | R11 租户分区；跨租户读返回空而不是别人的数据 |

补丁实现集中在 `backend/tenancy.py`（新增文件），`scrub` 复用 `services/platform/app/redaction.py` 的规则表副本，
两边由 `tests/test_redaction_parity.py` 做一致性断言。

## 依赖与构建

- 两个快照的 `node_modules` 都不入库：`make setup`（本地）与 `services/agent/Dockerfile`、`services/eval/Dockerfile`（镜像）分别执行 `npm ci`。
- `codebaseEval/bridge/client.py` 用 `parents[2] / "codebase"` 定位同级 codebase，因此镜像内目录必须保持 `/app/codebase` 与 `/app/codebaseEval` 同级。
