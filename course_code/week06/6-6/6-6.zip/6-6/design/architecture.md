# 平台架构与契约

## 1. 决策与事实

- 单机 compose 部署，五个应用服务加三组基础设施，全部绑定 `127.0.0.1`。
- 语言分工沿用参考实现：agent 与 codebase 是 Node/TypeScript，eval、retrieval、platform 是 Python 标准库 HTTP + SQLite，retrieval 的向量路径按需引入 LlamaIndex / Milvus（`import` 失败即降级 BM25，不阻塞服务启动）。
- Agent 服务不复制 Agent Loop：每次运行 spawn 一个 worker 子进程，worker 内 `buildPlatform → runManagedAgent`，与 `codebaseEval/bridge` 的做法一致。
- 模型调用只经 gateway：worker 用环境变量 `GATEWAY_BASE_URL` / `GATEWAY_MODEL_ID` 覆盖 codebase 配置（`config.ts` 已支持），不需要改 codebase 逻辑。
- Python 侧统一 `http.server`，与 5-5 的 eval 后端同构，减少依赖面；离线测试只需标准库。

## 2. 组件与端口

| 服务 | 镜像/运行时 | 宿主端口 | 职责 |
|---|---|---|---|
| gateway | `ghcr.io/berriai/litellm` | 4000 | 逻辑模型名 → 上游部署；虚拟密钥；限流与重试 |
| agent | `node:22-bookworm-slim` + tsx | 8080 | 运行编排、SSE、归档、回放、脱敏、指标、Langfuse 上报 |
| retrieval | `python:3.12-slim` + llama-index | 8770 | 向量/BM25/Hybrid 检索，强制租户过滤 |
| eval | `node:22-bookworm-slim` + python3.11 | 8765 | 5-5 评测工作台（容器化 + 租户分区） |
| platform | `python:3.12-slim` | 8090 | 发布单、路由、回放调度、预算、成本报表、审计、身份 |
| langfuse-web/worker | 官方镜像 | 3000 / 3030 | Trace 存储与查询 |
| clickhouse / minio / redis / postgres | 官方镜像 | 8123+9000 / 9090 / 6379 / 5432 | Langfuse 依赖 |
| prometheus | `prom/prometheus` | 9092 | 指标抓取 |
| grafana | `grafana/grafana` | 3001 | 看板（3000 让给 Langfuse） |
| milvus | 无容器 | 无端口 | Milvus Lite 文件卷 `data/milvus/` |

## 3. 数据流

```
client / SDK
  │  Bearer <platform key>
  ├─→ platform:8090  发布单 / 路由 / 预算 / 成本 / 审计 / 回放调度
  ├─→ agent:8080     创建运行 → spawn worker(子进程)
  │        │                 ├─→ gateway:4000  /v1/chat/completions（逻辑名 deepseek-flash）
  │        │                 ├─→ retrieval:8770 /v1/query（rag_query 工具，可选）
  │        │                 └─→ codebase 本地 SQLite（审计账本、审批）
  │        ├─→ Langfuse /api/public/ingestion   自建 exporter 写 trace
  │        ├─→ platform /v1/usage               上报用量与成本
  │        └─→ runs/<runId>/                    归档 input/versions/messages/raw
  └─→ eval:8765      实验 → bridge 子进程 → codebase（同一套 Runtime）
```

## 4. 发布单与路由

发布单 `releases/<version>/manifest.yaml`：

```yaml
version: rel-2026.11.09.1
created_at: 2026-11-09T12:00:00Z
components:
  gateway:   { model_alias: deepseek-flash, upstream: deepseek-v4-flash, config_hash: sha256:... }
  agent:     { prompt_name: codebase.agent, prompt_version: v1, prompt_hash: sha256:...,
               model_alias: deepseek-flash, tools_version: ten-tools-v1 }
  eval:      { strategy_ids: [s1, s2], strategy_hash: sha256:..., tasks_hash: sha256:... }
  retrieval: { collection: login_demo_chunks, corpus_hash: sha256:..., embed_model: embo-01 }
acceptance:
  cases:
    - { id: prompt-render,  probe: offline }
    - { id: retrieval-bm25, probe: offline, query: 登录失败 }
    - { id: redaction-sample, probe: offline }
```

- 状态机：`draft → checked → published`。`check` 逐条跑离线探针并记录结果，任一失败即 `failed`，`publish` 拒绝。
- 路由表：`{stable: version, pilot: version|null, pilot_ratio: 0..100}`。agent 选择逻辑：显式 `x-release-group=pilot` 优先；否则 `sha256(runId) % 100 < pilot_ratio` 走 pilot；否则 stable。
- 回滚只把 `pilot` 置空、`pilot_ratio` 归零，并把失败版本标 `rolled_back`；不重建镜像。
- 所有 publish / rollback / 自动回滚都写 `audit` 表。

## 5. 回放

`runs/<runId>/` 结构：

| 文件 | 内容 |
|---|---|
| `input.json` | 租户、用户、任务、goal、release 版本、模型别名、时间 |
| `versions.json` | prompt 名/版本/内容哈希、模型别名、工具版本、检索 collection/corpus 哈希 |
| `messages.jsonl` | 归一化事件流（已脱敏） |
| `raw/NNNN.json` | 每次模型调用的原始请求指纹与原始返回 |

回放先逐项比对 `versions.json`，不一致直接 `MISMATCH`（HTTP 409），输出差异项，不发起任何模型调用；一致则用 `raw/` 依次喂回，产物 `replay_report.md` 对比答案、工具调用序列与判定结果。

## 6. 脱敏

规则集中在 `services/platform/app/redaction.py`（Python）与 `services/agent/src/core/redact.ts`（TypeScript），两份实现共享同一份规则表（`docs/redaction-rules.md` 为真源，测试双向对齐）：

| 类别 | 处理 | 例 |
|---|---|---|
| id_card | 保留前 3 后 4，中间 `*` | `110***********1234` |
| phone | 保留前 3 后 4 | `138****8888` |
| address | 保留到「省/市」级，其余 `***` | `浙江省杭州市***` |
| amount | 原文替换为 `AMOUNT_n`，映射只在本次运行内存中 | `1,250,000.00 元` → `AMOUNT_1` |
| percent | 不脱敏（评测与报表需要） | `8%` 保留 |

金额 token 的生命周期：只在单次运行的内存作用域，运行结束即丢弃；不写 SQLite、不写归档、不跨租户。

## 7. 租户与身份

- `PLATFORM_API_KEYS` 形如 `key:tenant:dept:role,key2:tenant2:dept:role`，只从环境变量读，不落库。
- 每个服务本地解析并缓存；platform 额外提供 `GET /v1/identities` 回显租户/部门/角色与密钥前缀（前 6 位），永不回显完整密钥。
- 检索：服务端把 `identity.tenant` / `identity.dept` 拼进 metadata filter，请求体出现 `tenant` 字段直接 400 `TENANT_FIELD_FORBIDDEN`。
- eval：`entities` / `reviews` 增 `tenant` 列，列表与对比按身份过滤；越权 403 且写审计。
- 启动自检：platform 与 agent 启动时扫描 `data/`、`runs/`、`releases/`，发现形如 `sk-`、`Bearer ` 的疑似密钥即 `SECRET_IN_ARTIFACT` 拒绝启动。

## 8. 成本

- 真源是运行结束后的 `POST /v1/usage`（agent 与 eval 都上报），字段：tenant、dept、model、strategy、source、input/output/cache tokens、cost_usd（可空=未知）、run_id。
- `cost_usd` 由上报方按发布单里的价格计算；platform 只做聚合与预算判定，避免两套价格。
- 预算键：`tenant:<id>` / `dept:<tenant>/<id>` / `experiment:<id>`；周期 `daily|monthly`；`limit_usd` 与 `warn_ratio`（默认 0.8）。
- 运行前：`GET /v1/budgets/check?scope=...` 返回 `allowed` 或 429；运行后上报即扣减。
- 报表：`/v1/cost/report` 支持 `groupBy=tenant|dept|model|strategy|day`，`format=json|md`；缺失成本单独计数 `unknown_cost_runs`。

## 9. 可观测

- 指标口径沿用 6-4 三层，分母不同不混算：业务（运行数）、Agent（工具调用数）、模型（模型调用数）。
- agent 暴露 `/metrics`：`agent_runs_total{outcome,release,track}`、`agent_tool_calls_total{tool,status}`、`model_calls_total{model,status}`、`model_latency_ms`、`platform_cost_usd_total{tenant,model}`、`retrieval_queries_total{mode}`、`retrieval_hit_rate`。
- Trace：自建 exporter 调 Langfuse `/api/public/ingestion`，每个运行一个 trace，固定五段：`run` → `prompt_rendered` → `model_call`* → `tool_call`* → `outcome`；只写脱敏后的内容。
- Grafana provisioning 与 6-4 同法，新增「成本与预算」「发布与灰度」两块看板。

## 10. 失败语义

| 情形 | 返回 | 落库/审计 |
|---|---|---|
| 身份缺失/无效 | 401 `UNAUTHENTICATED` | 审计 `auth_denied` |
| 跨租户访问 | 403 `FORBIDDEN_TENANT` | 审计 `tenant_violation` |
| 预算耗尽 | 429 `BUDGET_EXCEEDED` + `Retry-After` | 审计 `budget_blocked` |
| 发布检查未过 | 409 `RELEASE_NOT_CHECKED` | 审计 `release_rejected` |
| 回放版本不一致 | 409 `REPLAY_VERSION_MISMATCH`（带差异项） | 审计 `replay_mismatch` |
| gateway 不可达 | 503 `GATEWAY_UNAVAILABLE` | 运行标 `error`，不写假答案 |
| 用量缺失 | 运行完成但 `cost_usd=null` | 报表计入 `unknown_cost_runs` |
