#!/usr/bin/env python3
"""契约一致性检查：docs/openapi.yaml ↔ 五个服务的真实路由。

为什么不用「再维护一份路由表」：那样两个地方都能改，检查就退化成自我确认。
这里从**服务源码**里抽出路由常量（针对每种写法定制提取器），再与契约比对：

  - 契约里有、代码里没有 → 文档在说谎；
  - 代码里有、契约里没有 → 调用方无法从契约发现这个端点。

提取器刻意写得很「窄」：只要服务改了路由的写法，这里就抽不到，检查立刻失败。
这比抽到一半静默通过要好——失败会逼着人回来同步契约。

用法：python3 scripts/check_contract.py [--verbose]
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SPEC = ROOT / "docs" / "openapi.yaml"
SERVICES = ("gateway", "agent", "retrieval", "eval", "platform")
METHODS = ("get", "post", "put", "patch", "delete")


# ------------------------------------------------------------------ 读契约

def load_spec_paths() -> dict[str, set[tuple[str, str]]]:
    """返回 {service: {(METHOD, 真实路径)}}，已剥掉文档前缀。"""
    try:
        import yaml  # 有就用，没有就走下面的窄扫描
    except ImportError:
        return _scan_spec_text(SPEC.read_text(encoding="utf-8"))

    document = yaml.safe_load(SPEC.read_text(encoding="utf-8"))
    table: dict[str, set[tuple[str, str]]] = {name: set() for name in SERVICES}
    for raw_path, item in document.get("paths", {}).items():
        prefix, _, real = raw_path.lstrip("/").partition("/")
        real = "/" + real
        for method, operation in item.items():
            if method not in METHODS:
                continue
            # tags 是权威分组；前缀只是为了让同名路径能共存。
            service = (operation.get("tags") or [prefix])[0]
            table.setdefault(service, set()).add((method.upper(), real))
    return table


def _scan_spec_text(text: str) -> dict[str, set[tuple[str, str]]]:
    """无 PyYAML 时的兜底：只认本文件的实际排版（路径 2 空格、方法 4 空格）。"""
    table: dict[str, set[tuple[str, str]]] = {name: set() for name in SERVICES}
    current = None
    tag = None
    for line in text.splitlines():
        path_match = re.match(r"^  (/\S+):\s*$", line)
        if path_match:
            raw = path_match.group(1)
            prefix, _, real = raw.lstrip("/").partition("/")
            current = (prefix, "/" + real)
            tag = None
            continue
        if line.startswith("components:"):
            current = None
            continue
        if current is None:
            continue
        tag_match = re.match(r"^      tags: \[([a-z]+)\]", line)
        if tag_match:
            tag = tag_match.group(1)
            continue
        method_match = re.match(r"^    (get|post|put|patch|delete):\s*$", line)
        if method_match:
            service = tag or current[0]
            table.setdefault(service, set()).add((method_match.group(1).upper(), current[1]))
    return table


# ------------------------------------------------------------------ 抽源码

def _read(relative: str) -> str:
    return (ROOT / relative).read_text(encoding="utf-8")


def agent_routes() -> set[tuple[str, str]]:
    text = _read("services/agent/src/server.ts")
    routes: set[tuple[str, str]] = set()
    for method, path in re.findall(r'req\.method === "(GET|POST)" && path === "([^"]+)"', text):
        routes.add((method, path))
    # 运行详情 / SSE / 回放共用一个正则，方法由 action 分支决定。
    if "([^/]+)(\\/events|\\/replay)?$" not in text:
        raise RuntimeError("agent: 没找到 /v1/runs/{run_id} 的动态路由正则，提取器需要同步")
    for marker, method, suffix in (("!action", "GET", ""),
                                   ('action === "/events"', "GET", "/events"),
                                   ('action === "/replay"', "POST", "/replay")):
        if marker not in text:
            raise RuntimeError(f"agent: 缺少 {marker} 分支，提取器需要同步")
        routes.add((method, "/v1/runs/{run_id}" + suffix))
    return routes


def retrieval_routes() -> set[tuple[str, str]]:
    text = _read("services/retrieval/app/server.py")
    # 只认 `if path == ...`：`internal = path == "/internal/query"` 是赋值，不是路由声明。
    routes = {("GET", path) for path in re.findall(r'if path == "(/[^"]+)"', text)}
    for group in re.findall(r"if path not in \{(.+?)\}:", text):
        for path in re.findall(r'"(/[^"]+)"', group):
            routes.add(("POST", path))
    return routes


def eval_routes() -> set[tuple[str, str]]:
    text = _read("codebaseEval/backend/server.py")
    routes: set[tuple[str, str]] = set()
    for path in re.findall(r'path\.rstrip\("/"\) == "(/[^"]+)"', text):
        routes.add(("GET", path))

    def join(parts: list[str]) -> str:
        return "/api/" + "/".join(parts)

    for method, raw in re.findall(r'method == "(\w+)" and route == \[([^\]]*)\]', text):
        routes.add((method, join(re.findall(r'"([^"]+)"', raw))))
    for method, names in re.findall(
            r'method == "(\w+)" and len\(route\) == 2 and route\[0\] in \{([^}]*)\}', text):
        for name in re.findall(r'"([^"]+)"', names):
            routes.add((method, join([name, "{id}"])))
    for method, head, tail in re.findall(
            r'method == "(\w+)" and len\(route\) == 3 and route\[0\] == "(\w+)" '
            r'and route\[2\] == "(\w+)"', text):
        routes.add((method, join([head, "{id}", tail])))
    if 'len(route) == 2 and route[0] == "runs"' in text:
        routes.add(("GET", join(["runs", "{id}"])))
    for tail in re.findall(r'if route\[2\] == "([^"]+)":', text):
        routes.add(("POST", join(["runs", "{id}", tail])))
    for group in re.findall(r'method == "GET" and route in \[\[(.*?)\]\]', text):
        for path in re.findall(r'"([^"]+)"', group):
            routes.add(("GET", join([path])))
    return routes


def platform_routes() -> set[tuple[str, str]]:
    text = _read("services/platform/app/server.py")
    routes: set[tuple[str, str]] = set()
    # 公开端点写在 dispatch 里：`self.path_only == "/health" and self.command == "GET"`
    for path, method in re.findall(
            r'self\.path_only == "(/[^"]+)" and self\.command == "(GET|POST)"', text):
        routes.add((method, path))

    # 逐块扫 `if path == "X"`：条件里自带 method 的直接计，块内的 method 分支也算。
    lines = text.splitlines()
    for index, line in enumerate(lines):
        start = re.match(r'^(\s*)if path == "(/[^"]+)"(?: and method == "(\w+)")?:\s*$', line)
        if not start:
            continue
        indent, path, inline = len(start.group(1)), start.group(2), start.group(3)
        if inline:
            routes.add((inline, path))
        block = [line]
        for follow in lines[index + 1:]:
            if not follow.strip():
                continue
            current = len(follow) - len(follow.lstrip())
            if current <= indent:
                break
            block.append(follow)
        for method in re.findall(r'method == "(\w+)"', "\n".join(block)):
            routes.add((method, path))

    if r"^/v1/releases/([^/]+)(/check|/publish)?$" not in text:
        raise RuntimeError("platform: 没找到发布单动态路由正则，提取器需要同步")
    if 'method == "GET" and not action' in text:
        routes.add(("GET", "/v1/releases/{version}"))
    for action, method in (("/check", "POST"), ("/publish", "POST")):
        if f'action == "{action}"' not in text:
            raise RuntimeError(f"platform: 缺少 {action} 分支，提取器需要同步")
        routes.add((method, "/v1/releases/{version}" + action))
    return routes


def gateway_routes() -> set[tuple[str, str]]:
    """网关的路由由 litellm 提供，不是本仓库代码；这里只记录我们确实依赖的那几条。

    刻意写死：升级 litellm 大版本时，这个清单必须人工复核——这正是「显式依赖」的意思。
    """
    return {("POST", "/v1/chat/completions"), ("GET", "/health/liveliness")}


EXTRACTORS = {
    "gateway": gateway_routes,
    "agent": agent_routes,
    "retrieval": retrieval_routes,
    "eval": eval_routes,
    "platform": platform_routes,
}


# ------------------------------------------------------------------ 比对

def canonical(path: str) -> str:
    """把路径参数名统一成 `{}`：契约用 {version}，代码用 {run_id}，语义相同。"""
    return re.sub(r"\{[^/}]+\}", "{}", path)


def main() -> int:
    parser = argparse.ArgumentParser(description="OpenAPI 契约 ↔ 实现路由一致性")
    parser.add_argument("--verbose", action="store_true")
    args = parser.parse_args()

    spec = load_spec_paths()
    failures: list[str] = []
    for service in SERVICES:
        try:
            code = EXTRACTORS[service]()
        except (OSError, RuntimeError) as error:
            failures.append(f"[{service}] 提取失败：{error}")
            continue
        documented = {(method, canonical(path)) for method, path in spec.get(service, set())}
        implemented = {(method, canonical(path)) for method, path in code}
        only_spec = sorted(documented - implemented)
        only_code = sorted(implemented - documented)
        if args.verbose:
            print(f"[{service}] 契约 {len(documented)} 条 / 实现 {len(implemented)} 条")
        for method, path in only_spec:
            failures.append(f"[{service}] 契约有、代码没有：{method} {path}")
        for method, path in only_code:
            failures.append(f"[{service}] 代码有、契约没有：{method} {path}")
        if not implemented:
            failures.append(f"[{service}] 一条路由都没抽到，提取器已经和实现脱节")

    if failures:
        print("\n".join(failures), file=sys.stderr)
        print(f"契约检查失败：{len(failures)} 处不一致", file=sys.stderr)
        return 1
    total = sum(len(spec.get(name, ())) for name in SERVICES)
    print(f"契约检查通过：{len(SERVICES)} 个服务 / {total} 个端点与实现一致")
    return 0


if __name__ == "__main__":
    sys.exit(main())
