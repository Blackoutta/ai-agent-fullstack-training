#!/usr/bin/env python3
"""在 agent 上真跑一次，给现场演示造一条新鲜运行。

为什么需要它：`make smoke-live` 的回放步骤按 run_id 去重——同一个 run 回放过就跳过。
连着演示第二场时，第 6 步只会打印「已回放过，跳过」，看不到 `status=match`。
演示前跑一次 `make run` 就能拿到一条未回放过、且归档在当前 stable 版本上的运行。

身份：必须用 `role=service` 的密钥（agent 只信任 service 身份代建运行）。
默认从 `.env` 的 `PLATFORM_API_KEYS` 里自动取那一条，也可用 `--api-key` 覆盖。

退出码：运行 `outcome=pass` 返回 0，否则返回 1（演示脚本能据此中断）。
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_PROMPT = "登录接口报 500，帮我定位是鉴权还是数据库"
TERMINAL = {"finished", "failed", "error", "cancelled"}


class RunFailure(RuntimeError):
    pass


def service_key_from_env_file(path: Path) -> str:
    """从 .env 的 PLATFORM_API_KEYS 里取 role=service 的密钥，取不到返回空串。"""
    if not path.is_file():
        return ""
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.startswith("PLATFORM_API_KEYS="):
            continue
        for entry in line.split("=", 1)[1].split(","):
            parts = entry.strip().split(":")
            if len(parts) >= 4 and parts[3] == "service":
                return parts[0]
    return ""


def parse_args(argv):
    parser = argparse.ArgumentParser(description="造一次 agent 运行（演示用）")
    parser.add_argument("--agent-url", default=os.environ.get("AGENT_URL", "http://127.0.0.1:8080"))
    parser.add_argument("--api-key", default=os.environ.get("PLATFORM_API_KEY", ""),
                        help="默认取环境变量，再退回 .env 里 role=service 的密钥")
    parser.add_argument("--task", default="understand", help="只允许 understand / rag_qa / status")
    parser.add_argument("--prompt", default=DEFAULT_PROMPT)
    parser.add_argument("--timeout", type=float, default=120.0, help="等待终态的秒数")
    return parser.parse_args(argv)


def call(url: str, key: str, method: str = "GET", body: dict | None = None) -> dict:
    data = json.dumps(body).encode("utf-8") if body is not None else None
    request = urllib.request.Request(url, data=data, method=method)
    request.add_header("Authorization", f"Bearer {key}")
    if data is not None:
        request.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            return json.loads(response.read().decode("utf-8") or "{}")
    except urllib.error.HTTPError as error:
        detail = error.read().decode("utf-8", "replace")[:400]
        raise RunFailure(f"{method} {url.split('://', 1)[-1]} → {error.code}：{detail}") from error
    except urllib.error.URLError as error:
        raise RunFailure(f"{method} {url} 连不上：{error.reason}") from error


def main(argv=None) -> int:
    args = parse_args(argv)
    key = args.api_key or service_key_from_env_file(ROOT / ".env")
    if not key:
        print("找不到 role=service 的密钥：设置 PLATFORM_API_KEY 或在 .env 里补 PLATFORM_API_KEYS", file=sys.stderr)
        return 2
    base = args.agent_url.rstrip("/")

    created = call(f"{base}/v1/runs", key, "POST", {"task": args.task, "prompt": args.prompt})
    run_id = created.get("run_id") or created.get("id")
    if not run_id:
        raise RunFailure(f"创建运行没拿到 run_id：{created}")
    release = created.get("release") or {}
    print(f"已创建 run_id={run_id}  版本={release.get('version')}  轨道={release.get('track')}", flush=True)

    deadline = time.monotonic() + args.timeout
    summary: dict = {}
    while time.monotonic() < deadline:
        summary = call(f"{base}/v1/runs/{run_id}", key)
        if str(summary.get("status")) in TERMINAL:
            break
        time.sleep(1.0)
    else:
        raise RunFailure(f"等 {args.timeout:.0f}s 还没到终态：{summary.get('status')}")

    print(json.dumps({k: summary.get(k) for k in
                      ("run_id", "status", "outcome", "release_version", "track", "steps", "cost_usd")},
                     ensure_ascii=False, indent=2))
    return 0 if summary.get("outcome") == "pass" else 1


if __name__ == "__main__":
    try:
        sys.exit(main())
    except RunFailure as error:
        print(f"失败：{error}", file=sys.stderr)
        sys.exit(1)
