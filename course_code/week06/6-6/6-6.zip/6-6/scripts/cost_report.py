#!/usr/bin/env python3
"""把成本报表从平台端点取下来并落盘。

为什么走 HTTP 而不是直接 import `cost.report`：报表的口径（未知成本单独计数、
分组维度校验、租户过滤）都在端点那一层，直接调函数等于绕过一半逻辑，
落盘的 Markdown 就可能和调用方看到的不一样。

两种模式：

- 默认（离线）：同进程起平台控制面，读本机账本 `data/platform.db`，不联网、不需要 Docker。
  账本不存在时用内存库出一份空报表，并在 stderr 说明——不伪造数据。
- `--platform-url` 或 `PLATFORM_URL`：打真实平台；密钥取 `--api-key` 或 `PLATFORM_API_KEY`。

产物：`reports/cost-<UTC 日期>.md`（`--format json` 则 `.json`），`--out -` 打到 stdout。
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import threading
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from http.server import ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))


class ReportFailure(RuntimeError):
    pass


def parse_args(argv):
    parser = argparse.ArgumentParser(description="成本报表（Markdown / JSON）")
    parser.add_argument("--format", choices=("md", "json"), default="md")
    parser.add_argument("--days", type=int, default=7,
                        help="统计最近 N 天（UTC）；0 表示全部（默认 7）")
    parser.add_argument("--group-by", default="tenant",
                        choices=("tenant", "dept", "model", "strategy", "day"))
    parser.add_argument("--tenant", default="", help="只看某个租户（服务身份才允许跨租户）")
    parser.add_argument("--out", default="", help="输出路径；'-' 表示 stdout；默认 reports/cost-<date>.md")
    parser.add_argument("--offline", action="store_true",
                        help="强制同进程平台（默认在没给 --platform-url 时就是离线）")
    parser.add_argument("--platform-url", default=os.environ.get("PLATFORM_URL", ""))
    parser.add_argument("--api-key", default=os.environ.get("PLATFORM_API_KEY", ""))
    return parser.parse_args(argv)


def local_bearer(settings) -> str:
    """离线时用环境里配的第一把密钥；没配就是本机单租户模式，不带身份头。"""
    from services.platform.app.identity import parse_api_keys

    keys = parse_api_keys(settings.api_keys)
    return next(iter(keys), "")


class OfflinePlatform:
    """只为了「调端点」而起的控制面；不发任何治理动作。"""

    def __init__(self):
        self.httpd = None
        self.store = None
        self.thread = None
        self.bearer = ""

    def start(self) -> str:
        from services.platform.app.server import handler_for
        from services.platform.app.settings import Settings
        from services.platform.app.store import Store

        settings = Settings.load()
        db_path = Path(settings.db_path)
        if db_path.is_file():
            source = str(db_path)
        else:
            # 账本还不存在：用内存库出空报表，顺手创建 data/ 目录但不留空 db 文件。
            db_path.parent.mkdir(parents=True, exist_ok=True)
            settings = _with_db(settings, ":memory:")
            source = f"{db_path}（不存在，按空账本处理）"
        self.store = Store(settings.db_path)
        self.bearer = local_bearer(settings)
        self.httpd = ThreadingHTTPServer(("127.0.0.1", 0), handler_for(self.store, settings))
        self.httpd.daemon_threads = True
        self.thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)
        self.thread.start()
        print(f"账本：{source}", file=sys.stderr, flush=True)
        return f"http://127.0.0.1:{self.httpd.server_address[1]}"

    def stop(self) -> None:
        if self.httpd:
            self.httpd.shutdown()
            self.httpd.server_close()
            self.httpd = None
        if self.store:
            self.store.close()
            self.store = None


def _with_db(settings, db_path: str):
    import dataclasses

    return dataclasses.replace(settings, db_path=Path(db_path))


def get_text(base_url: str, path: str, bearer: str) -> tuple:
    request = urllib.request.Request(base_url.rstrip("/") + path, method="GET")
    request.add_header("Accept", "text/markdown, application/json")
    if bearer:
        request.add_header("Authorization", f"Bearer {bearer}")
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            return response.status, response.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as exc:
        return exc.code, exc.read().decode("utf-8", "replace")
    except (urllib.error.URLError, OSError) as exc:
        raise ReportFailure(f"平台不可达：{exc}")


def build_path(args) -> str:
    query = {"format": args.format, "groupBy": args.group_by}
    if args.days and args.days > 0:
        query["days"] = args.days
    if args.tenant:
        query["tenant"] = args.tenant
    return "/v1/cost/report?" + urllib.parse.urlencode(query)


def default_out(fmt: str) -> Path:
    day = datetime.now(timezone.utc).strftime("%Y%m%d")
    return ROOT / "reports" / f"cost-{day}.{'md' if fmt == 'md' else 'json'}"


def summarize(text: str, fmt: str) -> str:
    if fmt == "json":
        try:
            payload = json.loads(text)
        except json.JSONDecodeError:
            return text.strip()[:200]
        totals = payload.get("totals") or {}
        return (f"运行 {totals.get('runs', 0)} 条 / 已知成本 "
                f"{totals.get('known_cost_usd', 0):.6f} USD / 未知成本 "
                f"{totals.get('unknown_cost_runs', 0)} 条")
    for line in text.splitlines():
        if line.startswith("| ") and not line.startswith("| 运行数") and "---" not in line:
            return line.strip()
    return text.strip().splitlines()[0] if text.strip() else "(空报表)"


def main(argv=None) -> int:
    args = parse_args(argv)
    platform = None
    try:
        if args.offline or not args.platform_url:
            platform = OfflinePlatform()
            base_url = platform.start()
            bearer = platform.bearer
        else:
            base_url = args.platform_url
            bearer = args.api_key
            print(f"平台：{base_url}", file=sys.stderr, flush=True)

        status, text = get_text(base_url, build_path(args), bearer)
        if status != 200:
            raise ReportFailure(f"报表端点返回 {status}：{text[:300]}")
        if args.format == "md" and "# 成本报表" not in text:
            raise ReportFailure("返回内容不是成本报表 Markdown，拒绝落盘")

        if args.out == "-":
            sys.stdout.write(text)
            return 0
        out = Path(args.out) if args.out else default_out(args.format)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(text, encoding="utf-8")
        print(f"已写入 {out}", flush=True)
        print(f"摘要：{summarize(text, args.format)}", flush=True)
        return 0
    except ReportFailure as exc:
        print(f"生成失败：{exc}", file=sys.stderr, flush=True)
        return 1
    finally:
        if platform:
            platform.stop()


if __name__ == "__main__":
    sys.exit(main())
