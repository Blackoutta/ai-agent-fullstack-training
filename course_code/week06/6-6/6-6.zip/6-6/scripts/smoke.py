#!/usr/bin/env python3
"""发布单 → 探针 → 灰度发布 → 回滚 → 回放 的演练脚本。

两种模式：

- `--offline`（`make smoke` 默认）：不碰 Docker、不联网。同进程起一个平台控制面，
  再加一个只回 `{"ok": true}` 的假 agent，状态落在 `data/smoke/`。
  跑的是 **真实的发布/检查/路由/回滚/回放代码**，只有外部依赖是假的。
- `--live`：打真实平台（`PLATFORM_URL`，默认 http://127.0.0.1:8090），
  真实调用 agent 回放。真实结果才允许写进「在线」那一栏。

为什么要幂等：演练会被反复执行（每次改代码都想跑一遍）。如果每次都新建发布单、
每次都插一条回放记录，「这次的演练和上次有什么不同」就无从对比。所以：

- 版本号按 UTC 日期固定为 `rel-YYYY.MM.DD.1`（stable 基线）与 `.2`（pilot），存在就复用；
- 已经 published 的版本不重复检查，路由已经指向目标版本就不重复发布；
- 回放按 `run_id` 去重，`/v1/replays` 里已有就跳过。

审计表例外：它本来就是 append-only 的流水，重复执行会多几条记录，这是设计如此，
不是「重复记录」。

退出码：0 全部通过；1 某一步不符合预期；2 环境问题（平台不可达等）。
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
import threading
import urllib.error
import urllib.parse
import urllib.request
import uuid
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_STATE = ROOT / "data" / "smoke"
# 环境变量里写 `key:tenant:dept:role`，调用方发的是 key 本身（这里是 `smoke`）。
DEMO_KEY = "smoke"
DEMO_KEY_ENTRY = f"{DEMO_KEY}:tenant_smoke:platform:admin"
TENANT = "tenant_smoke"
PILOT_RATIO = 10.0


class SmokeFailure(RuntimeError):
    """演练失败：带上下文，直接打到 stderr。"""


# ---------------------------------------------------------------- HTTP 小工具


def _decode(raw: bytes):
    text = raw.decode("utf-8", "replace")
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return {"raw": text[:400]}


class Api:
    """薄客户端：只做 JSON + Bearer + X-Request-Id，够演练用。"""

    def __init__(self, base_url: str, key: str | None = None):
        self.base = base_url.rstrip("/")
        self.key = key

    def call(self, method: str, path: str, body=None,
             expect: tuple = (200,), allow: tuple = ()):
        data = None if body is None else json.dumps(body, ensure_ascii=False).encode("utf-8")
        request = urllib.request.Request(self.base + path, data=data, method=method)
        request.add_header("Accept", "application/json")
        if data is not None:
            request.add_header("Content-Type", "application/json")
        if self.key:
            request.add_header("Authorization", f"Bearer {self.key}")
        request.add_header("X-Request-Id", f"smoke-{uuid.uuid4().hex[:8]}")
        try:
            with urllib.request.urlopen(request, timeout=60) as response:
                return response.status, _decode(response.read()), \
                    response.headers.get("X-Request-Id") or ""
        except urllib.error.HTTPError as exc:
            return exc.code, _decode(exc.read()), exc.headers.get("X-Request-Id") or ""
        except (urllib.error.URLError, OSError) as exc:
            raise SmokeFailure(f"{method} {path} 不可达：{exc}")

    def expect(self, method: str, path: str, body=None, codes: tuple = (200,)) -> dict:
        status, payload, request_id = self.call(method, path, body, expect=codes)
        if status not in codes:
            raise SmokeFailure(
                f"{method} {path} → {status}（期望 {codes}，request_id={request_id or '-'}）："
                f"{json.dumps(payload, ensure_ascii=False)[:400]}")
        return payload


# ---------------------------------------------------------------- 离线假 agent


class StubAgent:
    """只实现 `POST /v1/runs/<id>/replay`：回放是唯一会跨服务调用的一步。"""

    def __init__(self):
        self.httpd: ThreadingHTTPServer | None = None
        self.thread: threading.Thread | None = None
        self.calls: list[str] = []

    def start(self) -> str:
        outer = self

        class Handler(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"
            server_version = "stub-agent/1.0"

            def log_message(self, fmt, *args):  # 静默：演练输出要干净
                pass

            def do_POST(self):
                length = int(self.headers.get("Content-Length") or 0)
                if length:
                    self.rfile.read(length)
                path = urllib.parse.urlparse(self.path).path
                outer.calls.append(path)
                match = re.match(r"^/v1/runs/([^/]+)/replay$", path)
                if not match:
                    return self._send(404, {"error": {"code": "NOT_FOUND",
                                                      "message": f"stub 没有这个路由：{path}"}})
                run_id = urllib.parse.unquote(match.group(1))
                self._send(200, {"ok": True, "status": "passed", "run_id": run_id,
                                 "steps": 3, "offline": True})

            def _send(self, status: int, body: dict) -> None:
                payload = (json.dumps(body, ensure_ascii=False) + "\n").encode("utf-8")
                self.send_response(status)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Content-Length", str(len(payload)))
                self.end_headers()
                self.wfile.write(payload)

        self.httpd = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self.httpd.daemon_threads = True
        self.thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)
        self.thread.start()
        return f"http://127.0.0.1:{self.httpd.server_address[1]}"

    def stop(self) -> None:
        if self.httpd:
            self.httpd.shutdown()
            self.httpd.server_close()
            self.httpd = None


# ---------------------------------------------------------------- 离线平台


class OfflinePlatform:
    """同进程起真实平台控制面；配置与 data 目录都指向 data/smoke。"""

    def __init__(self, state_dir: Path):
        self.state_dir = Path(state_dir)
        self.stub = StubAgent()
        self.httpd: ThreadingHTTPServer | None = None
        self.store = None
        self.thread: threading.Thread | None = None

    def start(self) -> str:
        agent_url = self.stub.start()
        state = self.state_dir
        env = {
            "PLATFORM_DB": str(state / "data" / "platform.db"),
            "PLATFORM_RUNS_DIR": str(state / "runs"),
            "PLATFORM_RELEASES_DIR": str(state / "releases"),
            "PLATFORM_CORPUS_DIR": str(ROOT / "corpus"),
            "PLATFORM_GATEWAY_CONFIG": str(ROOT / "services/gateway/litellm.config.yaml"),
            "PLATFORM_AGENT_CONFIG": str(ROOT / "services/agent/config/platform.yaml"),
            "PLATFORM_PROMPTS": str(ROOT / "services/agent/config/prompts.yaml"),
            "PLATFORM_GRANTS": str(ROOT / "services/retrieval/config/grants.json"),
            "PLATFORM_EVAL_SOURCE": str(ROOT / "codebaseEval/backend"),
            "PLATFORM_API_KEYS": DEMO_KEY_ENTRY,
            "PLATFORM_ALLOWED_HOSTS": "localhost,127.0.0.1",
            "PLATFORM_SECRET_SCAN": "1",
            "PLATFORM_AGENT_URL": agent_url,
            "DEMO_TENANT": TENANT,
        }
        os.environ.update(env)

        sys.path.insert(0, str(ROOT))
        from services.platform.app import releases
        from services.platform.app.server import handler_for
        from services.platform.app.settings import Settings
        from services.platform.app.store import Store

        settings = Settings.load()
        self.store = Store(settings.db_path)
        # 启动自检照跑：演练目录里一旦出现疑似密钥就必须当场失败，而不是演练「成功」。
        releases.ensure_no_secrets(settings)
        releases.write_route(settings.releases_dir, self.store.route())
        self.httpd = ThreadingHTTPServer(("127.0.0.1", 0), handler_for(self.store, settings))
        self.httpd.daemon_threads = True
        self.thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)
        self.thread.start()
        return f"http://127.0.0.1:{self.httpd.server_address[1]}"

    def stop(self) -> None:
        if self.httpd:
            self.httpd.shutdown()
            self.httpd.server_close()
            self.httpd = None
        if self.store:
            self.store.close()
            self.store = None
        self.stub.stop()


# ---------------------------------------------------------------- 演练步骤


def versions_today() -> tuple:
    day = datetime.now(timezone.utc).strftime("%Y.%m.%d")
    return f"rel-{day}.1", f"rel-{day}.2"


def ensure_release(api: Api, version: str) -> tuple:
    """存在就复用；只有 404 才新建。重复执行不会产生第二张发布单。"""
    status, payload, _ = api.call("GET", f"/v1/releases/{urllib.parse.quote(version)}",
                                  allow=(404,))
    if status == 200:
        return payload["status"], "已存在，复用"
    if status != 404:
        raise SmokeFailure(f"读取发布单 {version} 得到 {status}：{payload}")
    created = api.expect("POST", "/v1/releases", {"version": version}, codes=(201,))
    release = created["release"]
    return release["status"], "新建 draft"


def ensure_checked(api: Api, version: str) -> str:
    release = api.expect("GET", f"/v1/releases/{urllib.parse.quote(version)}")
    if release.get("status") == "published":
        return "published，跳过重复探针"
    result = api.expect("POST", f"/v1/releases/{urllib.parse.quote(version)}/check")
    if result.get("status") != "checked":
        failed = [f"{item['id']}: {item['detail']}"
                  for item in result.get("cases", []) if not item.get("ok")]
        raise SmokeFailure("发布门禁未通过：" + "；".join(failed or ["未知原因"]))
    return f"checked，{len(result.get('cases', []))} 个探针全部通过"


def ensure_published(api: Api, version: str, track: str, ratio: float = 0.0) -> str:
    route = api.expect("GET", "/v1/releases/route")
    release = api.expect("GET", f"/v1/releases/{urllib.parse.quote(version)}")
    if track == "stable" and route.get("stable") == version \
            and release.get("status") == "published":
        return "stable 已指向该版本，跳过"
    if track == "pilot" and route.get("pilot") == version \
            and abs(float(route.get("pilot_ratio") or 0) - ratio) < 1e-9 \
            and release.get("status") == "published":
        return "pilot 已指向该版本，跳过"
    body = {"track": track}
    if track == "pilot":
        body["pilot_ratio"] = ratio
    result = api.expect("POST", f"/v1/releases/{urllib.parse.quote(version)}/publish", body)
    saved = result["route"]
    return (f"published {result['track']} → stable={saved['stable']} "
            f"pilot={saved['pilot']} ratio={float(saved['pilot_ratio']):g}")


def preview(api: Api, run_id: str, group: str) -> dict:
    query = urllib.parse.urlencode({"run_id": run_id, "group": group})
    payload = api.expect("GET", f"/v1/releases/route/preview?{query}")
    return payload["choice"]


def ensure_rollback(api: Api) -> str:
    route = api.expect("GET", "/v1/releases/route")
    if not route.get("pilot"):
        return "没有 pilot 在跑，跳过（幂等）"
    result = api.expect("POST", "/v1/releases/rollback",
                        {"reason": "smoke 演练：pilot 回滚"})
    return f"rolled_back {result['rolled_back']} → stable={result['stable']}"


def ensure_replay(api: Api, run_id: str) -> tuple:
    listing = api.expect("GET", "/v1/replays?limit=50")
    if any(item.get("run_id") == run_id for item in listing.get("items", [])):
        return "该 run 已回放过，跳过（幂等）", True
    status, payload, request_id = api.call("POST", "/v1/replays", {"run_id": run_id})
    if status == 409:
        # R8：版本指纹不一致时必须明确失败。这里不做任何「当作成功」的修饰。
        diffs = payload.get("details") or []
        return (f"409 版本不一致（符合 R8，不假装成功，request_id={request_id or '-'}）"
                f"：{json.dumps(diffs, ensure_ascii=False)[:200]}"), False
    if status != 200:
        raise SmokeFailure(f"回放失败：{status} {json.dumps(payload, ensure_ascii=False)[:300]}")
    replay = payload.get("replay") or {}
    return f"回放完成 run={run_id} ok={payload.get('ok')} status={payload.get('status') or replay.get('status')}", True


# ---------------------------------------------------------------- 主流程


class Runner:
    def __init__(self, api: Api, run_id: str, live: bool):
        self.api = api
        self.run_id = run_id
        self.live = live
        self.base_version, self.pilot_version = versions_today()
        self.index = 0
        self.total = 0

    def mark(self, label: str, detail: str) -> None:
        self.index += 1
        print(f"[{self.index}/{self.total}] {label:<6} {detail}", flush=True)

    def run(self, steps: list) -> None:
        self.total = len(steps)
        for label, action in steps:
            self.mark(label, action())

    # ------------------------------------------------------------ 单步

    def identity(self) -> str:
        payload = self.api.expect("GET", "/v1/identities")
        view = payload.get("identity", {})
        return f"tenant={view.get('tenant')} dept={view.get('dept')} role={view.get('role')}"

    def release(self) -> str:
        base_status, base_note = ensure_release(self.api, self.base_version)
        pilot_status, pilot_note = ensure_release(self.api, self.pilot_version)
        return (f"{self.base_version}={base_status}（{base_note}）；"
                f"{self.pilot_version}={pilot_status}（{pilot_note}）")

    def check(self) -> str:
        base = ensure_checked(self.api, self.base_version)
        pilot = ensure_checked(self.api, self.pilot_version)
        return f"base: {base}；pilot: {pilot}"

    def publish(self) -> str:
        stable = ensure_published(self.api, self.base_version, "stable")
        pilot = ensure_published(self.api, self.pilot_version, "pilot", PILOT_RATIO)
        chosen = preview(self.api, self.run_id, "pilot")
        if chosen.get("track") != "pilot":
            raise SmokeFailure(f"x-release-group=pilot 没有走 pilot：{chosen}")
        stable_choice = preview(self.api, self.run_id, "stable")
        if stable_choice.get("version") != self.base_version:
            raise SmokeFailure(f"x-release-group=stable 选错了版本：{stable_choice}")
        return f"{stable}；{pilot}；显式分组按预期命中"

    def rollback(self) -> str:
        detail = ensure_rollback(self.api)
        route = self.api.expect("GET", "/v1/releases/route")
        if route.get("pilot"):
            raise SmokeFailure(f"回滚后仍有 pilot：{route}")
        chosen = preview(self.api, self.run_id, "pilot")
        if chosen.get("track") != "stable":
            raise SmokeFailure(f"回滚后仍切到 pilot：{chosen}")
        return f"{detail}；回滚后重新全部走 stable"

    def replay(self) -> str:
        detail, ok = ensure_replay(self.api, self.run_id)
        if not ok:
            print(f"       ⚠ 回放未成立：{detail}", flush=True)
        return detail

    # ------------------------------------------------------------ 组合

    def full(self) -> None:
        self.run([
            ("身份", self.identity),
            ("发布单", self.release),
            ("探针", self.check),
            ("发布", self.publish),
            ("回滚", self.rollback),
            ("回放", self.replay),
        ])


def parse_args(argv):
    parser = argparse.ArgumentParser(description="发布单 / 灰度 / 回滚 / 回放演练")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--offline", action="store_true",
                      help="同进程起平台 + 假 agent，状态写 data/smoke（默认）")
    mode.add_argument("--live", action="store_true",
                      help="打真实平台与 agent（PLATFORM_URL）")
    parser.add_argument("--replay-only", action="store_true", help="只跑回放这一步")
    parser.add_argument("--step", choices=("release", "check", "publish", "rollback", "replay"),
                        help="只跑指定的一步（配合 make release-* 使用）")
    parser.add_argument("--run-id", default="",
                        help="要回放的运行号；live 模式留空则取 agent 最近一次运行")
    parser.add_argument("--state-dir", default=str(DEFAULT_STATE),
                        help=f"离线状态目录（默认 {DEFAULT_STATE}）")
    parser.add_argument("--platform-url", default=os.environ.get("PLATFORM_URL", ""),
                        help="live 模式的平台地址，默认取 PLATFORM_URL")
    parser.add_argument("--api-key", default=os.environ.get("PLATFORM_API_KEY", ""),
                        help="live 模式的平台密钥，默认取 PLATFORM_API_KEY")
    return parser.parse_args(argv)


def resolve_run_id(api: Api, args) -> str:
    if args.run_id:
        return args.run_id
    if not args.live:
        # 离线用固定 run 号：重复演练时按 run_id 去重才可能生效。
        return "run-smoke-" + datetime.now(timezone.utc).strftime("%Y%m%d")
    agent_url = (os.environ.get("AGENT_URL") or "http://127.0.0.1:8080").rstrip("/")
    payload = Api(agent_url, args.api_key or None).expect("GET", "/v1/runs")
    items = payload.get("items") or []
    if not items:
        raise SmokeFailure("agent 里没有任何运行记录，先用 POST /v1/runs 跑一次")
    return str(items[0].get("id") or items[0].get("run_id"))


def main(argv=None) -> int:
    args = parse_args(argv)
    offline = not args.live
    platform = None
    try:
        if offline:
            platform = OfflinePlatform(Path(args.state_dir))
            base_url = platform.start()
            api = Api(base_url, DEMO_KEY)
            print(f"模式：offline  状态目录：{Path(args.state_dir)}  平台：{base_url}", flush=True)
        else:
            base_url = args.platform_url or "http://127.0.0.1:8090"
            api = Api(base_url, args.api_key or None)
            print(f"模式：live  平台：{base_url}", flush=True)

        run_id = resolve_run_id(api, args)
        runner = Runner(api, run_id, live=not offline)

        if args.replay_only or args.step == "replay":
            runner.total = 1
            runner.mark("回放", runner.replay())
        elif args.step:
            action = getattr(runner, args.step)
            runner.total = 1
            runner.mark({"release": "发布单", "check": "探针", "publish": "发布",
                         "rollback": "回滚"}[args.step], action())
        else:
            runner.full()

        print(f"\n演练通过：{runner.index} 步，run_id={run_id}", flush=True)
        return 0
    except SmokeFailure as exc:
        print(f"\n演练失败：{exc}", file=sys.stderr, flush=True)
        return 1
    except KeyboardInterrupt:
        return 2
    finally:
        if platform:
            platform.stop()


if __name__ == "__main__":
    sys.exit(main())
