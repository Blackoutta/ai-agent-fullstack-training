# 阶段六 Production Ready Agent Engineering Platform 需求

授权在 `week06/6-6` 新建平台工程，组件来源固定为课程既有实现（`week05/5-5` 的 codebase 与 codebaseEval、`week06` 的 Langfuse 与 Prometheus、`week04` 的 LlamaIndex 与向量库）。采用用户确认的「可运行闭环」：`docker compose` 一键起全栈，不做 K8s 与 CI。

`week05/5-5` 为只读参考，快照复制后不得回写；每一处对快照的改动登记在 `design/vendor-patches.md`。

## 功能与验收

- R1 容器编排：gateway、agent、retrieval、eval、platform 五个应用服务 + Langfuse 六个官方服务 + Prometheus/Grafana + 向量库文件卷，统一 `docker-compose.yml`，`make up` 一次起齐，`make down` 干净停止，服务间只走 compose 内部网络名。
- R2 网关：使用 litellm，应用侧只发逻辑模型名 `deepseek-flash`，由网关解析到 `deepseek-v4-flash`；应用不得直连厂商端点；网关持有上游密钥，应用只持有平台签发的虚拟密钥。
- R3 Agent 服务化：codebase agent 从 CLI 升级为 HTTP 服务，提供创建运行、查询运行、订阅事件流、健康检查；每次运行归档输入、版本指纹、消息与原始模型返回。
- R4 检索服务化：LlamaIndex 检索（向量 / BM25 / Hybrid）以 HTTP 暴露；租户与部门过滤由服务端从身份推导后强制注入，请求体不接受的租户字段作为非法输入拒绝；Milvus Lite 单写者约束在文档与运行形态中体现。
- R5 Eval 平台容器化：保留 5-5 全部评测能力（Benchmark、策略、实验、Trace、Judge、人工评审、失败聚类、回归对比），补齐容器内同源校验、租户分区与成本回传。
- R6 版本管理与发布单：发布单记录组件版本与内容指纹，状态机为 `draft → checked → published`，未通过检查不得发布。
- R7 灰度发布与回滚：stable/pilot 双轨，按 `x-release-group` 或运行号哈希比例切流；发布与回滚只改路由表，不改镜像；每次路由变更写审计；pilot 失败自动回滚。
- R8 回放：基于运行归档重放，命中归档即不联网；版本指纹不一致时明确失败，绝不假装重放成功；回放结论与原运行逐字段对比。
- R9 成本治理：运行结束上报用量；按 tenant / dept / model / strategy 聚合；日/月预算超阈值告警、超硬上限 429 拒绝；报表支持 JSON 与 Markdown。
- R10 密钥与脱敏：API Key 只存在于环境变量与网关内存，不入 SQLite、不落运行归档、不进日志；身份证、手机号、地址按规则打码或哈希，合同金额原文 token 化，百分比与结构化数值字段保留；启动自检发现疑似密钥即拒绝启动。
- R11 租户隔离：平台 API 以 `Authorization: Bearer` 鉴别，映射到 tenant/dept/role；eval 数据、运行归档、成本报表、审计均按 tenant 分区；跨租户读取返回 403 并写审计；向量检索强制 metadata filter。
- R12 SDK 与契约：单一 `docs/openapi.yaml` 覆盖全部服务；提供 TypeScript 与 Python 薄客户端，统一错误体、重试与 SSE 解析；契约测试校验路径与错误体一致。

## 边界

- 单租户多部门教学规模；不做用户注册登录、OAuth、外网 TLS 与多副本水平扩展。
- Milvus Lite 为嵌入式文件，只允许 ingest 一次性写、retrieval 单副本打开；无密钥时降级 BM25，不声称向量检索有效。
- 离线模式（无 `DEEPSEEK_API_KEY`）走 codebase 的 `decider=mock` 与录制回放，结果一律标 `offline`，不计入真实成功率分母。
- 成本为按配置价格与用量估算，不等同供应商账单；缺失用量显式计数，不按 0 计。
- 不修改 `week05/5-5`、`week06/6-2..6-5`、`week04` 原目录；不自动提交或推送。
