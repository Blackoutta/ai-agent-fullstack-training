# 阶段六：Production Ready Agent Engineering Platform

## 0. 已确认的决策（本次澄清结果）

| 议题 | 决策 |
|---|---|
| 交付档位 | 可运行闭环：compose 一键起全部组件，端到端跑通一次实验 + trace + 指标 + 灰度发布 + 成本报表；不做 K8s/CI |
| 代码归属 | 快照复制到 6-6，5-5 原目录零改动，补丁记录在 `design/vendor-patches.md` |
| 灰度对象 | 平台级发布单（gateway 模型路由 + agent prompt/skill + eval 策略 + retrieval 索引版本） |
| 凭据 | 双模式：无密钥可离线跑通全链路（明确标注非真实成绩），配 `DEEPSEEK_API_KEY` 自动切真实 |
| 向量库 | Milvus Lite 文件挂卷（单写者约束，只读降级 BM25） |
| 隔离 | 强制隔离：API Key → tenant/dept/role，检索层强制注入 filter，越权 403 + 审计 |
| 脱敏 | 分类分级：身份证/手机号/地址打码或哈希；金额原文 token 化（`AMOUNT_1`），百分比与结构化数值保留 |
| 成本治理 | 预算拦截（超硬上限 429）+ 按租户/部门/模型/策略的报表 |
| 文档 | 沿用 5-5 四件套：`requirements/`、`design/`、`plans/`、`check/` + 角色门禁 |

## 1. 目录结构（根：`week06/6-6`）

```
week06/6-6/
├── docker-compose.yml            # 全栈编排（含 profile：core / observability / full）
├── Makefile                      # up/down/ps/logs/verify-offline/seed/smoke
├── .env.example                  # 唯一密钥入口（不入库、不落 DB）
├── README.md
├── requirements/platform.md      # R1..R12 与边界
├── design/architecture.md        # 架构、数据流、数据模型、失败语义
├── design/vendor-patches.md      # 对 codebase / codebaseEval 快照的每一处补丁
├── plans/TASK-001-platform.md    # 开发任务计划
├── plans/WP-001..WP-009-*.md     # 工作包（按 §5 顺序）
├── check/00-env/pipeline-status.md
├── check/validation.md           # 实际执行的验收结果与未覆盖项
├── docs/openapi.yaml             # 全部服务契约（手写单一真源）
├── docs/ops.md                   # 起停、端口、排障、密钥轮换
├── codebase/                     # 5-5 codebase 快照（保留相对路径，bridge 依赖 parents[2]）
├── codebaseEval/                 # 5-5 codebaseEval 快照 + 容器化/隔离/脱敏补丁
├── services/
│   ├── gateway/litellm.config.yaml      # deepseek-flash → deepseek-v4-flash
│   ├── agent/                            # Node 22 服务：HTTP + SSE + 归档 + Langfuse exporter
│   ├── retrieval/                        # Python 3.12：LlamaIndex + Milvus Lite + 强制 filter
│   ├── platform/                         # Python 3.12 控制面：release/cost/budget/tenant/audit/replay
│   └── eval/Dockerfile                   # node22 + python3.11 双运行时镜像
├── deploy/
│   ├── langfuse/docker-compose.langfuse.yml   # 复用 6-3 六服务，仅改端口冲突项
│   ├── prometheus/                            # 复用 6-4，Grafana 改 3001 + 新 dashboard
│   └── milvus/                                # 卷目录 + ingest 一次性作业
├── releases/                     # 发布单产物（manifest + 验收用例快照）
├── runs/                         # 运行归档（input/versions/messages/raw）
├── data/                         # SQLite（agent.db / platform.db）+ milvus lite
├── sdk/
│   ├── ts/                       # @platform/sdk（含 SSE、重试、错误归一）
│   └── python/                   # platform_sdk（仅标准库 urllib）
└── tests/                        # python 单测 + node 单测 + 契约测试
```

## 2. 端口规划（含既有冲突处理）

| 组件 | 宿主端口 | 说明 |
|---|---|---|
| gateway (litellm) | 4000 | 与应用同源，`/v1/chat/completions` |
| agent service | 8080 | 新服务 |
| retrieval service | 8770 | 新服务 |
| eval 平台 | 8765 | 沿用 |
| platform 控制面 | 8090 | 新服务 |
| Langfuse web / worker | 3000 / 3030 | 沿用 6-3 |
| Grafana | **3001** | 6-4 原为 3000，与 Langfuse 冲突，改 3001 |
| Prometheus | 9092 | 沿用 6-4（9090 被 Langfuse minio 占用） |
| clickhouse / minio / postgres / redis | 8123+9000 / 9090 / 5432 / 6379 | 沿用 6-3 |
| Milvus Lite | 无端口 | 文件卷 `data/milvus_login_demo.db` |

## 3. 服务契约（写进 `docs/openapi.yaml`）

统一约定：同源、JSON、`Authorization: Bearer <platform-api-key>`、错误体 `{error, code, details[], request_id}`、超限 `429` 带 `Retry-After`。

- **gateway**：litellm 原生 `/v1/chat/completions`；逻辑模型名 `deepseek-flash` 由网关解析到 `deepseek-v4-flash`；不允许应用直连厂商端点。
- **agent** `services/agent`
  - `POST /v1/runs` `{tenantId, userId, taskId|goal, releaseGroup?}` → `202 {runId, releaseVersion}`
  - `GET /v1/runs/{runId}` → 运行摘要（含 usage、cost、outcome）
  - `GET /v1/runs/{runId}/events` → SSE（tool/message/approval 事件，已脱敏）
  - `GET /health` → `{gateway, promptVersion, releaseVersion}`
- **retrieval** `services/retrieval`
  - `POST /v1/query` `{query, topK, mode: vector|bm25|hybrid}` → `{nodes[], trace{retrieval_mode, filters_applied}}`
  - tenant/dept filter 由服务端从身份推导注入，请求体不接受 tenant 字段
- **eval** 沿用 5-5 全部 `/api/*`，新增：`GET /api/cost`、`GET /api/health`；全部 `/api/*` 要求身份头并按 tenant 分区
- **platform** `services/platform`
  - `POST /v1/releases` 生成草稿（采集当前各组件版本 + 内容指纹）
  - `POST /v1/releases/{v}/check` 离线校验 + 可选 live 探针
  - `POST /v1/releases/{v}/publish` `{pilotRatio}` / `POST /v1/releases/{v}/rollback`
  - `GET /v1/releases/current`、`GET /v1/releases/{v}`
  - `POST /v1/replays` `{runId}`、`GET /v1/replays/{id}`
  - `GET /v1/cost/report?groupBy=tenant|dept|model|strategy&from&to&format=json|md`
  - `POST /v1/usage`（内部计量上报）、`GET /v1/budgets`、`PUT /v1/budgets`
  - `GET /v1/audit?tenant=&action=&from=`、`GET /v1/identities`（只回显 env 名，不回显密钥值）

## 4. 关键设计决策

**4.1 灰度与发布单**
- 发布单 `releases/<version>/manifest.yaml` 记录：gateway 模型映射与配置哈希、agent 的 prompt 名/版本/内容哈希/skill 版本、eval 的策略与任务快照哈希、retrieval 的 collection 与 corpus 哈希、验收用例。
- 路由表存在 platform（`stable` / `pilot` / `pilot_ratio`）。agent 启动与每 30s 拉取 active release；`x-release-group: pilot` 或 `sha256(runId) % 100 < pilot_ratio` 决定走哪个版本，响应头回写 `x-release-version`，审计留痕。
- 回滚 = 路由表切回上一版 + 用同一批验收用例复跑，不重训、不改代码。
- 发布门禁：`check` 未通过（验收用例失败/版本指纹不一致）拒绝 publish；pilot 失败自动回滚并写审计。

**4.2 回放**
- 每次运行归档 `runs/<runId>/{input.json, versions.json, messages.jsonl, raw/}`（沿用 6-3 的 replay bundle 结构）。
- agent 内置 `recorded` provider：命中归档即回放模型返回，不联网；版本不一致（prompt 哈希/模型别名/schema）直接退出码 1，不假装重放成功。
- 回放结果与原运行逐字段对比，产出 `replay_report.md`；评测侧复用 codebaseEval 的 `source_hash` + 策略快照保证同条件。

**4.3 脱敏（单一模块，三个消费点）**
- `services/platform/redaction.py`（并在 agent 侧提供等价 TS 实现）定义规则：`id_card`、`phone`、`address`、`amount`；`amount` 走 token 化（`AMOUNT_1`），百分比与结构化数值字段白名单保留。
- 消费点：agent 的 SSE/审计落库、eval 的 `scrub()`、platform 的审计与日志。任何出站 JSON 统一过滤，禁止 `v-html`。
- 不可逆原则：token 映射只在单次运行的内存作用域存活，不落库、不跨租户。

**4.4 租户与权限**
- 身份来自 `PLATFORM_API_KEYS`（`key:tenant:dept:role`），只存在环境变量；platform 提供校验端点，其他服务本地缓存 60s。
- 检索：服务端强制 `tenant_id` + `dept_id` metadata filter，请求体无 tenant 字段可传；Milvus Lite 单进程写入 → ingest 为一次性作业（RW），retrieval 单副本 RW 打开，文档写明不支持多副本。
- eval：`entities` / `reviews` 增 `tenant` 列与索引，`/api/state`、`/api/compare`、`/api/reports` 全部按身份过滤；跨租户读直接 403 并记审计。
- 密钥：只在 `.env`/compose `env_file`；litellm 用 master key + virtual key，应用侧只拿 virtual key；平台启动自检 `assert_no_secrets()` 扫描 `data/`、`runs/`、`releases/` 中的疑似密钥，命中则拒绝启动。

**4.5 成本治理**
- 计量真源：agent 与 eval 运行结束后向 `POST /v1/usage` 上报 `{tenant, dept, model, strategy, input_tokens, output_tokens, cache_tokens, cost_usd, run_id}`；litellm 的 spend log 仅作交叉核对，不作为唯一真源（避免依赖其内部表）。
- 预算：`budgets.yaml` 支持 tenant/dept/experiment 级日/月上限；运行前检查余额（耗尽 429），运行后扣减，80% 告警。codebase 自带 `max_cost_usd` 作为单次运行硬顶，双保险。
- 报表：`/v1/cost/report` 输出 JSON/Markdown；同时把 `platform_cost_usd_total`、`platform_tokens_total`、`agent_run_outcome_total`、`retrieval_hit_rate` 暴露给 Prometheus，Grafana 新增「成本与预算」看板（复用 6-4 provisioning 方式）。

**4.6 可观测接入（规避版本冲突）**
- codebase 依赖 `@earendil-works/pi-* 0.87.1`，而 6-3 的 `@langfuse/pi-observability-plugin` 面向 1.5.0。**不使用该插件**，改为在 agent 服务里用 `onEvent` 观察器 + `fetch` 调 Langfuse `/api/public/ingestion` 自建 exporter（trace/generation/span 映射固定 5 段证据链），避免 peer 版本崩溃。
- Prometheus 沿用 6-4 三层口径（业务/Agent/模型分母不同，不混算），新增平台与成本指标。

## 5. 工作包与实施顺序

| 顺序 | 工作包 | 产出 |
|---|---|---|
| 1 | WP-001 骨架与文档 | 目录、`requirements/platform.md`、`design/architecture.md`、`plans/*`、`.env.example`、compose 骨架；`docker compose config` 通过 |
| 2 | WP-002 gateway | litellm 配置化容器 + `deepseek-flash` 别名 + 虚拟密钥 + 冒烟脚本（离线用 stub 端点验证路由） |
| 3 | WP-003 agent 服务化 | HTTP/SSE/归档/recorded provider/脱敏/审计/Langfuse exporter/`/metrics`；仅以配置覆盖接入 gateway，不改 codebase 逻辑 |
| 4 | WP-004 retrieval | LlamaIndex + Milvus Lite 卷 + 强制 filter + BM25 离线降级 + ingest 作业 |
| 5 | WP-005 eval 容器化 | node22+py3.11 镜像、Host 校验放宽到 compose 服务名、tenant 分区、复用脱敏、成本回传 |
| 6 | WP-006 平台控制面 | 发布单/灰度/回滚/回放/预算/成本报表/审计/身份，SQLite `platform.db` |
| 7 | WP-007 可观测编排 | Langfuse 六服务 + Prometheus/Grafana(3001) + 新 dashboard + 指标接线 |
| 8 | WP-008 SDK 与契约 | `docs/openapi.yaml` + TS/Python 客户端 + 契约测试（路径/错误体/重试/SSE） |
| 9 | WP-009 验收 | `make verify-offline` 全绿、`check/validation.md`、`README` 一键起停与已知边界 |

每个工作包完成后按 5-5 门禁更新 `check/00-env/pipeline-status.md`；架构 → 编码 → 设计符合性 → 代码质量 → 测试 顺序不跳。

## 6. 验收方式

**我在本机离线自验（无需 Docker）**
- `python -m pytest tests/`：脱敏规则、成本聚合、预算拦截、发布单状态机（draft/check/publish/rollback）、租户过滤、回放版本不一致退出码。
- `npx vitest run tests/`：SSE 事件映射、manifest 哈希、recorded provider、审计脱敏。
- SDK 契约测试：OpenAPI 路径 ↔ 各服务路由常量一致；错误体与重试策略。
- `docker compose -f docker-compose.yml config` 语法与端口冲突校验。
- 灰度离线演练：`--offline` 走路由选择与版本验收，不调模型（对齐 6-5 的 offline 口径）。

**需要你执行（Docker daemon 当前未启动，检测到 orbstack 未运行）**
- `make up` 拉镜像起全栈 → `make seed` 入索引 → eval 跑一次 offline 实验 → 打开 Langfuse/Grafana 看 trace 与指标 → `make smoke` 跑灰度发布/回滚/回放 → `make cost` 出报表。
- 有 `DEEPSEEK_API_KEY` 时加 `make smoke-live` 走真实 deepseek-flash。

## 7. 风险与明确不做

- **Milvus Lite 单写者**：不允许 retrieval 多副本；并发写会锁失败。降级路径 = BM25（`rag/retrieve.py` 已有）。
- **Docker daemon 未运行**：完整栈验收必须你本机 `make up`；我只保证离线可验证部分 + compose 语法校验。
- **真实模型不可离线验证**：离线结果一律标 `offline`，不进入成功率分母（沿用 5-5 判定规则）。
- **pi 0.87.1 与 Langfuse 插件不兼容**：已决定自建 exporter，若后续要换官方插件需同步升级 pi 版本，不在本期。
- 不做：K8s/Helm、CI 流水线、外网 TLS、用户注册登录体系、Milvus 集群、多副本水平扩展。
