实现步骤：
1 分析需求， 基于需求和参考文件生成 plan
2 执行 plan
3 验证

---

# 一、原始需求（用户原话整理）

阶段六：Production Ready Agent Engineering Platform

项目背景：从「Agent 项目能运行」升级到「Agent 系统可部署、可监控、可发布、可审计」的 Agent 平台。

| 编号 | 需求 | 落到本期的具体口径 |
|---|---|---|
| N1 | 将组件 gateway、codebase agent、Eval 平台、langfuse、Prometheus、llamaindex、向量数据库 封装到 docker | 统一 `docker-compose.yml`，一键 `make up`；七个组件各有独立容器与服务入口 |
| N2 | 版本管理、灰度发布与回滚、回放 | 平台级发布单（manifest + 内容指纹 + 验收用例）；stable/pilot 双轨按比例切流；回滚切路由表；回放基于运行归档重放模型返回 |
| N3 | 成本治理和成本报表 | 按 tenant/dept/model/strategy 聚合；预算日/月阈值，超限 429；Markdown/JSON 报表 + Grafana 看板 |
| N4 | 安全与合规 | API Key 不入库（只在环境变量）；Trace/日志脱敏（身份证、手机号、地址、合同金额）；知识库/向量库/业务数据按租户、部门隔离并强制权限过滤 |
| N5 | 支持各组件的 SDK 和服务化 | 每个组件都有 HTTP 服务化入口；单一 OpenAPI 契约 + TS/Python 薄客户端（含重试、错误归一、SSE） |

指定技术选择（用户指定）：
- gateway 使用 **litellm**，模型使用 **DeepSeek-flash**。
- codebase agent 参考 `week05/5-5/codebase`。
- Eval 参考 `week05/5-5/codebaseEval`。
- langfuse 参考 `week06` 的代码。
- Prometheus 参考 `week06` 的代码。
- llamaindex 参考 `week04` 的代码。
- 向量数据库 参考 `week04` 的代码。

# 二、澄清后确认的决策

| 议题 | 决策 |
|---|---|
| 交付档位 | 可运行闭环：compose 一键起全部组件，端到端跑通实验 + trace + 指标 + 灰度发布 + 成本报表；不做 K8s/CI |
| 代码归属 | 快照复制到 `6-6`，`week05/5-5` 原目录零改动，每处补丁记录在 `design/vendor-patches.md` |
| 灰度对象 | 平台级发布单（gateway 模型路由 + agent prompt/skill + eval 策略 + retrieval 索引版本） |
| 凭据 | 双模式：无密钥可离线跑通全链路并标注 `offline`，配 `DEEPSEEK_API_KEY` 自动切真实 |
| 向量库 | Milvus Lite 文件挂卷；单写者约束；只读降级 BM25 |
| 隔离 | 强制隔离：API Key → tenant/dept/role；检索层强制注入 filter；越权 403 + 审计 |
| 脱敏 | 分类分级：身份证/手机号/地址打码或哈希；金额原文 token 化（`AMOUNT_1`），百分比与结构化数值保留 |
| 成本治理 | 预算拦截（超硬上限 429）+ 按租户/部门/模型/策略报表 |
| 文档 | 沿用 5-5 四件套 + 角色门禁 |

# 三、交付物索引

- 实施计划（本目录的上一级真源）：`.qoder/plans/阶段六_Agent_平台_50fd2507.md`
- 需求：`requirements/platform.md`
- 架构与契约：`design/architecture.md`、`docs/openapi.yaml`
- 快照补丁说明：`design/vendor-patches.md`
- 工作包与任务计划：`plans/TASK-001-platform.md`、`plans/WP-00X-*.md`
- 验收：`check/00-env/pipeline-status.md`、`check/validation.md`
- 运维：`README.md`、`docs/ops.md`
- 代码：`services/{gateway,agent,retrieval,platform,eval}`、`deploy/`、`sdk/{ts,python}`、`tests/`
