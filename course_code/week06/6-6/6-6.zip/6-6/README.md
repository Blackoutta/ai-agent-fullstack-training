# 阶段六：Production Ready Agent Engineering Platform

把「Agent 项目能运行」升级为「Agent 系统可部署、可监控、可发布、可审计」。

七个组件统一进 docker：gateway（litellm + DeepSeek-flash）、codebase agent、Eval 平台、Langfuse、Prometheus/Grafana、LlamaIndex 检索、Milvus Lite 向量库。
在此之上补四件事：发布单灰度/回滚/回放、成本预算与报表、租户隔离与脱敏、TS/Python SDK。

需求与决策见 [plan/README.md](plan/README.md)、[requirements/platform.md](requirements/platform.md)；架构见 [design/architecture.md](design/architecture.md)。

## 快速开始

```sh
cp .env.example .env      # 填 DEEPSEEK_API_KEY；留空则走离线模式
make up                   # 起全部组件
make ps                   # 看状态
```

| 入口 | 地址 |
|---|---|
| 平台控制面 | http://127.0.0.1:8090 |
| Agent 服务 | http://127.0.0.1:8080 |
| 检索服务 | http://127.0.0.1:8770 |
| Eval 平台 | http://127.0.0.1:8765 |
| 网关 | http://127.0.0.1:4000 |
| Langfuse | http://localhost:3000 |
| Grafana | http://localhost:3001 |
| Prometheus | http://127.0.0.1:9092 |

内存紧张时用 `make up-core`：只起五个应用服务，跳过 Langfuse 与监控栈。

> 本机走代理才能拉镜像时：宿主 `export https_proxy/http_proxy` 只影响 build 里的 `RUN`，
> `docker pull` 还要给 daemon 配 `proxies`（OrbStack 写在 `~/.orbstack/config/docker.json`）。
> 详见 `check/validation.md` 第六节。

## 演示线

```sh
make smoke        # 发布单 → 检查 → 灰度发布 → 回滚 → 回放，全部 offline
make cost         # 成本报表（平台在跑时走 HTTP 端点，没跑时读本地账本）
make seed         # 需要向量检索时：停 retrieval → 写 Milvus Lite → 起 retrieval
```

现场连着演示同一套环境时，先跑一次 `make run` 造一条新运行：回放按 `run_id` 去重，
回放过的 run 只会打印「已回放过，跳过」，新 run 才能看到 `status=match`。

`make smoke-live` 打真实平台与 agent，密钥自动取 `.env` 里 `PLATFORM_API_KEYS` 中
`role=service` 的那一条（也可用 `PLATFORM_API_KEY` 覆盖）。结果才计入真实成功率；
没有 `DEEPSEEK_API_KEY` 时 agent 走 mock，成本与 token 全部标为「未知」而不是补 0。

## 测一次大模型（网关）

网关起来后直接打 `deepseek-flash`，确认上游链路是通的：

```sh
export LITELLM_MASTER_KEY=$(grep '^LITELLM_MASTER_KEY=' .env | cut -d= -f2-)
curl -s http://127.0.0.1:4000/v1/chat/completions \
  -H "Authorization: Bearer $LITELLM_MASTER_KEY" \
  -H "Content-Type: application/json" \
  -d '{"model":"deepseek-flash","messages":[{"role":"user","content":"用一句话说明什么是幂等"}],"max_tokens":256}'
```

返回里带 `choices[0].message.content` 就说明模型通了。`deepseek-v4-flash` 是推理模型，
会先花 reasoning token：`max_tokens` 给太小（比如 32）时 `content` 会是空的、
`finish_reason=length`，只看到 `reasoning_content`，那不是故障。
没有 `DEEPSEEK_API_KEY` 时会报上游鉴权错误，那是密钥问题，不是容器问题。

同一次调用会同时进三处账，用 Prometheus 查（默认 15s 抓一次，等一个周期）：

```sh
# 请求数总量（先跑上面那条 curl，再跑这条；Prometheus 默认 15s 抓一次）
curl -s --get http://127.0.0.1:9092/api/v1/query \
  --data-urlencode 'query=sum(litellm_proxy_total_requests_metric_total)'

# 按部署与状态码拆开：deepseek-flash 有 primary/standby 两个部署，会看到两行
curl -s --get http://127.0.0.1:9092/api/v1/query \
  --data-urlencode 'query=sum by (model_id,status_code) (litellm_proxy_total_requests_metric_total)'

# token 与成本
curl -s --get http://127.0.0.1:9092/api/v1/query \
  --data-urlencode 'query=sum(litellm_total_tokens_metric_total)'
curl -s --get http://127.0.0.1:9092/api/v1/query \
  --data-urlencode 'query=sum(litellm_spend_metric_total)'
```

| 看什么 | 指标 / 入口 |
|---|---|
| 请求数、状态码、模型 | `litellm_proxy_total_requests_metric_total` |
| 延迟分布 | `litellm_request_total_latency_metric` |
| token 与成本 | `litellm_total_tokens_metric_total` / `litellm_spend_metric_total` |
| 逐次 trace | Langfuse http://localhost:3000 |
| 图表 | Grafana http://localhost:3001 → 面板 `Agent Platform` 最下方「网关：直连大模型的请求」 |
| 原始查询 | Prometheus http://127.0.0.1:9092 |

直接看网关原始指标（`/metrics` 会 307 跳转，必须带 `-L` 和 master key）：

```sh
curl -sL -H "Authorization: Bearer $LITELLM_MASTER_KEY" http://127.0.0.1:4000/metrics \
  | grep litellm_proxy_total_requests_metric_total
```

## 组件一览

| 组件 | 目录 | 说明 |
|---|---|---|
| gateway | `services/gateway/` | litellm 配置；`deepseek-flash` → `deepseek-v4-flash`，含 fallback、冷却、限流 |
| agent | `services/agent/` | Node 服务：`POST /v1/runs`、SSE 事件流、运行归档、回放、脱敏、`/metrics` |
| retrieval | `services/retrieval/` | LlamaIndex 向量/BM25/Hybrid 检索；租户与部门 filter 由服务端强制注入 |
| eval | `services/eval/` | 5-5 评测工作台容器化（node22 + python3.11），补租户分区与成本回传 |
| platform | `services/platform/` | 发布单、路由、回放调度、预算、成本报表、审计、身份 |
| 快照 | `codebase/`、`codebaseEval/` | 5-5 源码快照，补丁登记在 `design/vendor-patches.md` |
| SDK | `sdk/ts/`、`sdk/python/` | 薄客户端，统一错误体、重试、SSE |
| 契约 | `docs/openapi.yaml` | 全部服务接口的单一真源 |

## 离线自验（不需要 Docker）

```sh
make verify-offline
```

覆盖：脱敏规则与双语言一致性、成本聚合与预算拦截、发布单状态机、租户过滤、回放版本不一致、SSE 事件映射、契约路径对齐、compose 配置语法。

逐条验证方式与实际结果（含未覆盖项）记录在 [check/validation.md](check/validation.md)。

## 关键约束

- **Milvus Lite 单写者**：`make seed` 会先停 retrieval；不支持多副本与并发写。没有 `MINIMAX_CN_API_KEY` 时自动降级 BM25，并在响应里标 `retrieval_mode=bm25`。
- **离线不计分**：无密钥时的运行标 `offline`，不进入真实成功率分母。
- **密钥只在环境变量**：`PLATFORM_API_KEYS` 与网关密钥都不落库；启动自检命中疑似密钥即拒绝启动。
- **金额脱敏**：合同金额原文替换为 `AMOUNT_n`，映射只在单次运行内存中；百分比保留（评测需要）。
- 不包含：K8s、CI 流水线、外网 TLS、用户注册登录、Milvus 集群、多副本水平扩展。详见 `requirements/platform.md` 的边界一节。
