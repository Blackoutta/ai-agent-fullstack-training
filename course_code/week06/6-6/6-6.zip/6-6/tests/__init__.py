"""SDK 测试包。

`python3 -m unittest tests.test_sdk_python` 要能直接跑，所以这里必须有 `__init__.py`。
"""
