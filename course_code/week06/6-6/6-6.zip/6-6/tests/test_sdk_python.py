"""Python SDK 契约测试：路径表、鉴权头、错误归一、重试、SSE。

与 `sdk/ts/tests/contract.test.ts` 一一对应——两边同构不是口号，同样的用例两边都要过。
"""
from __future__ import annotations

import io
import json
import sys
import unittest
import urllib.error
import urllib.parse
from pathlib import Path
from typing import Any, Dict, List

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "sdk" / "python"))

from platform_sdk import (AgentClient, ApiError, EvalClient, PlatformClient,  # noqa: E402
                          RetrievalClient)


class FakeResponse:
    def __init__(self, body: bytes = b"{}", status: int = 200,
                 headers: Dict[str, str] | None = None):
        self._body = body
        self.status = status
        self.headers = headers or {}

    def read(self) -> bytes:
        return self._body

    def close(self) -> None:
        pass

    def __iter__(self):
        return iter(self._body.splitlines(keepends=True))


class Recorder:
    """替身 opener：记录方法+路径，按队列返回响应（队列空则回 200 {}）。"""

    def __init__(self):
        self.calls: List[Dict[str, Any]] = []
        self.queue: List[Any] = []

    def open(self, request, timeout=None):
        parsed = urllib.parse.urlparse(request.full_url)
        self.calls.append({
            "method": request.get_method(),
            "path": parsed.path,
            "query": urllib.parse.parse_qs(parsed.query),
            "headers": {key.lower(): value for key, value in request.header_items()},
        })
        item = self.queue.pop(0) if self.queue else {"status": 200, "body": b"{}"}
        if isinstance(item, FakeResponse):
            return item
        status = item.get("status", 200)
        headers = item.get("headers", {})
        body = item.get("body", b"{}")
        if status >= 400:
            raise urllib.error.HTTPError(request.full_url, status, "error", headers,
                                         io.BytesIO(body))
        return FakeResponse(body, status, headers)


def canonical(path: str) -> str:
    for value in ("rel-2026.11.09.1", "6f1c2a54-9e3b-4f0a-8d7c-1b2e3f4a5b6c",
                  "run-1", "tsk-1", "stg-1", "exp-1"):
        path = path.replace(value, "{}")
    return path


class PathTableTests(unittest.TestCase):
    def test_sdk_covers_all_non_probe_endpoints(self):
        recorder = Recorder()
        options = {"opener": recorder, "retry_base": 0, "api_key": "k:t:d:admin"}

        platform = PlatformClient("http://platform.test", **options)
        agent = AgentClient("http://agent.test", **options)
        retrieval = RetrievalClient("http://retrieval.test", **options)
        evals = EvalClient("http://eval.test", **options)

        platform.identity()
        platform.list_releases()
        platform.draft_release()
        platform.get_release("rel-2026.11.09.1")
        platform.check("rel-2026.11.09.1")
        platform.publish("rel-2026.11.09.1", track="pilot", pilot_ratio=10)
        platform.rollback(reason="5xx 上升")
        platform.route()
        platform.preview_route("6f1c2a54-9e3b-4f0a-8d7c-1b2e3f4a5b6c")
        platform.record_usage(source="test")
        platform.cost_report(days=7)
        platform.list_budgets()
        platform.set_budget("tenant:tenant_a", 1)
        platform.check_budget(["tenant:tenant_a"])
        platform.audit(limit=5)
        platform.list_replays()
        platform.replay("6f1c2a54-9e3b-4f0a-8d7c-1b2e3f4a5b6c")

        agent.run("ping")
        agent.list()
        agent.get("run-1")
        agent.replay("run-1")

        retrieval.query("登录失败先查哪张表")
        retrieval.internal_query("q", "tenant_a", "platform")

        evals.state()
        evals.cost()
        evals.save_task({"name": "t"})
        evals.import_tasks([{"name": "t"}])
        evals.export_tasks()
        evals.delete_task("tsk-1")
        evals.save_strategy({"name": "s"})
        evals.delete_strategy("stg-1")
        evals.start_experiment({"name": "e"})
        evals.cancel_experiment("exp-1")
        evals.get_run("run-1")
        evals.judge("run-1")
        evals.review("run-1", {"verdict": "ok"})
        evals.compare(baseline="a", candidate="b")
        evals.report(fmt="json")

        actual = {f"{call['method']} {canonical(call['path'])}" for call in recorder.calls}
        expected = {
            "GET /v1/identities",
            "GET /v1/releases", "POST /v1/releases",
            "GET /v1/releases/{}", "POST /v1/releases/{}/check",
            "POST /v1/releases/{}/publish", "POST /v1/releases/rollback",
            "GET /v1/releases/route", "GET /v1/releases/route/preview",
            "POST /v1/usage", "GET /v1/cost/report",
            "GET /v1/budgets", "POST /v1/budgets", "GET /v1/budgets/check",
            "GET /v1/audit", "GET /v1/replays", "POST /v1/replays",
            "POST /v1/runs", "GET /v1/runs", "GET /v1/runs/{}", "POST /v1/runs/{}/replay",
            "POST /v1/query", "POST /internal/query",
            "GET /api/state", "GET /api/cost",
            "POST /api/tasks", "POST /api/tasks/import", "GET /api/tasks/export",
            "DELETE /api/tasks/{}",
            "POST /api/strategies", "DELETE /api/strategies/{}",
            "POST /api/experiments", "POST /api/experiments/{}/cancel",
            "GET /api/runs/{}", "POST /api/runs/{}/judge", "POST /api/runs/{}/reviews",
            "GET /api/compare", "GET /api/reports",
        }
        self.assertEqual(sorted(actual), sorted(expected))


class HeaderTests(unittest.TestCase):
    def test_bearer_and_request_id(self):
        recorder = Recorder()
        PlatformClient("http://platform.test", api_key="sk-demo:tenant_a:platform:admin",
                       opener=recorder, retry_base=0, request_id="req-fixed").route()

        headers = recorder.calls[0]["headers"]
        self.assertEqual(headers["authorization"], "Bearer sk-demo:tenant_a:platform:admin")
        self.assertEqual(headers["x-request-id"], "req-fixed")

    def test_multi_value_query_repeats_scope(self):
        recorder = Recorder()
        PlatformClient("http://platform.test", opener=recorder, retry_base=0)\
            .check_budget(["tenant:a", "dept:a/b"])

        self.assertEqual(recorder.calls[0]["query"]["scope"], ["tenant:a", "dept:a/b"])


class ErrorNormalizationTests(unittest.TestCase):
    def _client(self, recorder: Recorder) -> PlatformClient:
        return PlatformClient("http://platform.test", opener=recorder, retry_base=0,
                              max_retries=0)

    def test_nested_error_shape(self):
        recorder = Recorder()
        recorder.queue.append({
            "status": 409,
            "body": json.dumps({
                "error": {"code": "RELEASE_NOT_CHECKED", "message": "先 check"},
                "code": "RELEASE_NOT_CHECKED", "details": [], "request_id": "req-1",
            }).encode(),
            "headers": {"X-Request-Id": "req-1"},
        })
        with self.assertRaises(ApiError) as ctx:
            self._client(recorder).route()
        error = ctx.exception
        self.assertEqual((error.status, error.code, error.message),
                         (409, "RELEASE_NOT_CHECKED", "先 check"))
        self.assertEqual(error.request_id, "req-1")
        self.assertEqual(error.details, [])

    def test_legacy_string_error_and_flat_code(self):
        recorder = Recorder()
        recorder.queue.append({
            "status": 400,
            "body": json.dumps({"error": "旧形状的字符串错误",
                                "code": "INVALID_ARGUMENT"}).encode(),
        })
        with self.assertRaises(ApiError) as ctx:
            self._client(recorder).route()
        self.assertEqual(ctx.exception.code, "INVALID_ARGUMENT")
        self.assertEqual(ctx.exception.message, "旧形状的字符串错误")

    def test_non_json_body(self):
        recorder = Recorder()
        recorder.queue.append({"status": 502, "body": b"upstream exploded"})
        with self.assertRaises(ApiError) as ctx:
            self._client(recorder).route()
        self.assertEqual((ctx.exception.status, ctx.exception.code),
                         (502, "HTTP_502"))
        self.assertEqual(ctx.exception.message, "HTTP 502")

    def test_details_and_request_id_exposed(self):
        recorder = Recorder()
        recorder.queue.append({
            "status": 409,
            "body": json.dumps({
                "error": {"code": "REPLAY_VERSION_MISMATCH", "message": "版本不一致"},
                "code": "REPLAY_VERSION_MISMATCH",
                "details": [{"diffs": [{"field": "tools"}]}],
                "request_id": "req-abc",
            }).encode(),
            "headers": {"X-Request-Id": "req-abc"},
        })
        with self.assertRaises(ApiError) as ctx:
            self._client(recorder).replay("run-1")
        self.assertEqual(ctx.exception.code, "REPLAY_VERSION_MISMATCH")
        self.assertEqual(ctx.exception.details[0]["diffs"][0]["field"], "tools")


class RetryTests(unittest.TestCase):
    def test_retries_5xx_then_succeeds(self):
        recorder = Recorder()
        recorder.queue.append({
            "status": 503,
            "body": json.dumps({"error": {"code": "UNAVAILABLE", "message": "reloading"}}).encode(),
        })
        recorder.queue.append({
            "status": 200, "body": json.dumps({"stable": "rel-1"}).encode(),
        })
        client = PlatformClient("http://platform.test", opener=recorder,
                                retry_base=0, max_retries=1)
        self.assertEqual(client.route()["stable"], "rel-1")
        self.assertEqual(len(recorder.calls), 2)

    def test_does_not_retry_4xx(self):
        recorder = Recorder()
        recorder.queue.append({
            "status": 403,
            "body": json.dumps({"error": {"code": "FORBIDDEN", "message": "no"}}).encode(),
        })
        client = PlatformClient("http://platform.test", opener=recorder,
                                retry_base=0, max_retries=3)
        with self.assertRaises(ApiError):
            client.route()
        self.assertEqual(len(recorder.calls), 1)


class StreamAndWaitTests(unittest.TestCase):
    def test_stream_parses_sse_and_stops_at_done(self):
        body = (b'data: {"type":"step","index":1}\n\n'
                b'data: {"type":"step","index":2}\n\n'
                b"data: [DONE]\n\n")
        recorder = Recorder()
        recorder.queue.append(FakeResponse(body, 200, {"Content-Type": "text/event-stream"}))

        client = AgentClient("http://agent.test", opener=recorder, retry_base=0)
        events = list(client.stream("run-1"))

        self.assertEqual([event["index"] for event in events], [1, 2])

    def test_stream_reassembles_split_frame(self):
        body = (b'data: {"type":"step","ind'
                b'ex":7}\n\ndata: [DONE]\n\n')
        recorder = Recorder()
        recorder.queue.append(FakeResponse(body, 200))

        client = AgentClient("http://agent.test", opener=recorder, retry_base=0)
        events = list(client.stream("run-1"))
        self.assertEqual(events, [{"type": "step", "index": 7}])

    def test_wait_polls_until_terminal(self):
        recorder = Recorder()
        for status in ("running", "running", "done"):
            recorder.queue.append({
                "status": 200,
                "body": json.dumps({"run_id": "run-1", "status": status}).encode(),
            })
        client = AgentClient("http://agent.test", opener=recorder, retry_base=0)
        run = client.wait("run-1", timeout=5, interval=0)
        self.assertEqual(run["status"], "done")
        self.assertEqual(len(recorder.calls), 3)


if __name__ == "__main__":
    unittest.main()
