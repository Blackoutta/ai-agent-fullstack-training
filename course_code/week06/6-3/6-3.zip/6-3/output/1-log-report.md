# 演示一：日志记录的真实调用

**一句话结论：接口全部成功，业务判断出错。**

客户查对了、接口都成功、政策返回了两版、模型正常结束但只拿到旧政策。

## 运行条件
- 运行编号：run-20261107-a6e0f1b1
- 平台 Trace ID：9c91869370b556323427e3b0b01f1fe9
- 业务时间：2026-11-06T09:00:00.000Z（演示固定值，不跟随系统时钟）
- 日志文件：`logs/agent-58030.jsonl`
- 生成模型：DeepSeek deepseek-flash
- 写入器：已写 30 条，丢弃 0，写入错误 无

## 主案例：连续证据链
按 `run_id` 过滤后，下面这些记录属于同一次问答，不是彼此孤立的事件。

| 步骤 | 日志记录 | 接口/调用状态 | 关键字段 | 说明 |
| --- |--- |--- |--- |--- |
| 1 客户查询 | customer.authorization + customer.http_request | 授权 allow；CRM HTTP 200 | C-1001 / 华东 / 制造 / 数据平台标准版 | 客户查对了，权限与接口都正常 |
| 2 政策检索 | policy.http_request | HTTP 200 | 查询条件含 customer_id / keyword / business_time；候选 P-old / P-current；P-current 有效期 2026-01-01~2026-12-31 | 接口成功，新旧两版都返回 |
| 3 服务查询 | catalog.http_request | HTTP 200 | 数据平台标准版；包含驻场=false | 服务目录成功，标准服务不含驻场 |
| 4 证据筛选 | evidence.selection | 无接口调用（业务代码） | 选中 P-old；excluded: P-current=截断在相关性第一名之后；selection_rule=relevance_top_1；validity_check_applied=false | 第一处偏差：按相关性取第一份，没有校验有效期 |
| 5 模型输入 | context.snapshot | provider payload 已归档 | 最终请求前快照只包含 P-old | 模型没有拿到 P-current |
| 6 模型生成 | model.message.completed | 最终 stop_reason=stop（共 3 次生成） | 折扣 15%；引用 P-old | 模型正常结束，但输出旧政策中的 15% |
| 7 答案审阅 | answer.review | outcome=failure | disposition=recheck；未通过 引用政策在业务时间有效（P-old 有效期 2025-01-01~2025-12-31 不覆盖业务时间 2026-11-06） | 业务控制不通过，答案不能直接交给销售 |

## 重点看这两行
### 1. `evidence.selection`：第一处明确偏差
- 候选：P-old / P-current
- 选中：P-old
- 排除：P-current=截断在相关性第一名之后
- 规则：`selection_rule=relevance_top_1`，`validity_check_applied=false`
- 业务时间：2026-11-06T09:00:00.000Z

这说明：P-current 已经被检索到，但在生成之前被筛掉；这是第一处明确偏差，不是接口错误。

```json
{
  "event": "evidence.selection",
  "run_id": "run-20261107-a6e0f1b1",
  "business_time": "2026-11-06T09:00:00.000Z",
  "candidate_ids": [
    "P-old",
    "P-current"
  ],
  "selected_ids": [
    "P-old"
  ],
  "excluded": [
    {
      "id": "P-current",
      "reason": "截断在相关性第一名之后"
    }
  ],
  "selection_rule": "relevance_top_1",
  "validity_check_applied": false
}
```

### 2. `answer.review`：答案不能直接交给销售
- `outcome=failure`，`disposition=recheck`
- 未通过：引用政策在业务时间有效（P-old 有效期 2025-01-01~2025-12-31 不覆盖业务时间 2026-11-06）

这说明：过期政策引用未通过，必须先补查、明确无法确认或转人工。

```json
{
  "event": "answer.review",
  "run_id": "run-20261107-a6e0f1b1",
  "outcome": "failure",
  "disposition": "recheck",
  "failed_checks": [
    {
      "check": "引用政策在业务时间有效",
      "detail": "P-old 有效期 2025-01-01~2025-12-31 不覆盖业务时间 2026-11-06"
    }
  ]
}
```

## 从日志得出的结论
- 客户查对了：C-1001 / 华东 / 制造 / 数据平台标准版，授权 allow，CRM HTTP 200。
- 接口都成功：CRM、政策检索、服务目录都是 200 / 200 / 200；日志里没有 HTTP 报错。
- 政策返回了两版：P-old / P-current；P-current 有效期 2026-01-01~2026-12-31，覆盖业务时间 2026-11-06=是。
- 模型正常结束（stop_reason=stop），但请求前快照只有 P-old，回答给出 15% 并引用 P-old。
- 第一处偏差在 evidence.selection：按相关性取第一份，没有校验有效期；P-current 在生成前被筛掉。
- 业务信号在 answer.review：引用政策在业务时间有效（P-old 有效期 2025-01-01~2025-12-31 不覆盖业务时间 2026-11-06） 未通过，disposition=recheck；答案不能直接交给销售。
- 下一步用 Trace 比较证据筛选结果和模型实际输入；只改 Prompt 不够，因为 P-current 没有进入生成请求。

## 附：运行汇总
| 项目 | 值 |
| --- |--- |
| 主案例模型调用 / provider 请求 | 3 / 3 |
| 主案例 Token（输入 / 输出 / 总） | 677 / 718 / 3187 |
| 主案例成本 / 未知用量 | 0.001075 USD / 0 次 |
| 主案例工具调用 / 失败 | 3 / 0 |
| 主案例接口请求 / 失败 | 3 / 0 |
| 主案例 P95 耗时 / 审阅未通过 | 52 ms / 1 |
| 日志写入 | 已写 30，丢弃 0，错误 无 |

## 结论边界
- 日志能确认调用事实，也能确认“新政策被检索到、但没有进入模型”。
- 日志不能单独说明是哪一行代码把新政策筛掉的；需要结合 Trace 和代码。
- 完整答案、请求前 payload 和接口原始返回都在归档引用里，日志只保留摘要。
