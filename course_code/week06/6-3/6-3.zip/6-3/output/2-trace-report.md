# 演示二：Trace 里看 P-current 在哪一步消失

生成时间：2026-11-07T08:48:29.266Z

## 运行标识
- 运行编号：run-20261107-6f4f37e4
- 平台 Trace ID：d4047279ff13277fe87869861f0d4e10
- 业务时间：2026-11-06T09:00:00.000Z（演示固定值）
- 问题：客户 C-1001 当前最高能享受多少折扣？报价是否包含驻场支持？
- 调用树链接：http://localhost:3000/project/proj-sales-agent-demo/traces/d4047279ff13277fe87869861f0d4e10
- Trace 校验：通过（平台 13 条记录；根节点与日志一致=是；本地 trace_id 一致=是）

## 核心证据链：P-current 从有到无
| Trace 节点 | P-current 状态 | 关键证据 | 说明 |
| --- |--- |--- |--- |
| retrieval.sales_policy | 有（P-old / P-current） | P-current 有效期 2026-01-01~2026-12-31；覆盖业务时间 2026-11-06=是 | 知识库确实返回了当前政策 |
| context.build.evidence_selection | 被排除 | 选中 P-old；排除 P-current=截断在相关性第一名之后；selection_rule=relevance_top_1；validity_check_applied=false | 第一处偏差：按相关性取第一份，没有校验有效期 |
| context.snapshot / 模型请求 | 没有 | 请求前 payload 只包含 P-old | 模型没有收到当前政策 |
| model.message.completed | 未采用 | 输出 15%；引用 P-old；stop_reason=stop | 模型正常结束，但只用了旧政策 |
| answer.review | 引用过期 | 未通过：引用政策在业务时间有效（P-old 有效期 2025-01-01~2025-12-31 不覆盖业务时间 2026-11-06）；disposition=recheck | 业务控制拦截，答案不能直接返回 |

## 第一处偏差：证据筛选
| 字段 | 值 |
| --- |--- |
| candidate_ids | ["P-old","P-current"] |
| selected_ids | ["P-old"] |
| excluded | [{"id":"P-current","reason":"截断在相关性第一名之后"}] |
| selection_rule | relevance_top_1 |
| validity_check_applied | false |
| business_time | 2026-11-06T09:00:00.000Z |

判断依据：P-current 已经被检索到，但筛选结果里没有它；过期政策却被选中。
下一步：先比较筛选规则和排除原因，再修改筛选代码。

## 为什么不是检索或模型
- 不是检索：retrieval.sales_policy 同时返回了 P-old 和 P-current，P-current 在业务时间 2026-11-06 有效。
- 不是模型执行失败：最终 stop_reason=stop，回答结构正常，只是采用了 P-old。
- 不是生成指令：P-current 在请求前 payload 里就不存在，模型没有机会采用。

## 结论
第一处偏差在证据筛选。优先修改证据筛选：先校验权限、适用条件和有效期，再排序截断；具体修改交给 Replay 验证。
只改 Prompt 不够：P-current 没有进入生成请求，模型无法使用它。
