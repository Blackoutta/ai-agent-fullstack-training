import { afterEach, describe, expect, it, vi } from "vitest";
import { waitForTraceTree } from "../src/langfuse-api.js";

const TRACE = "trace-1";

function observation(id: string, parentObservationId: string | null): Record<string, unknown> {
  return {
    id,
    traceId: TRACE,
    projectId: "proj-test",
    parentObservationId,
    type: "SPAN",
    startTime: "2026-01-01T00:00:00.000Z",
    endTime: "2026-01-01T00:00:00.010Z",
  };
}

/** 按调用顺序吐出预设页面，模拟异步入库让调用树逐步可见。 */
function stubPages(pages: Array<unknown[] | Error>): void {
  let index = 0;
  vi.stubGlobal("fetch", async () => {
    const next = pages[Math.min(index++, pages.length - 1)];
    if (next instanceof Error) throw next;
    return new Response(JSON.stringify({ data: next }), { status: 200 });
  });
}

afterEach(() => {
  vi.unstubAllGlobals();
});

describe("平台调用树读取", () => {
  it("抓到中间态时等到条数稳定再返回，不把半棵树当成完整调用树", async () => {
    const root = observation("root-span", null);
    const partial = [root, observation("child-1", "root-span")];
    const complete = [...partial, observation("child-2", "root-span"), observation("child-3", "root-span")];
    stubPages([partial, complete, complete]);

    const tree = await waitForTraceTree(TRACE, 1_000, 1);

    expect(tree.complete).toBe(true);
    expect(tree.observations).toHaveLength(4);
    expect(tree.observations.some((item) => item.id === "root-span")).toBe(true);
    expect(tree.rows[0]?.observation.id).toBe("root-span");
  });

  it("入库报错时继续轮询，第一条记录到齐后返回", async () => {
    const root = observation("root-span", null);
    stubPages([new Error("langfuse_api_404"), [], [root], [root]]);

    const tree = await waitForTraceTree(TRACE, 1_000, 1);

    expect(tree.complete).toBe(true);
    expect(tree.observations).toHaveLength(1);
    expect(tree.rootName).toBeNull();
  });

  it("平台一直没有记录时超时返回空树，并明确标记不完整", async () => {
    stubPages([[]]);

    const tree = await waitForTraceTree(TRACE, 20, 1);

    expect(tree.complete).toBe(false);
    expect(tree.observations).toHaveLength(0);
    expect(tree.traceId).toBe(TRACE);
  });
});
