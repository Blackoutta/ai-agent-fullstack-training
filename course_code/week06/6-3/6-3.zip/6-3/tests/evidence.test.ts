import { describe, expect, it } from "vitest";
import { selectEvidence } from "../src/evidence.js";
import { CUSTOMERS, POLICIES } from "../src/data.js";

const customer = CUSTOMERS["C-1001"]!;
const businessTime = "2026-11-05T09:00:00.000Z";

describe("证据整理", () => {
  it("旧版按相关性直接截断，会选中过期政策", () => {
    const decision = selectEvidence({
      candidates: POLICIES,
      customer,
      businessTime,
      policy: "relevance-first-v1",
      limit: 1,
    });
    expect(decision.selected.map((item) => item.id)).toEqual(["P-old"]);
    expect(decision.excluded).toEqual([{ id: "P-current", reason: "截断在相关性第一名之后" }]);
    // 旧版的真实行为要留在记录里：没有执行有效期与适用条件检查。
    expect(decision.selectionRule).toBe("relevance_top_1");
    expect(decision.validityCheckApplied).toBe(false);
    expect(decision.applicabilityCheckApplied).toBe(false);
  });

  it("修复版在排序截断之前校验有效期，排除过期政策", () => {
    const decision = selectEvidence({
      candidates: POLICIES,
      customer,
      businessTime,
      policy: "validity-first-v2",
      limit: 1,
    });
    expect(decision.selected.map((item) => item.id)).toEqual(["P-current"]);
    expect(decision.excluded[0]?.id).toBe("P-old");
    expect(decision.excluded[0]?.reason).toContain("不覆盖业务时间 2026-11-05");
    expect(decision.selectionRule).toBe("validity_then_relevance");
    expect(decision.validityCheckApplied).toBe(true);
    expect(decision.applicabilityCheckApplied).toBe(true);
  });

  it("两版使用同一批候选和同一个条数上限", () => {
    const legacy = selectEvidence({ candidates: POLICIES, customer, businessTime, policy: "relevance-first-v1", limit: 1 });
    const fixed = selectEvidence({ candidates: POLICIES, customer, businessTime, policy: "validity-first-v2", limit: 1 });
    expect(legacy.limit).toBe(fixed.limit);
    expect(legacy.selected.length + legacy.excluded.length).toBe(POLICIES.length);
    expect(fixed.selected.length + fixed.excluded.length).toBe(POLICIES.length);
  });

  it("业务时间落在旧政策有效期内时，旧政策仍可被采用", () => {
    const decision = selectEvidence({
      candidates: POLICIES,
      customer,
      businessTime: "2025-06-01T00:00:00.000Z",
      policy: "validity-first-v2",
      limit: 1,
    });
    expect(decision.selected.map((item) => item.id)).toEqual(["P-old"]);
  });

  it("客户条件不匹配时全部排除，不返回任何折扣依据", () => {
    const decision = selectEvidence({
      candidates: POLICIES,
      customer: { ...customer, region: "华北" },
      businessTime,
      policy: "validity-first-v2",
      limit: 1,
    });
    expect(decision.selected).toHaveLength(0);
    expect(decision.excluded.map((item) => item.id)).toEqual(["P-old", "P-current"]);
  });

  it("业务时间落在两版政策之外时返回依据不足，不回退选过期政策", () => {
    const decision = selectEvidence({
      candidates: POLICIES,
      customer,
      businessTime: "2027-06-01T00:00:00.000Z",
      policy: "validity-first-v2",
      limit: 1,
    });
    expect(decision.selected).toHaveLength(0);
    expect(decision.excluded.map((item) => item.id)).toEqual(["P-old", "P-current"]);
  });

  it("缺少客户条件时不能凭检索结果给折扣依据", () => {
    const decision = selectEvidence({
      candidates: POLICIES,
      customer: null,
      businessTime,
      policy: "validity-first-v2",
      limit: 1,
    });
    expect(decision.selected).toHaveLength(0);
    // 过期判定优先，其次才是缺少客户条件：两条排除各有各的原因。
    expect(decision.excluded.find((item) => item.id === "P-current")?.reason).toContain("缺少客户条件");
    expect(decision.excluded.find((item) => item.id === "P-old")?.reason).toContain("不覆盖业务时间");
  });
});
