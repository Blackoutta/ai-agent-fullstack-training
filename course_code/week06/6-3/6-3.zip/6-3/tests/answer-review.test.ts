import { describe, expect, it } from "vitest";
import { reviewAnswer } from "../src/answer-review.js";
import { createRunState } from "../src/run-state.js";
import { CUSTOMERS, POLICIES, SERVICES } from "../src/data.js";
import { NULL_TRACE, type EvidenceDecision, type SalesRun } from "../src/sales-types.js";

const run: SalesRun = {
  runId: "run-review",
  requestId: "req-review",
  question: "最高能享受多少折扣？",
  customerId: "C-1001",
  salesId: "S-77",
  tenantId: "tenant-demo",
  businessTime: "2026-11-05T09:00:00.000Z",
  promptVersion: "sales-answer-2026.2",
  promptHash: "test-hash",
  evidencePolicy: "relevance-first-v1",
  trace: NULL_TRACE,
};

function stateWith(selectedIds: string[], withServices = true) {
  const state = createRunState();
  const pick = (id: string) => POLICIES.find((policy) => policy.id === id)!;
  const decision: EvidenceDecision = {
    policy: run.evidencePolicy,
    businessTime: run.businessTime,
    limit: 1,
    selected: selectedIds.map(pick),
    excluded: POLICIES.filter((policy) => !selectedIds.includes(policy.id)).map((policy) => ({
      id: policy.id,
      reason: "测试排除",
    })),
    selectionRule: "relevance_top_1",
    validityCheckApplied: false,
    applicabilityCheckApplied: false,
  };
  state.evidence = decision;
  state.profile = CUSTOMERS["C-1001"]!;
  state.services = withServices ? SERVICES : null;
  return state;
}

describe("答案审阅", () => {
  it("引用过期政策时不通过，即使数字与引用都对得上", () => {
    const review = reviewAnswer("最高可以优惠 15%，依据 P-old（policy-2025.3）。驻场支持需另签服务方案。", stateWith(["P-old"]), run);
    expect(review.passed).toBe(false);
    expect(review.disposition).toBe("recheck");
    expect(review.findings.find((item) => item.check === "引用政策在业务时间有效")?.passed).toBe(false);
  });

  it("引用当前政策且数字正确时通过", () => {
    const review = reviewAnswer("当前最高 10% 折扣，即最低九折，依据 P-current（policy-2026.1）。标准服务不含驻场，驻场需另签服务方案（catalog-2026.1）。", stateWith(["P-current"]), run);
    expect(review.passed).toBe(true);
    expect(review.disposition).toBe("return");
  });

  it("没有可用证据时标记无法确认，不给出折扣数字", () => {
    const review = reviewAnswer("目前无法确认折扣比例，需要补查政策。", stateWith([]), run);
    expect(review.disposition).toBe("unknown");
    expect(review.findings.find((item) => item.check === "有可用证据")?.passed).toBe(false);
  });

  it("回答出现证据以外的数字时不通过", () => {
    const review = reviewAnswer("最高可以优惠 20%，依据 P-current。驻场需另签方案。", stateWith(["P-current"]), run);
    expect(review.passed).toBe(false);
    expect(review.findings.find((item) => item.check === "折扣数字有有效依据")?.passed).toBe(false);
  });

  it("回答把驻场说成包含在标准服务里时不通过", () => {
    const review = reviewAnswer("最高 10%，依据 P-current（policy-2026.1）。标准服务已经包含驻场支持。", stateWith(["P-current"]), run);
    expect(review.findings.find((item) => item.check === "服务范围陈述与目录一致")?.passed).toBe(false);
  });

  it("服务范围没有引用目录版本时不通过", () => {
    const review = reviewAnswer("当前最高 10% 折扣，依据 P-current（policy-2026.1）。标准服务不含驻场，驻场需另签服务方案。", stateWith(["P-current"]), run);
    expect(review.findings.find((item) => item.check === "服务范围陈述与目录一致")?.passed).toBe(false);
  });

  it("未取得服务目录时服务范围无法核对，不能算通过", () => {
    const review = reviewAnswer("最高 10%，依据 P-current。", stateWith(["P-current"], false), run);
    expect(review.findings.some((item) => !item.passed)).toBe(true);
  });
});
