import { describe, expect, it } from "vitest";
import { createRecordedCustomerApi, createRecordedKnowledgeBase, MaterialMismatch } from "../src/recorded-clients.js";
import type { ReplayBundle } from "../src/replay-bundle.js";
import { NULL_TRACE, type SalesRun } from "../src/sales-types.js";
import { POLICIES } from "../src/data.js";

const run: SalesRun = {
  runId: "replay-1",
  requestId: "req-1",
  question: "最高能享受多少折扣？",
  customerId: "C-1001",
  salesId: "S-77",
  tenantId: "tenant-demo",
  businessTime: "2026-11-05T09:00:00.000Z",
  promptVersion: "sales-answer-2026.2",
  promptHash: "test-hash",
  evidencePolicy: "validity-first-v2",
  replayOf: "run-original",
  trace: NULL_TRACE,
};

function customerBody(name: string) {
  return {
    customer_id: "C-1001",
    name,
    industry: "制造",
    region: "华东",
    products: ["数据平台标准版"],
    contract_tier: "gold",
  };
}

function bundleWith(rawResults: ReplayBundle["rawResults"]): ReplayBundle {
  return {
    originalRunId: "run-original",
    dir: "replays/run-original",
    input: {
      question: run.question,
      customerId: "C-1001",
      salesId: "S-77",
      tenantId: "tenant-demo",
      businessTime: run.businessTime,
      promptVersion: run.promptVersion,
      evidencePolicy: "relevance-first-v1",
    },
    versions: {
      prompt_version: run.promptVersion,
      prompt_hash: "hash",
      model_alias: "deepseek-flash",
      evidence_policy: "relevance-first-v1",
      crm_schema: "crm-profile-v1",
      kb_schema: "kb-policy-search-v2",
      catalog_schema: "catalog-service-v1",
      authz_policy_version: "authz-sales-scope-2026.1",
      knowledge_version: "kb-docs-2026.11",
    },
    failure: {
      run_id: "run-original",
      trace_id: "trace-original",
      answer: "15%",
      cited: ["P-old@policy-2025.3"],
      review: { passed: false, disposition: "recheck", failed_checks: ["引用政策在业务时间有效"] },
    },
    acceptance: {
      discount_percent: 10,
      forbidden_discount_percent: 15,
      required_policy: "P-current",
      required_service_version: "catalog-2026.1",
      onsite_in_standard_service: false,
    },
    state: { tool_calls: [], evidence: null, candidates: POLICIES, final_answer: "15%" },
    rawResults,
    contextMessages: [],
    integrity: { files: [], broken: [], complete: true },
  };
}

describe("录制结果客户端", () => {
  it("按接口与参数匹配返回归档数据", async () => {
    const kb = createRecordedKnowledgeBase(
      bundleWith([
        {
          interface: "kb.search_sales_policy",
          schemaVersion: "kb-policy-search-v2",
          params: { customerId: "C-1001", keyword: "折扣", businessTime: run.businessTime },
          status: 200,
          body: { candidates: POLICIES },
          ref: "run-original/raw-results/a.json",
        },
      ]),
    );
    const outcome = await kb.searchPolicies(run, { customerId: "C-1001", keyword: "折扣", businessTime: run.businessTime });
    expect(outcome.ok).toBe(true);
    expect(outcome.body?.map((item) => item.id)).toEqual(["P-old", "P-current"]);
    expect(outcome.rawRef).toContain("raw-results");
  });

  it("参数不一致时报材料不匹配，不退回去取一条旧数据", async () => {
    const kb = createRecordedKnowledgeBase(
      bundleWith([
        {
          interface: "kb.search_sales_policy",
          schemaVersion: "kb-policy-search-v2",
          params: { customerId: "C-1001", keyword: "折扣", businessTime: run.businessTime },
          status: 200,
          body: { candidates: POLICIES },
          ref: "a",
        },
      ]),
    );
    await expect(
      kb.searchPolicies(run, { customerId: "C-1001", keyword: "价格", businessTime: run.businessTime }),
    ).rejects.toThrow(MaterialMismatch);
  });

  it("同参数多次调用按次序区分各次结果", async () => {
    const params = { customerId: "C-1001" };
    const api = createRecordedCustomerApi(
      bundleWith([
        { interface: "crm.get_customer_profile", schemaVersion: "crm-profile-v1", params, status: 200, body: customerBody("第一次"), ref: "a" },
        { interface: "crm.get_customer_profile", schemaVersion: "crm-profile-v1", params, status: 200, body: customerBody("第二次"), ref: "b" },
      ]),
    );
    expect((await api.getProfile(run, "C-1001")).body).toMatchObject({ name: "第一次" });
    expect((await api.getProfile(run, "C-1001")).body).toMatchObject({ name: "第二次" });
    await expect(api.getProfile(run, "C-1001")).rejects.toThrow(/replay_coverage_missing/);
  });

  it("读历史资料仍执行当前授权，越权客户直接拒绝", async () => {
    const api = createRecordedCustomerApi(bundleWith([]));
    expect(await api.canReadCustomer(run, "C-1001")).toBe(true);
    expect(await api.canReadCustomer(run, "C-9002")).toBe(false);
    expect(await api.canReadCustomer({ ...run, salesId: "S-unknown" }, "C-1001")).toBe(false);
  });

  it("归档状态码非 2xx 时按失败返回，不伪装成功", async () => {
    const api = createRecordedCustomerApi(
      bundleWith([
        {
          interface: "crm.get_customer_profile",
          schemaVersion: "crm-profile-v1",
          params: { customerId: "C-1001" },
          status: 404,
          body: { error: "customer_not_found" },
          ref: "a",
        },
      ]),
    );
    const outcome = await api.getProfile(run, "C-1001");
    expect(outcome.ok).toBe(false);
    expect(outcome.status).toBe(404);
  });
});
