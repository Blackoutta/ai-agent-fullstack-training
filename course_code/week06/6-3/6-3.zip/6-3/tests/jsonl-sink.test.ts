import { mkdtemp, mkdir, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { describe, expect, it } from "vitest";
import { createJsonlSink } from "../src/jsonl-sink.js";
import { readJsonl, summarizeMetrics, summarizeUsage } from "../src/log-query.js";
import type { LogRecord } from "../src/sales-types.js";

/** 关联字段由后端带入，测试里用同一个基准补齐。 */
function rec(data: Record<string, unknown>): LogRecord {
  return { timestamp: new Date().toISOString(), service: "sales-agent-test", run_id: "r-1", request_id: "req-1", ...data };
}

async function tempFile(): Promise<string> {
  const dir = await mkdtemp(join(tmpdir(), "agent-log-"));
  return join(dir, "agent-test.jsonl");
}

describe("JSONL 写入器", () => {
  it("按顺序追加，flush 之后可以被读回", async () => {
    const file = await tempFile();
    const sink = await createJsonlSink(file);
    for (let index = 0; index < 5; index++) sink.write(rec({ seq: index }));
    await sink.flush();

    const log = await readJsonl(file);
    expect(log.records.map((record) => record.seq)).toEqual([0, 1, 2, 3, 4]);
    expect(sink.stats().written).toBe(5);
    expect(sink.stats().dropped).toBe(0);
    expect(sink.stats().write_error).toBeNull();
  });

  it("待写条数超上限时丢弃并计数，flush 明确报告", async () => {
    const file = await tempFile();
    const sink = await createJsonlSink(file, 2);
    for (let index = 0; index < 10; index++) sink.write(rec({ seq: index }));
    await expect(sink.flush()).rejects.toThrow(/agent_log_dropped:/);
    expect(sink.stats().dropped).toBeGreaterThan(0);
  });

  it("写入失败不静默吞掉，错误状态在 flush 时报告", async () => {
    const dir = await mkdtemp(join(tmpdir(), "agent-log-"));
    const blocked = join(dir, "blocked.jsonl");
    // 目标路径占一个目录，追加必然失败。
    await mkdir(blocked, { recursive: true });
    const sink = await createJsonlSink(blocked);
    sink.write(rec({ seq: 0 }));
    await expect(sink.flush()).rejects.toThrow();
    expect(sink.stats().write_error).toBeTruthy();
    await rm(blocked, { recursive: true, force: true });
  });

  it("不同进程的日志文件互不影响", async () => {
    const first = await tempFile();
    const second = await tempFile();
    const sinkA = await createJsonlSink(first);
    const sinkB = await createJsonlSink(second);
    sinkA.write(rec({ run_id: "run-a" }));
    sinkB.write(rec({ run_id: "run-b" }));
    await Promise.all([sinkA.flush(), sinkB.flush()]);
    expect((await readJsonl(first)).records.every((record) => record.run_id === "run-a")).toBe(true);
    expect((await readJsonl(second)).records.every((record) => record.run_id === "run-b")).toBe(true);
  });
});

describe("日志读取与汇总", () => {
  it("损坏行报告文件和行号并停止读取，不静默跳过", async () => {
    const file = await tempFile();
    const sink = await createJsonlSink(file);
    sink.write(rec({ event: "a" }));
    await sink.flush();
    const original = await readFile(file, "utf8");
    await import("node:fs/promises").then(({ writeFile }) => writeFile(file, `${original}{{坏行\n`, "utf8"));
    await expect(readJsonl(file)).rejects.toThrow(/invalid_log_json:.*:2/);
  });

  it("用量汇总把失败与重试的调用一并计入，且只按本地记录算一次", () => {
    const summary = summarizeUsage([
      { event: "model.message.completed", input_tokens: 100, output_tokens: 20, total_tokens: 120, cost_usd: 0.001, stop_reason: "stop" },
      { event: "model.message.completed", input_tokens: 50, output_tokens: 10, total_tokens: 60, cost_usd: 0.0005, stop_reason: "error", error_reason: "rate_limited" },
      { event: "tool.call.finished", outcome: "success" },
    ]);
    expect(summary.model_calls).toBe(2);
    expect(summary.input_tokens).toBe(150);
    expect(summary.total_tokens).toBe(180);
    expect(summary.abnormal_stop).toBe(1);
    expect(summary.error_messages).toBe(1);
    expect(summary.cost_source).toBe("pi_sdk_price_table");
    expect(summary.usage_unknown_calls).toBe(0);
    expect(summary.cost_unknown_calls).toBe(0);
  });

  it("缺失用量时保留未知计数，不把缺失值填成零", () => {
    const summary = summarizeUsage([
      {
        event: "model.message.completed",
        usage_source: "unknown",
        input_tokens: null,
        output_tokens: null,
        total_tokens: null,
        cost_usd: null,
        stop_reason: "stop",
      },
    ]);
    expect(summary.input_tokens).toBe(0);
    expect(summary.usage_unknown_calls).toBe(1);
    expect(summary.cost_unknown_calls).toBe(1);
    expect(summary.cost_source).toBe("unknown");
  });

  it("错误率与分位耗时把失败调用一并计入", () => {
    const metrics = summarizeMetrics([
      { run_id: "a", event: "tool.call.finished", outcome: "success", execution_ms: 10 },
      { run_id: "a", event: "tool.call.finished", outcome: "failure", execution_ms: 5003 },
      { run_id: "a", event: "tool.call.finished", outcome: "success", execution_ms: 20 },
      { run_id: "a", event: "customer.http_request", outcome: "success" },
      { run_id: "a", event: "policy.http_request", outcome: "failure" },
      { run_id: "a", event: "answer.review", outcome: "failure" },
    ]);
    expect(metrics.tool_calls).toBe(3);
    expect(metrics.tool_failures).toBe(1);
    expect(metrics.tool_error_rate).toBeCloseTo(0.333, 3);
    expect(metrics.http_requests).toBe(2);
    expect(metrics.http_error_rate).toBe(0.5);
    expect(metrics.p50_tool_ms).toBe(20);
    expect(metrics.max_tool_ms).toBe(5003);
    expect(metrics.reviews_failed).toBe(1);
  });
});
