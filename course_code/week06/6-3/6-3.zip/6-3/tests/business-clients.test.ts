import { mkdtemp, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { createArchiveStore, type ArchiveStore } from "../src/archive.js";
import { createCustomerApi, createKnowledgeBase, decodePolicyCandidates, decodeProfile, decodeServiceItems } from "../src/clients.js";
import { startMockServices, type MockServices } from "../src/mock-services.js";
import { NULL_TRACE, type SalesRun } from "../src/sales-types.js";

const run: SalesRun = {
  runId: "run-http-test",
  requestId: "req-http-test",
  question: "最高能享受多少折扣？",
  customerId: "C-1001",
  salesId: "S-77",
  tenantId: "tenant-demo",
  businessTime: "2026-11-05T09:00:00.000Z",
  promptVersion: "sales-answer-2026.2",
  promptHash: "test-hash",
  evidencePolicy: "relevance-first-v1",
  trace: NULL_TRACE,
};

let services: MockServices;
let archive: ArchiveStore;
let tempDir: string;

beforeAll(async () => {
  services = await startMockServices("127.0.0.1", 8799);
  tempDir = await mkdtemp(join(tmpdir(), "sales-archive-"));
  archive = await createArchiveStore(tempDir);
});

afterAll(async () => {
  await services.close();
  await rm(tempDir, { recursive: true, force: true });
});

function client(timeoutMs = 2000) {
  const common = { baseUrl: services.baseUrl, timeoutMs, archive, authzPolicyVersion: "authz-sales-scope-2026.1" };
  return {
    customer: createCustomerApi({ ...common, schemaVersion: "crm-profile-v1" }),
    kb: createKnowledgeBase({ ...common, schemaVersion: "kb-policy-search-v2" }),
  };
}

describe("真实 HTTP 业务客户端", () => {
  it("成功请求返回状态码、耗时和可回读的归档引用", async () => {
    const { customer } = client();
    const outcome = await customer.getProfile(run, "C-1001");
    expect(outcome.ok).toBe(true);
    expect(outcome.status).toBe(200);
    expect(outcome.durationMs).toBeGreaterThan(0);
    expect(outcome.rawRef).toBeTruthy();
    // 接口原始返回留在归档里，进入模型的字段已经按白名单收窄。
    expect(outcome.body?.contract_tier).toBe("");
    const archived = JSON.parse(await readFile(join(tempDir, outcome.rawRef!), "utf8")) as { body: unknown };
    expect(archived.body).toMatchObject({ customer_id: "C-1001", contract_tier: "gold" });
  });

  it("授权检查按后端认证结果与业务范围判断，不看模型填的身份", async () => {
    const { customer } = client();
    expect(await customer.canReadCustomer(run, "C-1001")).toBe(true);
    expect(await customer.canReadCustomer(run, "C-9002")).toBe(false);
    expect(await customer.canReadCustomer(run, "C-不存在")).toBe(false);
  });

  it("超时时状态码为空，但耗时和错误类型保留", async () => {
    const { customer } = client(400);
    const outcome = await customer.getProfile(run, "C-7003");
    expect(outcome.ok).toBe(false);
    expect(outcome.status).toBeNull();
    expect(outcome.errorType).toBeTruthy();
    expect(outcome.durationMs).toBeGreaterThanOrEqual(350);
  });

  it("知识库返回候选里新旧两版都在，并原样归档", async () => {
    const { kb } = client();
    const outcome = await kb.searchPolicies(run, {
      customerId: "C-1001",
      keyword: "折扣",
      businessTime: run.businessTime,
    });
    expect(outcome.ok).toBe(true);
    expect(outcome.body?.map((item) => item.id)).toEqual(["P-old", "P-current"]);
    // 查询条件必须真的发到接口，而不是只写在日志里。
    expect(services.requests.at(-1)?.path).toContain("/api/policies/search?customer_id=C-1001");
    expect(services.requests.at(-1)?.path).toContain("keyword=" + encodeURIComponent("折扣"));
    expect(services.requests.at(-1)?.path).toContain("business_time=" + encodeURIComponent(run.businessTime));
    const archived = JSON.parse(await readFile(join(tempDir, outcome.rawRef!), "utf8")) as {
      body: { candidates: Array<{ id: string }> };
    };
    expect(archived.body.candidates.map((item) => item.id)).toEqual(["P-old", "P-current"]);
  });

  it("缺少服务令牌时接口拒绝，不会返回客户资料", async () => {
    const response = await fetch(`${services.baseUrl}/api/customers/C-1001`);
    expect(response.status).toBe(401);
  });

  it("接口结果被工具访问过后，服务端有对应的请求记录", async () => {
    const before = services.requests.length;
    await client().customer.getProfile(run, "C-1001");
    expect(services.requests.length).toBeGreaterThan(before);
    expect(services.requests.at(-1)?.path).toBe("/api/customers/C-1001");
  });
});

describe("客户资料字段控制", () => {
  it("只提取允许进入模型上下文的字段", () => {
    const profile = decodeProfile(
      { customer_id: "C-1001", name: "华东精密制造", industry: "制造", region: "华东", products: ["数据平台标准版"], contract_tier: "gold" },
      "C-1001",
    );
    expect(profile).toEqual({
      customer_id: "C-1001",
      name: "华东精密制造",
      industry: "制造",
      region: "华东",
      products: ["数据平台标准版"],
      contract_tier: "",
    });
  });

  it("返回结构不完整时报错，不返回编造的资料", () => {
    expect(() => decodeProfile({ customer_id: "C-1001" }, "C-1001")).toThrow(/profile_field_missing/);
    expect(() => decodeProfile(null, "C-1001")).toThrow(/profile_shape_invalid/);
  });
});

describe("知识库与服务目录返回结构校验", () => {
  it("候选字段缺失时整批按失败处理", () => {
    expect(() => decodePolicyCandidates({ candidates: [{ id: "P-only" }] })).toThrow(/policy_candidate_field_missing/);
    expect(() => decodePolicyCandidates({})).toThrow(/response_field_missing:candidates/);
  });

  it("驻场支持字段不是布尔值时按失败处理", () => {
    expect(() =>
      decodeServiceItems({
        items: [{ productId: "数据平台标准版", includesOnsiteSupport: "false", onsiteCondition: "另签", remoteSupport: "5x8", version: "v1" }],
      }),
    ).toThrow(/service_item_field_missing/);
  });
});

describe("归档完整性", () => {
  it("写入后长度校验，损坏文件会被列出来", async () => {
    const ref = await archive.put("run-check", "raw-results", { ok: true });
    const { verifyArchive } = await import("../src/archive.js");
    const result = await verifyArchive(tempDir, "run-check");
    expect(result.files).toContain(ref);
    expect(result.broken).toHaveLength(0);

    const { writeFile } = await import("node:fs/promises");
    await writeFile(join(tempDir, ref), "{坏JSON", "utf8");
    const after = await verifyArchive(tempDir, "run-check");
    expect(after.broken).toContain(ref);
  });
});
