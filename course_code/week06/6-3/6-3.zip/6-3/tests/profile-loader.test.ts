import { describe, expect, it } from "vitest";
import { ensureCustomerProfile } from "../src/profile-loader.js";
import { createRunState } from "../src/run-state.js";
import { CUSTOMERS, type CustomerRecord } from "../src/data.js";
import { NULL_TRACE, type BusinessTracer, type CustomerApi, type SalesAudit, type SalesRun } from "../src/sales-types.js";

const run: SalesRun = {
  runId: "run-profile",
  requestId: "req-profile",
  question: "客户 C-1001 当前最高能享受多少折扣？",
  customerId: "C-1001",
  salesId: "S-77",
  tenantId: "tenant-demo",
  businessTime: "2026-11-06T09:00:00.000Z",
  promptVersion: "sales-answer-2026.2",
  promptHash: "test-hash",
  evidencePolicy: "validity-first-v2",
  trace: NULL_TRACE,
};

const tracer: BusinessTracer = { start: () => ({ end: () => {} }) };

function fakeApi(options: { allow?: boolean; profile?: CustomerRecord } = {}) {
  const counters = { authz: 0, profile: 0 };
  const api: CustomerApi = {
    source: "crm",
    authzPolicyVersion: "authz-test",
    schemaVersion: "crm-profile-v1",
    async canReadCustomer() {
      counters.authz += 1;
      return options.allow ?? true;
    },
    async getProfile() {
      counters.profile += 1;
      return {
        ok: true,
        status: 200,
        body: options.profile ?? CUSTOMERS["C-1001"]!,
        durationMs: 5,
        errorType: null,
        method: "GET",
        path: "/api/customers/C-1001",
        rawRef: "ref",
      };
    },
  };
  return { api, counters };
}

describe("客户资料加载", () => {
  it("并行调用只查一次 CRM，授权与 HTTP 记录各一条", async () => {
    const state = createRunState();
    const { api, counters } = fakeApi();
    const events: SalesAudit[] = [];
    const deps = { customerApi: api, tracer, emit: (audit: SalesAudit) => events.push(audit) };

    const [first, second] = await Promise.all([
      ensureCustomerProfile(run, deps, state, "C-1001", "call-1"),
      ensureCustomerProfile(run, deps, state, "C-1001", "call-2"),
    ]);

    expect(first.customer_id).toBe("C-1001");
    expect(second.customer_id).toBe("C-1001");
    expect(counters.authz).toBe(1);
    expect(counters.profile).toBe(1);
    expect(events.filter((event) => event.action === "customer.authorization")).toHaveLength(1);
    expect(events.filter((event) => event.action === "customer.http_request")).toHaveLength(1);
    expect(state.profileCustomerId).toBe("C-1001");
  });

  it("授权拒绝时结束查询，不请求 CRM", async () => {
    const state = createRunState();
    const { api, counters } = fakeApi({ allow: false });
    const events: SalesAudit[] = [];
    const deps = { customerApi: api, tracer, emit: (audit: SalesAudit) => events.push(audit) };

    await expect(ensureCustomerProfile(run, deps, state, "C-9002", "call-deny")).rejects.toThrow(/customer_access_denied/);
    expect(counters.profile).toBe(0);
    expect(events.find((event) => event.action === "customer.authorization")?.authorization).toBe("deny");
    expect(state.profile).toBeNull();
  });

  it("查询非本次目标客户时不覆盖共享客户条件", async () => {
    const state = createRunState();
    const { api } = fakeApi({ profile: CUSTOMERS["C-9002"]! });
    const deps = { customerApi: api, tracer, emit: () => {} };

    await ensureCustomerProfile(run, deps, state, "C-9002", "call-other");
    expect(state.profile).toBeNull();
  });
});
