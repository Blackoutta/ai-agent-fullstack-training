import { answerSalesQuestion } from "./src/runner.js";
import { startRuntime, SCHEMA_VERSIONS, type DemoRuntime } from "./src/runtime.js";
import { readJsonl, selectByRun } from "./src/log-query.js";
import { selectEvidence } from "./src/evidence.js";
import { bundleProfile, bundleServiceItems, loadBundle, type ReplayBundle } from "./src/replay-bundle.js";
import {
  createRecordedCustomerApi,
  createRecordedKnowledgeBase,
  createRecordedServiceCatalog,
  MaterialMismatch,
} from "./src/recorded-clients.js";
import { buildSalesPrompt } from "./src/prompt.js";
import type { EvidencePolicyName, SalesAnswer } from "./src/sales-types.js";

/**
 * 重跑一份已保存的 replay 材料：replays/<run-id>/。
 *
 * 与 3.ts 的区别：不现场制造失败、不写回归集，只把归档材料交给当前代码，
 * 先用归档策略复现原判断，再用修复后的策略验证能否满足 acceptance.json。
 *
 * 退出码：0 通过｜1 参数或材料、版本问题｜2 验收未通过｜3 材料不匹配。
 */
const runId = process.argv[2];
if (!runId) {
  console.error("用法：npm run replay -- <run-id>（材料在 replays/<run-id>/）");
  process.exit(1);
}

const runtime = await startRuntime();

const bundle = await loadBundle(runtime.replayRoot, runId).catch(async (error: unknown) => {
  console.error(`读不到复现材料 replays/${runId}/：${(error as Error).message}`);
  await closeQuietly();
  process.exit(1);
});

console.log(`Replay · ${runId}`);
console.log(
  `  材料：文件 ${bundle.integrity.files.length}｜损坏 ${bundle.integrity.broken.length}｜可完整重放=${bundle.integrity.complete ? "是" : "否"}`,
);
if (!bundle.integrity.complete) {
  console.error("  归档缺少原始候选或存在损坏文件，不能声明重放结果。");
  await closeQuietly();
  process.exit(1);
}

// 除了本次要验证的 evidence_policy，其余版本必须与归档一致，否则不是同一组条件。
const prompt = tryBuildPrompt(bundle.input.promptVersion);
const versionRows: Array<[string, string, string]> = [
  ["prompt_version", bundle.versions.prompt_version, prompt.version],
  ["prompt_hash", bundle.versions.prompt_hash, prompt.contentHash],
  ["model_alias", bundle.versions.model_alias, runtime.model.model.id],
  ["crm_schema", bundle.versions.crm_schema, SCHEMA_VERSIONS.crm],
  ["kb_schema", bundle.versions.kb_schema, SCHEMA_VERSIONS.kb],
  ["catalog_schema", bundle.versions.catalog_schema, SCHEMA_VERSIONS.catalog],
  ["authz_policy_version", bundle.versions.authz_policy_version, SCHEMA_VERSIONS.authz],
  ["knowledge_version", bundle.versions.knowledge_version, SCHEMA_VERSIONS.knowledge],
];
const drifted = versionRows.filter(([, recorded, current]) => recorded !== current);
console.log(
  `  版本：${versionRows.length - drifted.length}/${versionRows.length} 项一致｜evidence_policy ${bundle.versions.evidence_policy} → validity-first-v2（本次要验证的改动）`,
);
if (drifted.length) {
  console.error(`  版本不一致：${drifted.map(([name, recorded, current]) => `${name} ${recorded}→${current}`).join("；")}`);
  console.error("  条件已经变了，这次重跑不能当作同一组材料的结论。");
  await closeQuietly();
  process.exit(1);
}

const businessTime = bundle.input.businessTime;
const customer = bundleProfile(bundle);
const requiredPolicy = bundle.acceptance.required_policy;
const serviceVersion = bundleServiceItems(bundle)[0]?.version ?? bundle.acceptance.required_service_version;
const currentPolicy = bundle.state.candidates.find((item) => item.id === requiredPolicy);

// 第一层：归档策略应当复现原判断；修复后的策略应当选出验收要求的政策。
const asRecorded = selectEvidence({
  candidates: bundle.state.candidates,
  customer,
  businessTime,
  policy: bundle.versions.evidence_policy as EvidencePolicyName,
  limit: bundle.state.evidence?.limit ?? 1,
});
const fixed = selectEvidence({
  candidates: bundle.state.candidates,
  customer,
  businessTime,
  policy: "validity-first-v2",
  limit: 1,
});
const recordedSelected = bundle.state.evidence?.selected.map((item) => item.id) ?? [];
const reproduced = asRecorded.selected.map((item) => item.id).join("/") === recordedSelected.join("/");
const policyFixed = fixed.selected.map((item) => item.id).join("/") === requiredPolicy;
console.log(
  `  第一层：归档策略选中 ${asRecorded.selected.map((item) => item.id).join("/") || "无"}（原记录 ${recordedSelected.join("/") || "无"}）→ ${
    reproduced ? "原判断已复现" : "与原记录不一致"
  }`,
);
console.log(
  `          修复后选中 ${fixed.selected.map((item) => item.id).join("/") || "无"}（要求 ${requiredPolicy}）→ ${
    policyFixed ? "符合验收" : "不符合验收"
  }`,
);

// 第二层：录制依赖 + 同一个 pi SDK 入口，由模型重新生成答案。
const requestsBefore = runtime.services.requests.length;
const result = await replayOnce(runtime, bundle).catch(handleReplayError);
const requestsDuring = runtime.services.requests.length - requestsBefore;
await runtime.sink.flush();

const records = selectByRun((await readJsonl(runtime.logFile)).records, result.runId);
const snapshotRecord = [...records]
  .filter((record) => record.event === "context.snapshot" && record.phase === "provider_request")
  .at(-1);
const snapshot = snapshotRecord?.raw_ref ? await runtime.archive.read(String(snapshotRecord.raw_ref)) : "";
const evidenceRecord = records.find((record) => record.event === "evidence.selection");
const selectedIds = (evidenceRecord?.selected_ids as string[] | undefined) ?? [];
const text = result.answer.text;

const checks: Array<[string, boolean, string]> = [
  ["证据筛选保留当前政策", selectedIds.includes(requiredPolicy), `选中 ${selectedIds.join("/") || "无"}`],
  [
    "模型输入包含当前政策与有效期",
    snapshot.includes(requiredPolicy) &&
      Boolean(currentPolicy && snapshot.includes(currentPolicy.validFrom) && snapshot.includes(currentPolicy.validUntil)),
    `${currentPolicy?.validFrom ?? "?"}~${currentPolicy?.validUntil ?? "?"}`,
  ],
  [
    `折扣为 ${bundle.acceptance.discount_percent}%，且不出现 ${bundle.acceptance.forbidden_discount_percent}%`,
    percentHit(text, bundle.acceptance.discount_percent) && !percentHit(text, bundle.acceptance.forbidden_discount_percent),
    `回答中的折扣 ${extractPercent(text)}`,
  ],
  ["说明标准服务不含驻场支持", onsiteBasis(text) === "说明驻场需另签", onsiteBasis(text)],
  [
    "引用政策与服务目录",
    text.includes(requiredPolicy) && text.includes(serviceVersion),
    `${text.includes(requiredPolicy) ? requiredPolicy : "未引用政策"}｜${text.includes(serviceVersion) ? serviceVersion : "未引用服务目录"}`,
  ],
  ["答案审阅通过", result.answer.review?.passed === true, describeReview(result.answer)],
];

console.log(`  第二层：${result.runId}（replay_of=${bundle.originalRunId}，期间真实接口新增请求 ${requestsDuring} 次）`);
for (const [name, passed, detail] of checks) {
  console.log(`    ${passed ? "通过" : "未通过"}  ${name}｜${detail}`);
}

const layer1Passed = reproduced && policyFixed;
const layer2Passed = checks.every(([, passed]) => passed);
console.log(`  结论：${layer1Passed && layer2Passed ? "通过" : "未通过"}（第一层 ${layer1Passed ? "通过" : "未通过"}｜第二层 ${layer2Passed ? "通过" : "未通过"}）`);
console.log(`  回答：${text.slice(0, 120).replace(/\n/g, " ")}…`);
console.log(`  新日志：${runtime.logFile}（按运行编号 ${result.runId} 筛选）`);

await runtime.close();
process.exit(layer1Passed && layer2Passed ? 0 : 2);

/** 用录制依赖重跑同一个 pi SDK 入口；材料匹配不上就抛 MaterialMismatch，绝不回退真实接口。 */
async function replayOnce(current: DemoRuntime, data: ReplayBundle): Promise<{ runId: string; answer: SalesAnswer }> {
  const started = await current.beginRun(
    {
      question: data.input.question,
      customerId: data.input.customerId,
      salesId: data.input.salesId,
      businessTime: data.input.businessTime,
      promptVersion: data.input.promptVersion,
      evidencePolicy: "validity-first-v2",
      replayOf: data.originalRunId,
      label: "replay-once",
    },
    {
      customerApi: createRecordedCustomerApi(data),
      knowledgeBase: createRecordedKnowledgeBase(data),
      serviceCatalog: createRecordedServiceCatalog(data),
    },
  );
  try {
    const answer = await answerSalesQuestion(started.run, started.deps);
    await started.host.end({ final_answer: answer.text, replay_of: data.originalRunId });
    return { runId: started.run.runId, answer };
  } catch (error) {
    await started.host.end({ error: String((error as Error).message) });
    throw error;
  }
}

async function handleReplayError(error: unknown): Promise<never> {
  if (error instanceof MaterialMismatch) {
    console.error(`  材料不匹配，停止重放：${error.message.slice(0, 240)}`);
    console.error("  没有访问真实接口；要补材料，必须重新采集并重新声明条件。");
    await closeQuietly();
    process.exit(3);
  }
  await closeQuietly();
  console.error(`  重放失败：${String((error as Error).message)}`);
  process.exit(1);
}

/** 失败路径先刷新日志再关服务；刷新失败只提示，不掩盖原始错误。 */
async function closeQuietly(): Promise<void> {
  await runtime.close().catch((error: unknown) => console.error(`  日志刷新失败：${String((error as Error).message)}`));
}

function tryBuildPrompt(version: string): { version: string; contentHash: string } {
  // 归档里的 Prompt 版本可能已经改名或删除；这时只报不一致，不让重放直接崩掉。
  try {
    const built = buildSalesPrompt(version);
    return { version: built.version, contentHash: built.contentHash };
  } catch {
    return { version: "unknown", contentHash: "unknown" };
  }
}

function percentHit(text: string, percent: number): boolean {
  return new RegExp(`${percent}\\s*%`).test(text);
}

function extractPercent(text: string): string {
  const values = [...new Set([...text.matchAll(/(\d+(?:\.\d+)?)\s*%/g)].map((match) => match[1]!))];
  return values.join("/") || "无";
}

function onsiteBasis(text: string): string {
  if (!text.includes("驻场")) return "未提到驻场";
  return /另签|另行|需额外|不包含|不含|不在标准服务|标准服务不含/.test(text) ? "说明驻场需另签" : "未说明驻场条件";
}

function describeReview(answer: SalesAnswer): string {
  if (!answer.review) return "未执行";
  return `${answer.review.passed ? "通过" : "未通过"}｜${answer.review.disposition}`;
}
