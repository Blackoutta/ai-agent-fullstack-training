import { randomUUID } from "node:crypto";
import { mkdir } from "node:fs/promises";
import { join, resolve } from "node:path";
import { loadLocalEnv, optional, port } from "./env.js";
import { createArchiveStore, type ArchiveStore } from "./archive.js";
import { createJsonlSink } from "./jsonl-sink.js";
import { createModelSetup, type ModelSetup } from "./model.js";
import { startMockServices, type MockServices } from "./mock-services.js";
import { createCustomerApi, createKnowledgeBase, createServiceCatalog } from "./clients.js";
import { beginHostTrace, type HostTrace } from "./langfuse-host.js";
import type {
  CustomerApi,
  EvidencePolicyName,
  JsonLogSink,
  KnowledgeBase,
  SalesDependencies,
  SalesRun,
  ServiceCatalog,
} from "./sales-types.js";
import { DEFAULT_PROMPT_VERSION, buildSalesPrompt } from "./prompt.js";

export const SCHEMA_VERSIONS = {
  crm: "crm-profile-v1",
  kb: "kb-policy-search-v2",
  catalog: "catalog-service-v1",
  authz: "authz-sales-scope-2026.1",
  knowledge: "kb-docs-2026.11",
};

export interface ClientSet {
  customerApi: CustomerApi;
  knowledgeBase: KnowledgeBase;
  serviceCatalog: ServiceCatalog;
}

export interface RunInput {
  question: string;
  customerId: string;
  evidencePolicy: EvidencePolicyName;
  salesId?: string;
  promptVersion?: string;
  businessTime?: string;
  replayOf?: string;
  label?: string;
}

export interface DemoRuntime {
  root: string;
  logFile: string;
  replayRoot: string;
  reportDir: string;
  sink: JsonLogSink;
  archive: ArchiveStore;
  services: MockServices;
  model: ModelSetup;
  baseUrl: string;
  beginRun(input: RunInput, clients?: ClientSet): Promise<{ run: SalesRun; host: HostTrace; deps: SalesDependencies }>;
  realClients(): ClientSet;
  close(): Promise<void>;
}

/** 三个演示入口共用一套运行环境：真实 HTTP 依赖、DeepSeek 模型、本地文件日志和 Langfuse 父节点。 */
export async function startRuntime(): Promise<DemoRuntime> {
  loadLocalEnv();
  const root = process.cwd();
  const agentDirectory = resolve(root, ".runtime/agent");
  const resourceDirectory = resolve(root, ".runtime/workspace");
  await mkdir(agentDirectory, { recursive: true });
  await mkdir(resourceDirectory, { recursive: true });

  const logDir = resolve(root, optional("AGENT_LOG_DIR", "logs"));
  const replayRoot = resolve(root, optional("REPLAY_DIR", "replays"));
  const reportDir = resolve(root, optional("REPORT_DIR", "output"));
  await mkdir(logDir, { recursive: true });
  await mkdir(replayRoot, { recursive: true });
  await mkdir(reportDir, { recursive: true });

  const host = optional("MOCK_SERVICE_HOST", "127.0.0.1");
  const services = await startMockServices(host, port("MOCK_SERVICE_PORT", 8791));
  const model = await createModelSetup(agentDirectory);
  // 演示用固定业务时间：旧政策在 2025 年有效，当前政策在 2026 年有效。
  // 如果直接用系统时间，课程录到 2027 年时两版政策都会过期，缺陷就复现不出来。
  const demoBusinessTime = optional("DEMO_BUSINESS_TIME", "2026-11-06T09:00:00.000Z");
  const logFile = join(logDir, `agent-${process.pid}.jsonl`);
  const sink = await createJsonlSink(logFile);
  const archive = await createArchiveStore(replayRoot);
  const timeoutMs = port("CRM_TIMEOUT_MS", 5000);

  const realClients = (): ClientSet => {
    const common = {
      baseUrl: services.baseUrl,
      timeoutMs,
      archive,
      authzPolicyVersion: SCHEMA_VERSIONS.authz,
    };
    return {
      customerApi: createCustomerApi({ ...common, schemaVersion: SCHEMA_VERSIONS.crm }),
      knowledgeBase: createKnowledgeBase({ ...common, schemaVersion: SCHEMA_VERSIONS.kb }),
      serviceCatalog: createServiceCatalog({ ...common, schemaVersion: SCHEMA_VERSIONS.catalog }),
    };
  };

  return {
    root,
    logFile,
    replayRoot,
    reportDir,
    sink,
    archive,
    services,
    model,
    baseUrl: services.baseUrl,
    realClients,
    async beginRun(input, clients) {
      const stamp = new Date();
      const runId = `run-${stamp.toISOString().slice(0, 10).replaceAll("-", "")}-${randomUUID().slice(0, 8)}`;
      const requestId = `req-${randomUUID().slice(0, 12)}`;
      const salesId = input.salesId ?? "S-77";
      const prompt = buildSalesPrompt(input.promptVersion ?? DEFAULT_PROMPT_VERSION);
      const businessTime = input.businessTime ?? demoBusinessTime;
      const hostTrace = beginHostTrace({
        name: `sales.question.${input.evidencePolicy}`,
        input: {
          question: input.question,
          customer_id: input.customerId,
          business_time: businessTime,
          replay_of: input.replayOf ?? null,
          label: input.label ?? null,
        },
        sessionId: `sales-${randomUUID().slice(0, 8)}`,
        runId,
        requestId,
        userId: salesId,
        replayOf: input.replayOf,
        tags: [input.label ?? input.evidencePolicy, ...(input.replayOf ? ["replay"] : [])],
      });

      const run: SalesRun = {
        runId,
        requestId,
        question: input.question,
        customerId: input.customerId,
        salesId,
        tenantId: "tenant-demo",
        businessTime,
        promptVersion: prompt.version,
        promptHash: prompt.contentHash,
        evidencePolicy: input.evidencePolicy,
        replayOf: input.replayOf,
        trace: hostTrace.ref,
      };

      const use = clients ?? realClients();
      const deps: SalesDependencies = {
        modelRuntime: model.modelRuntime,
        model: model.model,
        resourceDirectory,
        agentDirectory,
        logSink: sink,
        archive,
        customerApi: use.customerApi,
        knowledgeBase: use.knowledgeBase,
        serviceCatalog: use.serviceCatalog,
        tracer: hostTrace.tracer,
      };
      return { run, host: hostTrace, deps };
    },
    async close() {
      await sink.flush().catch(async (error: unknown) => {
        console.error(`日志刷新失败：${String((error as Error).message)}`);
        throw error;
      });
      await services.close();
    },
  };
}
