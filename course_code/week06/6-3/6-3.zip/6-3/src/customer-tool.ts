import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
import { Type } from "typebox";
import { ensureCustomerProfile } from "./profile-loader.js";
import type { RunState } from "./run-state.js";
import type { BusinessTracer, CustomerApi, SalesAudit, SalesRun } from "./sales-types.js";

export interface CustomerToolDeps {
  customerApi: CustomerApi;
  tracer: BusinessTracer;
}

/**
 * get_customer_profile：接收客户编号，先校验当前销售的访问范围，
 * 再真实请求 CRM，并把授权决定与接口结果交给日志扩展。
 *
 * 授权、HTTP 与返回结构校验都在 ensureCustomerProfile 中完成；
 * 与政策工具共用同一份在途查询，避免并行调用时重复请求 CRM。
 */
export function createCustomerProfileToolExtension(run: SalesRun, deps: CustomerToolDeps, state: RunState) {
  return (pi: ExtensionAPI) => {
    const emit = (audit: SalesAudit) => pi.events.emit("sales:audit", audit);

    pi.registerTool({
      name: "get_customer_profile",
      label: "查询客户资料",
      description: "查询已授权客户的区域、行业与产品信息。参数 customer 是客户编号，例如 C-1001。",
      promptSnippet: "get_customer_profile 查询客户行业、区域与已购产品",
      promptGuidelines: ["回答折扣问题前必须先调用 get_customer_profile 确认客户条件。"],
      parameters: Type.Object({ customer: Type.String({ description: "客户编号" }) }),
      async execute(toolCallId, { customer }, signal) {
        const profile = await ensureCustomerProfile(
          run,
          { customerApi: deps.customerApi, tracer: deps.tracer, emit },
          state,
          customer,
          toolCallId,
          signal,
        );
        return {
          content: [{ type: "text" as const, text: JSON.stringify(profile) }],
          details: { customerId: customer, source: deps.customerApi.source, schemaVersion: deps.customerApi.schemaVersion },
        };
      },
    });
  };
}
