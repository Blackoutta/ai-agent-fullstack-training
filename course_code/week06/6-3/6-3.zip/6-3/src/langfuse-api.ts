export interface PlatformObservation {
  id: string;
  traceId: string;
  name: string | null;
  parentObservationId: string | null;
  type: string | null;
  level: string | null;
  startTime: string | null;
  endTime: string | null;
  latencyMs: number | null;
  userId: string | null;
  sessionId: string | null;
  isRoot: boolean;
  input: string;
  output: string;
  metadata: Record<string, unknown> | null;
}

export interface TraceTree {
  traceId: string;
  rootName: string | null;
  observations: PlatformObservation[];
  /** 按父子关系排好的展示行，depth 用于缩进。 */
  rows: Array<{ depth: number; observation: PlatformObservation }>;
  /** 平台侧没收到记录时为空，报告里要明确写出缺口。 */
  complete: boolean;
}

const API = "/api/public/v2/observations";

function baseUrl(): string {
  return (process.env.LANGFUSE_BASE_URL ?? "http://127.0.0.1:3000").replace(/\/$/, "");
}

/**
 * 浏览器打开界面用的地址，与 API 地址分开配置。
 *
 * Cookie 不跨 host 共享：在 localhost 登录、点 127.0.0.1 的链接会被当成未登录，
 * 所以这里的值必须和 config/langfuse.env 的 NEXTAUTH_URL 同源。
 */
export function langfuseUiUrl(): string {
  return (process.env.LANGFUSE_UI_URL ?? process.env.LANGFUSE_BASE_URL ?? "http://127.0.0.1:3000").replace(/\/$/, "");
}

/** 报告里给出的调用树链接，直接指向能打开的那一套界面。 */
export function traceLink(traceId: string): string {
  const projectId = process.env.LANGFUSE_PROJECT_ID ?? "proj-sales-agent-demo";
  return `${langfuseUiUrl()}/project/${projectId}/traces/${traceId}`;
}

function authHeader(): string {
  const publicKey = process.env.LANGFUSE_PUBLIC_KEY ?? "";
  const secretKey = process.env.LANGFUSE_SECRET_KEY ?? "";
  return `Basic ${Buffer.from(`${publicKey}:${secretKey}`).toString("base64")}`;
}

/**
 * 按运行编号读回平台侧调用树。
 *
 * Langfuse v4 默认是 events_only 部署，/api/public/traces 和 /api/public/observations 已关闭，
 * 这里用 v2 observations 接口取同一批记录，并用 fields 参数把输入输出带回来。
 */
export async function fetchTraceTree(traceId: string): Promise<TraceTree> {
  const path = `${API}?traceId=${encodeURIComponent(traceId)}&limit=100&fields=core,basic,io,metadata`;
  const response = await fetch(`${baseUrl()}${path}`, { headers: { Authorization: authHeader() } });
  if (!response.ok) {
    throw new Error(`langfuse_api_${response.status}:${API}`);
  }
  const page = (await response.json()) as { data?: Record<string, unknown>[] };
  const observations = (page.data ?? []).map(toObservation).filter((item) => item.traceId === traceId);
  return {
    traceId,
    rootName: observations.find((item) => item.isRoot)?.name ?? null,
    observations,
    rows: arrange(observations),
    complete: observations.length > 0,
  };
}

function toObservation(item: Record<string, unknown>): PlatformObservation {
  return {
    id: String(item.id ?? ""),
    traceId: String(item.traceId ?? ""),
    name: (item.name as string | null) ?? null,
    parentObservationId: (item.parentObservationId as string | null) ?? null,
    type: (item.type as string | null) ?? null,
    level: (item.level as string | null) ?? null,
    startTime: (item.startTime as string | null) ?? null,
    endTime: (item.endTime as string | null) ?? null,
    latencyMs: item.latency === undefined || item.latency === null ? null : Number(item.latency) * 1000,
    userId: (item.userId as string | null) ?? null,
    sessionId: (item.sessionId as string | null) ?? null,
    isRoot: Boolean(item.isRootObservation) || !item.parentObservationId,
    input: preview(item.input),
    output: preview(item.output),
    metadata: (item.metadata as Record<string, unknown> | null) ?? null,
  };
}

/** 由 parentObservationId 还原调用顺序；父节点缺失的记录挂在孤儿层，不丢。 */
function arrange(observations: PlatformObservation[]): TraceTree["rows"] {
  const byId = new Map(observations.map((item) => [item.id, item]));
  const childrenOf = new Map<string, PlatformObservation[]>();
  const roots: PlatformObservation[] = [];
  for (const item of observations) {
    const parent = item.parentObservationId && byId.has(item.parentObservationId) ? byId.get(item.parentObservationId)! : null;
    if (!parent) {
      roots.push(item);
      continue;
    }
    childrenOf.set(parent.id, [...(childrenOf.get(parent.id) ?? []), item]);
  }
  const rows: TraceTree["rows"] = [];
  const walk = (node: PlatformObservation, depth: number) => {
    rows.push({ depth, observation: node });
    for (const child of (childrenOf.get(node.id) ?? []).sort((a, b) => (a.startTime ?? "").localeCompare(b.startTime ?? ""))) {
      walk(child, depth + 1);
    }
  };
  for (const root of roots.sort((a, b) => (a.startTime ?? "").localeCompare(b.startTime ?? ""))) walk(root, 0);
  return rows;
}

/**
 * 采集是异步入库的，按编号轮询直到调用树可见或超时。
 *
 * 查到第一条记录就返回会把中间态当成完整调用树：报告里会出现「根节点编号对不上」的假缺口。
 * 这里要求连续两次轮询条数不再增长，才认为这批记录已经入库完成。
 */
export async function waitForTraceTree(
  traceId: string,
  timeoutMs = 90_000,
  intervalMs = 3_000,
): Promise<TraceTree> {
  const deadline = Date.now() + timeoutMs;
  let last: TraceTree | null = null;
  let settledCount = -1;
  while (Date.now() < deadline) {
    try {
      last = await fetchTraceTree(traceId);
      if (last.complete && last.observations.length === settledCount) return last;
      settledCount = last.complete ? last.observations.length : -1;
    } catch {
      // 尚未入库时报错，继续等。
      settledCount = -1;
    }
    await new Promise((resolveWait) => setTimeout(resolveWait, intervalMs));
  }
  return last ?? { traceId, rootName: null, observations: [], rows: [], complete: false };
}

/** 记录里保存的 Trace ID 要在平台侧真的读到调用树，才算关联接通。 */
export async function verifyCorrelation(traceId: string): Promise<{ platform_reached: boolean; observation_count: number }> {
  const tree = await waitForTraceTree(traceId);
  return { platform_reached: tree.complete, observation_count: tree.observations.length };
}

function preview(value: unknown): string {
  if (value === null || value === undefined) return "";
  const text = typeof value === "string" ? value : JSON.stringify(value);
  return text.length > 300 ? `${text.slice(0, 300)}...` : text;
}
