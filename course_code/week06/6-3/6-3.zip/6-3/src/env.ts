import { readFileSync, existsSync } from "node:fs";
import { resolve } from "node:path";

/**
 * 读取 config/local.env。已存在的环境变量优先，方便临时覆盖：
 *   DEEPSEEK_API_KEY=... npm run demo:log
 */
export function loadLocalEnv(rootDir = process.cwd()): void {
  const file = resolve(rootDir, "config/local.env");
  if (!existsSync(file)) return;
  for (const rawLine of readFileSync(file, "utf8").split("\n")) {
    const line = rawLine.trim();
    if (!line || line.startsWith("#")) continue;
    const separator = line.indexOf("=");
    if (separator < 1) continue;
    const key = line.slice(0, separator).trim();
    if (process.env[key] !== undefined) continue;
    process.env[key] = unquote(line.slice(separator + 1).trim());
  }
}

function unquote(value: string): string {
  if (value.length > 1 && /^(".*"|'.*')$/.test(value)) return value.slice(1, -1);
  return value;
}

export function required(name: string): string {
  const value = process.env[name];
  if (!value) throw new Error(`MISSING_ENV: 请设置 ${name}（可写在 config/local.env）`);
  return value;
}

export function optional(name: string, fallback: string): string {
  return process.env[name] || fallback;
}

export function port(name: string, fallback: number): number {
  const parsed = Number(process.env[name]);
  return Number.isInteger(parsed) && parsed > 0 ? parsed : fallback;
}
