import { mkdir, readFile, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { verifyArchive } from "./archive.js";
import type { PolicyCandidate, ServiceItem, CustomerRecord } from "./data.js";
import type { EvidenceDecision, ToolCallRecord } from "./sales-types.js";

export interface BundleInput {
  question: string;
  customerId: string;
  salesId: string;
  tenantId: string;
  businessTime: string;
  promptVersion: string;
  evidencePolicy: string;
}

export interface BundleVersions {
  prompt_version: string;
  prompt_hash: string;
  model_alias: string;
  evidence_policy: string;
  crm_schema: string;
  kb_schema: string;
  catalog_schema: string;
  authz_policy_version: string;
  knowledge_version: string;
}

/** 原失败结果：明确要复现什么问题，而不是只留一句错误答案。 */
export interface ReplayFailure {
  run_id: string;
  trace_id: string;
  answer: string;
  cited: string[];
  review: {
    passed: boolean;
    disposition: string;
    failed_checks: string[];
  } | null;
}

/** 验收规则与材料一起归档，回归时不需要再从对话里回忆标准。 */
export interface ReplayAcceptance {
  discount_percent: number;
  forbidden_discount_percent: number;
  required_policy: string;
  required_service_version: string;
  onsite_in_standard_service: boolean;
}

export interface RawResult {
  interface: string;
  schemaVersion: string;
  params: Record<string, unknown>;
  status: number | null;
  body: unknown;
  ref: string;
}

export interface ReplayBundle {
  originalRunId: string;
  dir: string;
  input: BundleInput;
  versions: BundleVersions;
  failure: ReplayFailure;
  acceptance: ReplayAcceptance;
  state: {
    tool_calls: ToolCallRecord[];
    evidence: EvidenceDecision | null;
    candidates: PolicyCandidate[];
    final_answer: string;
  };
  rawResults: RawResult[];
  /** 进入模型的上下文快照（provider 请求前保存的 payload）。 */
  contextMessages: unknown;
  integrity: { files: string[]; broken: string[]; complete: boolean };
}

/**
 * 把失败运行的复现材料写到 replays/<原运行编号>/。
 *
 * 最容易漏掉的是接口原始返回：只存筛选后的工具结果，新版程序就拿不到当时那份新政策。
 * 因此这里同时保存检索返回的完整候选和证据整理之后的结果，并在写完后回读校验。
 */
export async function writeBundle(
  root: string,
  originalRunId: string,
  data: {
    input: BundleInput;
    versions: BundleVersions;
    failure: ReplayFailure;
    acceptance: ReplayAcceptance;
    toolCalls: ToolCallRecord[];
    evidence: EvidenceDecision | null;
    candidates: PolicyCandidate[];
    finalAnswer: string;
    contextMessages: unknown;
  },
): Promise<string> {
  const dir = join(root, originalRunId);
  await mkdir(dir, { recursive: true });
  await writeFile(join(dir, "input.json"), JSON.stringify(data.input, null, 2), "utf8");
  await writeFile(join(dir, "versions.json"), JSON.stringify(data.versions, null, 2), "utf8");
  await writeFile(join(dir, "failure.json"), JSON.stringify(data.failure, null, 2), "utf8");
  await writeFile(join(dir, "acceptance.json"), JSON.stringify(data.acceptance, null, 2), "utf8");
  await writeFile(
    join(dir, "state.json"),
    JSON.stringify(
      {
        tool_calls: data.toolCalls,
        evidence: data.evidence,
        candidates: data.candidates.map((item) => item.id),
        final_answer: data.finalAnswer,
        stage: "answer_generated",
        pending: [],
      },
      null,
      2,
    ),
    "utf8",
  );
  const toolCallsText = data.toolCalls.map((record) => JSON.stringify(record)).join("\n");
  await writeFile(join(dir, "tool-calls.jsonl"), `${toolCallsText}\n`, "utf8");
  await mkdir(join(dir, "context"), { recursive: true });
  await writeFile(join(dir, "context", "messages.json"), JSON.stringify(data.contextMessages, null, 2), "utf8");
  await mkdir(join(dir, "raw-results"), { recursive: true });
  return dir;
}

/** 读取并校验复现材料；材料缺失时标记为无法完整重放，不当成业务测试通过。 */
export async function loadBundle(root: string, originalRunId: string): Promise<ReplayBundle> {
  const dir = join(root, originalRunId);
  const input = JSON.parse(await readFile(join(dir, "input.json"), "utf8")) as BundleInput;
  const versions = JSON.parse(await readFile(join(dir, "versions.json"), "utf8")) as BundleVersions;
  const failure = JSON.parse(await readFile(join(dir, "failure.json"), "utf8")) as ReplayFailure;
  const acceptance = JSON.parse(await readFile(join(dir, "acceptance.json"), "utf8")) as ReplayAcceptance;
  const stateFile = JSON.parse(await readFile(join(dir, "state.json"), "utf8")) as {
    tool_calls: ToolCallRecord[];
    evidence: EvidenceDecision | null;
    candidates: string[];
    final_answer: string;
  };
  const contextMessages = JSON.parse(
    await readFile(join(dir, "context", "messages.json"), "utf8"),
  ) as unknown;

  const integrity = await verifyArchive(root, originalRunId);
  const rawResults: RawResult[] = [];
  for (const ref of integrity.files) {
    if (!ref.includes("raw-results")) continue;
    const parsed = JSON.parse(await readFile(join(root, ref), "utf8")) as Omit<RawResult, "ref">;
    rawResults.push({ ...parsed, ref });
  }

  const policyRaw = rawResults.find((item) => item.interface === "kb.search_sales_policy");
  const candidates = ((policyRaw?.body as { candidates?: PolicyCandidate[] })?.candidates ?? []) as PolicyCandidate[];
  // 完整性要求：候选里必须同时有当期政策和上一版政策，否则无法检查“两份候选里选哪一份”。
  const complete = integrity.broken.length === 0 && candidates.length >= 2 && rawResults.length > 0;

  return {
    originalRunId,
    dir,
    input,
    versions,
    failure,
    acceptance,
    state: { tool_calls: stateFile.tool_calls, evidence: stateFile.evidence, candidates, final_answer: stateFile.final_answer },
    rawResults,
    contextMessages,
    integrity: { ...integrity, complete },
  };
}

export function bundleServiceItems(bundle: ReplayBundle): ServiceItem[] {
  const raw = bundle.rawResults.find((item) => item.interface === "catalog.get_service_catalog");
  return ((raw?.body as { items?: ServiceItem[] })?.items ?? []) as ServiceItem[];
}

export function bundleProfile(bundle: ReplayBundle): CustomerRecord | null {
  const raw = bundle.rawResults.find((item) => item.interface === "crm.get_customer_profile");
  return (raw?.body as CustomerRecord) ?? null;
}
