/** 销售问答的业务语料：两版折扣政策、客户资料与服务范围。 */

export interface PolicyCandidate {
  id: string;
  title: string;
  body: string;
  version: string;
  validFrom: string;
  validUntil: string;
  /** 最高折扣百分比，10 表示最低九折。 */
  maxDiscountPercent: number;
  /** 检索相关性分数，越大越靠前。 */
  relevance: number;
  appliesTo: {
    industries: string[];
    regions: string[];
    products: string[];
  };
}

export interface ServiceItem {
  productId: string;
  includesOnsiteSupport: boolean;
  onsiteCondition: string;
  remoteSupport: string;
  version: string;
}

export interface CustomerRecord {
  customer_id: string;
  name: string;
  industry: string;
  region: string;
  products: string[];
  contract_tier: string;
}

/**
 * 旧政策适用于上一年度，最高 15%；当前政策适用于本年度，最高 10%。
 * 相关性分数故意让旧政策更高，这样“按相关性取第一份”必然选中过期政策。
 */
export const POLICIES: PolicyCandidate[] = [
  {
    id: "P-old",
    title: "2025 年度销售折扣政策",
    body: "2025 年度内，制造业华东客户采购数据平台标准版，最高可享受 15% 折扣。",
    version: "policy-2025.3",
    validFrom: "2025-01-01",
    validUntil: "2025-12-31",
    maxDiscountPercent: 15,
    relevance: 0.91,
    appliesTo: { industries: ["制造"], regions: ["华东"], products: ["数据平台标准版"] },
  },
  {
    id: "P-current",
    title: "2026 年度销售折扣政策",
    body: "2026 年度内，制造业华东客户采购数据平台标准版，最高可享受 10% 折扣，即最低九折。",
    version: "policy-2026.1",
    validFrom: "2026-01-01",
    validUntil: "2026-12-31",
    maxDiscountPercent: 10,
    relevance: 0.88,
    appliesTo: { industries: ["制造"], regions: ["华东"], products: ["数据平台标准版"] },
  },
];

export const CUSTOMERS: Record<string, CustomerRecord> = {
  "C-1001": {
    customer_id: "C-1001",
    name: "华东精密制造",
    industry: "制造",
    region: "华东",
    products: ["数据平台标准版"],
    contract_tier: "gold",
  },
  "C-7003": {
    customer_id: "C-7003",
    name: "华东汽车零部件",
    industry: "制造",
    region: "华东",
    products: ["数据平台标准版"],
    contract_tier: "silver",
  },
  "C-9002": {
    customer_id: "C-9002",
    name: "华南医疗器械",
    industry: "医疗",
    region: "华南",
    products: ["数据平台企业版"],
    contract_tier: "gold",
  },
};

export const SERVICES: ServiceItem[] = [
  {
    productId: "数据平台标准版",
    includesOnsiteSupport: false,
    onsiteCondition: "驻场支持需另签服务方案并按项目报价",
    remoteSupport: "标准服务含 5x8 远程支持",
    version: "catalog-2026.1",
  },
  {
    productId: "数据平台企业版",
    includesOnsiteSupport: false,
    onsiteCondition: "驻场支持需另签服务方案并按项目报价",
    remoteSupport: "标准服务含 7x24 远程支持",
    version: "catalog-2026.1",
  },
];

/** 当前演示销售只能读取华东制造业客户，用于展示越权拒绝。 */
export const SALES_SCOPE: Record<string, { regions: string[]; industries: string[] }> = {
  "S-77": { regions: ["华东"], industries: ["制造"] },
};

/** C-7003 的 CRM 响应被人为拖慢，用来产生超时记录。 */
export const SLOW_CUSTOMER_IDS = new Set(["C-7003"]);
