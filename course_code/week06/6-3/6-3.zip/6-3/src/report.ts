import { writeFile, mkdir } from "node:fs/promises";
import { join } from "node:path";

export function table(headers: string[], rows: Array<Array<string | number | null | undefined>>): string {
  const cell = (value: string | number | null | undefined) => String(value ?? "").replace(/\|/g, "\\|").replace(/\n/g, " ");
  const lines = [`| ${headers.join(" | ")} |`, `| ${headers.map(() => "---").join(" |")} |`];
  for (const row of rows) lines.push(`| ${row.map(cell).join(" | ")} |`);
  return lines.join("\n");
}

/** 演示产出的对照报告，课上可以直接照着讲。 */
export async function writeReport(dir: string, name: string, body: string[]): Promise<string> {
  await mkdir(dir, { recursive: true });
  const file = join(dir, name);
  await writeFile(file, `${body.join("\n")}\n`, "utf8");
  return file;
}

export function heading(level: number, text: string): string {
  return `${"#".repeat(level)} ${text}`;
}
