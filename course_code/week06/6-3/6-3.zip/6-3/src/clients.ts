import { CUSTOMERS, SALES_SCOPE, type CustomerRecord, type PolicyCandidate, type ServiceItem } from "./data.js";
import type { ArchiveStore } from "./archive.js";
import type {
  CustomerApi,
  HttpOutcome,
  KnowledgeBase,
  PolicySearchQuery,
  ServiceCatalog,
} from "./sales-types.js";
import { MOCK_SERVICE_TOKEN } from "./mock-services.js";

interface RequestFields {
  method: string;
  path: string;
}

/** 统一的 HTTP 出口：把状态、耗时、错误类型和原始返回一起交回，不抛异常。 */
async function requestJson<T>(
  baseUrl: string,
  fields: RequestFields,
  init: RequestInit,
  timeoutMs: number,
  externalSignal?: AbortSignal,
): Promise<HttpOutcome<T>> {
  const timeout = AbortSignal.timeout(timeoutMs);
  const signal = externalSignal ? AbortSignal.any([externalSignal, timeout]) : timeout;
  const started = performance.now();
  let status: number | null = null;
  let errorType: string | null = null;
  let body: T | null = null;

  try {
    const response = await fetch(`${baseUrl}${fields.path}`, {
      ...init,
      redirect: "error",
      signal,
      headers: { Authorization: `Bearer ${MOCK_SERVICE_TOKEN}`, ...(init.headers ?? {}) },
    });
    status = response.status;
    if (!response.ok) {
      // 非 2xx 也保留具体错误类型；状态码已经单独记，不要都退化成 Error。
      errorType = `http_${status}`;
      throw new Error(errorType);
    }
    body = (await response.json()) as T;
  } catch (error) {
    errorType ??= error instanceof Error ? error.name || error.constructor.name : "UnknownError";
  }

  return {
    ok: errorType === null,
    status,
    body,
    durationMs: Math.round((performance.now() - started) * 100) / 100,
    errorType,
    method: fields.method,
    path: fields.path,
  };
}

function requireText(value: unknown, target: string): string {
  if (typeof value !== "string" || value.length === 0) throw new Error(`response_field_missing:${target}`);
  return value;
}

function requireArray(value: unknown, target: string): unknown[] {
  if (!Array.isArray(value)) throw new Error(`response_field_missing:${target}`);
  return value;
}

/** 知识库返回结构校验：字段缺失就按失败处理，不能把半截候选交给证据筛选。 */
export function decodePolicyCandidates(raw: unknown): PolicyCandidate[] {
  const value = raw as { candidates?: unknown } | null;
  if (!value || typeof value !== "object") throw new Error("policy_candidates_shape_invalid");
  return requireArray(value.candidates, "candidates").map((item, index) => {
    const policy = item as Partial<PolicyCandidate>;
    const appliesTo = policy.appliesTo as Partial<PolicyCandidate["appliesTo"]> | undefined;
    if (typeof policy.maxDiscountPercent !== "number" || typeof policy.relevance !== "number") {
      throw new Error(`policy_candidate_field_missing:${index}.numbers`);
    }
    if (!appliesTo) throw new Error(`policy_candidate_field_missing:${index}.appliesTo`);
    return {
      id: requireText(policy.id, `${index}.id`),
      title: requireText(policy.title, `${index}.title`),
      body: requireText(policy.body, `${index}.body`),
      version: requireText(policy.version, `${index}.version`),
      validFrom: requireText(policy.validFrom, `${index}.validFrom`),
      validUntil: requireText(policy.validUntil, `${index}.validUntil`),
      maxDiscountPercent: policy.maxDiscountPercent,
      relevance: policy.relevance,
      appliesTo: {
        industries: requireArray(appliesTo.industries, `${index}.appliesTo.industries`).map(String),
        regions: requireArray(appliesTo.regions, `${index}.appliesTo.regions`).map(String),
        products: requireArray(appliesTo.products, `${index}.appliesTo.products`).map(String),
      },
    };
  });
}

/** 服务目录返回结构校验：驻场支持字段必须是布尔值，不能用字符串猜。 */
export function decodeServiceItems(raw: unknown): ServiceItem[] {
  const value = raw as { items?: unknown } | null;
  if (!value || typeof value !== "object") throw new Error("service_catalog_shape_invalid");
  return requireArray(value.items, "items").map((item, index) => {
    const service = item as Partial<ServiceItem>;
    if (typeof service.includesOnsiteSupport !== "boolean") {
      throw new Error(`service_item_field_missing:${index}.includesOnsiteSupport`);
    }
    return {
      productId: requireText(service.productId, `${index}.productId`),
      includesOnsiteSupport: service.includesOnsiteSupport,
      onsiteCondition: requireText(service.onsiteCondition, `${index}.onsiteCondition`),
      remoteSupport: requireText(service.remoteSupport, `${index}.remoteSupport`),
      version: requireText(service.version, `${index}.version`),
    };
  });
}

/** 校验接口返回结构，并只提取允许进入模型上下文的客户字段。 */
export function decodeProfile(raw: unknown, customerId: string): CustomerRecord {
  const value = raw as Partial<CustomerRecord> | null;
  if (!value || typeof value !== "object") throw new Error(`profile_shape_invalid:${customerId}`);
  const requiredText = (field: keyof CustomerRecord, target: string) => {
    if (typeof value[field] !== "string" || !value[field]) throw new Error(`profile_field_missing:${target}`);
  };
  requiredText("name", "name");
  requiredText("industry", "industry");
  requiredText("region", "region");
  if (!Array.isArray(value.products)) throw new Error("profile_field_missing:products");
  return {
    customer_id: String(value.customer_id ?? customerId),
    name: String(value.name),
    industry: String(value.industry),
    region: String(value.region),
    products: value.products.map(String),
    // contract_tier 属于内部字段，不放进模型上下文。
    contract_tier: "",
  };
}

export interface RealClientOptions {
  baseUrl: string;
  timeoutMs: number;
  archive: ArchiveStore;
  authzPolicyVersion: string;
  schemaVersion: string;
}

export function createCustomerApi(options: RealClientOptions): CustomerApi {
  return {
    source: "crm",
    authzPolicyVersion: options.authzPolicyVersion,
    schemaVersion: options.schemaVersion,
    async canReadCustomer(run, customerId) {
      // 权限判断来自后端认证结果与业务授权表，不看模型填写的身份。
      const scope = SALES_SCOPE[run.salesId];
      const customer = CUSTOMERS[customerId];
      if (!scope || !customer) return false;
      return scope.regions.includes(customer.region) && scope.industries.includes(customer.industry);
    },
    async getProfile(run, customerId, signal) {
      const path = `/api/customers/${encodeURIComponent(customerId)}`;
      const outcome = await requestJson<unknown>(
        options.baseUrl,
        { method: "GET", path },
        { method: "GET" },
        options.timeoutMs,
        signal,
      );
      if (outcome.status !== null && outcome.body !== null) {
        outcome.rawRef = await options.archive.put(run.runId, "raw-results", {
          interface: "crm.get_customer_profile",
          schemaVersion: options.schemaVersion,
          params: { customerId },
          status: outcome.status,
          body: outcome.body,
        });
      }
      if (!outcome.ok || outcome.body === null) return { ...outcome, body: null };
      try {
        return { ...outcome, body: decodeProfile(outcome.body, customerId) };
      } catch (error) {
        return {
          ...outcome,
          ok: false,
          body: null,
          errorType: error instanceof Error ? error.message : "profile_shape_invalid",
        };
      }
    },
  };
}

export function createKnowledgeBase(options: RealClientOptions): KnowledgeBase {
  return {
    source: "kb",
    authzPolicyVersion: options.authzPolicyVersion,
    schemaVersion: options.schemaVersion,
    async searchPolicies(run, query: PolicySearchQuery, signal) {
      // 查询条件必须真的发出去：日志里记录的 keyword / business_time 要和接口收到的一致。
      const path =
        `/api/policies/search?customer_id=${encodeURIComponent(query.customerId)}` +
        `&keyword=${encodeURIComponent(query.keyword)}&business_time=${encodeURIComponent(query.businessTime)}`;
      const outcome = await requestJson<unknown>(
        options.baseUrl,
        { method: "GET", path },
        { method: "GET" },
        options.timeoutMs,
        signal,
      );
      if (outcome.status !== null && outcome.body !== null) {
        outcome.rawRef = await options.archive.put(run.runId, "raw-results", {
          interface: "kb.search_sales_policy",
          schemaVersion: options.schemaVersion,
          params: query,
          status: outcome.status,
          // 候选原样保存，新旧两版都在，修复后的程序才拿得到当时那份新政策。
          body: outcome.body,
        });
      }
      if (!outcome.ok || outcome.body === null) return { ...outcome, body: null };
      try {
        return { ...outcome, body: decodePolicyCandidates(outcome.body) };
      } catch (error) {
        return {
          ...outcome,
          ok: false,
          body: null,
          errorType: error instanceof Error ? error.message : "policy_candidates_shape_invalid",
        };
      }
    },
  };
}

export function createServiceCatalog(options: RealClientOptions): ServiceCatalog {
  return {
    source: "catalog",
    authzPolicyVersion: options.authzPolicyVersion,
    schemaVersion: options.schemaVersion,
    async getServices(run, productId, signal) {
      const path = `/api/service-catalog/${encodeURIComponent(productId)}`;
      const outcome = await requestJson<unknown>(
        options.baseUrl,
        { method: "GET", path },
        { method: "GET" },
        options.timeoutMs,
        signal,
      );
      if (outcome.status !== null && outcome.body !== null) {
        outcome.rawRef = await options.archive.put(run.runId, "raw-results", {
          interface: "catalog.get_service_catalog",
          schemaVersion: options.schemaVersion,
          params: { productId },
          status: outcome.status,
          body: outcome.body,
        });
      }
      if (!outcome.ok || outcome.body === null) return { ...outcome, body: null };
      try {
        return { ...outcome, body: decodeServiceItems(outcome.body) };
      } catch (error) {
        return {
          ...outcome,
          ok: false,
          body: null,
          errorType: error instanceof Error ? error.message : "service_catalog_shape_invalid",
        };
      }
    },
  };
}
