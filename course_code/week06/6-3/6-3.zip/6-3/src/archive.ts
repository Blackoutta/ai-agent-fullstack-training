import { mkdir, writeFile, readFile, readdir, stat } from "node:fs/promises";
import { join } from "node:path";

/**
 * 复现材料归档。日志里只保存摘要和引用，完整数据写到这里，
 * 并且写入后立刻按“能否读回并解析”校验，不把没写完的文件当成已归档证据。
 */
export interface ArchiveStore {
  readonly root: string;
  /** 返回可定位到实际文件的相对引用路径。 */
  put(runId: string, kind: ArchiveKind, payload: unknown): Promise<string>;
  read(ref: string): Promise<string>;
}

export type ArchiveKind =
  | "raw-results"
  | "context"
  | "output"
  | "tool-calls"
  | "input"
  | "versions"
  | "state";

const counters = new Map<string, number>();

export async function createArchiveStore(root: string): Promise<ArchiveStore> {
  await mkdir(root, { recursive: true });
  return {
    root,
    async put(runId, kind, payload) {
      const dir = join(root, runId, kind);
      await mkdir(dir, { recursive: true });
      const key = `${runId}/${kind}`;
      const seq = (counters.get(key) ?? 0) + 1;
      counters.set(key, seq);
      const name = `${kind}-${String(seq).padStart(3, "0")}.json`;
      const file = join(dir, name);
      const text = JSON.stringify(payload, null, 2);
      await writeFile(file, text, "utf8");
      // 写完立即校验长度，避免把截断文件当成完整证据。
      const info = await stat(file);
      if (info.size !== Buffer.byteLength(text, "utf8")) {
        throw new Error(`archive_incomplete:${file}`);
      }
      return join(runId, kind, name);
    },
    async read(ref) {
      return readFile(join(root, ref), "utf8");
    },
  };
}

/** 校验归档目录里的每个 JSON 文件都能读回并解析，返回文件清单。 */
export async function verifyArchive(root: string, runId: string): Promise<{ files: string[]; broken: string[] }> {
  const dir = join(root, runId);
  const files: string[] = [];
  const broken: string[] = [];
  const walk = async (current: string) => {
    for (const entry of await readdir(current, { withFileTypes: true })) {
      const child = join(current, entry.name);
      if (entry.isDirectory()) {
        await walk(child);
        continue;
      }
      if (!entry.name.endsWith(".json")) continue;
      try {
        JSON.parse(await readFile(child, "utf8"));
        files.push(child.slice(root.length + 1));
      } catch {
        broken.push(child.slice(root.length + 1));
      }
    }
  };
  await walk(dir);
  return { files, broken };
}
