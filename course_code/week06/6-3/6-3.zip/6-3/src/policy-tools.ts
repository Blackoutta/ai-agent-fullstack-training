import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
import { Type } from "typebox";
import { selectEvidence } from "./evidence.js";
import { ensureCustomerProfile } from "./profile-loader.js";
import type {
  BusinessTracer,
  CustomerApi,
  EvidencePolicyName,
  KnowledgeBase,
  SalesAudit,
  SalesRun,
  ServiceCatalog,
} from "./sales-types.js";
import type { RunState } from "./run-state.js";

export interface PolicyToolDeps {
  knowledgeBase: KnowledgeBase;
  serviceCatalog: ServiceCatalog;
  customerApi: CustomerApi;
  tracer: BusinessTracer;
  /** 证据整理条数上限，新旧两版用同一个值，差异只在筛选前后。 */
  evidenceLimit: number;
}

interface PolicyToolDetails {
  evidencePolicy: EvidencePolicyName;
  selected: string[];
  excluded: Array<{ id: string; reason: string }>;
  selectionRule: string;
  validityCheckApplied: boolean;
  rawRef: string | null;
  [key: string]: unknown;
}

/**
 * search_sales_policy 与 get_service_catalog。
 *
 * search_sales_policy 先取回全部原始候选，再执行证据整理，
 * 只把选中的资料返回给 Agent。模型看到什么，由这段业务代码决定。
 */
export function createPolicyToolsExtension(run: SalesRun, deps: PolicyToolDeps, state: RunState) {
  return (pi: ExtensionAPI) => {
    const emit = (payload: SalesAudit) => pi.events.emit("sales:audit", payload);

    /** 模型没先查客户时也要拿到客户条件，否则适用性校验没有依据。 */
    const ensureProfile = (toolCallId: string, signal?: AbortSignal) =>
      ensureCustomerProfile(
        run,
        { customerApi: deps.customerApi, tracer: deps.tracer, emit },
        state,
        run.customerId,
        toolCallId,
        signal,
      );

    pi.registerTool({
      name: "search_sales_policy",
      label: "检索折扣政策",
      description: "检索当前客户的销售折扣政策，返回政策正文、适用条件、有效期和文档版本。",
      promptSnippet: "search_sales_policy 检索折扣政策的正文、适用条件、有效期与版本",
      promptGuidelines: [
        "给出折扣数字前必须调用 search_sales_policy，并只引用返回的政策版本。",
        "返回结果里没有的政策不得凭记忆补充。",
      ],
      // 检索条件来自后端运行上下文，不交给模型自由填写：
      // 同一问题在 Replay 时必须用同一组查询条件，才能算固定条件。
      parameters: Type.Object({}),
      async execute(toolCallId, _params, signal) {
        const customer = await ensureProfile(toolCallId, signal);
        const keyword = "折扣";

        const retrievalSpan = deps.tracer.start("retrieval.sales_policy", {
          keyword,
          customerId: run.customerId,
          businessTime: run.businessTime,
        });
        const outcome = await deps.knowledgeBase.searchPolicies(
          run,
          { customerId: run.customerId, keyword, businessTime: run.businessTime },
          signal,
        );
        emit({
          runId: run.runId,
          action: "policy.http_request",
          toolCallId,
          customerId: run.customerId,
          method: outcome.method,
          path: outcome.path,
          status: outcome.status,
          durationMs: outcome.durationMs,
          outcome: outcome.ok ? "success" : "failure",
          errorType: outcome.errorType,
          rawRef: outcome.rawRef ?? null,
        });
        if (!outcome.ok || !outcome.body) {
          retrievalSpan.end({ outcome: "failure", error_type: outcome.errorType }, "error");
          throw new Error(`kb_request_failed:${outcome.errorType ?? `http_${outcome.status}`}`);
        }

        const candidates = outcome.body;
        state.candidates = candidates;
        retrievalSpan.end({
          outcome: "success",
          hit_count: candidates.length,
          candidates: candidates.map((item) => ({
            id: item.id,
            version: item.version,
            validFrom: item.validFrom,
            validUntil: item.validUntil,
            relevance: item.relevance,
            raw_ref: outcome.rawRef ?? null,
          })),
          raw_ref: outcome.rawRef ?? null,
        });

        // 证据整理是本次排错的关键节点，单独埋一个业务子节点。
        const evidenceSpan = deps.tracer.start("context.build.evidence_selection", {
          candidate_ids: candidates.map((item) => item.id),
          evidence_policy: run.evidencePolicy,
          business_time: run.businessTime,
          limit: deps.evidenceLimit,
          customer: { region: customer.region, industry: customer.industry, products: customer.products },
        });
        const decision = selectEvidence({
          candidates,
          customer,
          businessTime: run.businessTime,
          policy: run.evidencePolicy,
          limit: deps.evidenceLimit,
        });
        state.evidence = decision;
        emit({
          runId: run.runId,
          action: "evidence.selection",
          toolCallId,
          customerId: run.customerId,
          outcome: "success",
          policyVersion: decision.policy,
          candidateIds: candidates.map((item) => item.id),
          selected: decision.selected.map((item) => item.id),
          excluded: decision.excluded,
          selectionRule: decision.selectionRule,
          validityCheckApplied: decision.validityCheckApplied,
          businessTime: run.businessTime,
          rawRef: outcome.rawRef ?? null,
        });
        emit({
          runId: run.runId,
          action: "context.build",
          toolCallId,
          customerId: run.customerId,
          outcome: "success",
          policyVersion: decision.policy,
          contextRefs: decision.selected.map((item) => `${item.id}@${item.version}`),
          selected: decision.selected.map((item) => item.id),
          excluded: decision.excluded,
          selectionRule: decision.selectionRule,
          validityCheckApplied: decision.validityCheckApplied,
          businessTime: run.businessTime,
        });
        evidenceSpan.end({
          selected_ids: decision.selected.map((item) => item.id),
          excluded: decision.excluded,
          evidence_policy: decision.policy,
          selection_rule: decision.selectionRule,
          validity_check_applied: decision.validityCheckApplied,
          // 只有 selected 会进入工具返回值，也就是进入模型上下文。
          returned_to_model: decision.selected.map((item) => item.id),
        });

        if (decision.selected.length === 0) {
          const details: PolicyToolDetails = {
            evidencePolicy: decision.policy,
            selected: [],
            excluded: decision.excluded,
            selectionRule: decision.selectionRule,
            validityCheckApplied: decision.validityCheckApplied,
            rawRef: outcome.rawRef ?? null,
          };
          return {
            content: [
              {
                type: "text" as const,
                text: JSON.stringify({
                  policies: [],
                  note: "没有通过有效期与适用条件校验的政策，应回答无法确认或转人工，不得给出折扣数字。",
                }),
              },
            ],
            details,
          };
        }

        const details: PolicyToolDetails = {
          evidencePolicy: decision.policy,
          selected: decision.selected.map((item) => item.id),
          excluded: decision.excluded,
          selectionRule: decision.selectionRule,
          validityCheckApplied: decision.validityCheckApplied,
          rawRef: outcome.rawRef ?? null,
        };
        return {
          content: [{ type: "text" as const, text: JSON.stringify({ policies: decision.selected }) }],
          details,
        };
      },
    });

    pi.registerTool({
      name: "get_service_catalog",
      label: "查询产品服务范围",
      description: "查询当前客户已购产品的服务范围，确认标准服务是否包含驻场支持。",
      promptSnippet: "get_service_catalog 查询标准服务范围与驻场支持条件",
      promptGuidelines: ["回答服务范围前必须调用 get_service_catalog 确认驻场支持是否包含在标准服务内。"],
      parameters: Type.Object({}),
      async execute(toolCallId, _params, signal) {
        // 产品来自客户资料，不由模型另填一个产品名，避免查询对象和客户条件脱节。
        const customer = await ensureProfile(toolCallId, signal);
        const product = customer.products[0];
        if (!product) throw new Error("customer_product_missing");

        const span = deps.tracer.start("tool.service_catalog", { product });
        const outcome = await deps.serviceCatalog.getServices(run, product, signal);
        emit({
          runId: run.runId,
          action: "catalog.http_request",
          toolCallId,
          customerId: run.customerId,
          method: outcome.method,
          path: outcome.path,
          status: outcome.status,
          durationMs: outcome.durationMs,
          outcome: outcome.ok ? "success" : "failure",
          errorType: outcome.errorType,
          rawRef: outcome.rawRef ?? null,
        });
        if (!outcome.ok || !outcome.body) {
          span.end({ outcome: "failure", error_type: outcome.errorType }, "error");
          throw new Error(`catalog_request_failed:${outcome.errorType ?? `http_${outcome.status}`}`);
        }
        state.services = outcome.body;
        span.end({ outcome: "success", items: outcome.body.length, raw_ref: outcome.rawRef ?? null });
        return {
          content: [{ type: "text" as const, text: JSON.stringify({ services: outcome.body }) }],
          details: { product, source: deps.serviceCatalog.source, rawRef: outcome.rawRef ?? null },
        };
      },
    });
  };
}
