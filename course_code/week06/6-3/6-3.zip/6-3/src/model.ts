import { join } from "node:path";
import { ModelRuntime, type Model } from "./pi-types.js";
import { required, optional, port } from "./env.js";

export interface ModelSetup {
  modelRuntime: ModelRuntime;
  model: Model<any>;
  /** 配置里请求的模型别名。服务只提供别名时具体版本保留未知，由响应里的 model 字段补。 */
  requestedAlias: string;
}

/**
 * 模型在服务端统一配置：这里用 pi 内置的 deepseek provider，
 * 密钥由运行入口注入，不写入会话文件，也不从开发者机器上的 ~/.pi 继承。
 */
export async function createModelSetup(agentDirectory: string): Promise<ModelSetup> {
  const modelRuntime = await ModelRuntime.create({
    authPath: join(agentDirectory, "auth.json"),
    modelsPath: null,
    allowModelNetwork: false,
    refreshOnCreate: false,
  });

  const apiKey = required("DEEPSEEK_API_KEY");
  await modelRuntime.setRuntimeApiKey("deepseek", apiKey);

  const modelId = optional("DEMO_CHAT_MODEL", "deepseek-flash");
  const model = modelRuntime.getModel("deepseek", modelId);
  if (!model) {
    const known = modelRuntime
      .getModels("deepseek")
      .map((item) => item.id)
      .join(", ");
    throw new Error(`model_unavailable:deepseek/${modelId}；可选：${known}`);
  }
  return { modelRuntime, model, requestedAlias: modelId };
}

export function maxOutputTokens(): number {
  return port("DEMO_MAX_TOKENS", 2000);
}

export function reasoningEffort(): "low" | "medium" | "high" {
  const value = optional("DEMO_REASONING_EFFORT", "low");
  return value === "medium" || value === "high" ? value : "low";
}
