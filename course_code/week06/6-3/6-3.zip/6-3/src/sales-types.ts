import type { Model } from "@earendil-works/pi-ai";
import type { ModelRuntime } from "@earendil-works/pi-coding-agent";
import type { ArchiveStore } from "./archive.js";
import type { CustomerRecord, PolicyCandidate, ServiceItem } from "./data.js";

/** 本次问答运行的身份与业务口径，由后端认证结果创建，通过闭包传给工具。 */
export interface SalesRun {
  runId: string;
  requestId: string;
  question: string;
  customerId: string;
  salesId: string;
  tenantId: string;
  /** 业务时间：判断政策当时是否适用的唯一依据。 */
  businessTime: string;
  promptVersion: string;
  /** Prompt 内容指纹：只记录文件名无法定位被覆盖前的具体内容。 */
  promptHash: string;
  /** 证据整理策略版本，决定用旧版还是修复后的筛选逻辑。 */
  evidencePolicy: EvidencePolicyName;
  /** 重放运行时指向原失败运行编号。 */
  replayOf?: string;
  /** 本次运行在观测平台中的父节点。 */
  trace: TraceRef;
}

/** 观测平台父节点引用。Langfuse 使用 OpenTelemetry 的十六进制编号。 */
export interface TraceRef {
  traceId: string;
  parentSpanId: string;
  sessionId: string;
  /** 平台名称，写进日志字段名，避免和别的平台混用。 */
  platform: "langfuse" | "none";
}

export const NULL_TRACE: TraceRef = {
  traceId: "unknown",
  parentSpanId: "unknown",
  sessionId: "unknown",
  platform: "none",
};

/** 业务子节点埋点句柄。现成平台扩展只覆盖模型与工具，业务节点要自己挂。 */
export interface SpanHandle {
  end(output: Record<string, unknown>, level?: "default" | "error"): void;
}

export interface BusinessTracer {
  start(name: string, input: Record<string, unknown>): SpanHandle;
}

export const NO_TRACER: BusinessTracer = {
  start: () => ({ end: () => {} }),
};

/** 结构化日志的一条记录。 */
export interface LogRecord {
  timestamp: string;
  service: string;
  run_id: string;
  request_id: string;
  [key: string]: unknown;
}

export interface JsonLogSink {
  readonly file: string;
  write(record: LogRecord): void;
  flush(): Promise<void>;
  stats(): LogSinkStats;
}

export interface LogSinkStats {
  written: number;
  queued: number;
  dropped: number;
  write_error: string | null;
}

/** 工具与业务接口之间传递的事实。 */
export type AuditAction =
  | "customer.authorization"
  | "customer.http_request"
  | "policy.http_request"
  | "catalog.http_request"
  | "evidence.selection"
  | "context.build"
  | "answer.review";

export interface SalesAudit {
  runId: string;
  action: AuditAction;
  toolCallId?: string;
  customerId?: string;
  authorization?: "allow" | "deny";
  policyVersion?: string;
  method?: string;
  path?: string;
  status?: number | null;
  durationMs?: number | null;
  outcome?: "success" | "failure" | "unknown";
  errorType?: string | null;
  /** 检索返回的原始候选，按知识库返回顺序保存，不受筛选结果影响。 */
  candidateIds?: string[];
  selected?: string[];
  excluded?: Array<{ id: string; reason: string }>;
  contextRefs?: string[];
  /** 本次真正执行的筛选规则，必须由筛选代码返回，不能事后补写。 */
  selectionRule?: string;
  validityCheckApplied?: boolean;
  /** 判定期限时用的业务时间，和筛选结果一起记录。 */
  businessTime?: string;
  [key: string]: unknown;
}

/** HTTP 结果：状态码可为空，因为超时和中断时拿不到响应。 */
export interface HttpOutcome<T = unknown> {
  ok: boolean;
  status: number | null;
  body: T | null;
  durationMs: number;
  errorType: string | null;
  method: string;
  path: string;
  /** 原始返回的归档引用，日志里只留摘要和这个引用。 */
  rawRef?: string;
}

export interface PolicySearchQuery {
  customerId: string;
  keyword: string;
  businessTime: string;
}

/** 客户接口依赖。真实实现发 HTTP，录制实现读归档材料。 */
export interface CustomerApi {
  readonly source: "crm" | "recorded";
  readonly authzPolicyVersion: string;
  readonly schemaVersion: string;
  canReadCustomer(run: SalesRun, customerId: string): Promise<boolean>;
  getProfile(run: SalesRun, customerId: string, signal?: AbortSignal): Promise<HttpOutcome<CustomerRecord>>;
}

export interface KnowledgeBase {
  readonly source: "kb" | "recorded";
  readonly schemaVersion: string;
  readonly authzPolicyVersion: string;
  searchPolicies(run: SalesRun, query: PolicySearchQuery, signal?: AbortSignal): Promise<HttpOutcome<PolicyCandidate[]>>;
}

export interface ServiceCatalog {
  readonly source: "catalog" | "recorded";
  readonly schemaVersion: string;
  readonly authzPolicyVersion: string;
  getServices(run: SalesRun, productId: string, signal?: AbortSignal): Promise<HttpOutcome<ServiceItem[]>>;
}

/** 证据整理策略：旧版按相关性直接取，新版先校验适用性与有效期。 */
export type EvidencePolicyName = "relevance-first-v1" | "validity-first-v2";

export interface EvidenceDecision {
  policy: EvidencePolicyName;
  businessTime: string;
  selected: PolicyCandidate[];
  excluded: Array<{ id: string; reason: string }>;
  limit: number;
  /** 实际执行的规则名，日志与 Trace 都从这里取值。 */
  selectionRule: EvidenceSelectionRule;
  /** 旧版没有这一步，就如实记录 false，不能补写成“因有效期被排除”。 */
  validityCheckApplied: boolean;
  /** 同上：客户适用条件检查是否真的执行。 */
  applicabilityCheckApplied: boolean;
}

export type EvidenceSelectionRule = "relevance_top_1" | "validity_then_relevance";

export interface AnswerReview {
  passed: boolean;
  findings: Array<{ check: string; passed: boolean; detail: string }>;
  /** 未通过时的业务处置：补查、标记未知或转人工。 */
  disposition: "return" | "recheck" | "unknown" | "escalate";
}

/** SDK 运行入口的依赖集合。正常运行与重放只有这里的内容不同。 */
export interface SalesDependencies {
  modelRuntime: ModelRuntime;
  model: Model<any>;
  /** pi 的工作目录，用于限定资源发现范围。 */
  resourceDirectory: string;
  /** pi 的配置目录，指向项目内空目录，避免继承开发者个人扩展。 */
  agentDirectory: string;
  logSink: JsonLogSink;
  /** 完整返回与上下文的归档位置，日志只保存摘要和引用。 */
  archive: ArchiveStore;
  customerApi: CustomerApi;
  knowledgeBase: KnowledgeBase;
  serviceCatalog: ServiceCatalog;
  tracer: BusinessTracer;
}

export interface SalesAnswer {
  text: string;
  runId: string;
  requestId: string;
  traceId: string;
  toolCalls: ToolCallRecord[];
  review: AnswerReview | null;
  /** 模型停止生成后的业务处置：能否直接返回答案由这里决定，不由“模型已结束”推断。 */
  delivery: AnswerReview["disposition"];
}

export interface ToolCallRecord {
  toolCallId: string;
  toolName: string;
  args: Record<string, unknown>;
  outcome: "success" | "failure";
  durationMs: number | null;
  resultSummary: string;
  rawRef?: string;
}
