import { appendFile, mkdir } from "node:fs/promises";
import { dirname } from "node:path";
import type { JsonLogSink, LogRecord, LogSinkStats } from "./sales-types.js";

/**
 * JSONL 文件写入器：同一进程共用一个，按顺序追加，待写条数有上限。
 *
 * 写入失败不静默吞掉：错误状态保留下来，在 flush() 时明确报告；
 * 队列满而被丢弃的条数同样在 flush() 抛出，避免把采集故障误认为 Agent 没有执行。
 */
export async function createJsonlSink(file: string, limit = 1000): Promise<JsonLogSink> {
  await mkdir(dirname(file), { recursive: true });
  let pending: Promise<void> = Promise.resolve();
  let queued = 0;
  let written = 0;
  let dropped = 0;
  let writeError: unknown = null;

  return {
    file,
    write(record: LogRecord) {
      if (queued >= limit) {
        dropped++;
        return;
      }
      const line = `${JSON.stringify(record)}\n`;
      queued++;
      pending = pending.then(async () => {
        try {
          await appendFile(file, line, "utf8");
          written++;
        } catch (error) {
          writeError ??= error;
        } finally {
          queued--;
        }
      });
    },
    async flush() {
      await pending;
      // 队列里可能还有在本次 flush 期间排入的任务，等待排空后再判定。
      if (queued > 0) await pending;
      if (writeError !== null) {
        throw writeError instanceof Error ? writeError : new Error(String(writeError));
      }
      if (dropped > 0) throw new Error(`agent_log_dropped:${dropped}`);
    },
    stats(): LogSinkStats {
      return {
        written,
        queued,
        dropped,
        write_error: writeError instanceof Error ? writeError.message : writeError ? String(writeError) : null,
      };
    },
  };
}
