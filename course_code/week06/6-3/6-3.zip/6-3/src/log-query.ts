import { readFile } from "node:fs/promises";

export interface LogFile {
  file: string;
  records: Record<string, unknown>[];
}

/**
 * 按行读取 JSONL。遇到损坏行立即报出文件与行号并停止，
 * 不能跳过坏行后把剩下的记录当成一次完整的执行过程。
 */
export async function readJsonl(file: string): Promise<LogFile> {
  const text = await readFile(file, "utf8");
  const records: LogFile["records"] = [];
  const lines = text.split("\n");
  for (let index = 0; index < lines.length; index++) {
    const raw = lines[index];
    if (raw === undefined || raw.trim().length === 0) continue;
    try {
      records.push(JSON.parse(raw) as Record<string, unknown>);
    } catch {
      throw new Error(`invalid_log_json:${file}:${index + 1}`);
    }
  }
  return { file, records };
}

export function selectByRun(records: Record<string, unknown>[], runId: string) {
  return records.filter((record) => record.run_id === runId);
}

/** 把工具调用与接口访问并排，核对接口是否成功、耗时多少。 */
export type CallRow = Record<"event" | "tool" | "call" | "status" | "ms" | "error", string | number | null>;

export function callTable(records: Record<string, unknown>[]): CallRow[] {
  const pick = (value: unknown): string | number | null => {
    if (value === null || value === undefined) return null;
    return typeof value === "string" || typeof value === "number" ? value : String(value);
  };
  return records.map((record) => ({
    event: pick(record.event),
    tool: pick(record.tool_name),
    call: String(record.tool_call_id ?? "").slice(0, 12),
    status: pick(record.http_status ?? record.outcome),
    ms: pick(record.duration_ms ?? record.execution_ms),
    error: pick(record.error_type),
  }));
}

interface UsageTotals {
  input_tokens: number;
  output_tokens: number;
  total_tokens: number;
  cost_usd: number;
  abnormal_stop: number;
  error_messages: number;
}

/**
 * 用量与成本汇总。本地文件和观测平台记录的是同一批调用，
 * 这里只按本地记录汇总一次，避免两边相加造成重复累计；
 * 失败与重试的消耗同样计入。
 *
 * 没有返回 Token 或价格时保留未知计数，不能把缺失值当成 0。
 */
export function summarizeUsage(records: Record<string, unknown>[]) {
  const modelRecords = records.filter((record) => record.event === "model.message.completed");
  const providerRequests = records.filter((record) => record.event === "model.request.started").length;
  const totals: UsageTotals = {
    input_tokens: 0,
    output_tokens: 0,
    total_tokens: 0,
    cost_usd: 0,
    abnormal_stop: 0,
    error_messages: 0,
  };
  let usageKnown = 0;
  let usageUnknown = 0;
  let costKnown = 0;
  let costUnknown = 0;

  for (const record of modelRecords) {
    const hasUsage =
      record.usage_source !== "unknown" &&
      [record.input_tokens, record.output_tokens, record.total_tokens].some((value) => typeof value === "number");
    if (hasUsage) {
      usageKnown += 1;
      totals.input_tokens += Number(record.input_tokens ?? 0);
      totals.output_tokens += Number(record.output_tokens ?? 0);
      totals.total_tokens += Number(record.total_tokens ?? 0);
    } else {
      usageUnknown += 1;
    }
    if (typeof record.cost_usd === "number") {
      costKnown += 1;
      totals.cost_usd += record.cost_usd;
    } else {
      costUnknown += 1;
    }
    if (record.stop_reason !== "stop" && record.stop_reason !== "toolUse") totals.abnormal_stop += 1;
    if (record.error_reason) totals.error_messages += 1;
  }

  return {
    model_calls: modelRecords.length,
    // provider 请求数不等于模型消息数：底层重试时一个回答可能对应多次请求。
    provider_requests: providerRequests || null,
    provider_retries: providerRequests === 0 ? null : Math.max(0, providerRequests - modelRecords.length),
    ...totals,
    cost_usd: Math.round(totals.cost_usd * 1e6) / 1e6,
    usage_known_calls: usageKnown,
    usage_unknown_calls: usageUnknown,
    cost_known_calls: costKnown,
    cost_unknown_calls: costUnknown,
    cost_source: modelRecords.length === 0 || costKnown === 0 ? "unknown" : costUnknown > 0 ? "partial" : "pi_sdk_price_table",
  };
}

/** 错误率与分位耗时从同一批记录汇总，失败与重试都计入。 */
export interface RunMetrics {
  tool_calls: number;
  tool_failures: number;
  tool_error_rate: number;
  http_requests: number;
  http_failures: number;
  http_error_rate: number;
  p50_tool_ms: number | null;
  p95_tool_ms: number | null;
  max_tool_ms: number | null;
  runs: number;
  reviews_failed: number;
}

function percentile(values: number[], ratio: number): number | null {
  if (values.length === 0) return null;
  const sorted = [...values].sort((a, b) => a - b);
  const index = Math.min(sorted.length - 1, Math.ceil(ratio * sorted.length) - 1);
  return sorted[index] ?? null;
}

export function summarizeMetrics(records: Record<string, unknown>[]): RunMetrics {
  const toolEnds = records.filter((record) => record.event === "tool.call.finished");
  const httpRecords = records.filter((record) => String(record.event).endsWith("http_request"));
  const durations = toolEnds
    .map((record) => record.execution_ms)
    .filter((value): value is number => typeof value === "number");
  const failures = toolEnds.filter((record) => record.outcome === "failure").length;
  const httpFailures = httpRecords.filter((record) => record.outcome === "failure").length;
  const rate = (count: number, total: number) => (total === 0 ? 0 : Math.round((count / total) * 1000) / 1000);
  return {
    tool_calls: toolEnds.length,
    tool_failures: failures,
    tool_error_rate: rate(failures, toolEnds.length),
    http_requests: httpRecords.length,
    http_failures: httpFailures,
    http_error_rate: rate(httpFailures, httpRecords.length),
    p50_tool_ms: percentile(durations, 0.5),
    p95_tool_ms: percentile(durations, 0.95),
    max_tool_ms: percentile(durations, 1),
    runs: new Set(records.map((record) => record.run_id)).size,
    reviews_failed: records.filter((record) => record.event === "answer.review" && record.outcome === "failure").length,
  };
}
