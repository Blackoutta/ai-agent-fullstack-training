import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
import type { ArchiveStore } from "./archive.js";
import type { PolicyCandidate } from "./data.js";
import type { JsonLogSink, LogRecord, SalesAudit, SalesRun } from "./sales-types.js";

export interface ObservabilityOptions {
  sink: JsonLogSink;
  archive: ArchiveStore;
  /** 当前已选中的证据，用于在模型请求前的上下文快照里带上引用。 */
  selectedEvidence?: () => PolicyCandidate[];
}

/** 工具实现与参数 Schema 的版本，和外部接口 Schema 分开记录。 */
const TOOL_VERSIONS: Record<string, string> = {
  get_customer_profile: "customer-profile-tool-v1",
  search_sales_policy: "policy-search-tool-v2",
  get_service_catalog: "service-catalog-tool-v1",
};

/** 关联字段由后端创建的 run 带入，扩展与运行入口共用同一个构造函数。 */
export function buildRecord(run: SalesRun, data: Record<string, unknown>): LogRecord {
  return {
    timestamp: new Date().toISOString(),
    service: "sales-agent",
    run_id: run.runId,
    request_id: run.requestId,
    // 审计信息：租户、操作人、访问对象、策略版本都要有来源，不能事后靠猜。
    tenant_id: run.tenantId,
    operator_id: run.salesId,
    session_id: run.trace.sessionId,
    trace_platform: run.trace.platform,
    trace_id: run.trace.traceId,
    parent_span_id: run.trace.parentSpanId,
    replay_of: run.replayOf ?? null,
    ...data,
  } as LogRecord;
}

/**
 * 销售问答的观测扩展：由 SDK 加载，监听模型与工具生命周期事件，
 * 以及业务工具通过 pi.events 发出的自定义事件，统一写成结构化 JSONL。
 *
 * 关联字段（运行编号、请求编号、平台 Trace ID）由后端创建的 run 带入闭包，
 * 不放在共享的全局变量里，并发请求之间不会串号。
 */
export function createSalesObservability(run: SalesRun, options: ObservabilityOptions) {
  return (pi: ExtensionAPI) => {
    const emit = (data: Record<string, unknown>) => options.sink.write(buildRecord(run, data));

    let attempt = 0;
    let turnIndex = 0;
    let providerSeq = 0;
    let providerStartedAt = 0;
    let currentContextRef: string | null = null;
    const firstChunkMs = new Map<number, number>();

    pi.on("agent_start", () => {
      attempt += 1;
      emit({
        event: "run.attempt_started",
        attempt,
        question: run.question,
        customer_id: run.customerId,
        business_time: run.businessTime,
        evidence_policy: run.evidencePolicy,
        prompt_version: run.promptVersion,
        prompt_hash: run.promptHash,
      });
    });

    pi.on("turn_start", () => {
      turnIndex += 1;
    });

    // 模型请求前保存实际 payload：这是“模型真正收到什么”的依据，
    // 不能等生成结束再按 session 状态反推。
    pi.on("before_provider_request", async ({ payload }) => {
      providerSeq += 1;
      providerStartedAt = performance.now();
      const ref = await options.archive.put(run.runId, "context", {
        phase: "provider_request",
        provider_request_seq: providerSeq,
        turn_index: turnIndex,
        payload,
      });
      currentContextRef = ref;
      const selected = options.selectedEvidence?.() ?? [];
      const summary = summarizePayload(payload);
      emit({
        event: "context.snapshot",
        phase: "provider_request",
        provider_request_seq: providerSeq,
        turn_index: turnIndex,
        message_count: summary.payload_message_count,
        selected_ids: selected.map((item) => item.id),
        context_refs: selected.map((item) => `${item.id}@${item.version}`),
        raw_ref: ref,
      });
      emit({
        event: "model.request.started",
        provider_request_seq: providerSeq,
        evidence_policy: run.evidencePolicy,
        context_ref: ref,
        ...summary,
      });
    });

    pi.on("after_provider_response", ({ status, headers }) => {
      emit({
        event: "model.response.received",
        provider_request_seq: providerSeq,
        http_status: status,
        // 这是收到响应头的时间，不等于首 Token，也不等于整次生成耗时。
        ttfb_ms: Math.round((performance.now() - providerStartedAt) * 100) / 100,
        provider_request_id: headers["x-request-id"] ?? headers["request-id"] ?? null,
      });
    });

    pi.on("message_update", ({ message }) => {
      if (message.role !== "assistant") return;
      if (firstChunkMs.has(message.timestamp)) return;
      firstChunkMs.set(message.timestamp, Math.max(0, Date.now() - message.timestamp));
    });

    pi.on("message_end", ({ message }) => {
      if (message.role !== "assistant") return;
      const usage = message.usage;
      const firstChunk = firstChunkMs.get(message.timestamp) ?? null;
      firstChunkMs.delete(message.timestamp);
      emit({
        event: "model.message.completed",
        // 用于和平台侧记录去重；服务没有返回编号时用本地请求序号。
        model_call_id: message.responseId ?? `model-${providerSeq}`,
        provider_request_seq: providerSeq || null,
        model: message.model,
        response_model: message.responseModel ?? null,
        provider_request_id: message.responseId ?? null,
        prompt_version: run.promptVersion,
        prompt_hash: run.promptHash,
        evidence_policy: run.evidencePolicy,
        context_ref: currentContextRef,
        stop_reason: message.stopReason,
        error_reason: message.errorMessage ?? null,
        // 费用口径：SDK 按内置价格表计算，未返回用量时保留 null，不填 0。
        usage_source: usage ? "pi_sdk" : "unknown",
        input_tokens: usage?.input ?? null,
        output_tokens: usage?.output ?? null,
        reasoning_tokens: usage?.reasoning ?? null,
        cache_read_tokens: usage?.cacheRead ?? null,
        total_tokens: usage?.totalTokens ?? null,
        cost_usd: usage?.cost?.total ?? null,
        // 测量范围分开写：整次调用耗时来自 SDK；首个流式分片可能是 thinking。
        duration_scope: "model",
        duration_ms: message.durationMs ?? null,
        first_chunk_ms: firstChunk,
        output_preview: textOf(message.content).slice(0, 240),
        content_types: [...new Set(message.content.map((part) => part.type))],
      });
    });

    pi.on("tool_execution_start", (event) => {
      emit({
        event: "tool.call.started",
        tool_call_id: event.toolCallId,
        tool_name: event.toolName,
        tool_version: TOOL_VERSIONS[event.toolName] ?? "unknown",
        customer_id: run.customerId,
        tool_arguments: event.args,
      });
    });

    pi.on("tool_execution_end", (event) => {
      emit({
        event: "tool.call.finished",
        outcome: event.isError ? "failure" : "success",
        tool_call_id: event.toolCallId,
        tool_name: event.toolName,
        tool_version: TOOL_VERSIONS[event.toolName] ?? "unknown",
        customer_id: run.customerId,
        execution_ms: event.durationMs ?? null,
        result_summary: summarize(event.result),
      });
    });

    pi.on("agent_end", (event) => {
      emit({
        event: "run.attempt_finished",
        attempt,
        message_count: event.messages.length,
        // 每个 provider 请求都单独记过；这里给出本次运行实际发出的 HTTP 请求数。
        provider_requests: providerSeq,
      });
    });

    // 业务自定义事件：授权决定、接口访问、证据整理、上下文构建。
    pi.events.on("sales:audit", (data) => {
      const audit = data as SalesAudit;
      if (audit.runId !== run.runId) return;
      emit({
        event: audit.action,
        outcome: audit.outcome ?? "unknown",
        tool_call_id: audit.toolCallId ?? null,
        customer_id: audit.customerId ?? null,
        authorization: audit.authorization ?? null,
        policy_version: audit.policyVersion ?? null,
        http_method: audit.method ?? null,
        http_path: audit.path ?? null,
        http_status: audit.status ?? null,
        // 业务 HTTP 记录的耗时写明范围；证据整理、上下文构建没有接口耗时，不补 duration 字段。
        ...(audit.action.endsWith("http_request")
          ? { duration_scope: "http", duration_ms: audit.durationMs ?? null }
          : {}),
        error_type: audit.errorType ?? null,
        raw_ref: audit.rawRef ?? null,
        candidate_ids: audit.candidateIds ?? null,
        selected_ids: audit.selected ?? null,
        excluded: audit.excluded ?? null,
        context_refs: audit.contextRefs ?? null,
        selection_rule: audit.selectionRule ?? null,
        validity_check_applied: audit.validityCheckApplied ?? null,
        business_time: audit.businessTime ?? null,
      });
    });
  };
}

/** 大段结果不进普通日志，只留摘要和归档引用。 */
function summarize(result: unknown): string {
  const content = (result as { content?: Array<{ type: string; text?: string }> })?.content ?? [];
  const text = content
    .map((part) => (part.type === "text" ? (part.text ?? "") : `[${part.type}]`))
    .join(" ");
  return text.length > 160 ? `${text.slice(0, 160)}...` : text;
}

function textOf(content: Array<{ type: string; text?: string }>): string {
  return content.map((part) => (part.type === "text" ? (part.text ?? "") : "")).join("");
}

function summarizePayload(payload: unknown): { payload_bytes: number; payload_message_count: number | null } {
  let bytes = 0;
  let messageCount: number | null = null;
  try {
    bytes = Buffer.byteLength(JSON.stringify(payload) ?? "", "utf8");
  } catch {
    bytes = 0;
  }
  const value = payload as { messages?: unknown } | null;
  if (value && Array.isArray(value.messages)) messageCount = value.messages.length;
  if (Array.isArray(payload)) messageCount = payload.length;
  return { payload_bytes: bytes, payload_message_count: messageCount };
}
