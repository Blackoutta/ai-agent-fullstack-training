import { createServer, type Server } from "node:http";
import { CUSTOMERS, POLICIES, SERVICES, SLOW_CUSTOMER_IDS } from "./data.js";

export interface MockServices {
  baseUrl: string;
  close(): Promise<void>;
  /** 记录服务端收到的请求，用于核对“工具真的访问了接口”。 */
  requests: Array<{ method: string; path: string; at: string }>;
}

const SERVICE_TOKEN = "demo-service-token";

/**
 * 本机模拟 CRM、知识库和服务目录。工具用真实 fetch 访问它们，
 * 这样接口耗时、状态码、超时和原始返回都是真的，不是打桩函数返回值。
 */
export async function startMockServices(host: string, port: number): Promise<MockServices> {
  const requests: MockServices["requests"] = [];

  const server: Server = createServer((req, res) => {
    const url = new URL(req.url ?? "/", `http://${host}:${port}`);
    const path = url.pathname;
    // 记录带查询串的完整路径，用来核对“查询条件真的发出去了”，而不只是看路由。
    requests.push({ method: req.method ?? "GET", path: `${path}${url.search}`, at: new Date().toISOString() });

    const send = (status: number, body: unknown) => {
      res.writeHead(status, { "content-type": "application/json; charset=utf8" });
      res.end(JSON.stringify(body));
    };

    if (path === "/healthz") return send(200, { ok: true });

    if (req.headers.authorization !== `Bearer ${SERVICE_TOKEN}`) {
      return send(401, { error: "service_token_missing" });
    }

    const customerMatch = path.match(/^\/api\/customers\/([^/]+)$/);
    if (customerMatch && req.method === "GET") {
      const customerId = decodeURIComponent(customerMatch[1]!);
      const customer = CUSTOMERS[customerId];
      if (!customer) return send(404, { error: "customer_not_found", customer_id: customerId });
      // C-7003 慢响应，用来产生“状态码为空但耗时和错误类型保留”的记录。
      const delay = SLOW_CUSTOMER_IDS.has(customerId) ? 6000 : 40;
      setTimeout(() => send(200, customer), delay);
      return;
    }

    if (path === "/api/policies/search" && req.method === "GET") {
      const keyword = url.searchParams.get("keyword") ?? "";
      const hits = POLICIES.filter(
        (policy) =>
          policy.title.includes(keyword) ||
          policy.body.includes(keyword) ||
          keyword === "" ||
          keyword === "折扣",
      );
      // 知识库按相关性排序返回，新旧两版都在结果里。
      const candidates = [...hits].sort((a, b) => b.relevance - a.relevance);
      return send(200, { query: { keyword, business_time: url.searchParams.get("business_time") }, candidates });
    }

    const catalogMatch = path.match(/^\/api\/service-catalog\/([^/]+)$/);
    if (catalogMatch && req.method === "GET") {
      const productId = decodeURIComponent(catalogMatch[1]!);
      const items = SERVICES.filter((item) => item.productId === productId);
      if (items.length === 0) return send(404, { error: "product_not_found", product_id: productId });
      return send(200, { items });
    }

    send(404, { error: "route_not_found", path });
  });

  await new Promise<void>((resolveListen, rejectListen) => {
    server.once("error", rejectListen);
    server.listen(port, host, () => resolveListen());
  });

  return {
    baseUrl: `http://${host}:${port}`,
    requests,
    close: () =>
      new Promise<void>((resolveClose, rejectClose) => {
        server.close((error) => (error ? rejectClose(error) : resolveClose()));
      }),
  };
}

export const MOCK_SERVICE_TOKEN = SERVICE_TOKEN;
