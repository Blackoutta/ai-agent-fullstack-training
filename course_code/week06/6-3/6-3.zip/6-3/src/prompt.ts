import { createHash } from "node:crypto";

/** 销售回答规则。版本号对应具体内容，改一个字就要升一个版本，避免只写一个会被覆盖的文件名。 */
const PROMPT_BODIES: Record<string, string> = {
  "sales-answer-2026.2": `你是销售智能问答助手，服务企业内部销售。回答客户折扣与服务范围问题时遵守：
1. 先调用 get_customer_profile 确认客户的行业、区域与已购产品。
2. 再调用 search_sales_policy 获取折扣政策，只使用返回结果中的政策正文、版本与有效期。
3. 涉及服务范围时调用 get_service_catalog，明确标准服务包含什么、驻场支持需要什么条件，并注明服务目录版本。
4. 折扣必须给出具体百分比，并注明依据的政策编号与文档版本。
5. 返回结果里没有的政策不得凭记忆补充；检索结果里有政策时，按政策正文给出折扣并注明有效期；只有检索结果为空时才回答“无法确认”。
6. 不要输出客户编号以外的个人敏感信息，不要承诺审批范围之外的例外折扣。`,
};

export const DEFAULT_PROMPT_VERSION = "sales-answer-2026.2";

export interface PromptBundle {
  version: string;
  text: string;
  /** 内容指纹，让“Prompt 版本”能定位到具体内容。 */
  contentHash: string;
}

export function buildSalesPrompt(version = DEFAULT_PROMPT_VERSION): PromptBundle {
  const text = PROMPT_BODIES[version];
  if (!text) throw new Error(`prompt_version_unknown:${version}`);
  return {
    version,
    text,
    contentHash: createHash("sha256").update(text, "utf8").digest("hex").slice(0, 16),
  };
}
