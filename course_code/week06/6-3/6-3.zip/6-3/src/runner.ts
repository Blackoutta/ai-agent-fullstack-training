import { createAgentSession, DefaultResourceLoader, SessionManager } from "@earendil-works/pi-coding-agent";
import { createRequire } from "node:module";
import { buildSalesPrompt } from "./prompt.js";
import { createRunState } from "./run-state.js";
import { createCustomerProfileToolExtension } from "./customer-tool.js";
import { createPolicyToolsExtension } from "./policy-tools.js";
import { buildRecord, createSalesObservability } from "./observability.js";
import { reviewAnswer } from "./answer-review.js";
import { reasoningEffort } from "./model.js";
import type { SalesAnswer, SalesDependencies, SalesRun, ToolCallRecord } from "./sales-types.js";

const BUSINESS_TOOLS = ["get_customer_profile", "search_sales_policy", "get_service_catalog"];

// 官方插件以 TypeScript 源码发布，交给 pi 自带的扩展加载器编译，凭据从环境变量读取。
const LANGFUSE_EXTENSION_PATH = createRequire(import.meta.url).resolve(
  "@langfuse/pi-observability-plugin/src/index.ts",
);

/**
 * TypeScript 后端以 headless 方式驱动 pi：同一次请求加载业务工具、
 * 文件日志扩展和 Langfuse 扩展，记录对应的就是实际回答销售问题的执行过程。
 *
 * 与讲稿的两处差异：DefaultResourceLoader 的 agentDir 是必填项；
 * 扩展由 createAgentSession 随 resourceLoader 自动绑定，没有额外的 bindExtensions() 调用。
 */
export async function answerSalesQuestion(run: SalesRun, deps: SalesDependencies): Promise<SalesAnswer> {
  const state = createRunState();
  const prompt = buildSalesPrompt(run.promptVersion);
  const startedAt = performance.now();

  const resourceLoader = new DefaultResourceLoader({
    cwd: deps.resourceDirectory,
    // 指向项目内的空配置目录，不继承开发者机器上的个人扩展、技能和设置。
    agentDir: deps.agentDirectory,
    systemPrompt: prompt.text,
    noExtensions: true,
    noSkills: true,
    noPromptTemplates: true,
    noThemes: true,
    noContextFiles: true,
    // Langfuse 官方扩展：把模型与工具明细发到平台，并按环境变量里的父节点建立调用关系。
    additionalExtensionPaths: [LANGFUSE_EXTENSION_PATH],
    extensionFactories: [
      (pi) => createCustomerProfileToolExtension(run, { customerApi: deps.customerApi, tracer: deps.tracer }, state)(pi),
      (pi) =>
        createPolicyToolsExtension(
          run,
          {
            knowledgeBase: deps.knowledgeBase,
            serviceCatalog: deps.serviceCatalog,
            customerApi: deps.customerApi,
            tracer: deps.tracer,
            evidenceLimit: 1,
          },
          state,
        )(pi),
      (pi) =>
        createSalesObservability(run, {
          sink: deps.logSink,
          archive: deps.archive,
          selectedEvidence: () => state.evidence?.selected ?? [],
        })(pi),
    ],
  });
  await resourceLoader.reload();

  const { session } = await createAgentSession({
    modelRuntime: deps.modelRuntime,
    model: deps.model,
    resourceLoader,
    // 只开放业务工具，内置的读写与命令工具不参与本次问答。
    tools: BUSINESS_TOOLS,
    thinkingLevel: reasoningEffort(),
    sessionManager: SessionManager.inMemory(),
  });

  const byCall = new Map<string, ToolCallRecord>();
  const unsubscribe = session.subscribe((event) => {
    if (event.type === "tool_execution_start") {
      byCall.set(event.toolCallId, {
        toolCallId: event.toolCallId,
        toolName: event.toolName,
        args: (event.args ?? {}) as Record<string, unknown>,
        outcome: "failure",
        durationMs: null,
        resultSummary: "",
      });
      return;
    }
    if (event.type === "tool_execution_end") {
      const record = byCall.get(event.toolCallId);
      if (!record) return;
      record.outcome = event.isError ? "failure" : "success";
      record.durationMs = event.durationMs ?? null;
      record.resultSummary = textOf(event.result).slice(0, 400);
      record.rawRef = (event.result as { details?: { rawRef?: string } })?.details?.rawRef ?? undefined;
      state.toolCalls.push(record);
    }
  });

  deps.logSink.write(
    buildRecord(run, {
      event: "run.started",
      question: run.question,
      customer_id: run.customerId,
      business_time: run.businessTime,
      evidence_policy: run.evidencePolicy,
      prompt_version: prompt.version,
      prompt_hash: prompt.contentHash,
      model_alias: deps.model.id,
      agent_dir: deps.agentDirectory,
      resource_dir: deps.resourceDirectory,
    }),
  );

  try {
    await session.prompt(run.question);
    const text = session.getLastAssistantText() ?? "";

    const reviewSpan = deps.tracer.start("answer.review", {
      selected_ids: (state.evidence?.selected ?? []).map((item) => item.id),
      services: (state.services ?? []).map((item) => `${item.productId}@${item.version}`),
      business_time: run.businessTime,
    });
    const review = reviewAnswer(text, state, run);
    reviewSpan.end(
      {
        passed: review.passed,
        disposition: review.disposition,
        findings: review.findings.map((item) => ({ check: item.check, passed: item.passed })),
      },
      review.passed ? "default" : "error",
    );
    deps.logSink.write(
      buildRecord(run, {
        event: "answer.review",
        outcome: review.passed ? "success" : "failure",
        disposition: review.disposition,
        findings: review.findings.map((item) => ({ check: item.check, passed: item.passed })),
      }),
    );

    // 完整输出单独归档，日志只保留摘要与引用。
    const answerRef = await deps.archive.put(run.runId, "output", {
      text,
      review,
      prompt_version: prompt.version,
      prompt_hash: prompt.contentHash,
    });
    deps.logSink.write(
      buildRecord(run, {
        event: "answer.archived",
        outcome: "success",
        text_length: text.length,
        review_passed: review.passed,
        disposition: review.disposition,
        raw_ref: answerRef,
      }),
    );
    deps.logSink.write(
      buildRecord(run, {
        event: "run.finished",
        outcome: review.passed ? "success" : "failure",
        // 整次问答耗时：从提交问题到答案归档，包含所有模型与工具调用。
        duration_scope: "question",
        duration_ms: Math.round(performance.now() - startedAt),
        answer_ref: answerRef,
        review_disposition: review.disposition,
      }),
    );

    return {
      text,
      runId: run.runId,
      requestId: run.requestId,
      traceId: run.trace.traceId,
      toolCalls: state.toolCalls,
      review,
      delivery: review.disposition,
    };
  } finally {
    unsubscribe();
    session.dispose();
  }
}

function textOf(result: unknown): string {
  const content = (result as { content?: Array<{ type: string; text?: string }> })?.content ?? [];
  return content.map((part) => (part.type === "text" ? part.text ?? "" : `[${part.type}]`)).join(" ");
}
