import type { CustomerRecord, PolicyCandidate } from "./data.js";
import type { EvidenceDecision, EvidencePolicyName } from "./sales-types.js";

export interface EvidenceInput {
  candidates: PolicyCandidate[];
  customer: CustomerRecord | null;
  businessTime: string;
  policy: EvidencePolicyName;
  limit: number;
}

const byRelevanceDesc = (a: PolicyCandidate, b: PolicyCandidate) => b.relevance - a.relevance;

function isWithinValidity(policy: PolicyCandidate, businessTime: string): boolean {
  const day = businessTime.slice(0, 10);
  return policy.validFrom <= day && day <= policy.validUntil;
}

function appliesToCustomer(policy: PolicyCandidate, customer: CustomerRecord): boolean {
  return (
    policy.appliesTo.industries.includes(customer.industry) &&
    policy.appliesTo.regions.includes(customer.region) &&
    customer.products.some((product) => policy.appliesTo.products.includes(product))
  );
}

/**
 * 证据整理：决定哪些检索结果可以进入模型请求。
 *
 * relevance-first-v1 是缺陷版本，按相关性分数排序后直接截断，不校验有效期和适用条件。
 * validity-first-v2 是修复版本，先按业务条件、权限和有效期校验，再排序截断。
 */
export function selectEvidence(input: EvidenceInput): EvidenceDecision {
  const limit = input.limit;
  const excluded: EvidenceDecision["excluded"] = [];

  if (input.policy === "relevance-first-v1") {
    const ranked = [...input.candidates].sort(byRelevanceDesc);
    const selected = ranked.slice(0, limit);
    for (const policy of ranked.slice(limit)) {
      excluded.push({ id: policy.id, reason: "截断在相关性第一名之后" });
    }
    return {
      policy: input.policy,
      businessTime: input.businessTime,
      selected,
      excluded,
      limit,
      // 旧版的真实行为：只按相关性截断，有效期和适用条件都没有执行。
      selectionRule: "relevance_top_1",
      validityCheckApplied: false,
      applicabilityCheckApplied: false,
    };
  }

  const checked: PolicyCandidate[] = [];
  for (const policy of [...input.candidates].sort(byRelevanceDesc)) {
    if (!isWithinValidity(policy, input.businessTime)) {
      excluded.push({ id: policy.id, reason: `有效期 ${policy.validFrom}~${policy.validUntil} 不覆盖业务时间 ${input.businessTime.slice(0, 10)}` });
      continue;
    }
    if (!input.customer) {
      excluded.push({ id: policy.id, reason: "缺少客户条件，无法确认适用性" });
      continue;
    }
    if (!appliesToCustomer(policy, input.customer)) {
      excluded.push({ id: policy.id, reason: `适用条件与客户 ${input.customer.region}/${input.customer.industry} 不匹配` });
      continue;
    }
    checked.push(policy);
  }
  const selected = checked.slice(0, limit);
  for (const policy of checked.slice(limit)) {
    excluded.push({ id: policy.id, reason: "校验通过但被条数上限截断" });
  }
  return {
    policy: input.policy,
    businessTime: input.businessTime,
    selected,
    excluded,
    limit,
    selectionRule: "validity_then_relevance",
    validityCheckApplied: true,
    applicabilityCheckApplied: true,
  };
}
