import type { CustomerRecord } from "./data.js";
import type { RunState } from "./run-state.js";
import type { BusinessTracer, CustomerApi, SalesAudit, SalesRun } from "./sales-types.js";

export interface ProfileLoaderDeps {
  customerApi: CustomerApi;
  tracer: BusinessTracer;
  emit(audit: SalesAudit): void;
}

/**
 * 查询客户资料：授权检查与 CRM 请求只在这里发生一次。
 *
 * 模型可能把 get_customer_profile 和 search_sales_policy 放在同一轮并行调用，
 * 两个工具都依赖客户条件。这里用同一个 Promise 合并重复查询，
 * 日志里就只会有一次授权记录和一次 HTTP 记录，不会看起来像重试了两次。
 */
export async function ensureCustomerProfile(
  run: SalesRun,
  deps: ProfileLoaderDeps,
  state: RunState,
  customerId: string,
  toolCallId: string,
  signal?: AbortSignal,
): Promise<CustomerRecord> {
  if (state.profile && state.profileCustomerId === customerId) return state.profile;

  const existing = state.profileInFlight.get(customerId);
  if (existing) return existing;

  const task = load();
  state.profileInFlight.set(customerId, task);
  try {
    return await task;
  } finally {
    state.profileInFlight.delete(customerId);
  }

  async function load(): Promise<CustomerRecord> {
    const span = deps.tracer.start("customer.profile", { customer_id: customerId, tool_call_id: toolCallId });

    const allowed = await deps.customerApi.canReadCustomer(run, customerId);
    deps.emit({
      runId: run.runId,
      action: "customer.authorization",
      toolCallId,
      customerId,
      authorization: allowed ? "allow" : "deny",
      policyVersion: deps.customerApi.authzPolicyVersion,
      outcome: allowed ? "success" : "failure",
    });
    if (!allowed) {
      span.end({ authorization: "deny", customer_id: customerId }, "error");
      throw new Error("customer_access_denied");
    }

    const outcome = await deps.customerApi.getProfile(run, customerId, signal);
    deps.emit({
      runId: run.runId,
      action: "customer.http_request",
      toolCallId,
      customerId,
      method: outcome.method,
      path: outcome.path,
      status: outcome.status,
      durationMs: outcome.durationMs,
      outcome: outcome.ok ? "success" : "failure",
      errorType: outcome.errorType,
      rawRef: outcome.rawRef ?? null,
    });
    if (!outcome.ok || !outcome.body) {
      span.end(
        {
          authorization: "allow",
          outcome: "failure",
          http_status: outcome.status,
          duration_ms: outcome.durationMs,
          error_type: outcome.errorType,
        },
        "error",
      );
      throw new Error(`crm_request_failed:${outcome.errorType ?? `http_${outcome.status}`}`);
    }

    // 只有本次运行的目标客户才能成为证据筛选的客户条件；
    // 模型传入别的客户编号时，查询结果只回给这次工具调用，不写进共享状态。
    if (customerId === run.customerId) {
      state.profile = outcome.body;
      state.profileCustomerId = customerId;
    }
    span.end({
      authorization: "allow",
      outcome: "success",
      http_status: outcome.status,
      duration_ms: outcome.durationMs,
      raw_ref: outcome.rawRef ?? null,
      customer_id: customerId,
    });
    return outcome.body;
  }
}
