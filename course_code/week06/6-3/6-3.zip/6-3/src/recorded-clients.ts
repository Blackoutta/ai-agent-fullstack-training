import { decodePolicyCandidates, decodeProfile, decodeServiceItems } from "./clients.js";
import { CUSTOMERS, SALES_SCOPE, type PolicyCandidate } from "./data.js";
import type { ReplayBundle, RawResult } from "./replay-bundle.js";
import type { CustomerApi, HttpOutcome, KnowledgeBase, PolicySearchQuery, ServiceCatalog } from "./sales-types.js";
import { bundleProfile, bundleServiceItems } from "./replay-bundle.js";

/**
 * 录制结果客户端：按接口名、参数、Schema 版本和调用次序匹配归档返回。
 *
 * 匹配不上时明确报告材料不匹配或覆盖不足，保留现场，不悄悄访问真实接口，
 * 否则这次运行的条件就不再是声明的固定条件。
 */
class MaterialMismatch extends Error {
  readonly detail: Record<string, unknown>;
  constructor(reason: string, detail: Record<string, unknown>) {
    super(`${reason}:${JSON.stringify(detail)}`);
    this.name = "MaterialMismatch";
    this.detail = detail;
  }
}

const stableKey = (params: Record<string, unknown>) =>
  JSON.stringify(Object.keys(params).sort().map((key) => [key, params[key]]));

class RecordingMatcher {
  private readonly used = new Map<string, number>();
  constructor(private readonly bundle: ReplayBundle) {}

  private candidatesFor(iface: string): RawResult[] {
    return this.bundle.rawResults.filter((item) => item.interface === iface);
  }

  match(iface: string, params: Record<string, unknown>): RawResult {
    const key = `${iface}|${stableKey(params)}`;
    const occurrence = (this.used.get(key) ?? 0) + 1;
    this.used.set(key, occurrence);
    const hits = this.candidatesFor(iface).filter((item) => stableKey(item.params) === stableKey(params));
    if (hits.length === 0) {
      throw new MaterialMismatch("replay_material_mismatch", {
        interface: iface,
        params,
        available: this.candidatesFor(iface).map((item) => item.params),
      });
    }
    const chosen = hits[occurrence - 1];
    if (!chosen) {
      throw new MaterialMismatch("replay_coverage_missing", {
        interface: iface,
        params,
        occurrence,
        recorded_times: hits.length,
      });
    }
    return chosen;
  }
}

function toOutcome<T>(record: RawResult, body: T | null, path: string): HttpOutcome<T> {
  return {
    ok: record.status !== null && record.status >= 200 && record.status < 300,
    status: record.status,
    body,
    // 录制结果没有真实网络往返，耗时为 0 不能当作接口性能。
    durationMs: 0,
    errorType: null,
    method: "GET",
    path,
    rawRef: record.ref,
  };
}

export function createRecordedCustomerApi(bundle: ReplayBundle): CustomerApi {
  const matcher = new RecordingMatcher(bundle);
  return {
    source: "recorded",
    authzPolicyVersion: bundle.versions.authz_policy_version,
    schemaVersion: bundle.versions.crm_schema,
    async canReadCustomer(run, customerId) {
      // 读历史资料仍然执行当前授权，不因为材料是归档就放行。
      const scope = SALES_SCOPE[run.salesId];
      const customer = CUSTOMERS[customerId];
      if (!scope || !customer) return false;
      return scope.regions.includes(customer.region) && scope.industries.includes(customer.industry);
    },
    async getProfile(_run, customerId) {
      const record = matcher.match("crm.get_customer_profile", { customerId });
      const ok = record.status !== null && record.status >= 200 && record.status < 300;
      // 归档保存的是接口原始返回；进入工具前仍按同一套规则解析，不能绕过字段控制。
      const body = ok ? decodeProfile(record.body, customerId) : null;
      return toOutcome(record, body, `/api/customers/${encodeURIComponent(customerId)}`);
    },
  };
}

export function createRecordedKnowledgeBase(bundle: ReplayBundle): KnowledgeBase {
  const matcher = new RecordingMatcher(bundle);
  return {
    source: "recorded",
    authzPolicyVersion: bundle.versions.authz_policy_version,
    schemaVersion: bundle.versions.kb_schema,
    async searchPolicies(_run, query: PolicySearchQuery) {
      const record = matcher.match("kb.search_sales_policy", {
        customerId: query.customerId,
        keyword: query.keyword,
        businessTime: query.businessTime,
      });
      const body = record.body as { candidates?: PolicyCandidate[] };
      const path =
        `/api/policies/search?customer_id=${encodeURIComponent(query.customerId)}` +
        `&keyword=${encodeURIComponent(query.keyword)}&business_time=${encodeURIComponent(query.businessTime)}`;
      const ok = record.status !== null && record.status >= 200 && record.status < 300;
      return toOutcome(record, ok ? decodePolicyCandidates(body) : null, path);
    },
  };
}

export function createRecordedServiceCatalog(bundle: ReplayBundle): ServiceCatalog {
  const items = bundleServiceItems(bundle);
  const profile = bundleProfile(bundle);
  return {
    source: "recorded",
    authzPolicyVersion: bundle.versions.authz_policy_version,
    schemaVersion: bundle.versions.catalog_schema,
    async getServices(_run, productId) {
      const matched = items.filter((item) => item.productId === productId);
      if (matched.length === 0) {
        throw new MaterialMismatch("replay_material_mismatch", {
          interface: "catalog.get_service_catalog",
          params: { productId },
          recorded_products: items.map((item) => item.productId),
          profile_products: profile?.products ?? [],
        });
      }
      const record = bundle.rawResults.find((item) => item.interface === "catalog.get_service_catalog");
      if (!record) throw new MaterialMismatch("replay_coverage_missing", { interface: "catalog.get_service_catalog" });
      const ok = record.status !== null && record.status >= 200 && record.status < 300;
      return toOutcome(
        record,
        ok ? decodeServiceItems({ items: matched }) : null,
        `/api/service-catalog/${encodeURIComponent(productId)}`,
      );
    },
  };
}

export { MaterialMismatch };
