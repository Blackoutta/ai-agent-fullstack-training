import { LangfuseSpanProcessor } from "@langfuse/otel";
import { LangfuseOtelSpanAttributes, setLangfuseTracerProvider, startObservation } from "@langfuse/tracing";
import { AlwaysOnSampler, NodeTracerProvider } from "@opentelemetry/sdk-trace-node";
import { TraceFlags } from "@opentelemetry/api";
import type { BusinessTracer, TraceRef } from "./sales-types.js";

export interface HostTraceOptions {
  name: string;
  input: Record<string, unknown>;
  sessionId: string;
  runId: string;
  requestId: string;
  /** Replay 运行指向原失败运行，平台侧也要能看出这层关系。 */
  replayOf?: string;
  userId?: string;
  tags?: string[];
}

export interface HostTrace {
  ref: TraceRef;
  /** 业务子节点埋点：工具内部接口访问与证据整理挂在本请求父节点下。 */
  tracer: BusinessTracer;
  end(output: Record<string, unknown>): Promise<void>;
}

/** 观测平台未配置时的空实现，业务流程照常跑。 */
export const NO_HOST_TRACE: HostTrace = {
  ref: { traceId: "unknown", parentSpanId: "unknown", sessionId: "unknown", platform: "none" },
  tracer: { start: () => ({ end: () => {} }) },
  async end() {},
};

/**
 * 为本次业务请求建立宿主父节点，并把编号交给 pi 的 Langfuse 扩展。
 *
 * 扩展通过 LANGFUSE_PI_PARENT_TRACE_ID / _SPAN_ID 环境变量继承父节点，
 * 在加载扩展时读取一次，因此必须在创建会话之前设置。
 * 文件日志与平台记录用的就是这里的同一组编号。
 */
export function beginHostTrace(options: HostTraceOptions): HostTrace {
  const publicKey = process.env.LANGFUSE_PUBLIC_KEY?.trim();
  const secretKey = process.env.LANGFUSE_SECRET_KEY?.trim();
  if (!publicKey || !secretKey) return NO_HOST_TRACE;

  const baseUrl = (process.env.LANGFUSE_BASE_URL ?? process.env.LANGFUSE_HOST ?? "http://127.0.0.1:3000").replace(
    /\/$/,
    "",
  );
  const environment = process.env.LANGFUSE_TRACING_ENVIRONMENT?.trim() || "development";

  const processor = new LangfuseSpanProcessor({
    publicKey,
    secretKey,
    baseUrl,
    environment,
    release: "6-3-sales-agent-demo",
  });

  // 父节点编号在 span 创建时由 processor 回调交出，这里同时给整条 trace 打上业务字段。
  const captured: { root: { traceId: string; spanId: string } | null } = { root: null };
  const traceAttributes: Record<string, string | string[]> = {
    [LangfuseOtelSpanAttributes.TRACE_NAME]: options.name,
    [LangfuseOtelSpanAttributes.TRACE_SESSION_ID]: options.sessionId,
    [LangfuseOtelSpanAttributes.TRACE_TAGS]: ["sales-agent", "6-3", ...(options.tags ?? [])],
    "langfuse.trace.metadata.run_id": options.runId,
    "langfuse.trace.metadata.request_id": options.requestId,
    ...(options.replayOf ? { "langfuse.trace.metadata.replay_of": options.replayOf } : {}),
    ...(options.userId ? { [LangfuseOtelSpanAttributes.TRACE_USER_ID]: options.userId } : {}),
  };
  const baseOnStart = processor.onStart.bind(processor);
  processor.onStart = (span, parentContext) => {
    baseOnStart(span, parentContext);
    span.setAttributes(traceAttributes);
    if (!captured.root) captured.root = { traceId: span.spanContext().traceId, spanId: span.spanContext().spanId };
  };

  const provider = new NodeTracerProvider({ spanProcessors: [processor], sampler: new AlwaysOnSampler() });
  setLangfuseTracerProvider(provider);

  const root = startObservation(
    options.name,
    { input: options.input, metadata: { run_id: options.runId, request_id: options.requestId, replay_of: options.replayOf ?? null } },
    { asType: "span" },
  );
  const rootContext = captured.root;
  if (!rootContext) throw new Error("langfuse_root_span_context_unavailable");
  const parentSpanContext = {
    traceId: rootContext.traceId,
    spanId: rootContext.spanId,
    traceFlags: TraceFlags.SAMPLED,
    isRemote: false,
  };

  // 必须在 createAgentSession 之前写入，pi 的扩展在绑定阶段读取。
  process.env.LANGFUSE_PI_PARENT_TRACE_ID = rootContext.traceId;
  process.env.LANGFUSE_PI_PARENT_SPAN_ID = rootContext.spanId;
  process.env.LANGFUSE_PI_PARENT_SESSION_ID = options.sessionId;
  process.env.LANGFUSE_PI_PARENT_DEPTH = "1";

  return {
    ref: {
      traceId: rootContext.traceId,
      parentSpanId: rootContext.spanId,
      sessionId: options.sessionId,
      platform: "langfuse",
    },
    tracer: {
      start(name, input) {
        const child = startObservation(
          name,
          { input, metadata: { run_id: options.runId } },
          { asType: "span", parentSpanContext },
        );
        return {
          end(output, level = "default") {
            child.update({ output, level: level === "error" ? "ERROR" : "DEFAULT" });
            child.end();
          },
        };
      },
    },
    async end(output) {
      root.update({ output });
      root.end();
      await processor.forceFlush();
    },
  };
}
