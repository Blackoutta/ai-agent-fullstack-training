import type { RunState } from "./run-state.js";
import type { AnswerReview, SalesRun } from "./sales-types.js";

const PERCENT = /(\d+(?:\.\d+)?)\s*%/g;

/**
 * 答案审阅：业务控制，不依赖“模型已经停止”等于“业务已经完成”。
 *
 * 检查回答里的折扣数字、引用是否来自本次选中且有效的证据，
 * 以及服务范围陈述是否与产品目录一致。
 */
export function reviewAnswer(text: string, state: RunState, run: SalesRun): AnswerReview {
  const findings: AnswerReview["findings"] = [];
  const selected = state.evidence?.selected ?? [];

  findings.push({
    check: "有可用证据",
    passed: selected.length > 0,
    detail: selected.length
      ? `证据整理策略 ${state.evidence?.policy}，选中 ${selected.map((item) => item.id).join("/")}`
      : "没有通过校验的政策进入上下文，不能给出折扣数字",
  });

  const mentioned = [...text.matchAll(PERCENT)].map((match) => Number(match[1]));
  const allowedNumbers = new Set(selected.map((policy) => policy.maxDiscountPercent));
  const unsupported = mentioned.filter((value) => !allowedNumbers.has(value));
  findings.push({
    check: "折扣数字有有效依据",
    passed: mentioned.length > 0 && unsupported.length === 0,
    detail: mentioned.length
      ? `回答提到 ${mentioned.join("/")}%，选中政策允许 ${[...allowedNumbers].join("/")}%${
          unsupported.length ? `，无依据：${unsupported.join("/")}%` : ""
        }`
      : "回答未给出折扣数字",
  });

  const cited = selected.some((policy) => text.includes(policy.id) || text.includes(policy.version));
  findings.push({
    check: "引用指向选中政策",
    passed: selected.length > 0 && cited,
    detail: cited
      ? `引用了 ${selected.map((policy) => `${policy.id}@${policy.version}`).join(" ")}`
      : `未引用 ${selected.map((policy) => policy.id).join("/")} 任一版本`,
  });

  // 审阅是独立的业务控制，不信任证据整理环节的结论：直接按业务时间复核有效期。
  const day = run.businessTime.slice(0, 10);
  const expired = selected.filter((policy) => !(policy.validFrom <= day && day <= policy.validUntil));
  findings.push({
    check: "引用政策在业务时间有效",
    passed: selected.length > 0 && expired.length === 0,
    detail: expired.length
      ? `${expired.map((policy) => `${policy.id} 有效期 ${policy.validFrom}~${policy.validUntil}`).join("；")} 不覆盖业务时间 ${day}`
      : `选中政策在业务时间 ${day} 内有效`,
  });

  const onsite = state.services?.[0];
  if (onsite) {
    const mentionsOnsite = text.includes("驻场");
    const saysExtra = /另签|另行|需额外|不包含|不含|不在标准服务|标准服务不含/.test(text);
    const consistent = onsite.includesOnsiteSupport ? !saysExtra : saysExtra;
    // 服务结论也要能追溯到目录版本，不能只有一句“不含驻场”。
    const citesCatalog = text.includes(onsite.version) || text.includes(onsite.productId);
    findings.push({
      check: "服务范围陈述与目录一致",
      passed: mentionsOnsite && consistent && citesCatalog,
      detail: `目录：${onsite.onsiteCondition}（${onsite.version}）；回答${mentionsOnsite ? "提到驻场并说明" : "未提到"}${
        onsite.includesOnsiteSupport ? "包含驻场" : "驻场不在标准服务内"
      }${citesCatalog ? "，已引用目录版本" : "，未引用目录版本"}`,
    });
  } else {
    findings.push({
      check: "服务范围陈述与目录一致",
      passed: false,
      detail: "本次运行未取得服务目录结果，无法核对驻场支持范围",
    });
  }

  const passed = findings.every((item) => item.passed);
  const disposition: AnswerReview["disposition"] = !passed
    ? selected.length === 0
      ? "unknown"
      : "recheck"
    : "return";

  return { passed, findings, disposition };
}

export function describeReview(review: AnswerReview): string {
  return review.findings.map((item) => `${item.passed ? "通过" : "未通过"}｜${item.check}：${item.detail}`).join("\n");
}
