import type { CustomerRecord, PolicyCandidate, ServiceItem } from "./data.js";
import type { EvidenceDecision, ToolCallRecord } from "./sales-types.js";

/** 一次运行内各工具共享的状态，避免同一客户重复访问 CRM，也便于审阅取证据。 */
export interface RunState {
  profile: CustomerRecord | null;
  profileCustomerId: string | null;
  /** 同一客户正在查询时，其它工具等待同一个 Promise，避免并发重复请求 CRM。 */
  profileInFlight: Map<string, Promise<CustomerRecord>>;
  /** 检索返回的原始候选，进入筛选前完整保留。 */
  candidates: PolicyCandidate[];
  evidence: EvidenceDecision | null;
  services: ServiceItem[] | null;
  toolCalls: ToolCallRecord[];
}

export function createRunState(): RunState {
  return {
    profile: null,
    profileCustomerId: null,
    profileInFlight: new Map(),
    candidates: [],
    evidence: null,
    services: null,
    toolCalls: [],
  };
}
