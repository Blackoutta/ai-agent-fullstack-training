import { answerSalesQuestion } from "./src/runner.js";
import { startRuntime, SCHEMA_VERSIONS } from "./src/runtime.js";
import { readJsonl, selectByRun, summarizeUsage } from "./src/log-query.js";
import { selectEvidence } from "./src/evidence.js";
import {
  bundleProfile,
  bundleServiceItems,
  loadBundle,
  writeBundle,
  type ReplayAcceptance,
  type ReplayBundle,
  type ReplayFailure,
} from "./src/replay-bundle.js";
import {
  createRecordedCustomerApi,
  createRecordedKnowledgeBase,
  createRecordedServiceCatalog,
  MaterialMismatch,
} from "./src/recorded-clients.js";
import { waitForTraceTree } from "./src/langfuse-api.js";
import { heading, table, writeReport } from "./src/report.js";
import { buildSalesPrompt } from "./src/prompt.js";
import { POLICIES, type PolicyCandidate } from "./src/data.js";
import type { EvidenceDecision, EvidenceSelectionRule, SalesAnswer } from "./src/sales-types.js";

/**
 * 演示三：Replay。在同一个 pi SDK 入口下复现问题、验证修复。
 *
 * 顺序按讲稿 4.2 → 4.6：
 * 留材料并校验版本 → 旧版复现 → 修复后筛选 → 边界 → 完整问答两层验收
 * → 真实依赖集成复测 → 通过后才加入回归集。
 */
const QUESTION = "客户 C-1001 当前最高能享受多少折扣？报价是否包含驻场支持？";

const ACCEPTANCE: ReplayAcceptance = {
  discount_percent: 10,
  forbidden_discount_percent: 15,
  required_policy: "P-current",
  required_service_version: "catalog-2026.1",
  onsite_in_standard_service: false,
};

const runtime = await startRuntime();
const prompt = buildSalesPrompt();
const lines: string[] = [];

console.log("演示三 · Replay：固定条件 → 复现旧问题 → 验证修复\n");
console.log("第 1 步：跑一次真实问答，留下失败任务和复现材料");
const first = await runtime.beginRun({
  question: QUESTION,
  customerId: "C-1001",
  evidencePolicy: "relevance-first-v1",
  label: "replay-source",
});
const failing = await answerSalesQuestion(first.run, first.deps);
await first.host.end({ final_answer: failing.text, delivery: failing.delivery });
await runtime.sink.flush();

const sourceRecords = selectByRun((await readJsonl(runtime.logFile)).records, first.run.runId);
const sourceSnapshot = [...sourceRecords]
  .filter((record) => record.event === "context.snapshot" && record.phase === "provider_request")
  .at(-1);
const contextMessages = sourceSnapshot?.raw_ref ? JSON.parse(await runtime.archive.read(String(sourceSnapshot.raw_ref))) : null;
const sourceEvidenceRecord = sourceRecords.find((record) => record.event === "evidence.selection");
const candidateIds = (sourceEvidenceRecord?.candidate_ids as string[] | undefined) ?? [];
const selectedIds = (sourceEvidenceRecord?.selected_ids as string[] | undefined) ?? [];
const sourcePolicyRaw = sourceEvidenceRecord?.raw_ref
  ? (JSON.parse(await runtime.archive.read(String(sourceEvidenceRecord.raw_ref))) as {
      body?: { candidates?: PolicyCandidate[] };
    })
  : null;
// 优先用归档的接口原始返回；读不到时才退回教学语料，避免把预期写成事实。
const sourceCandidates: PolicyCandidate[] =
  sourcePolicyRaw?.body?.candidates ??
  (candidateIds.length ? POLICIES.filter((policy) => candidateIds.includes(policy.id)) : [...POLICIES]);
const sourceEvidence: EvidenceDecision | null = sourceEvidenceRecord
  ? {
      policy: "relevance-first-v1",
      businessTime: first.run.businessTime,
      limit: 1,
      selected: sourceCandidates.filter((policy) => selectedIds.includes(policy.id)),
      excluded: (sourceEvidenceRecord.excluded as Array<{ id: string; reason: string }>) ?? [],
      selectionRule: (sourceEvidenceRecord.selection_rule as EvidenceSelectionRule | undefined) ?? "relevance_top_1",
      validityCheckApplied: Boolean(sourceEvidenceRecord.validity_check_applied),
      applicabilityCheckApplied: false,
    }
  : null;

const failure: ReplayFailure = {
  run_id: first.run.runId,
  trace_id: first.run.trace.traceId,
  answer: failing.text,
  cited: citedIds(failing.text, sourceCandidates),
  review: failing.review
    ? {
        passed: failing.review.passed,
        disposition: failing.review.disposition,
        failed_checks: failing.review.findings.filter((item) => !item.passed).map((item) => item.check),
      }
    : null,
};

await writeBundle(runtime.replayRoot, first.run.runId, {
  input: {
    question: first.run.question,
    customerId: first.run.customerId,
    salesId: first.run.salesId,
    tenantId: first.run.tenantId,
    businessTime: first.run.businessTime,
    promptVersion: first.run.promptVersion,
    evidencePolicy: first.run.evidencePolicy,
  },
  versions: {
    prompt_version: prompt.version,
    prompt_hash: prompt.contentHash,
    model_alias: runtime.model.model.id,
    evidence_policy: first.run.evidencePolicy,
    crm_schema: SCHEMA_VERSIONS.crm,
    kb_schema: SCHEMA_VERSIONS.kb,
    catalog_schema: SCHEMA_VERSIONS.catalog,
    authz_policy_version: SCHEMA_VERSIONS.authz,
    knowledge_version: SCHEMA_VERSIONS.knowledge,
  },
  failure,
  acceptance: ACCEPTANCE,
  toolCalls: failing.toolCalls,
  evidence: sourceEvidence,
  candidates: sourceCandidates,
  finalAnswer: failing.text,
  contextMessages,
});

let bundle = await loadBundle(runtime.replayRoot, first.run.runId);
const prefix = `${bundle.originalRunId}/`;
const requiredFiles = ["input.json", "versions.json", "failure.json", "acceptance.json", "state.json", "context/messages.json"];
const missingFiles = requiredFiles.filter((name) => !bundle.integrity.files.includes(`${prefix}${name}`));
const hasRawResults = bundle.integrity.files.some((file) => file.includes("raw-results"));
const materialComplete = bundle.integrity.complete && missingFiles.length === 0 && hasRawResults;

console.log(`  归档：${bundle.dir}`);
console.log(
  `  材料：文件 ${bundle.integrity.files.length}｜损坏 ${bundle.integrity.broken.length}｜缺失 ${missingFiles.length}｜可完整重放=${materialComplete ? "是" : "否"}`,
);
console.log(`  候选（筛前原始）：${bundle.state.candidates.map((item) => `${item.id} ${item.validFrom}~${item.validUntil}`).join("｜")}`);
if (missingFiles.length) console.log(`  缺失材料：${missingFiles.join("、")}`);

if (!materialComplete) {
  console.error("\n复现材料不完整，本次不能声明重放有效。");
  await runtime.close();
  process.exit(1);
}

// 4.2：材料齐全、可解析之后，还要核对版本是否匹配当前代码。
const versionChecks = checkVersions(bundle);
const versionMatched = versionChecks.every((item) => item.matched || item.intentional);
const intendedChanges = versionChecks.filter((item) => !item.matched && item.intentional);
const unexpectedChanges = versionChecks.filter((item) => !item.matched && !item.intentional);
console.log(
  `  版本：${versionChecks.length} 项核对，${versionChecks.length - intendedChanges.length - unexpectedChanges.length} 项一致` +
    `${intendedChanges.length ? `｜本次故意改变 ${intendedChanges.map((item) => item.name).join("/")}` : ""}` +
    `${unexpectedChanges.length ? `｜意外不一致 ${unexpectedChanges.map((item) => item.name).join("/")}` : ""}`,
);
if (!versionMatched) console.log("  版本不一致：这组条件不能当作同一组条件来比较。");

const businessTime = bundle.input.businessTime;
const customer = bundleProfile(bundle);
const serviceVersion = bundleServiceItems(bundle)[0]?.version ?? ACCEPTANCE.required_service_version;
const currentPolicy = bundle.state.candidates.find((policy) => policy.id === ACCEPTANCE.required_policy);

console.log("\n第 2 步：同一批材料交给旧代码，先复现缺陷");
const legacy = selectEvidence({
  candidates: bundle.state.candidates,
  customer,
  businessTime,
  policy: "relevance-first-v1",
  limit: 1,
});
const recordedSelected = bundle.state.evidence?.selected.map((item) => item.id) ?? [];
const reproduced =
  legacy.selected.map((item) => item.id).join("/") === recordedSelected.join("/") &&
  legacy.selected.some((item) => item.id === "P-old");
console.log(
  `  旧代码选中 ${legacy.selected.map((item) => item.id).join("/") || "无"}（原失败选中 ${recordedSelected.join("/") || "无"}）→ ${
    reproduced ? "问题已复现，后面的比较才有意义" : "未复现，后面的比较不能当作修复结论"
  }`,
);

console.log("\n第 3 步：同一批材料交给修复后的筛选");
const fixed = selectEvidence({
  candidates: bundle.state.candidates,
  customer,
  businessTime,
  policy: "validity-first-v2",
  limit: 1,
});
const fixedOk =
  fixed.selected.map((item) => item.id).join("/") === "P-current" &&
  fixed.excluded.some((item) => item.id === "P-old" && item.reason.includes("不覆盖业务时间")) &&
  fixed.validityCheckApplied;
console.log(
  `  选中 ${fixed.selected.map((item) => item.id).join("/") || "无"}｜排除 ${JSON.stringify(fixed.excluded)} → ${
    fixedOk ? "过期政策被排除，当前政策被保留" : "结果不符合预期"
  }`,
);

// 4.4 边界：所有候选都不符合条件时，必须返回依据不足，不能回退选一份过期政策。
const noEligible = selectEvidence({
  candidates: bundle.state.candidates,
  customer,
  businessTime: "2027-06-01T00:00:00.000Z",
  policy: "validity-first-v2",
  limit: 1,
});
const edgeOk = noEligible.selected.length === 0 && noEligible.excluded.length === bundle.state.candidates.length;
console.log(
  `  边界：业务时间 2027-06-01 时选中 ${noEligible.selected.length} 份 → ${
    edgeOk ? "返回依据不足，没有回退选一份过期政策" : "边界处理不符合预期"
  }`,
);

const fixedLayerPassed = reproduced && fixedOk && edgeOk && versionMatched;

// 4.3/4.5：用录制依赖重新执行同一个 pi SDK 入口；材料不匹配就停止，不偷偷改回真实接口。
const requestsBefore = runtime.services.requests.length;
let replayAnswer: SalesAnswer | null = null;
let replayRunId = "";
let replayTraceId = "";
let replayStatus: "ok" | "material_mismatch" | "error" | "skipped" = "skipped";

if (reproduced && versionMatched && fixedOk) {
  const replayClients = {
    customerApi: createRecordedCustomerApi(bundle),
    knowledgeBase: createRecordedKnowledgeBase(bundle),
    serviceCatalog: createRecordedServiceCatalog(bundle),
  };
  const started = await runtime.beginRun(
    {
      question: bundle.input.question,
      customerId: bundle.input.customerId,
      salesId: bundle.input.salesId,
      businessTime,
      promptVersion: bundle.input.promptVersion,
      evidencePolicy: "validity-first-v2",
      replayOf: first.run.runId,
      label: "replay-fixed",
    },
    replayClients,
  );
  replayRunId = started.run.runId;
  replayTraceId = started.run.trace.traceId;
  try {
    replayAnswer = await answerSalesQuestion(started.run, started.deps);
    await started.host.end({ final_answer: replayAnswer.text, replay_of: first.run.runId });
    replayStatus = "ok";
  } catch (error) {
    await started.host.end({ error: String((error as Error).message) });
    if (error instanceof MaterialMismatch) {
      replayStatus = "material_mismatch";
      console.log(`\n  重放材料不匹配，停止固定条件验证：${error.message.slice(0, 240)}`);
      console.log("  没有访问真实接口；要补材料，必须重新采集并重新声明条件。");
    } else {
      replayStatus = "error";
      throw error;
    }
  }
} else {
  console.log("\n完整问答未执行：旧行为复现、版本核对或筛选修复未通过。");
}
const requestsDuringReplay = runtime.services.requests.length - requestsBefore;

await runtime.sink.flush();
const replayRecords = replayRunId ? selectByRun((await readJsonl(runtime.logFile)).records, replayRunId) : [];
const replaySnapshot = [...replayRecords]
  .filter((record) => record.event === "context.snapshot" && record.phase === "provider_request")
  .at(-1);
const replaySnapshotText = replaySnapshot ? await runtime.archive.read(String(replaySnapshot.raw_ref)) : "";
const replayEvidence = replayRecords.find((record) => record.event === "evidence.selection");
const replaySelected = (replayEvidence?.selected_ids as string[] | undefined) ?? [];
const replayInputIds = bundle.state.candidates.map((item) => item.id).filter((id) => replaySnapshotText.includes(id));
const replayText = replayAnswer?.text ?? "";
const replayReview = replayAnswer?.review ?? null;

const answerChecks = [
  {
    item: "第一层：证据筛选保留当前政策",
    passed: replaySelected.includes(ACCEPTANCE.required_policy),
    detail: `选中 ${replaySelected.join("/") || "无"}，排除 ${JSON.stringify(replayEvidence?.excluded ?? [])}`,
  },
  {
    item: "第二层：实际模型输入包含当前政策与有效期",
    passed:
      replayInputIds.includes(ACCEPTANCE.required_policy) &&
      Boolean(currentPolicy && replaySnapshotText.includes(currentPolicy.validFrom) && replaySnapshotText.includes(currentPolicy.validUntil)),
    detail: `请求前快照包含 ${replayInputIds.join("/") || "无"}；有效期 ${currentPolicy?.validFrom ?? "?"}~${currentPolicy?.validUntil ?? "?"}`,
  },
  {
    item: "第二层：折扣为 10%，且不出现 15%",
    passed: /10\s*%/.test(replayText) && !/15\s*%/.test(replayText),
    detail: `回答中的折扣：${extractPercent(replayText)}`,
  },
  {
    item: "第二层：说明标准服务不含驻场支持",
    passed: mentionsOnsite(replayText) === "说明驻场需另签",
    detail: mentionsOnsite(replayText),
  },
  {
    item: "第二层：引用当前政策 P-current",
    passed: replayText.includes(ACCEPTANCE.required_policy),
    detail: citedIds(replayText, bundle.state.candidates).join(" ") || "无引用",
  },
  {
    item: "第二层：引用服务目录版本",
    passed: replayText.includes(serviceVersion),
    detail: replayText.includes(serviceVersion) ? `已引用 ${serviceVersion}` : `未引用 ${serviceVersion}`,
  },
  {
    item: "第二层：答案审阅通过",
    passed: replayReview?.passed === true,
    detail: replayReview ? `${replayReview.disposition}｜${replayReview.findings.filter((item) => !item.passed).map((item) => item.check).join("；") || "全部通过"}` : "未执行",
  },
];
const fullAnswerPassed = replayStatus === "ok" && answerChecks.every((item) => item.passed);
const replayDiagnosis = diagnoseReplay(replaySelected, replayInputIds, answerChecks);

console.log(`\n第 4 步：录制依赖下重跑同一个 pi SDK 入口（期间真实接口新增请求 ${requestsDuringReplay} 次）`);
console.log(`  新运行 ${replayRunId || "未执行"}（replay_of=${first.run.runId}），状态 ${replayStatus}`);
console.log(`  两层验收：第一层=${fixedLayerPassed ? "通过" : "未通过"}｜第二层=${fullAnswerPassed ? "通过" : "未通过"} → ${replayDiagnosis}`);

// 4.6：固定材料通过后，再用真实依赖检查当前系统能否完整工作。
console.log("\n第 5 步：真实依赖集成复测（当前资料、当前业务时间）");
const liveStartedAt = new Date().toISOString();
const live = await runtime.beginRun({
  question: bundle.input.question,
  customerId: bundle.input.customerId,
  salesId: bundle.input.salesId,
  businessTime: liveStartedAt,
  evidencePolicy: "validity-first-v2",
  label: "integration-retest",
});
let liveAnswer: SalesAnswer | null = null;
let liveError: string | null = null;
try {
  liveAnswer = await answerSalesQuestion(live.run, live.deps);
  await live.host.end({ final_answer: liveAnswer.text, delivery: liveAnswer.delivery });
} catch (error) {
  liveError = String((error as Error).message);
  await live.host.end({ error: liveError });
}
await runtime.sink.flush();
const liveRecords = selectByRun((await readJsonl(runtime.logFile)).records, live.run.runId);
const liveHttpRecords = liveRecords.filter((record) => String(record.event).endsWith("http_request"));
const liveIntegrationOk =
  liveError === null &&
  liveHttpRecords.length >= 3 &&
  liveHttpRecords.every((record) => record.http_status === 200) &&
  liveRecords.some((record) => record.event === "model.message.completed") &&
  liveRecords.some((record) => record.event === "answer.review");
console.log(
  `  运行 ${live.run.runId}｜接口 ${liveHttpRecords.length} 次，全部 2xx=${liveHttpRecords.every((record) => record.http_status === 200)}｜折扣 ${extractPercent(
    liveAnswer?.text ?? "",
  )}｜审阅 ${describeReview(liveAnswer)} → ${liveIntegrationOk ? "通过" : "未通过"}${liveError ? `（${liveError}）` : ""}`,
);

// 4.6：结果和引用通过后，再比较耗时、Token 和成本；失败、重试和审阅消耗都计入。
const usageRows = [
  ["原失败运行", summarizeUsage(sourceRecords)],
  ["录制依赖重放", summarizeUsage(replayRecords)],
  ["真实依赖复测", summarizeUsage(liveRecords)],
] as const;
const usageLine = usageRows
  .map(([label, usage]) => `${label} ${usage.input_tokens}/${usage.output_tokens} tokens、$${usage.cost_usd}`)
  .join("｜");
if (fullAnswerPassed) {
  console.log(`  用量（入/出 Token、成本）：${usageLine}（录制依赖无网络耗时，不作性能对比）`);
} else {
  console.log("  用量暂缓比较：结果与引用未通过，先修答案。");
}

// 4.6：只有两层都通过，才把失败材料、版本和验收规则加入回归集。
const regressionEligible = fixedLayerPassed && fullAnswerPassed;
const regressionCase = {
  case_id: `regression-${first.run.runId}`,
  source_run: first.run.runId,
  source_trace: first.run.trace.traceId,
  replay_run: replayRunId || null,
  replay_trace: replayTraceId || null,
  bundle: `replays/${first.run.runId}`,
  business_time: businessTime,
  versions: bundle.versions,
  acceptance: bundle.acceptance,
  failure: bundle.failure,
  added_at: new Date().toISOString(),
  note: "重放记录属于测试运行，不能直接当作今天给客户的建议。",
};
if (regressionEligible) {
  await runtime.archive.put("regression-cases", "state", regressionCase);
  console.log(`\n第 6 步：已加入回归集 ${regressionCase.case_id}（bundle=replays/${first.run.runId}）`);
} else {
  console.log("\n第 6 步：两层验收未通过，不写入回归集；先修复再复测。");
}

const replayTrace = replayTraceId ? await waitForTraceTree(replayTraceId, 45_000, 3_000) : null;

// 报告只保留 replay 的主线：固定条件 → 复现 → 两层验收 → 真实依赖 → 回归集。
const acceptanceRows = [
  ["选中政策", legacy.selected.map((item) => item.id).join("/") || "无", fixed.selected.map((item) => item.id).join("/") || "无", "复现 P-old → 修复为 P-current"],
  ["有效期检查", `未执行（${legacy.validityCheckApplied}）`, `已执行（${fixed.validityCheckApplied}）`, "按原业务时间判断"],
  ["排除记录", JSON.stringify(legacy.excluded), JSON.stringify(fixed.excluded), "写明过期原因与规则版本"],
];
const answerRows = answerChecks.map((item) => [item.item.replace(/^第[一二]层：/, ""), item.passed ? "通过" : "未通过", item.detail]);
const highlights = answerHighlights(replayText);
const intended = intendedChanges.map((item) => `${item.name} ${item.recorded} → ${item.current}`).join("；") || "无";

lines.push(
  heading(1, "演示三：Replay —— 固定条件，复现问题，验证修复"),
  "",
  `生成时间：${new Date().toISOString()}`,
  "",
  "**同一批历史材料下，旧代码仍选中过期政策 P-old（复现）；修复后排除 P-old、保留 P-current，答案从 15% 变为 10%（修复）。**",
  "",
  `- 原失败：${first.run.runId}（Trace ${first.run.trace.traceId}）`,
  `- 重放：${replayRunId || "未执行"}（replay_of=${first.run.runId}，Trace ${replayTraceId || "无"}${
    replayTrace ? `，${replayTrace.observations.length} 条记录` : ""
  }）——新运行编号 + 新 Trace，新旧记录分别保留`,
  "",
  heading(2, "一、固定了什么（4.2）"),
  table(
    ["固定项", "本次取值"],
    [
      ["问题 / 客户 / 业务时间", `${bundle.input.question}｜${bundle.input.customerId}｜${bundle.input.businessTime}`],
      ["外部返回", `筛前原始候选 ${bundle.state.candidates.map((item) => item.id).join(" + ")}（不是工具最终结果）｜服务目录 ${serviceVersion}`],
      [
        "版本",
        `prompt ${bundle.versions.prompt_version}#${bundle.versions.prompt_hash}｜model ${bundle.versions.model_alias}｜${versionChecks.length - intendedChanges.length - unexpectedChanges.length} 项一致；${intended}`,
      ],
      [
        "验收规则",
        `折扣 ${ACCEPTANCE.discount_percent}%（禁止 ${ACCEPTANCE.forbidden_discount_percent}%）｜政策 ${ACCEPTANCE.required_policy}｜服务 ${ACCEPTANCE.required_service_version}｜标准服务不含驻场`,
      ],
      [
        "材料自检",
        `文件 ${bundle.integrity.files.length}｜损坏 ${bundle.integrity.broken.length}｜缺失 ${missingFiles.length}｜可完整重放=${materialComplete ? "是" : "否"}`,
      ],
    ],
  ),
  "",
  `归档目录：\`replays/${first.run.runId}/\``,
  "",
  heading(2, "二、第一层：缺陷复现 → 筛选修复（4.4）"),
  table(["检查项", "旧代码", "修改后", "意义"], acceptanceRows),
  "",
  `- ${reproduced ? "旧代码仍选中 P-old，与归档的原失败一致：问题已复现，比较才有意义" : "旧行为没有出现：先查材料、代码版本和运行配置，本次不能作为修复结论"}`,
  `- 边界：业务时间移到 2027-06-01 时选中 ${noEligible.selected.length} 份，${edgeOk ? "返回依据不足，没有回退选一份过期政策" : "边界处理不符合预期"}`,
  "",
  heading(2, "三、第二层：完整问答（4.5）"),
  `用录制客户端重跑同一个 pi SDK 入口，由模型重新生成答案（不复用归档答案）；期间真实接口新增请求 ${requestsDuringReplay} 次。`,
  "",
  table(["检查项", "结果", "观察到的证据"], answerRows),
  "",
  "回答要点：",
  ...highlights.map((line) => `> ${line}`),
  "",
  `诊断：${replayDiagnosis}`,
  "",
  heading(2, "四、真实依赖复测（4.6）"),
  `- ${live.run.runId}｜业务时间 ${liveStartedAt}｜接口 ${liveHttpRecords.length} 次，全部 2xx=${liveHttpRecords.every((record) => record.http_status === 200)}`,
  `- 折扣 ${extractPercent(liveAnswer?.text ?? "")}｜引用 ${citedIds(liveAnswer?.text ?? "", bundle.state.candidates).join(" ") || "无"}｜服务范围 ${mentionsOnsite(
    liveAnswer?.text ?? "",
  )}｜审阅 ${describeReview(liveAnswer)}`,
  `- 结论：${liveIntegrationOk ? "通过" : "未通过"}${liveError ? `（${liveError}）` : ""}——固定材料证明缺陷已修，真实依赖证明当前系统仍能跑通`,
  "",
  heading(2, "五、进入回归集"),
  regressionEligible
    ? [
        `- case_id：${regressionCase.case_id}`,
        `- bundle：\`replays/${first.run.runId}/\`（失败材料 + 版本 + 验收规则一起保存）`,
        `- 起点运行：${first.run.runId} → 重放 ${replayRunId}；以后改模型、Prompt、上下文预算或检索策略，就重跑这道题`,
        "- 完整记录：`replays/regression-cases/state/state-001.json`",
      ].join("\n")
    : "两层验收未通过，本次不写入回归集。",
  "",
  heading(2, "用量与成本（参考）"),
  `${usageLine}｜录制依赖接口耗时记 0ms，不作性能对比；失败、重试、审阅的消耗都计入。`,
  "",
  heading(2, "说明"),
  "- 本次只说明改动在这组历史条件下有效，不能推广为整体质量提高。",
  "- Replay 是新的验证运行；任务恢复是中断后继续原任务，两者不是一件事。",
);

const reportFile = await writeReport(runtime.reportDir, "3-replay-report.md", lines);
console.log(`报告已写入 ${reportFile}`);
await runtime.close();

function checkVersions(bundle: ReplayBundle) {
  // 归档里的 Prompt 版本可能已经被删除或改名；这时只标记不一致，不让整个演示崩掉。
  let currentPrompt: { version: string; contentHash: string };
  try {
    const built = buildSalesPrompt(bundle.input.promptVersion);
    currentPrompt = { version: built.version, contentHash: built.contentHash };
  } catch {
    currentPrompt = { version: "unknown", contentHash: "unknown" };
  }
  const rows = [
    { name: "prompt_version", recorded: bundle.versions.prompt_version, current: currentPrompt.version, matched: bundle.versions.prompt_version === currentPrompt.version, intentional: false },
    { name: "prompt_hash", recorded: bundle.versions.prompt_hash, current: currentPrompt.contentHash, matched: bundle.versions.prompt_hash === currentPrompt.contentHash, intentional: false },
    { name: "model_alias", recorded: bundle.versions.model_alias, current: runtime.model.model.id, matched: bundle.versions.model_alias === runtime.model.model.id, intentional: false },
    { name: "crm_schema", recorded: bundle.versions.crm_schema, current: SCHEMA_VERSIONS.crm, matched: bundle.versions.crm_schema === SCHEMA_VERSIONS.crm, intentional: false },
    { name: "kb_schema", recorded: bundle.versions.kb_schema, current: SCHEMA_VERSIONS.kb, matched: bundle.versions.kb_schema === SCHEMA_VERSIONS.kb, intentional: false },
    { name: "catalog_schema", recorded: bundle.versions.catalog_schema, current: SCHEMA_VERSIONS.catalog, matched: bundle.versions.catalog_schema === SCHEMA_VERSIONS.catalog, intentional: false },
    { name: "authz_policy_version", recorded: bundle.versions.authz_policy_version, current: SCHEMA_VERSIONS.authz, matched: bundle.versions.authz_policy_version === SCHEMA_VERSIONS.authz, intentional: false },
    { name: "knowledge_version", recorded: bundle.versions.knowledge_version, current: SCHEMA_VERSIONS.knowledge, matched: bundle.versions.knowledge_version === SCHEMA_VERSIONS.knowledge, intentional: false },
    { name: "evidence_policy", recorded: bundle.versions.evidence_policy, current: "validity-first-v2", matched: bundle.versions.evidence_policy === "validity-first-v2", intentional: true },
  ];
  return rows;
}

function diagnoseReplay(selected: string[], inputIds: string[], checks: Array<{ item: string; passed: boolean }>): string {
  if (!selected.includes(ACCEPTANCE.required_policy)) return "证据筛选没有保留当前政策，先修筛选代码";
  if (!inputIds.includes(ACCEPTANCE.required_policy)) return "当前政策已选中但请求前快照里没有，检查上下文组装";
  const answerFailures = checks.filter((item) => !item.passed && item.item.startsWith("第二层"));
  if (answerFailures.length) {
    return `当前政策已进入模型，但答案未满足：${answerFailures.map((item) => item.item.replace("第二层：", "")).join("；")}`;
  }
  return "两层均通过：筛选选对资料，完整问答也给出正确结论";
}

function extractPercent(text: string): string {
  const values = [...new Set([...text.matchAll(/(\d+(?:\.\d+)?)\s*%/g)].map((match) => match[1]!))];
  return values.join("/") || "无";
}

function mentionsOnsite(text: string): string {
  if (!text.includes("驻场")) return "未提到驻场";
  return /另签|另行|需额外|不包含|不含|不在标准服务|标准服务不含/.test(text) ? "说明驻场需另签" : "未说明驻场条件";
}

function citedIds(text: string, candidates: PolicyCandidate[]): string[] {
  return candidates
    .filter((policy) => text.includes(policy.id) || text.includes(policy.version))
    .map((policy) => `${policy.id}@${policy.version}`);
}

function describeReview(produced: SalesAnswer | null): string {
  if (!produced?.review) return "未执行";
  return `${produced.review.passed ? "通过" : "未通过"}｜${produced.review.disposition}`;
}

/** 报告只留结论行：折扣、引用、驻场，不贴整段回答；纯小节标题不取。 */
function answerHighlights(text: string, limit = 3): string[] {
  const rows = text
    .split("\n")
    .map((line) => line.trim())
    .filter((line) => line && !/^\*\*\d+[.、]/.test(line));
  const picked = rows.filter((line) => /折扣|驻场|不含|另签|P-current|catalog/.test(line));
  return (picked.length ? picked : rows).slice(0, limit);
}
