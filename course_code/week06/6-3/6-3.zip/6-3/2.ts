import { answerSalesQuestion } from "./src/runner.js";
import { startRuntime } from "./src/runtime.js";
import { readJsonl, selectByRun } from "./src/log-query.js";
import { traceLink, waitForTraceTree } from "./src/langfuse-api.js";
import { heading, table, writeReport } from "./src/report.js";

/**
 * 演示二：Trace。只看一件事：P-current 在哪一步消失。
 *
 * 证据链：检索返回两版 → 证据筛选只留 P-old → 模型输入只有 P-old
 * → 模型输出 15% → 答案审阅因过期政策未通过。
 */
const QUESTION = "客户 C-1001 当前最高能享受多少折扣？报价是否包含驻场支持？";

interface ChainRow {
  node: string;
  pCurrent: string;
  evidence: string;
  meaning: string;
}

const runtime = await startRuntime();
const { run, host, deps } = await runtime.beginRun({
  question: QUESTION,
  customerId: "C-1001",
  evidencePolicy: "relevance-first-v1",
  label: "trace-demo",
});

console.log(`运行编号 ${run.runId}`);
console.log(`业务时间 ${run.businessTime}（演示固定值）`);
console.log(`平台父节点 trace=${run.trace.traceId} span=${run.trace.parentSpanId}`);
console.log(`本地日志 ${runtime.logFile}`);

const produced = await answerSalesQuestion(run, deps);
await host.end({ final_answer: produced.text, delivery: produced.delivery });
await runtime.sink.flush();
console.log(`[trace] 完成（业务处置 ${produced.delivery}）`);

const log = await readJsonl(runtime.logFile);
const records = selectByRun(log.records, run.runId);

// 只做一次平台校验：确认这条 Trace 真的来自本次问答，且调用树完整。
const tree = await waitForTraceTree(run.trace.traceId);
const rootMatches = tree.observations.some((item) => item.id === run.trace.parentSpanId);
const localTraceMatches = records.every((record) => record.trace_id === run.trace.traceId);
const platformRunIds = new Set(
  tree.observations
    .map((item) => item.metadata?.run_id)
    .filter((value): value is string => typeof value === "string"),
);
const traceOk = tree.complete && rootMatches && localTraceMatches && platformRunIds.has(run.runId);

const readJson = async (ref: unknown) => {
  if (typeof ref !== "string" || !ref) return null;
  try {
    return JSON.parse(await runtime.archive.read(ref)) as Record<string, unknown>;
  } catch {
    return null;
  }
};

// 1. 检索：原始候选里有 P-old 和 P-current。
const evidenceRecord = records.find((record) => record.event === "evidence.selection");
const candidateIds = (evidenceRecord?.candidate_ids as string[] | undefined) ?? [];
const selectedIds = (evidenceRecord?.selected_ids as string[] | undefined) ?? [];
const policyRaw = await readJson(evidenceRecord?.raw_ref);
const rawCandidates = ((policyRaw?.body as { candidates?: Array<{ id: string; validFrom: string; validUntil: string }> })?.candidates ?? []);
const currentPolicy = rawCandidates.find((item) => item.id === "P-current");
const day = run.businessTime.slice(0, 10);
const currentValid = currentPolicy ? currentPolicy.validFrom <= day && day <= currentPolicy.validUntil : false;

// 2. 模型请求前：最后一次 provider payload 里实际有什么。
const snapshotRecord = [...records]
  .filter((record) => record.event === "context.snapshot" && record.phase === "provider_request")
  .at(-1);
const snapshotText = snapshotRecord ? await runtime.archive.read(String(snapshotRecord.raw_ref)) : "";
const modelInputIds = candidateIds.filter((id) => snapshotText.includes(id));

// 3. 模型输出与审阅结论。
const finalAnswer = produced.text;
const finalStop = String(
  [...records].reverse().find((record) => record.event === "model.message.completed")?.stop_reason ?? "未知",
);
const reviewFailedDetail =
  produced.review?.findings
    .filter((item) => !item.passed)
    .map((item) => `${item.check}（${item.detail}）`)
    .join("；") || "无";

const diagnosis = diagnose({
  candidates: candidateIds,
  selected: selectedIds,
  modelInputIds,
  answer: finalAnswer,
});

const chain: ChainRow[] = [
  {
    node: "retrieval.sales_policy",
    pCurrent: `有（${candidateIds.join(" / ") || "无"}）`,
    evidence: `P-current 有效期 ${currentPolicy?.validFrom ?? "?"}~${currentPolicy?.validUntil ?? "?"}；覆盖业务时间 ${day}=${currentValid ? "是" : "否"}`,
    meaning: "知识库确实返回了当前政策",
  },
  {
    node: "context.build.evidence_selection",
    pCurrent: "被排除",
    evidence: `选中 ${selectedIds.join(" / ") || "无"}；排除 ${describeExcluded(evidenceRecord?.excluded)}；selection_rule=${String(evidenceRecord?.selection_rule ?? "无")}；validity_check_applied=${String(evidenceRecord?.validity_check_applied ?? "无")}`,
    meaning: "第一处偏差：按相关性取第一份，没有校验有效期",
  },
  {
    node: "context.snapshot / 模型请求",
    pCurrent: "没有",
    evidence: `请求前 payload 只包含 ${modelInputIds.join(" / ") || "无"}`,
    meaning: "模型没有收到当前政策",
  },
  {
    node: "model.message.completed",
    pCurrent: "未采用",
    evidence: `输出 ${percentOf(finalAnswer)}；引用 ${citeOf(finalAnswer)}；stop_reason=${finalStop}`,
    meaning: "模型正常结束，但只用了旧政策",
  },
  {
    node: "answer.review",
    pCurrent: "引用过期",
    evidence: `未通过：${reviewFailedDetail}；disposition=${produced.delivery}`,
    meaning: "业务控制拦截，答案不能直接返回",
  },
];

const selectionRows: Array<[string, string]> = [
  ["candidate_ids", JSON.stringify(candidateIds)],
  ["selected_ids", JSON.stringify(selectedIds)],
  ["excluded", JSON.stringify(evidenceRecord?.excluded ?? [])],
  ["selection_rule", String(evidenceRecord?.selection_rule ?? "无")],
  ["validity_check_applied", String(evidenceRecord?.validity_check_applied ?? "无")],
  ["business_time", String(evidenceRecord?.business_time ?? run.businessTime)],
];

console.log(`\nTrace 校验：${traceOk ? "通过" : "未通过"}（平台 ${tree.observations.length} 条记录）`);
console.log(`\n核心证据链：P-current 从有到无`);
console.table(chain);
console.log(`\n第一处偏差：${diagnosis.location}`);
console.log(`判断依据：${diagnosis.reason}`);
console.log(`下一步：${diagnosis.next}`);

const reportFile = await writeReport(runtime.reportDir, "2-trace-report.md", [
  heading(1, "演示二：Trace 里看 P-current 在哪一步消失"),
  "",
  `生成时间：${new Date().toISOString()}`,
  "",
  heading(2, "运行标识"),
  `- 运行编号：${run.runId}`,
  `- 平台 Trace ID：${run.trace.traceId}`,
  `- 业务时间：${run.businessTime}（演示固定值）`,
  `- 问题：${QUESTION}`,
  `- 调用树链接：${traceLink(run.trace.traceId)}`,
  `- Trace 校验：${traceOk ? "通过" : "未通过"}（平台 ${tree.observations.length} 条记录；根节点与日志一致=${rootMatches ? "是" : "否"}；本地 trace_id 一致=${localTraceMatches ? "是" : "否"}）`,
  "",
  heading(2, "核心证据链：P-current 从有到无"),
  table(
    ["Trace 节点", "P-current 状态", "关键证据", "说明"],
    chain.map((row) => [row.node, row.pCurrent, row.evidence, row.meaning]),
  ),
  "",
  heading(2, "第一处偏差：证据筛选"),
  table(["字段", "值"], selectionRows),
  "",
  `判断依据：${diagnosis.reason}`,
  `下一步：${diagnosis.next}`,
  "",
  heading(2, "为什么不是检索或模型"),
  `- 不是检索：retrieval.sales_policy 同时返回了 P-old 和 P-current，P-current 在业务时间 ${day} ${currentValid ? "有效" : "无效"}。`,
  `- 不是模型执行失败：最终 stop_reason=${finalStop}，回答结构正常，只是采用了 P-old。`,
  "- 不是生成指令：P-current 在请求前 payload 里就不存在，模型没有机会采用。",
  "",
  heading(2, "结论"),
  `第一处偏差在${diagnosis.location}。优先修改证据筛选：先校验权限、适用条件和有效期，再排序截断；具体修改交给 Replay 验证。`,
  "只改 Prompt 不够：P-current 没有进入生成请求，模型无法使用它。",
]);

console.log(`\n报告已写入 ${reportFile}`);
await runtime.close();

function diagnose(input: {
  candidates: string[];
  selected: string[];
  modelInputIds: string[];
  answer: string;
}): { location: string; reason: string; next: string } {
  if (!input.candidates.includes("P-current")) {
    return {
      location: "政策检索",
      reason: "知识库原始候选里没有 P-current，需要检查查询条件或知识库返回。",
      next: "先修检索，不要继续改证据筛选。",
    };
  }
  if (!input.selected.includes("P-current")) {
    return {
      location: "证据筛选",
      reason: "P-current 已经被检索到，但筛选结果里没有它；过期政策却被选中。",
      next: "先比较筛选规则和排除原因，再修改筛选代码。",
    };
  }
  if (!input.modelInputIds.includes("P-current")) {
    return {
      location: "上下文组装",
      reason: "P-current 已经通过筛选，但请求前快照里没有它，说明组装或截断把它丢掉了。",
      next: "检查 Context Build 的截断、压缩和消息组装。",
    };
  }
  if (!input.answer.includes("P-current") || !/10\s*%/.test(input.answer)) {
    return {
      location: "生成指令或模型",
      reason: "P-current 已经进入模型输入，但回答没有按这份政策给出 10% 的结论。",
      next: "检查回答指令、引用要求和模型表现，不能沿用“筛选有问题”的结论。",
    };
  }
  return {
    location: "未发现预期偏差",
    reason: "P-current 已被检索、选中并进入模型，回答也引用了它。",
    next: "回到记录确认本次运行是否真的是失败案例。",
  };
}

function describeExcluded(value: unknown): string {
  if (!Array.isArray(value)) return "无";
  return value
    .map((item) => {
      const record = item as { id?: string; reason?: string };
      return `${record.id ?? "?"}=${record.reason ?? "?"}`;
    })
    .join("；") || "无";
}

function percentOf(text: string): string {
  const values = [...new Set([...text.matchAll(/(\d+(?:\.\d+)?)\s*%/g)].map((match) => match[1]!))];
  return values.length ? `${values.join("/")}%` : "无百分比";
}

function citeOf(text: string): string {
  const ids = ["P-old", "P-current"].filter((id) => text.includes(id));
  return ids.length ? ids.join("/") : "无政策编号";
}
