import { startRuntime } from "./src/runtime.js";
import { answerSalesQuestion } from "./src/runner.js";
import { readJsonl, selectByRun, summarizeMetrics, summarizeUsage } from "./src/log-query.js";
import { heading, table, writeReport } from "./src/report.js";
import type { AnswerReview, LogSinkStats, SalesAnswer } from "./src/sales-types.js";
import type { PolicyCandidate } from "./src/data.js";

/**
 * 演示一：日志。先把模型和工具的每次调用记清楚。
 *
 * 只跑主案例：一个正常客户的销售问答。
 * 报告只保留连续证据链和两条关键记录，完整事件仍在 JSONL 日志里。
 */
const DEMO_QUESTION = "客户 C-1001 当前最高能享受多少折扣？报价是否包含驻场支持？";
const DEMO_EXPECT = "客户查询正确、政策检索返回两版、服务目录成功、模型采用旧政策 15%";

interface PrimaryRun {
  runId: string;
  traceId: string;
  businessTime: string;
  answer: string;
  produced: SalesAnswer | null;
  records: Record<string, unknown>[];
}

interface ProfileFact {
  customer_id?: string;
  industry?: string;
  region?: string;
  products?: string[];
}

interface ServiceFact {
  productId?: string;
  includesOnsiteSupport?: boolean;
  onsiteCondition?: string;
  version?: string;
}

interface PrimaryFacts {
  result: PrimaryRun;
  authz?: Record<string, unknown>;
  customerHttp?: Record<string, unknown>;
  profile?: ProfileFact;
  policyHttp?: Record<string, unknown>;
  policies: PolicyCandidate[];
  candidateIds: string[];
  evidence?: Record<string, unknown>;
  catalogHttp?: Record<string, unknown>;
  service?: ServiceFact;
  modelRequests: Record<string, unknown>[];
  modelMessages: Record<string, unknown>[];
  snapshots: Record<string, unknown>[];
  inputIds: string[];
  finalText: string;
  reviewRecord?: Record<string, unknown>;
  review: AnswerReview | null;
  delivery: string;
  /** 三个业务接口是否都返回 200；决定报告开头写“接口全部成功”还是“先处理接口异常”。 */
  interfacesOk: boolean;
  usage: ReturnType<typeof summarizeUsage>;
}

interface ChainRow {
  step: string;
  record: string;
  interfaceStatus: string;
  keyFields: string;
  meaning: string;
}

const runtime = await startRuntime();
console.log(`运行编号写入日志文件：${runtime.logFile}`);
console.log(`业务接口：${runtime.baseUrl}（真实 HTTP）  模型：deepseek/${runtime.model.model.id}\n`);

const { run, host, deps } = await runtime.beginRun({
  question: DEMO_QUESTION,
  customerId: "C-1001",
  evidencePolicy: "relevance-first-v1",
  label: "log-main",
});
process.stdout.write(`[main] run=${run.runId} trace=${run.trace.traceId} ... `);
let answer = "";
let produced: SalesAnswer | null = null;
try {
  produced = await answerSalesQuestion(run, deps);
  answer = produced.text;
} catch (error) {
  answer = `运行异常：${String((error as Error).message)}`;
}
await host.end({ answer_preview: answer.slice(0, 200), delivery: produced?.delivery ?? "unknown" });
console.log(`完成（业务处置 ${produced?.delivery ?? "unknown"}）`);

// 写入器刷新以后，文件里的记录才具备被读取和核对的条件。
await runtime.sink.flush();
let log;
try {
  log = await readJsonl(runtime.logFile);
} catch (error) {
  console.error(`日志损坏，停止核对：${String((error as Error).message)}`);
  await runtime.close();
  process.exit(1);
}

const records = selectByRun(log.records, run.runId);
const stats = runtime.sink.stats();
console.log(
  `\n写入器状态：已写 ${stats.written} 条，队列 ${stats.queued}，丢弃 ${stats.dropped}，写入错误 ${stats.write_error ?? "无"}`,
);

const primary: PrimaryRun = {
  runId: run.runId,
  traceId: run.trace.traceId,
  businessTime: run.businessTime,
  answer,
  produced,
  records,
};

console.log(`\n${"=".repeat(88)}`);
console.log(`运行 ${primary.runId}（log-main） 业务处置：${primary.produced?.delivery ?? "unknown"}`);
console.log(`期望核对点：${DEMO_EXPECT}`);
console.log(`平台 Trace ID：${primary.traceId}  业务时间：${primary.businessTime}`);
console.log(`回答摘要：${primary.answer.slice(0, 200).replace(/\n/g, " ")}`);

// 主案例：把日志整理成一条连续证据链，而不是按事件平铺。
const facts = await collectPrimaryFacts(primary);
const chain = buildChain(facts);
const evidenceView = buildEvidenceView(facts);
const reviewView = buildReviewView(facts);
const metrics = summarizeMetrics(records);
const appendixRows = buildAppendixRows(facts, metrics, stats);
const headline = facts.interfacesOk ? "接口全部成功，业务判断出错。" : "接口存在异常，先处理接口错误。";
const finalStop = String(facts.modelMessages.at(-1)?.stop_reason ?? "未知");
const summary = facts.interfacesOk
  ? `客户查对了、接口都成功、政策返回了两版、模型${finalStop === "stop" ? "正常结束" : `结束状态为 ${finalStop}`}但只拿到旧政策。`
  : "接口存在异常，先处理失败调用；下面的证据链仍按同一 run_id 排列。";

console.log(`\n${"=".repeat(88)}\n主案例连续证据链：${headline}`);
console.table(chain);
console.log(`\n重点看这两行：evidence.selection / answer.review`);
console.log(JSON.stringify(evidenceView, null, 2));
console.log(JSON.stringify(reviewView, null, 2));
console.log(`\n从日志得出的结论：`);
for (const line of conclusionLines(facts)) console.log(`- ${line}`);
console.log(`\n运行汇总：`);
console.table(appendixRows.map(([item, value]) => ({ item, value })));

const reportFile = await writeReport(runtime.reportDir, "1-log-report.md", [
  heading(1, "演示一：日志记录的真实调用"),
  "",
  `**一句话结论：${headline}**`,
  "",
  summary,
  "",
  heading(2, "运行条件"),
  `- 运行编号：${primary.runId}`,
  `- 平台 Trace ID：${primary.traceId}`,
  `- 业务时间：${primary.businessTime}（演示固定值，不跟随系统时钟）`,
  `- 日志文件：\`logs/${runtime.logFile.split("/").pop() ?? runtime.logFile}\``,
  `- 生成模型：DeepSeek ${runtime.model.model.id}`,
  `- 写入器：已写 ${stats.written} 条，丢弃 ${stats.dropped}，写入错误 ${stats.write_error ?? "无"}`,
  "",
  heading(2, "主案例：连续证据链"),
  "按 `run_id` 过滤后，下面这些记录属于同一次问答，不是彼此孤立的事件。",
  "",
  table(
    ["步骤", "日志记录", "接口/调用状态", "关键字段", "说明"],
    chain.map((row) => [row.step, row.record, row.interfaceStatus, row.keyFields, row.meaning]),
  ),
  "",
  heading(2, "重点看这两行"),
  heading(3, "1. `evidence.selection`：第一处明确偏差"),
  `- 候选：${facts.candidateIds.join(" / ") || "无"}`,
  `- 选中：${idsOf(facts.evidence?.selected_ids).join(" / ") || "无"}`,
  `- 排除：${describeExcluded(facts.evidence?.excluded)}`,
  `- 规则：\`selection_rule=${String(facts.evidence?.selection_rule ?? "无")}\`，\`validity_check_applied=${String(facts.evidence?.validity_check_applied ?? "无")}\``,
  `- 业务时间：${String(facts.evidence?.business_time ?? primary.businessTime)}`,
  "",
  "这说明：P-current 已经被检索到，但在生成之前被筛掉；这是第一处明确偏差，不是接口错误。",
  "",
  "```json",
  JSON.stringify(evidenceView, null, 2),
  "```",
  "",
  heading(3, "2. `answer.review`：答案不能直接交给销售"),
  `- \`outcome=${String(reviewView.outcome)}\`，\`disposition=${String(reviewView.disposition)}\``,
  `- 未通过：${reviewFailedText(facts)}`,
  "",
  "这说明：过期政策引用未通过，必须先补查、明确无法确认或转人工。",
  "",
  "```json",
  JSON.stringify(reviewView, null, 2),
  "```",
  "",
  heading(2, "从日志得出的结论"),
  ...conclusionLines(facts).map((line) => `- ${line}`),
  "",
  heading(2, "附：运行汇总"),
  table(["项目", "值"], appendixRows),
  "",
  heading(2, "结论边界"),
  "- 日志能确认调用事实，也能确认“新政策被检索到、但没有进入模型”。",
  "- 日志不能单独说明是哪一行代码把新政策筛掉的；需要结合 Trace 和代码。",
  "- 完整答案、请求前 payload 和接口原始返回都在归档引用里，日志只保留摘要。",
]);

console.log(`\n报告已写入 ${reportFile}`);
await runtime.close();

/**
 * 只读取主案例的事实，供报告复用。
 * 事实来自本次运行的 JSONL 记录和归档原文，不按预期补写。
 */
async function collectPrimaryFacts(result: PrimaryRun): Promise<PrimaryFacts> {
  const byEvent = (event: string) => result.records.filter((record) => record.event === event);
  const readJson = async (ref: unknown) => {
    if (typeof ref !== "string" || !ref) return null;
    try {
      return JSON.parse(await runtime.archive.read(ref)) as Record<string, unknown>;
    } catch {
      return null;
    }
  };

  const authz = byEvent("customer.authorization")[0];
  const customerHttp = byEvent("customer.http_request")[0];
  const profileRaw = await readJson(customerHttp?.raw_ref);
  const profile = profileRaw?.body as ProfileFact | undefined;

  const policyHttp = byEvent("policy.http_request")[0];
  const policyRaw = await readJson(policyHttp?.raw_ref);
  const policies = ((policyRaw?.body as { candidates?: PolicyCandidate[] })?.candidates ?? []);
  const candidateIds = policies.map((policy) => policy.id);
  const evidence = byEvent("evidence.selection")[0];

  const catalogHttp = byEvent("catalog.http_request")[0];
  const catalogRaw = await readJson(catalogHttp?.raw_ref);
  const service = ((catalogRaw?.body as { items?: ServiceFact[] })?.items ?? [])[0];

  const modelRequests = byEvent("model.request.started");
  const modelMessages = byEvent("model.message.completed");
  const snapshots = byEvent("context.snapshot");
  const inputIds = await modelInputIds(snapshots);

  const answerRecord = byEvent("answer.archived")[0];
  const answerRaw = await readJson(answerRecord?.raw_ref);
  const finalText = String((answerRaw as { text?: string } | null)?.text ?? result.answer);
  const reviewRecord = byEvent("answer.review")[0];
  const review = result.produced?.review ?? null;
  const delivery = result.produced?.delivery ?? "unknown";
  const interfacesOk = [customerHttp?.http_status, policyHttp?.http_status, catalogHttp?.http_status].every(
    (status) => status === 200,
  );

  return {
    result,
    authz,
    customerHttp,
    profile,
    policyHttp,
    policies,
    candidateIds,
    evidence,
    catalogHttp,
    service,
    modelRequests,
    modelMessages,
    snapshots,
    inputIds,
    finalText,
    reviewRecord,
    review,
    delivery,
    interfacesOk,
    usage: summarizeUsage(result.records),
  };
}

function buildChain(facts: PrimaryFacts): ChainRow[] {
  const current = facts.policies.find((policy) => policy.id === "P-current");
  const selected = idsOf(facts.evidence?.selected_ids);
  const finalStop = String(facts.modelMessages.at(-1)?.stop_reason ?? "未知");
  const usedOld = /15\s*%/.test(facts.finalText) && facts.finalText.includes("P-old");
  const citesOld = facts.finalText.includes("P-old");
  const reviewFailed = reviewFailedText(facts);

  return [
    {
      step: "1 客户查询",
      record: "customer.authorization + customer.http_request",
      interfaceStatus: `授权 ${String(facts.authz?.authorization ?? "未知")}；CRM HTTP ${String(facts.customerHttp?.http_status ?? "无")}`,
      keyFields: describeProfile(facts.profile),
      meaning: "客户查对了，权限与接口都正常",
    },
    {
      step: "2 政策检索",
      record: "policy.http_request",
      interfaceStatus: `HTTP ${String(facts.policyHttp?.http_status ?? "无")}`,
      keyFields: `查询条件含 customer_id / keyword / business_time；候选 ${facts.candidateIds.join(" / ") || "无"}；P-current 有效期 ${current?.validFrom ?? "?"}~${current?.validUntil ?? "?"}`,
      meaning: "接口成功，新旧两版都返回",
    },
    {
      step: "3 服务查询",
      record: "catalog.http_request",
      interfaceStatus: `HTTP ${String(facts.catalogHttp?.http_status ?? "无")}`,
      keyFields: `${facts.service?.productId ?? "无"}；包含驻场=${String(facts.service?.includesOnsiteSupport ?? "未知")}`,
      meaning: "服务目录成功，标准服务不含驻场",
    },
    {
      step: "4 证据筛选",
      record: "evidence.selection",
      interfaceStatus: "无接口调用（业务代码）",
      keyFields: `选中 ${selected.join(" / ") || "无"}；excluded: ${describeExcluded(facts.evidence?.excluded)}；selection_rule=${String(facts.evidence?.selection_rule ?? "无")}；validity_check_applied=${String(facts.evidence?.validity_check_applied ?? "无")}`,
      meaning: "第一处偏差：按相关性取第一份，没有校验有效期",
    },
    {
      step: "5 模型输入",
      record: "context.snapshot",
      interfaceStatus: "provider payload 已归档",
      keyFields: `最终请求前快照只包含 ${facts.inputIds.join(" / ") || "无"}`,
      meaning: "模型没有拿到 P-current",
    },
    {
      step: "6 模型生成",
      record: "model.message.completed",
      interfaceStatus: `最终 stop_reason=${finalStop}（共 ${facts.modelMessages.length} 次生成）`,
      keyFields: `折扣 ${percentOf(facts.finalText)}；引用 ${citeOf(facts.finalText)}`,
      meaning: usedOld
        ? finalStop === "stop"
          ? "模型正常结束，但输出旧政策中的 15%"
          : `模型结束状态为 ${finalStop}，仍输出旧政策中的 15%`
        : citesOld
          ? finalStop === "stop"
            ? "模型正常结束，但只拿到旧政策，回答无法给出当前折扣"
            : `模型结束状态为 ${finalStop}，且只拿到旧政策`
          : "模型正常结束，但没有采用当前政策",
    },
    {
      step: "7 答案审阅",
      record: "answer.review",
      interfaceStatus: `outcome=${String(facts.reviewRecord?.outcome ?? "unknown")}`,
      keyFields: `disposition=${facts.delivery}；未通过 ${reviewFailed}`,
      meaning: "业务控制不通过，答案不能直接交给销售",
    },
  ];
}

function buildEvidenceView(facts: PrimaryFacts) {
  return {
    event: "evidence.selection",
    run_id: facts.evidence?.run_id ?? facts.result.runId,
    business_time: facts.evidence?.business_time ?? facts.result.businessTime,
    candidate_ids: facts.evidence?.candidate_ids ?? facts.candidateIds,
    selected_ids: facts.evidence?.selected_ids ?? [],
    excluded: facts.evidence?.excluded ?? [],
    selection_rule: facts.evidence?.selection_rule ?? null,
    validity_check_applied: facts.evidence?.validity_check_applied ?? null,
  };
}

function buildReviewView(facts: PrimaryFacts) {
  return {
    event: "answer.review",
    run_id: facts.reviewRecord?.run_id ?? facts.result.runId,
    outcome: facts.reviewRecord?.outcome ?? "unknown",
    disposition: facts.delivery,
    failed_checks:
      facts.review?.findings
        .filter((item) => !item.passed)
        .map((item) => ({ check: item.check, detail: item.detail })) ?? [],
  };
}

function conclusionLines(facts: PrimaryFacts): string[] {
  const current = facts.policies.find((policy) => policy.id === "P-current");
  const day = facts.result.businessTime.slice(0, 10);
  const currentValid = current ? current.validFrom <= day && day <= current.validUntil : false;
  const usedOld = /15\s*%/.test(facts.finalText) && facts.finalText.includes("P-old");
  const finalStop = String(facts.modelMessages.at(-1)?.stop_reason ?? "未知");
  const citesOld = facts.finalText.includes("P-old");
  const stopPhrase = finalStop === "stop" ? "模型正常结束" : `模型结束状态为 ${finalStop}`;
  const apiStatus = `${String(facts.customerHttp?.http_status ?? "无")} / ${String(facts.policyHttp?.http_status ?? "无")} / ${String(facts.catalogHttp?.http_status ?? "无")}`;
  return [
    `客户查对了：${describeProfile(facts.profile)}，授权 ${String(facts.authz?.authorization ?? "未知")}，CRM HTTP ${String(facts.customerHttp?.http_status ?? "无")}。`,
    facts.interfacesOk
      ? `接口都成功：CRM、政策检索、服务目录都是 ${apiStatus}；日志里没有 HTTP 报错。`
      : `接口并非全部成功：CRM / 政策检索 / 服务目录为 ${apiStatus}；先处理接口异常，再判断业务结论。`,
    `政策返回了两版：${facts.candidateIds.join(" / ") || "无"}；P-current 有效期 ${current?.validFrom ?? "?"}~${current?.validUntil ?? "?"}，覆盖业务时间 ${day}=${currentValid ? "是" : "否"}。`,
    usedOld
      ? finalStop === "stop"
        ? "模型正常结束（stop_reason=stop），但请求前快照只有 P-old，回答给出 15% 并引用 P-old。"
        : `模型结束状态为 ${finalStop}，回答仍给出 15% 并引用 P-old；先确认这次生成是否完整。`
      : citesOld
        ? `${stopPhrase}，但只拿到 P-old；因为没有当前有效政策，回答无法给出折扣（实际：${percentOf(facts.finalText)}）。`
        : `${stopPhrase}，但没有采用当前政策（实际：${percentOf(facts.finalText)}）。`,
    "第一处偏差在 evidence.selection：按相关性取第一份，没有校验有效期；P-current 在生成前被筛掉。",
    `业务信号在 answer.review：${reviewFailedText(facts)} 未通过，disposition=${facts.delivery}；答案不能直接交给销售。`,
    "下一步用 Trace 比较证据筛选结果和模型实际输入；只改 Prompt 不够，因为 P-current 没有进入生成请求。",
  ];
}

function buildAppendixRows(
  facts: PrimaryFacts,
  metrics: ReturnType<typeof summarizeMetrics>,
  stats: LogSinkStats,
): Array<[string, string]> {
  const usage = facts.usage;
  return [
    ["主案例模型调用 / provider 请求", `${usage.model_calls} / ${usage.provider_requests ?? "未知"}`],
    ["主案例 Token（输入 / 输出 / 总）", `${usage.input_tokens} / ${usage.output_tokens} / ${usage.total_tokens}`],
    ["主案例成本 / 未知用量", `${usage.cost_usd} USD / ${usage.usage_unknown_calls} 次`],
    ["主案例工具调用 / 失败", `${metrics.tool_calls} / ${metrics.tool_failures}`],
    ["主案例接口请求 / 失败", `${metrics.http_requests} / ${metrics.http_failures}`],
    ["主案例 P95 耗时 / 审阅未通过", `${metrics.p95_tool_ms ?? "-"} ms / ${metrics.reviews_failed}`],
    ["日志写入", `已写 ${stats.written}，丢弃 ${stats.dropped}，错误 ${stats.write_error ?? "无"}`],
  ];
}

function reviewFailedText(facts: PrimaryFacts): string {
  const failed = facts.review?.findings.filter((item) => !item.passed) ?? [];
  return failed.length ? failed.map((item) => `${item.check}（${item.detail}）`).join("；") : "无";
}

function describeProfile(profile: ProfileFact | undefined): string {
  if (!profile) return "未读到归档客户资料";
  return `${profile.customer_id ?? "?"} / ${profile.region ?? "?"} / ${profile.industry ?? "?"} / ${(profile.products ?? []).join(",")}`;
}

function describeExcluded(value: unknown): string {
  if (!Array.isArray(value)) return "无";
  return value.map((item) => {
    const record = item as { id?: string; reason?: string };
    return `${record.id ?? "?"}=${record.reason ?? "?"}`;
  }).join("；") || "无";
}

function idsOf(value: unknown): string[] {
  return Array.isArray(value) ? value.map(String) : [];
}

function percentOf(text: string): string {
  const values = [...new Set([...text.matchAll(/(\d+(?:\.\d+)?)\s*%/g)].map((match) => match[1]!))];
  return values.length ? `${values.join("/")}%` : "无百分比";
}

function citeOf(text: string): string {
  const ids = ["P-old", "P-current"].filter((id) => text.includes(id));
  return ids.length ? ids.join("/") : "无政策编号";
}

async function modelInputIds(snapshots: Record<string, unknown>[]): Promise<string[]> {
  // 取最后一次请求前快照：它才是生成最终答案时模型收到的输入。
  const last = [...snapshots].reverse().find((record) => typeof record.raw_ref === "string");
  if (!last) return [];
  try {
    const text = await runtime.archive.read(String(last.raw_ref));
    return ["P-old", "P-current"].filter((id) => text.includes(id));
  } catch {
    return [];
  }
}
