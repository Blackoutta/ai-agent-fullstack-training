# 6.3 Agent 可观测性：销售智能问答的三个演示入口

演示业务时间固定为 `2026-11-06T09:00:00.000Z`：旧政策在 2025 年有效，当前政策在 2026 年有效。案例结果：检索拿到新旧两版政策，证据整理按相关性取第一份，选中已过期的 `P-old` 并回答 15%；改成排序截断前先校验有效期后，同一批候选里选出 `P-current`，回答 10%。

## 目录

| 路径 | 用途 |
| --- | --- |
| `1.ts`、`2.ts`、`3.ts` | 三个演示入口：日志、Trace、Replay |
| `replay-once.ts` | 重跑已保存的 replay 材料，输出精简验收结论 |
| `src/runtime.ts`、`src/model.ts`、`src/prompt.ts` | 运行环境：起模拟接口、配模型、固定业务时间与 Prompt 版本 |
| `src/clients.ts`、`src/customer-tool.ts`、`src/policy-tools.ts`、`src/evidence.ts` | 业务链路：三个工具、证据整理（本节缺陷所在）、上下文构建 |
| `src/observability.ts`、`src/jsonl-sink.ts`、`src/archive.ts` | 采集与落盘：观测扩展、JSONL 写入器、原始返回与上下文归档 |
| `src/langfuse-host.ts`、`src/langfuse-api.ts` | Trace：宿主父节点与平台调用树读回 |
| `src/replay-bundle.ts`、`src/recorded-clients.ts`、`src/answer-review.ts` | Replay：材料存取、录制客户端、答案审阅 |
| `src/log-query.ts`、`src/report.ts` | 按运行编号查询日志、生成 Markdown 报告 |
| `config/` | `local.env`、`langfuse.env` 与 Langfuse 编排 |
| `logs/`、`replays/`、`output/` | 运行产出：JSONL 日志、复现材料与回归任务、对照报告 |
| `tests/` | vitest 单元测试 |

## 安装

Node 22.19+，在工程根目录执行：

```bash
npm install --legacy-peer-deps --cache ./.npm-cache
npm run typecheck
npm test
```

两个参数都必需：`--legacy-peer-deps` 绕开 npm 11 处理 pi 1.5.0 与 OpenTelemetry、vitest 的 peer 组合时在 `#loadPeerSet` 崩溃；`--cache ./.npm-cache` 改用项目内缓存，避开本机 `~/.npm/_cacache` 的权限问题。

## 启动 Langfuse（演示二、三需要）

```bash
npm run langfuse:up      # 首次会拉镜像并跑迁移，约几分钟
curl -s http://127.0.0.1:3000/api/public/health
npm run langfuse:down    # 关闭
```

编排文件只保留官方六个服务（web、worker、postgres、clickhouse、redis、minio），端口全部绑定 127.0.0.1。`config/langfuse.env` 的 `LANGFUSE_INIT_*` 会在首次启动时自动建好用户、项目与项目密钥；自助注册已关闭，只有初始化账号能看到 Trace。登录：`demo@sales-agent.local` / `sales-agent-demo`。

界面地址统一用 `http://localhost:3000`，与 `NEXTAUTH_URL` 同源；报告里的调用树链接由 `LANGFUSE_UI_URL` 拼出，两者不同源时会在两边登录间来回跳。改这两个变量要重新 `down` / `up` 才生效。

## 运行

```bash
npm run demo:log                 # 1.ts
npm run demo:trace               # 2.ts
npm run demo:replay              # 3.ts：现场造一次失败，再重放并复测
npm run replay -- run-<run-id>   # 重跑 replays/<run-id>/ 里已保存的材料
```

`config/local.env` 由入口脚本自动读取，已存在的环境变量优先；换模型或平台地址改这里即可。`DEMO_BUSINESS_TIME` 是判断政策是否有效的唯一依据：Replay 的完整问答沿用原运行业务时间，真实依赖复测才使用当前时间。

所有入口都写 `logs/agent-<进程号>.jsonl`，结束前 `sink.flush()` 报告写入错误与丢弃条数；某行 JSON 损坏时会报出文件与行号并停止，不会跳过坏行把剩余记录当成完整执行过程。

## 重跑已保存的 Replay

`3.ts` 每次都会现场造一个新的失败再重放它。要重跑**历史材料**，用独立入口：

```bash
npm run replay -- run-20261106-cf397f98      # 材料在 replays/<run-id>/
```

它不制造新失败、不写回归集，只把归档材料交给当前代码重跑一次：

- 读 `replays/<run-id>/` 并回读校验；文件损坏、缺原始候选就直接退出，不会声明「重放过」。
- 版本核对：Prompt 版本与内容指纹、模型别名、三个 Schema、授权策略、知识库版本必须与归档一致；`evidence_policy` 是本次要验证的变量，不计入不一致。
- 第一层：先用归档策略（`relevance-first-v1`）跑筛选，结果要与 `state.json` 里的原判断一致；再用修复后的策略跑一次，结果要等于 `acceptance.json` 的 `required_policy`。
- 第二层：换成录制客户端，走同一个 `answerSalesQuestion` 重新生成答案，按 `acceptance.json` 判定折扣、服务范围、引用与审阅。
- 业务时间取 `input.json` 里的原请求时间，不用当前时间；检索条件由后端固定，模型改不了 keyword，这样重放时才是同一组查询条件。

新运行编号与 Trace 通过 `replay_of` 关联原失败；要请求的数据不在归档里会报材料不匹配并停止，不会回退到真实接口。

| 退出码 | 含义 |
| --- | --- |
| `0` | 两层验收通过 |
| `1` | 缺参数、材料读不到或不完整、版本不一致、运行异常 |
| `2` | 跑完了，但验收项未通过 |
| `3` | 材料不匹配（归档里没有新运行要请求的数据） |

`replays/` 下只有 `raw-results/`、没有 `input.json` 的目录，是 `1.ts`、`2.ts` 的普通运行产出，不能用来重放。

## 每个入口产出什么

`1.ts` 跑一次真实问答再读回日志：

- 客户授权与 CRM 请求各一条（并行工具共用同一个在途查询）；检索路径里带着 `customer_id`、`keyword`、`business_time`；证据筛选记录 `candidate_ids=P-old,P-current`、`selected_ids=P-old`、`selection_rule=relevance_top_1`、`validity_check_applied=false`。
- 按 2.7 的顺序核对客户查询、政策与服务查询、模型生成，输出 2.8 的结论：客户查对、接口都成功、政策返回两版，模型却只拿到旧政策。
- 报告只留连续证据链和 `evidence.selection`、`answer.review` 两条关键记录；末尾汇总失败率、P95 耗时、Token 与成本，缺失值保留未知计数。

`2.ts` 只沿 Trace 看 `P-current` 在哪一步消失：

- 先校验 Trace 与日志指向同一次运行：平台 `run_id`、根节点、`parent_span_id`、本地 `trace_id`。
- 固定五段证据链：检索（P-old / P-current）→ 证据筛选（排除 P-current）→ 模型请求（只有 P-old）→ 模型代次（15% / P-old）→ 答案审阅（未通过）。
- 结论：第一处偏差在证据筛选，不是检索也不是模型，下一步交给 Replay。

`3.ts` 先留材料，再按 4.2 → 4.6 走六步：

1. **留材料并自检**：归档到 `replays/<原运行编号>/`，含原失败、输入、版本、验收规则、上下文与 `raw-results/`；原始返回同时保存新旧两版政策。
2. **复现缺陷**：同一批候选交给旧版证据整理，必须仍选中 `P-old`；没复现就先查材料、版本与配置。
3. **验证修复**：排除 `P-old` 并记录过期原因、保留 `P-current`；边界把业务时间推到 2027-06-01，必须返回依据不足。
4. **完整问答**：换录制客户端，走同一个 `answerSalesQuestion` 重新生成，检查筛选、模型输入、折扣、服务范围、引用与审阅。
5. **真实依赖复测**：换回真实客户端、用当前业务时间再跑一次，与固定材料的复测分开报告。
6. **入回归集**：两层都通过才写 `replays/regression-cases/`，否则不写。

## 版本与边界

| 依赖 | 版本 | 说明 |
| --- | --- | --- |
| `@earendil-works/pi-*` | 1.5.0 | SDK 入口，`tool_execution_end.durationMs` 可用 |
| `@langfuse/pi-observability-plugin` | 0.1.2 | 官方扩展，peer 依赖写 `*`，源码交给 pi 的加载器编译 |
| `typebox` | 1.3.27 | 与 pi 内置版本一致，用于工具参数 Schema |
| Langfuse 自托管 | 4.75.0 | v4 默认 events_only，调用树走 `/api/public/v2/observations` |
| Node.js | >= 22.19 | pi 要求 |