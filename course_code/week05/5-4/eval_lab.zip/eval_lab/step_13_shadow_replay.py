"""9.2拓展：隔离重放已保存的真实任务，不冒充线上A/B。"""
from lab.cli import emit, main, parser, resolve_run
from lab.workflows import shadow_replay


def run():
    p = parser(__doc__)
    p.add_argument("--source-run", required=True)
    p.add_argument("--variant", choices=["v1", "v2"], default="v2")
    p.add_argument("--program-only", action="store_true")
    args = p.parse_args()
    directory, result = shadow_replay(resolve_run(args.source_run), args.variant, not args.program_only)
    emit({"run": directory, "result": result})


if __name__ == "__main__":
    raise SystemExit(main(run))
