"""8.1/8.4：pi只读风险扫描/预审；候选发现交给人复核。"""
from lab.cli import emit, main, parser, resolve_run
from lab.workflows import review_change
from lab.io import read_json


def run():
    p = parser(__doc__)
    p.add_argument("--run", help="已有修复运行；不填则扫描初始工程")
    p.add_argument("--mode", choices=["scan", "pre-pr"], default="scan")
    args = p.parse_args()
    directory = review_change(resolve_run(args.run) if args.run else None, args.mode)
    emit({"run": directory, "report": directory / "artifacts/final_answer.md", "human_review_required": True})
    return 0 if read_json(directory / "manifest.json")["run_status"] == "completed" else 2


if __name__ == "__main__":
    raise SystemExit(main(run))
