"""4.4：汇总真实事件、测试版本与消耗，不把缺失usage填成零。"""
from lab.cli import emit, main, parser, resolve_run
from lab.evidence import collect_evidence


def run():
    p = parser(__doc__, with_run=True)
    args = p.parse_args()
    directory = resolve_run(args.run)
    emit({"run": directory, "metrics": collect_evidence(directory)})


if __name__ == "__main__":
    raise SystemExit(main(run))
