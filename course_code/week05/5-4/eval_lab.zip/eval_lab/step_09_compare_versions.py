"""7.1—7.3/8.2/8.3：真实运行新旧Skill，逐题比较并保留未知，不承诺新版必胜。"""
from lab.cli import emit, main, parser
from lab.analysis import compare
from lab.io import ROOT, read_json


def run():
    p = parser(__doc__)
    p.add_argument("--tasks", nargs="+", default=["duplicate-repair", "rule-retrieval"])
    p.add_argument("--trials", type=int, default=3)
    p.add_argument("--program-only", action="store_true")
    p.add_argument("--include-regression", action="store_true")
    args = p.parse_args()
    names = list(args.tasks)
    if args.include_regression:
        registry = ROOT / "cases/registry.json"
        if registry.exists():
            names += [str(ROOT / x) for x in read_json(registry)["tasks"]]
    directory, report = compare(names, args.trials, not args.program_only)
    emit({"report": directory, "candidate_decision": report["candidate_decision"], "mode": report["evaluation_mode"]})
    return 0 if report["candidate_decision"] == "accept" else 1


if __name__ == "__main__":
    raise SystemExit(main(run))
