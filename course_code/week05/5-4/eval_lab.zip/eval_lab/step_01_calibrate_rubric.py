"""2.3/2.4：同一批人工标注样本，实际调用模型比较两种Rubric。"""
from lab.cli import emit, main, parser
from lab.judge import calibrate


def run():
    p = parser(__doc__)
    p.add_argument("--limit", type=int, help="先用少量样本检查；每个样本分别调用两次模型")
    args = p.parse_args()
    directory, report = calibrate(args.limit)
    emit({"report": str(directory / "report.json"), "results": report})


if __name__ == "__main__":
    raise SystemExit(main(run))
