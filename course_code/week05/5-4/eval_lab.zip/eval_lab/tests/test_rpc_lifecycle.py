"""Transport unit fixtures only; no model answers are claimed here."""
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from lab.pi_client import execute_rpc


class LifecycleTests(unittest.TestCase):
    def test_unicode_separator_does_not_break_jsonl_and_acceptance_is_not_completion(self):
        script = '''
import json,sys
sys.stdin.buffer.readline()
for obj in [
 {"type":"response","id":"task-prompt","success":True},
 {"type":"message_end","message":{"role":"assistant","content":[{"type":"text","text":"a\\u2028b"}]}},
 {"type":"agent_end","messages":[]},
 {"type":"agent_settled","aborted":False}]:
 sys.stdout.buffer.write(json.dumps(obj,ensure_ascii=False).encode()+b"\\n")
 sys.stdout.buffer.flush()
'''
        with tempfile.TemporaryDirectory() as d:
            result = execute_rpc([sys.executable, "-c", script], d, os.environ.copy(), "test", Path(d)/"trace.jsonl", 5)
            self.assertEqual(result["run_status"], "completed")
            self.assertEqual(result["final_answer"], "a\u2028b")
            self.assertEqual(len(result["events"]), 4)

    def test_prompt_accepted_but_process_exit_is_not_success(self):
        script = 'import sys; sys.stdin.buffer.readline(); print(\'{"type":"response","id":"task-prompt","success":true}\',flush=True)'
        with tempfile.TemporaryDirectory() as d:
            result = execute_rpc([sys.executable, "-c", script], d, os.environ.copy(), "test", Path(d)/"trace.jsonl", 5)
            self.assertEqual(result["run_status"], "process_exit")

    def test_deadline_is_preserved_instead_of_success(self):
        script = 'import sys,time; sys.stdin.buffer.readline(); time.sleep(30)'
        with tempfile.TemporaryDirectory() as d:
            result = execute_rpc([sys.executable, "-c", script], d, os.environ.copy(), "test", Path(d)/"trace.jsonl", 0.1)
            self.assertEqual(result["run_status"], "timeout")


if __name__ == "__main__":
    unittest.main()
