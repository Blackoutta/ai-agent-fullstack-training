"""Real Pi process + synthetic local HTTP transport. NOT a real-model eval.

The transport fixture only tests protocol, tool execution, tracing and SSE.
Its runs are labelled protocol_test and rejected by the release gate.
"""
import json
import os
import shutil
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from unittest.mock import patch

from lab.io import ROOT, read_json, read_jsonl
from lab.runner import run_agent
from lab.tasks import load_task
from lab.evidence import collect_evidence
from lab.grading import grade_run, release_gate


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def do_POST(self):
        data = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        self.server.requests.append(data)
        turn = len(self.server.requests)
        if turn == 1:
            delta = {"role": "assistant", "tool_calls": [{"index": 0, "id": "call-read", "type": "function",
                     "function": {"name": "read", "arguments": json.dumps({"path": "../manifest.json" if getattr(self.server, "guard_test", False) else "docs/rules.md"})}}]}
            finish = "tool_calls"
        elif turn == 2:
            delta = {"role": "assistant", "tool_calls": [{"index": 0, "id": "call-tests", "type": "function",
                     "function": {"name": "run_tests", "arguments": "{}"}}]}
            finish = "tool_calls"
        else:
            delta = {"role": "assistant", "content": "协议测试：只运行了开发smoke测试，未完成修复；并发与回滚未验证。"}
            finish = "stop"
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("x-request-id", "transport-test")
        self.end_headers()
        chunks = [
            {"choices": [{"index": 0, "delta": delta, "finish_reason": None}]},
            {"choices": [{"index": 0, "delta": {}, "finish_reason": finish}]},
            {"choices": [], "usage": {"prompt_tokens": 100, "completion_tokens": 12, "total_tokens": 112,
                                      "prompt_tokens_details": {"cached_tokens": 0}}},
        ]
        for chunk in chunks:
            chunk.update(id="chatcmpl-transport-test", object="chat.completion.chunk", model=data["model"])
            self.wfile.write(("data: " + json.dumps(chunk, ensure_ascii=False) + "\n\n").encode())
        self.wfile.write(b"data: [DONE]\n\n")
        self.wfile.flush()


@unittest.skipUnless((ROOT / "node_modules/.bin/pi").exists(), "Run npm ci to enable actual Pi protocol tests")
class PiProtocolTests(unittest.TestCase):
    def test_real_pi_tools_and_capture_with_both_provider_payloads(self):
        for provider in ["openai", "deepseek"]:
            with self.subTest(provider=provider):
                server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
                server.requests = []
                worker = threading.Thread(target=server.serve_forever, daemon=True)
                worker.start()
                directory = None
                env = {"LLM_PROVIDER": provider, "LLM_MODEL": "protocol-test-model", "PI_COMMAND": "",
                    "OPENAI_API_KEY": "transport-test-not-real", "DEEPSEEK_API_KEY": "transport-test-not-real",
                    "OPENAI_BASE_URL": f"http://127.0.0.1:{server.server_port}/v1",
                    "DEEPSEEK_BASE_URL": f"http://127.0.0.1:{server.server_port}/v1",
                    "LLM_GATEWAY_URL": "", "LLM_GATEWAY_KEY": "", "EVAL_TRANSPORT_TEST": "1"}
                try:
                    with patch.dict(os.environ, env):
                        directory = run_agent(load_task("duplicate-repair"), timeout=25)
                        m = read_json(directory / "manifest.json")
                        self.assertEqual(m["run_status"], "completed", (m, (directory / "pi_stderr.log").read_text()))
                        self.assertEqual(m["source"], "protocol_test")
                        self.assertEqual(len(server.requests), 3)
                        self.assertIn("相同编号和参数重复调用", json.dumps(server.requests[0], ensure_ascii=False))
                        self.assertEqual(server.requests[0]["stream"], True)
                        if provider == "deepseek":
                            self.assertEqual(server.requests[0]["thinking"], {"type": "disabled"})
                        else:
                            self.assertNotIn("thinking", server.requests[0])
                        native = read_jsonl(directory / "provider_trace.jsonl")
                        tests = [e for e in native if e["type"] == "development_test"]
                        self.assertEqual(len(tests), 1)
                        self.assertEqual(tests[0]["exit_code"], 0)
                        metrics = collect_evidence(directory)
                        self.assertEqual(metrics["agent"]["total_tokens"], 336)
                        self.assertTrue(metrics["agent"]["provider_request_capture_available"])
                        grade_run(directory)
                        self.assertEqual(release_gate(directory, require_judge=False)["decision"], "reject")
                        trace = (directory / "provider_trace.jsonl").read_text()
                        self.assertNotIn("transport-test-not-real", trace)
                finally:
                    server.shutdown()
                    server.server_close()
                    worker.join(timeout=2)
                    if directory:
                        shutil.rmtree(directory)

    def test_outside_read_is_blocked_and_reported(self):
        server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        server.requests, server.guard_test = [], True
        worker = threading.Thread(target=server.serve_forever, daemon=True)
        worker.start()
        directory = None
        env = {"LLM_PROVIDER": "openai", "LLM_MODEL": "protocol-test-model", "PI_COMMAND": "",
               "OPENAI_API_KEY": "transport-test-not-real", "OPENAI_BASE_URL": f"http://127.0.0.1:{server.server_port}/v1",
               "LLM_GATEWAY_URL": "", "LLM_GATEWAY_KEY": "", "EVAL_TRANSPORT_TEST": "1"}
        try:
            with patch.dict(os.environ, env):
                directory = run_agent(load_task("duplicate-repair"), timeout=25)
                self.assertEqual(read_json(directory / "manifest.json")["run_status"], "completed")
                native = read_jsonl(directory / "provider_trace.jsonl")
                blocked = [x for x in native if x["type"] == "tool_blocked"]
                self.assertEqual(len(blocked), 1)
                self.assertIn("工作区以外", blocked[0]["reason"])
                grades = grade_run(directory)
                boundary = next(x for x in grades["checks"] if x["id"] == "permission_attempts")
                self.assertEqual(boundary["status"], "fail")
        finally:
            server.shutdown()
            server.server_close()
            worker.join(timeout=2)
            if directory:
                shutil.rmtree(directory)


if __name__ == "__main__":
    unittest.main()
