"""Temporary workflow fixtures test admission rules, not model performance."""
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from lab.io import read_json, tree_hash, write_json
from lab.workflows import case_to_regression, shadow_replay


class WorkflowTests(unittest.TestCase):
    def make_run(self, root, name, fail=True, source="pi_live"):
        directory = root / name
        (directory / "initial").mkdir(parents=True)
        (directory / "workspace").mkdir()
        (directory / "initial/inventory.py").write_text("# original input\n")
        (directory / "workspace/inventory.py").write_text("# candidate output\n")
        task = {"id": "fixture", "name": "workflow unit fixture", "checks": ["duplicate"], "kind": "coding"}
        write_json(directory / "manifest.json", {"run_id": name, "source": source, "task": task,
            "initial_tree_sha256": tree_hash(directory / "initial"),
            "final_tree_sha256": tree_hash(directory / "workspace")})
        write_json(directory / "program_grades.json", {"tree_sha256": tree_hash(directory / "workspace"),
            "checks": [{"id": "duplicate", "status": "fail" if fail else "pass"}]})
        return directory

    def test_candidate_uses_original_input_and_only_validated_approval_registers(self):
        with tempfile.TemporaryDirectory() as tmp, patch("lab.workflows.ROOT", Path(tmp)):
            root = Path(tmp)
            failed, repaired = self.make_run(root, "failed"), self.make_run(root, "repaired", fail=False)
            case, result = case_to_regression(failed)
            self.assertEqual(result["state"], "candidate")
            self.assertEqual((case / "fixture/inventory.py").read_text(), "# original input\n")
            self.assertFalse((root / "cases/registry.json").exists())
            with patch("lab.grading.release_gate", return_value={"decision": "pending"}):
                with self.assertRaisesRegex(ValueError, "完整独立验收"):
                    case_to_regression(failed, repaired, True, "reviewer")
            self.assertFalse((root / "cases/registry.json").exists())
            with patch("lab.grading.release_gate", return_value={"decision": "accept"}):
                manifest = read_json(repaired / "manifest.json")
                manifest["initial_tree_sha256"] = "different"
                write_json(repaired / "manifest.json", manifest)
                with self.assertRaisesRegex(ValueError, "相同任务与初始工程"):
                    case_to_regression(failed, repaired, True, "reviewer")
                manifest["initial_tree_sha256"] = tree_hash(failed / "initial")
                write_json(repaired / "manifest.json", manifest)
                _, result = case_to_regression(failed, repaired, True, "reviewer")
            self.assertEqual(result["state"], "active_regression")
            self.assertEqual(read_json(root / "cases/registry.json")["tasks"], ["cases/case_failed/task.json"])
            self.assertEqual(case_to_regression(failed)[1]["state"], "active_regression")

    def test_non_live_success_and_stale_evidence_do_not_create_regressions(self):
        with tempfile.TemporaryDirectory() as tmp, patch("lab.workflows.ROOT", Path(tmp)):
            root = Path(tmp)
            for name, fail, source in [("protocol", True, "protocol_test"), ("success", False, "pi_live")]:
                with self.assertRaises(ValueError):
                    case_to_regression(self.make_run(root, name, fail, source))
            stale = self.make_run(root, "stale")
            (stale / "workspace/inventory.py").write_text("# changed after grading\n")
            with self.assertRaisesRegex(ValueError, "过期"):
                case_to_regression(stale)
            self.assertFalse((root / "cases").exists())

    def test_shadow_replays_initial_input_and_preserves_original(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            original = self.make_run(root, "original")
            candidate = root / "candidate"
            before = tree_hash(original)
            with patch("lab.workflows.run_agent", return_value=candidate) as launch, \
                 patch("lab.workflows.assess", return_value={"decision": "pending"}):
                _, result = shadow_replay(original, "v2")
            self.assertEqual(launch.call_args.kwargs["workspace_source"], original / "initial")
            self.assertEqual(tree_hash(original), before)
            self.assertEqual(result["mode"], "isolated_replay_not_online_ab")


if __name__ == "__main__":
    unittest.main()
