import json
import os
import shutil
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from lab.config import settings
from lab.evidence import normalize_usage, summarize_usage
from lab.grading import check_behavior, boundary_check, release_gate
from lab.io import ROOT, read_json, write_json, snapshot_tree, tree_hash
from lab.judge import validate_checks
from lab.statistics import summarize
from lab.tasks import CHECKS, all_tasks


class BehaviorTests(unittest.TestCase):
    def test_reference_passes_every_independent_check(self):
        rows = check_behavior(ROOT / "references/inventory.py", sorted(CHECKS))
        self.assertTrue(all(x["status"] == "pass" for x in rows), rows)

    def test_broken_implementation_does_not_pass_the_target_checks(self):
        rows = check_behavior(ROOT / "fixtures/project/inventory.py", ["duplicate", "conflict", "rollback"])
        self.assertTrue(all(x["status"] == "fail" for x in rows), rows)
        self.assertEqual(rows[0]["observations"]["state"]["available"], 6)

    def test_task_definitions_are_valid(self):
        self.assertEqual(len(all_tasks()), 3)


class EvidenceTests(unittest.TestCase):
    def test_unknown_usage_stays_unknown(self):
        cfg = settings(require_key=False)
        result = summarize_usage([normalize_usage({"prompt_tokens": 20, "completion_tokens": 5}), None], cfg)
        self.assertIsNone(result["total_tokens"])
        self.assertEqual(result["known_total_tokens"], 25)
        self.assertEqual(result["unknown_usage_calls"], 1)
        self.assertIsNone(result["estimated_cost"])

    def test_pi_cached_input_is_part_of_total_input(self):
        result = normalize_usage({"input": 10, "output": 3, "cacheRead": 7, "cacheWrite": 0})
        self.assertEqual(result["input_tokens"], 17)
        self.assertEqual(result["total_tokens"], 20)

    def test_different_keys_do_not_select_wrong_provider(self):
        with patch.dict(os.environ, {"LLM_PROVIDER": "openai", "OPENAI_API_KEY": "test-key", "LLM_MODEL": "test-model"}):
            cfg = settings()
            self.assertEqual(cfg.provider, "openai")
            self.assertEqual(cfg.model, "test-model")


class GradingTests(unittest.TestCase):
    def test_new_tests_allowed_existing_contract_edits_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            p = Path(temp)
            shutil.copytree(ROOT / "fixtures/project", p / "workspace")
            p = p / "workspace"
            initial = snapshot_tree(p)
            (p / "tests/test_added.py").write_text("# new test\n")
            self.assertEqual(boundary_check(p, initial)["status"], "pass")
            (p / "contracts/response.json").write_text("{}")
            self.assertEqual(boundary_check(p, initial)["status"], "fail")

    def test_judge_cannot_invent_evidence_ids_or_omit_checks(self):
        value = {"checks": [{"id": "claim_grounded", "status": "pass", "reason": "ok", "evidence": ["nonexistent"]}]}
        with self.assertRaises(ValueError):
            validate_checks(value, ["claim_grounded"], {"report"})
        with self.assertRaises(ValueError):
            validate_checks({"checks": []}, ["claim_grounded"], {"report"})

    def test_unknown_judge_never_accepts_and_changed_code_invalidates_scores(self):
        with tempfile.TemporaryDirectory() as temp:
            d = Path(temp)
            shutil.copytree(ROOT / "fixtures/project", d / "workspace")
            h = tree_hash(d / "workspace")
            manifest = {"run_id": "unit-fixture-not-a-model-run", "source": "pi_live", "run_status": "completed",
                "task": {"checks": [], "required_semantic_checks": ["claim_grounded"]}, "final_tree_sha256": h}
            write_json(d / "manifest.json", manifest)
            write_json(d / "program_grades.json", {"tree_sha256": h, "checks": [
                {"id": "boundary", "status": "pass"}, {"id": "permission_attempts", "status": "pass"},
                {"id": "grading_no_source_mutation", "status": "pass"}]})
            write_json(d / "judge_grades.json", {"status": "ok", "tree_sha256": h,
                "checks": [{"id": "claim_grounded", "status": "unknown"}]})
            self.assertEqual(release_gate(d)["decision"], "pending")
            data = read_json(d / "judge_grades.json")
            data["checks"][0]["status"] = "pass"
            write_json(d / "judge_grades.json", data)
            self.assertEqual(release_gate(d)["decision"], "accept")
            with (d / "workspace/inventory.py").open("a") as f:
                f.write("\n# changed after grading\n")
            self.assertEqual(release_gate(d)["decision"], "pending")
            manifest["source"] = "protocol_test"
            write_json(d / "manifest.json", manifest)
            self.assertEqual(release_gate(d)["decision"], "reject")


class StatisticsTests(unittest.TestCase):
    def test_two_of_three_is_not_pass_at_three(self):
        result = summarize([True, False, True], 3)
        self.assertAlmostEqual(result["confirmed_pass_fraction"], 2/3)
        self.assertEqual(result["pass_at_k_estimate"], 1)
        self.assertEqual(result["pass_all_k_estimate"], 0)

    def test_unknown_trials_are_not_silently_deleted(self):
        result = summarize([True, None, True], 3)
        self.assertEqual(result["runs"], 3)
        self.assertEqual(result["unknown"], 1)
        self.assertIsNone(result["pass_at_k_estimate"])


if __name__ == "__main__":
    unittest.main()
