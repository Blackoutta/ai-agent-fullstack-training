"""Tests only the compatible streaming client against a local HTTP fixture."""
import json
import os
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from unittest.mock import patch

from lab.llm import chat_json
from lab.judge import judge_material


class JudgeHandler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def do_POST(self):
        data = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        self.server.requests.append(data)
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.end_headers()
        mode = self.server.mode
        if mode == "bad_json":
            answer = "not a JSON result"
        elif mode == "invented_ref":
            answer = json.dumps({"checks": [{"id": "claim_grounded", "status": "pass", "reason": "looks good", "evidence": ["invented"]}]})
        else:
            answer = json.dumps({"checks": [{"id": "claim_grounded", "status": "unknown", "reason": "记录不足", "evidence": []}]}, ensure_ascii=False)
        for text in [answer[:12], answer[12:]]:
            self.wfile.write(("data: " + json.dumps({"model": "transport-fixture", "choices": [{"delta": {"content": text}}]}, ensure_ascii=False) + "\n\n").encode())
        self.wfile.write(b'data: {"choices":[],"usage":{"prompt_tokens":20,"completion_tokens":10,"total_tokens":30}}\n\n')
        if mode != "partial":
            self.wfile.write(b"data: [DONE]\n\n")
        self.wfile.flush()


class LLMTransportTests(unittest.TestCase):
    def setUp(self):
        self.server = ThreadingHTTPServer(("127.0.0.1", 0), JudgeHandler)
        self.server.requests = []
        self.server.mode = "normal"
        self.worker = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.worker.start()
        self.env = patch.dict(os.environ, {"LLM_PROVIDER": "openai", "OPENAI_API_KEY": "transport-fixture-not-a-key",
            "OPENAI_BASE_URL": f"http://127.0.0.1:{self.server.server_port}/v1", "LLM_MODEL": "transport-fixture",
            "LLM_GATEWAY_URL": "", "LLM_GATEWAY_KEY": ""})
        self.env.start()

    def tearDown(self):
        self.env.stop()
        self.server.shutdown()
        self.server.server_close()
        self.worker.join(timeout=2)

    def test_stream_reconstruction_and_unknown(self):
        result = judge_material({"report": "记录缺失"}, ["claim_grounded"])
        self.assertEqual(result["status"], "ok")
        self.assertEqual(result["checks"][0]["status"], "unknown")
        self.assertTrue(self.server.requests[0]["stream"])

    def test_invalid_json_is_error_not_success(self):
        self.server.mode = "bad_json"
        result = judge_material({"report": "text"}, ["claim_grounded"])
        self.assertEqual(result["status"], "error")

    def test_invented_reference_is_error(self):
        self.server.mode = "invented_ref"
        result = judge_material({"report": "text"}, ["claim_grounded"])
        self.assertEqual(result["status"], "error")

    def test_partial_sse_is_not_a_complete_response(self):
        self.server.mode = "partial"
        result = chat_json("只输出JSON", {}, retries=0)
        self.assertEqual(result["status"], "error")
        self.assertIn("[DONE]", result["error"])


if __name__ == "__main__":
    unittest.main()
