"""Teaching defect fixture. This is intentionally incorrect, not a reference."""
import sqlite3
import time


def initialize(db_path, stock=10):
    with sqlite3.connect(db_path) as db:
        db.executescript('''
            CREATE TABLE IF NOT EXISTS inventory(sku TEXT PRIMARY KEY, available INTEGER NOT NULL);
            CREATE TABLE IF NOT EXISTS reservations(
                id INTEGER PRIMARY KEY AUTOINCREMENT, request_id TEXT NOT NULL,
                sku TEXT NOT NULL, quantity INTEGER NOT NULL);
        ''')
        db.execute("INSERT OR REPLACE INTO inventory VALUES (?, ?)", ("sku-1", stock))


def reserve(db_path, request_id, sku="sku-1", quantity=2, fail_at=None):
    if not isinstance(request_id, str) or not request_id or type(quantity) is not int or quantity <= 0:
        return {"status": "invalid_request"}
    seen = set()  # Bug: recreated for every invocation.
    if request_id in seen:
        return {"status": "reserved", "request_id": request_id, "sku": sku,
                "quantity": quantity, "replayed": True}
    with sqlite3.connect(db_path, timeout=15) as db:
        row = db.execute("SELECT available FROM inventory WHERE sku=?", (sku,)).fetchone()
        if row is None:
            return {"status": "invalid_request"}
        if row[0] < quantity:
            return {"status": "insufficient_stock"}
        time.sleep(0.01)  # Simulated I/O exposes the check/update race in this fixture.
        db.execute("UPDATE inventory SET available=available-? WHERE sku=?", (quantity, sku))
    if fail_at == "after_inventory":
        raise RuntimeError("injected_after_inventory")  # Bug: inventory was already committed.
    with sqlite3.connect(db_path, timeout=15) as db:
        db.execute("INSERT INTO reservations(request_id,sku,quantity) VALUES(?,?,?)",
                   (request_id, sku, quantity))
    seen.add(request_id)
    return {"status": "reserved", "request_id": request_id, "sku": sku,
            "quantity": quantity, "replayed": False}
