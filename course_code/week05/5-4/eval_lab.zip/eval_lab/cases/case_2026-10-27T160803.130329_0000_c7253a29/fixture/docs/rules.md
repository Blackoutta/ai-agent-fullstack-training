# 当前库存预占规则（本实验的有效业务契约，版本 1）

本实验只实现单商品库存预占，不包含支付确认、释放、多仓库或生产性能承诺。

## 调用方式

- `initialize(db_path, stock=10)` 初始化独立 SQLite 数据库。商品为 `sku-1`。
- `reserve(db_path, request_id, sku="sku-1", quantity=2, fail_at=None)`。
- 函数签名、数据库表名和已有列、返回结构必须保持兼容。
- 表：inventory(sku, available)，reservations(id, request_id, sku, quantity)。可以增加索引。

## 必须满足的行为

1. 正常预占：库存10件，预占2件，最终库存8件，一条有效预占记录。
2. 同一请求编号和相同参数重复提交，只能产生一次有效预占。第一次 `replayed=false`，重试 `replayed=true`。
3. 同一编号携带不同 sku 或 quantity 返回 `{"status":"conflict"}`，不能再次改变库存或记录。
4. 不同编号并发竞争，成功预占总量不能超过库存，且库存与有效预占总量一致。不能拒绝所有合法请求来规避问题。
5. 相同编号并发重试也只能产生一次有效预占。
6. 库存不足返回 `{"status":"insufficient_stock"}`，没有额外业务修改。
7. request_id 必须为非空字符串，quantity 必须为正整数（bool 不算整数）；非法值或未知 sku 返回 `{"status":"invalid_request"}`。
8. `fail_at="after_inventory"` 表示在库存更新之后、写入预占记录之前注入 RuntimeError。
   这次操作必须整体回滚；正常路径不能忽略此参数以绕过检查。

成功响应必须恰好包含 status、request_id、sku、quantity、replayed 五个字段。
失败响应的 status 必须符合上面的业务分类。

## 开发与验收

- 只能修改 inventory.py，可新增 tests/test_*.py，不得修改已有 test_smoke.py、docs、contracts、AGENTS.md。
- 使用 run_tests 执行开发用例。初始 smoke 测试通过不代表上述缺陷已解决。
- 独立验收由宿主在最终代码上执行；Agent 的报告不能代替实际验证。
- 若任务只要求修复某一项，仍需保持该任务列明的既有能力；未完成的其他问题要明确说明。
