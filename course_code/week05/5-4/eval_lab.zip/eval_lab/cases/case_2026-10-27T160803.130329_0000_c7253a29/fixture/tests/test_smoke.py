"""Existing baseline tests. Agent may add tests, not edit this file."""
import tempfile
import unittest
from pathlib import Path
from inventory import initialize, reserve


class SmokeTest(unittest.TestCase):
    def test_normal_reservation(self):
        with tempfile.TemporaryDirectory() as directory:
            path = str(Path(directory) / "inventory.db")
            initialize(path, 10)
            result = reserve(path, "smoke", quantity=2)
            self.assertEqual(result, {"status": "reserved", "request_id": "smoke",
                                     "sku": "sku-1", "quantity": 2, "replayed": False})


if __name__ == "__main__":
    unittest.main()
