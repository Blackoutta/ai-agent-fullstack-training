"""3.2/3.3：验证题目能做、正确实现能过、目标缺陷能被识别。无需模型。"""
from lab.cli import emit, main, parser
from lab.grading import check_behavior
from lab.io import ROOT, write_json
from lab.tasks import all_tasks, CHECKS


def run():
    parser(__doc__).parse_args()
    tasks = all_tasks()
    reference = check_behavior(ROOT / "references/inventory.py", sorted(CHECKS))
    broken = check_behavior(ROOT / "fixtures/project/inventory.py", ["duplicate", "conflict", "rollback"])
    valid = all(c["status"] == "pass" for c in reference) and all(c["status"] == "fail" for c in broken)
    report = {"source": "reference_and_known_defect_not_agent", "tasks": [{"id": t["id"], "name": t["name"], "kind": t["kind"], "checks": t["checks"]} for t in tasks],
              "reference": reference, "known_defects": broken, "valid": valid,
              "note": "只证明题目与评分器基本可用，不代表真实Agent已经通过。"}
    write_json(ROOT / "reports/task_validation.json", report)
    emit(report)
    return 0 if valid else 1


if __name__ == "__main__":
    raise SystemExit(main(run))
