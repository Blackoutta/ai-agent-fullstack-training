from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from .io import ROOT, read_json


def resolve_run(value="latest"):
    if value != "latest":
        path = Path(value)
        if not path.is_absolute() and not path.exists():
            path = ROOT / "runs" / value
    else:
        runs = sorted((ROOT / "runs").glob("*/manifest.json"), key=lambda p: p.stat().st_mtime)
        if not runs:
            raise ValueError("尚无运行记录。先运行 step_03_run_trial.py")
        path = runs[-1].parent
    if not (path / "manifest.json").is_file():
        raise ValueError("不是有效运行包：" + str(path))
    return path.resolve()


def parser(description, with_run=False):
    p = argparse.ArgumentParser(description=description)
    if with_run:
        p.add_argument("--run", default="latest", help="运行目录、运行编号或latest")
    return p


def emit(value):
    print(json.dumps(value, ensure_ascii=False, indent=2, default=str))


def main(function):
    try:
        result = function()
        return result if isinstance(result, int) else 0
    except KeyboardInterrupt:
        print("已取消。", file=sys.stderr)
        return 130
    except (ValueError, OSError, KeyError) as exc:
        print(f"错误：{exc}", file=sys.stderr)
        return 2
