from __future__ import annotations

import os
import shlex
import shutil
import sys
from dataclasses import dataclass
from pathlib import Path
from .io import ROOT, load_env


@dataclass
class Config:
    base_url: str
    model: str
    key: str
    pi: list[str]
    timeout: float
    max_turns: int
    max_output_tokens: int
    temperature: float
    input_price: float | None
    output_price: float | None
    cached_input_price: float | None
    provider: str = "deepseek"


def _price(name):
    val = os.environ.get(name, "").strip()
    return float(val) if val else None


def settings(require_key=True):
    load_env()
    provider = os.environ.get("LLM_PROVIDER", "deepseek").lower()
    if provider not in {"deepseek", "openai"}:
        raise ValueError("LLM_PROVIDER 只能是 deepseek 或 openai")
    key = os.environ.get("LLM_GATEWAY_KEY") or os.environ.get("OPENAI_API_KEY" if provider == "openai" else "DEEPSEEK_API_KEY", "")
    if require_key and not key:
        raise ValueError("未配置模型密钥。请在 .env 填写当前 provider 对应的 API key，或 LLM_GATEWAY_KEY。")
    base = os.environ.get("LLM_GATEWAY_URL") or (os.environ.get("OPENAI_BASE_URL", "https://api.openai.com/v1") if provider == "openai" else os.environ.get("DEEPSEEK_BASE_URL", "https://api.deepseek.com"))
    base = base.rstrip("/")
    if base.endswith("/chat/completions"):
        raise ValueError("base URL 应填写 API 基址，不要包含 /chat/completions。")
    local = ROOT / "node_modules" / ".bin" / ("pi.cmd" if os.name == "nt" else "pi")
    cmd = os.environ.get("PI_COMMAND")
    pi = shlex.split(cmd) if cmd else [str(local) if local.exists() else (shutil.which("pi") or "pi")]
    if not pi:
        raise ValueError("PI_COMMAND 不能为空白命令")
    return Config(base, os.environ.get("LLM_MODEL", "gpt-4.1-mini" if provider == "openai" else "deepseek-flash"), key, pi,
                  float(os.environ.get("TASK_TIMEOUT", "300")),
                  int(os.environ.get("MAX_AGENT_TURNS", "18")),
                  int(os.environ.get("MAX_OUTPUT_TOKENS", "8192")),
                  float(os.environ.get("LLM_TEMPERATURE", "0.2")),
                  _price("INPUT_PRICE_PER_MILLION"), _price("OUTPUT_PRICE_PER_MILLION"),
                  _price("CACHED_INPUT_PRICE_PER_MILLION"), provider)


def make_agent_config(directory: Path, cfg: Config):
    from .io import write_json
    directory.mkdir(parents=True, exist_ok=True)
    write_json(directory / "models.json", {"providers": {"eval-model": {
        "baseUrl": cfg.base_url, "api": "openai-completions", "apiKey": "$EVAL_API_KEY",
        "models": [{"id": cfg.model, "name": cfg.provider + " evaluation model", "reasoning": False,
                    "input": ["text"], "contextWindow": 128000, "maxTokens": cfg.max_output_tokens,
                    "compat": {"supportsDeveloperRole": False, "supportsStore": False}}]}}})
    write_json(directory / "settings.json", {"retry": {"enabled": False},
        "compaction": {"enabled": False}, "packages": []})


def safe_python_env():
    # A test subprocess does not need the model key or user Python startup config.
    return {**{k: os.environ[k] for k in ("PATH", "LANG", "LC_ALL", "SYSTEMROOT", "TMPDIR") if k in os.environ},
            "PYTHONIOENCODING": "utf-8", "PYTHONDONTWRITEBYTECODE": "1", "PYTHONHASHSEED": "0"}
