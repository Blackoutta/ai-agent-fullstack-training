"""Small, explicit persistence helpers; JSONL is an append-only event log."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[1]


def utcnow():
    return datetime.now(timezone.utc).isoformat()


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def append_jsonl(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(value, ensure_ascii=False) + "\n")


def read_jsonl(path):
    path = Path(path)
    if not path.exists():
        return []
    return [json.loads(s) for s in path.read_text(encoding="utf-8").splitlines() if s.strip()]


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def snapshot_tree(path):
    """Content identity, including untracked files; ignore generated caches/DBs."""
    result = {}
    for item in sorted(Path(path).rglob("*")):
        relative = item.relative_to(path)
        if any(p in {"__pycache__", ".git", "node_modules"} for p in relative.parts):
            continue
        if item.is_file() and not item.is_symlink() and item.suffix not in {".pyc", ".db", ".sqlite"}:
            result[relative.as_posix()] = digest(item)
    return result


def tree_hash(path):
    data = json.dumps(snapshot_tree(path), sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(data).hexdigest()


def scrub(value):
    """No credentials or thinking content in persisted public traces."""
    secrets = [os.environ.get(k, "") for k in ("DEEPSEEK_API_KEY", "OPENAI_API_KEY", "LLM_GATEWAY_KEY", "EVAL_API_KEY")]
    hidden = {"authorization", "api_key", "apikey", "reasoning_content", "reasoning", "thinking", "thought"}
    if isinstance(value, dict):
        if value.get("type") in {"thinking", "thinking_delta", "thinking_end", "thinking_start"}:
            return {"type": "thinking_redacted"}
        return {k: scrub(v) for k, v in value.items() if k.lower() not in hidden}
    if isinstance(value, list):
        return [scrub(v) for v in value]
    if isinstance(value, str):
        for secret in secrets:
            if secret:
                value = value.replace(secret, "[REDACTED]")
    return value


def load_env():
    """Read KEY=value, without shell evaluation or modifying an existing env."""
    path = ROOT / ".env"
    if path.exists():
        for raw in path.read_text(encoding="utf-8").splitlines():
            raw = raw.strip()
            if not raw or raw.startswith("#") or "=" not in raw:
                continue
            key, val = raw.removeprefix("export ").split("=", 1)
            val = val.strip()
            if len(val) >= 2 and val[0] == val[-1] and val[0] in "\"'":
                val = val[1:-1]
            os.environ.setdefault(key.strip(), val)
