from __future__ import annotations

import copy
import json
from pathlib import Path
from .io import ROOT, read_json, digest

REQUIRED = {"id", "name", "kind", "prompt", "checks", "references", "forbidden_paths", "version"}
CHECKS = {"normal", "duplicate", "conflict", "concurrent", "concurrent_duplicate", "rollback", "contract", "invalid"}


def load_task(name="inventory-refactor", file=None):
    data = read_json(file or ROOT / "tasks" / f"{name}.json")
    missing = REQUIRED - data.keys()
    if missing:
        raise ValueError(f"任务缺字段：{sorted(missing)}")
    if data["kind"] not in {"coding", "retrieval", "understanding"}:
        raise ValueError("未知 task kind")
    if set(data["checks"]) - CHECKS:
        raise ValueError("未知程序检查项")
    fixture = (ROOT / data.get("fixture", "fixtures/project")).resolve()
    if not fixture.is_relative_to(ROOT.resolve()):
        raise ValueError("任务fixture必须在本实验工程内部")
    for item in data["references"]:
        if not (fixture / item).is_file():
            raise ValueError(f"资料不存在：{item}")
    return data


def all_tasks():
    return [load_task(file=p) for p in sorted((ROOT / "tasks").glob("*.json"))]


def effective_prompt(task):
    if task["kind"] != "coding":
        return task["prompt"] + "\n只读工程，不执行修复。引用当前有效规则，证据不足时明确说明。"
    return task["prompt"] + "\n\n共同交付要求：\n" + (
        "先读取 AGENTS.md 与 docs/rules.md；存在 docs/archive_2024.md 时注意它已过期。\n"
        "只能修改 inventory.py，可新增 tests/test_*.py；不得改现有 tests/test_smoke.py、docs 或 contracts。\n"
        "使用 run_tests 执行开发测试。独立验收由宿主负责，不要尝试寻找参考实现或独立评分器。\n"
        "技能内容已由宿主注入上下文，不要从磁盘读取任何 SKILL.md；只用相对路径访问本工程内文件，禁止用绝对路径访问工程外路径。\n"
        "最终说明实际改动、实际执行的测试、验证结果及未验证内容；不能把计划写成已完成。\n"
    )
