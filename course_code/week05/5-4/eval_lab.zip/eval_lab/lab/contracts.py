"""Executable Schema/Snapshot examples; structural success is not business success."""
import json


def check_success_schema(value):
    keys = {"status", "request_id", "sku", "quantity", "replayed"}
    return (isinstance(value, dict) and set(value) == keys and value["status"] == "reserved"
            and isinstance(value["request_id"], str) and isinstance(value["sku"], str)
            and type(value["quantity"]) is int and type(value["replayed"]) is bool)


def stable_response_snapshot(value):
    # request_id is request-specific: compare its type/schema, not a fixed literal.
    # All other fields remain part of the snapshot. No arbitrary field deletion.
    normalized = dict(value)
    if "request_id" in normalized:
        normalized["request_id"] = "<request-id>"
    return json.dumps(normalized, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
