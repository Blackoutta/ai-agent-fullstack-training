"""Finite-sample estimates, with unknown runs kept visible."""
import math


def summarize(outcomes, k=3):
    n = len(outcomes)
    passed = sum(x is True for x in outcomes)
    failed = sum(x is False for x in outcomes)
    unknown = n - passed - failed
    result = {"runs": n, "passed": passed, "failed": failed, "unknown": unknown,
              "confirmed_pass_fraction": passed / n if n else None, "k": k,
              "pass_at_k_estimate": None, "pass_all_k_estimate": None}
    if n >= k and k > 0 and unknown == 0:
        denominator = math.comb(n, k)
        result["pass_at_k_estimate"] = 1 - (math.comb(n-passed, k) if n-passed >= k else 0) / denominator
        result["pass_all_k_estimate"] = (math.comb(passed, k) if passed >= k else 0) / denominator
    result["interpretation"] = (
        "组合估计需要同题同条件独立尝试。n=k时只是该组的至少一次/全部成功观察，"
        "不是可靠性100%的证明。未知运行不删除；存在未知时不计算k估计。")
    return result
