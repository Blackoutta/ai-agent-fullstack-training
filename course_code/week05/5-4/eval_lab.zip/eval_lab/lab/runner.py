from __future__ import annotations

import difflib
import os
import shutil
import subprocess
import sys
import uuid
from pathlib import Path
from .config import make_agent_config, settings
from .io import ROOT, read_jsonl, scrub, snapshot_tree, tree_hash, utcnow, write_json
from .pi_client import execute_rpc
from .tasks import effective_prompt


def _patch(workspace, initial_dir, output):
    before, after = snapshot_tree(initial_dir), snapshot_tree(workspace)
    chunks = []
    for name in sorted(set(before) | set(after)):
        if before.get(name) == after.get(name):
            continue
        a, b = initial_dir / name, workspace / name
        old = a.read_text(encoding="utf-8", errors="replace").splitlines(True) if a.is_file() else []
        new = b.read_text(encoding="utf-8", errors="replace").splitlines(True) if b.is_file() and not b.is_symlink() else []
        chunks.extend(difflib.unified_diff(old, new, fromfile="a/" + name, tofile="b/" + name))
    output.write_text("".join(chunks), encoding="utf-8")


def run_agent(task, variant="v2", timeout=None, display_stream=False, prompt_override=None,
              readonly=None, workspace_source=None, inject_read_timeout=False):
    cfg = settings()
    if variant not in {"v1", "v2"}:
        raise ValueError("variant 必须是 v1 或 v2")
    source = Path(workspace_source or ROOT / task.get("fixture", "fixtures/project")).resolve()
    if any(p.is_symlink() for p in source.rglob("*")):
        raise ValueError("实验输入不能包含符号链接")
    run_id = utcnow().replace(":", "").replace("+", "_") + "_" + uuid.uuid4().hex[:8]
    directory = ROOT / "runs" / run_id
    workspace, initial = directory / "workspace", directory / "initial"
    ignored = shutil.ignore_patterns("__pycache__", ".git", "node_modules", ".env", "*.db", "*.pyc", "*.db-wal", "*.db-shm")
    shutil.copytree(source, workspace, ignore=ignored)
    shutil.copytree(workspace, initial)
    (directory / "artifacts").mkdir()
    make_agent_config(directory / "agent_config", cfg)
    is_readonly = task["kind"] != "coding" if readonly is None else readonly
    tools = "read,grep,find,ls" if is_readonly else "read,grep,find,ls,edit,write,run_tests"
    instructions = directory / "instructions.md"
    instructions.write_text((ROOT / "fixtures/project/AGENTS.md").read_text(encoding="utf-8"), encoding="utf-8")
    command = cfg.pi + ["--offline", "--mode", "rpc", "--no-session", "--provider", "eval-model", "--model", cfg.model,
        "--thinking", "off", "--no-extensions", "--no-skills", "--no-mcp", "--no-prompt-templates",
        "--no-themes", "--no-context-files", "--no-approve", "--extension", str(ROOT / "extensions/eval_trace.ts"),
        "--append-system-prompt", str(instructions), "--tools", tools]
    prompt = prompt_override or effective_prompt(task)
    if not is_readonly:
        command += ["--skill", str(ROOT / "skills" / variant / "SKILL.md")]
        prompt = "/skill:inventory-review " + prompt
    env = {**os.environ, "PI_CODING_AGENT_DIR": str(directory / "agent_config"), "EVAL_API_KEY": cfg.key,
        "PI_OFFLINE": "1", "PI_TELEMETRY": "0", "PI_SKIP_VERSION_CHECK": "1",
        "EVAL_MODEL_PROVIDER": cfg.provider, "EVAL_WORKSPACE": str(workspace),
        "EVAL_PROVIDER_TRACE": str(directory / "provider_trace.jsonl"), "EVAL_PYTHON": sys.executable,
        "EVAL_READ_ONLY": "1" if is_readonly else "0", "EVAL_MAX_TURNS": str(cfg.max_turns),
        "EVAL_TEMPERATURE": str(cfg.temperature), "EVAL_MAX_OUTPUT": str(cfg.max_output_tokens),
        "EVAL_INJECT_READ_TIMEOUT": "1" if inject_read_timeout else "0"}
    try:
        version = subprocess.run(cfg.pi + ["--offline", "--version"], capture_output=True, text=True, timeout=15, env=env).stdout.strip()
    except (OSError, subprocess.SubprocessError) as exc:
        version = "unavailable: " + str(exc)
    origin = "protocol_test" if os.environ.get("EVAL_TRANSPORT_TEST") == "1" else "pi_live"
    manifest = {"run_id": run_id, "created_at": utcnow(), "source": origin, "task": task,
        "variant": variant, "pi_version": version, "model": cfg.model, "provider": cfg.provider,
        "base_url": cfg.base_url, "temperature": cfg.temperature, "max_turns": cfg.max_turns,
        "max_output_tokens": cfg.max_output_tokens, "timeout": timeout or cfg.timeout,
        "startup_network_disabled": True,
        "readonly": is_readonly, "initial_files": snapshot_tree(workspace), "initial_tree_sha256": tree_hash(workspace),
        "skill_loaded": not is_readonly,
        "skill_sha256": __import__("hashlib").sha256((ROOT / "skills" / variant / "SKILL.md").read_bytes()).hexdigest() if not is_readonly else None,
        "declared_fault": "first_read_timeout" if inject_read_timeout else None,
        "run_status": "starting", "prompt": prompt}
    write_json(directory / "manifest.json", manifest)
    try:
        result = execute_rpc(command, workspace, env, prompt, directory / "trace.jsonl", timeout or cfg.timeout, display_stream)
    except OSError as exc:
        result = {"run_status": "startup_error", "error": str(exc), "final_answer": "", "agent_seconds": 0, "stderr": ""}
    manifest.update({k: scrub(v) for k, v in result.items() if k not in {"events", "final_answer", "stderr"}})
    manifest["finished_at"] = utcnow()
    manifest["final_tree_sha256"] = tree_hash(workspace)
    native = read_jsonl(directory / "provider_trace.jsonl")
    if any(e["type"] == "budget_exceeded" for e in native):
        manifest["run_status"] = "budget_exceeded"
    manifest["provider_request_count"] = sum(e["type"] == "provider_request" for e in native)
    manifest["provider_request_capture_available"] = manifest["provider_request_count"] > 0
    manifest["served_model_identifiers"] = sorted({x["served_model"] for x in native if x["type"] == "provider_model"})
    (directory / "artifacts/final_answer.md").write_text(result.get("final_answer", ""), encoding="utf-8")
    (directory / "pi_stderr.log").write_text(result.get("stderr", ""), encoding="utf-8")
    _patch(workspace, initial, directory / "artifacts/code.patch")
    write_json(directory / "manifest.json", manifest)
    return directory
