"""Independent behavioral assertions; runs in a separate process per check."""
from __future__ import annotations

import contextlib
import importlib.util
import io
import json
import sqlite3
import sys
import tempfile
import threading
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from lab.contracts import check_success_schema, stable_response_snapshot


def state(db_path):
    with sqlite3.connect(db_path) as db:
        available = db.execute("SELECT available FROM inventory WHERE sku='sku-1'").fetchone()[0]
        rows = db.execute("SELECT request_id,sku,quantity FROM reservations ORDER BY id").fetchall()
    return {"available": available, "reservations": [list(x) for x in rows],
            "count": len(rows), "reserved_quantity": sum(x[2] for x in rows)}


def check(module, name, path, observations=None):
    module.initialize(path, 10)
    observations = observations if observations is not None else {}

    def call(request_id="req-1", quantity=2, **kwargs):
        return module.reserve(path, request_id, quantity=quantity, **kwargs)

    def require(ok, message):
        if not ok:
            raise AssertionError(message)

    if name in {"normal", "contract"}:
        response = call()
        observations["response"] = response
        require(check_success_schema(response), "成功响应Schema不符合约定")
        baseline = {"status": "reserved", "request_id": "any", "sku": "sku-1", "quantity": 2, "replayed": False}
        require(stable_response_snapshot(response) == stable_response_snapshot(baseline), "稳定响应Snapshot发生变化")
        require(response == {"status": "reserved", "request_id": "req-1", "sku": "sku-1",
                             "quantity": 2, "replayed": False}, "正常响应与契约不符")
        s = state(path)
        observations["state"] = s
        require(s["available"] == 8 and s["count"] == 1 and s["reserved_quantity"] == 2, "正常请求实际状态不符")
        if name == "contract":
            response = call("req-too-big", 100)
            require(response.get("status") == "insufficient_stock", "库存不足的错误语义不符")
            require(state(path) == s, "库存不足仍然修改业务数据")
    elif name == "duplicate":
        first, second = call(), call()
        s = state(path)
        observations.update(first=first, second=second, state=s)
        require(first.get("status") == second.get("status") == "reserved", "相同请求不能按契约返回")
        require(first.get("replayed") is False and second.get("replayed") is True, "首次/重放标记不符")
        require(s["available"] == 8 and s["count"] == 1 and s["reserved_quantity"] == 2, "重复扣减或重复预占")
    elif name == "conflict":
        call()
        before = state(path)
        response = call(quantity=3)
        after = state(path)
        observations.update(response=response, before=before, after=after)
        require(response.get("status") == "conflict", "相同编号不同参数未拒绝")
        require(before == after, "冲突请求修改了业务数据")
    elif name in {"concurrent", "concurrent_duplicate"}:
        count = 12
        barrier = threading.Barrier(count)

        def worker(i):
            barrier.wait(timeout=10)
            try:
                return call("same-request" if name == "concurrent_duplicate" else f"parallel-{i}")
            except Exception as exc:
                return {"unexpected_exception": f"{type(exc).__name__}: {exc}"}

        with ThreadPoolExecutor(max_workers=count) as pool:
            responses = list(pool.map(worker, range(count)))
        s = state(path)
        observations.update(responses=responses, state=s)
        require(all("unexpected_exception" not in r for r in responses), "并发调用出现未处理异常")
        successes = sum(r.get("status") == "reserved" for r in responses)
        if name == "concurrent":
            require(successes == 5, "既要避免超卖，也不能拒绝所有正常请求；预期恰好5次成功")
            require(s["available"] == 0 and s["count"] == 5 and s["reserved_quantity"] == 10,
                    "成功响应、库存与有效预占记录不一致")
        else:
            require(successes == count, "相同请求并发重试应返回既有成功结果")
            require(sum(r.get("replayed") is False for r in responses) == 1, "并发重试不止一次首次执行")
            require(s["available"] == 8 and s["count"] == 1, "相同请求并发产生多次业务效果")
    elif name == "rollback":
        raised = False
        try:
            call(fail_at="after_inventory")
        except RuntimeError:
            raised = True
        s = state(path)
        observations.update(injected_exception_observed=raised, state=s)
        require(raised, "候选实现没有触发约定异常，不能靠忽略 fail_at 绕过检查")
        require(s["available"] == 10 and s["count"] == 0, "异常后存在部分提交")
    elif name == "invalid":
        responses = [call(request_id=""), call(quantity=0), call(quantity=-1), call(quantity=True), call(sku="missing")]
        s = state(path)
        observations.update(responses=responses, state=s)
        require(all(r.get("status") == "invalid_request" for r in responses), "非法参数或未知商品未正确拒绝")
        require(s["available"] == 10 and s["count"] == 0, "非法请求修改了状态")
    else:
        raise ValueError("Unknown probe: " + name)
    return observations


def run(module_path, name):
    captured = io.StringIO()
    observations = {}
    with contextlib.redirect_stdout(captured), tempfile.TemporaryDirectory(prefix="inventory-probe-") as directory:
        try:
            spec = importlib.util.spec_from_file_location("candidate_inventory", module_path)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            observations = check(module, name, str(Path(directory) / "inventory.db"), observations)
            result = {"id": name, "status": "pass", "reason": "行为断言通过", "observations": observations}
        except Exception as exc:
            result = {"id": name, "status": "fail", "reason": f"{type(exc).__name__}: {exc}", "observations": observations}
        result["candidate_stdout"] = captured.getvalue()[-4000:]
    return result


if __name__ == "__main__":
    print(json.dumps(run(Path(sys.argv[1]).resolve(), sys.argv[2]), ensure_ascii=False))
