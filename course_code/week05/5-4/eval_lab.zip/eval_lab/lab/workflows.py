from __future__ import annotations

import json
import shutil
from pathlib import Path
from .io import ROOT, read_json, tree_hash, utcnow, write_json
from .runner import run_agent
from .tasks import load_task
from .analysis import assess


def readonly_task(name, prompt):
    task = load_task("rule-retrieval")
    task.update(id=name, name=name, kind="understanding", prompt=prompt,
                required_semantic_checks=["claim_grounded", "limits_disclosed"], release_required=False)
    return task


def review_change(source_run=None, mode="pre-pr"):
    source = ROOT / "fixtures/project"
    diff = "初始缺陷工程，尚无变更；只能报告候选风险，不声称已确认故障。"
    if source_run:
        source_run = Path(source_run)
        source = source_run / "workspace"
        diff = (source_run / "artifacts/code.patch").read_text(encoding="utf-8")[:24000]
    sop = (ROOT / "docs/inventory_sop.md").read_text(encoding="utf-8")
    prompt = ("只读执行" + ("范围内风险扫描" if mode == "scan" else "提交前预审") +
        "。限定库存请求、幂等、事务、接口。先读规则与源码，再检查已给Diff。"
        "每项发现列代码位置、触发条件、证据、影响、待验证点。区分确认事实与风险假设。"
        "AI可建议优先级，但由人决定。不要虚构性能实测。最终给出PR草稿：目标、实际修改、影响范围、验证证据、未验证、重点Review。\n"
        + sop + "\n当前Diff（可能截断，应按需读取源码核实）：\n" + diff)
    directory = run_agent(readonly_task("pre-pr-" + mode, prompt), readonly=True, workspace_source=source,
                          prompt_override=prompt)
    write_json(directory / "workflow.json", {"kind": "pre_pr_review", "human_review_required": True,
        "generated_findings_are_not_confirmed_defects": True})
    return directory


def test_design(source_run=None):
    scope = read_json(ROOT / "data/risk_scope.json")
    prompt = ("只读库存工程，结合下面已由人圈定的范围和风险设计测试。"
        "只输出JSON对象，字段包括 scope、risk_review、decision_table、cases、coverage_matrix、open_questions。"
        "cases每项含 name、preconditions、actions、expected_response、expected_inventory、expected_records、risk。"
        "覆盖正常、重复、参数冲突、不同请求并发、相同请求并发、异常回滚、契约。"
        "用判定表分组，不把并发时序压成静态组合，不为减少数量删除高风险项。"
        "未确认业务规则放open_questions；不写已执行/已通过。\n人工范围：" + json.dumps(scope, ensure_ascii=False))
    source = Path(source_run) / "workspace" if source_run else ROOT / "fixtures/project"
    directory = run_agent(readonly_task("risk-test-design", prompt), readonly=True, workspace_source=source,
                          prompt_override=prompt)
    answer = (directory / "artifacts/final_answer.md").read_text(encoding="utf-8")
    from .llm import parse_object
    try:
        plan = parse_object(answer)
        expected = {"scope", "risk_review", "decision_table", "cases", "coverage_matrix", "open_questions"}
        if not expected <= plan.keys() or not isinstance(plan["cases"], list):
            raise ValueError("测试计划结构不完整")
        result = {"status": "designed_not_executed", "human_approved": False, "plan": plan,
                  "note": "模型生成的矩阵不能证明覆盖完整。人工确认后另行实现并执行测试。"}
    except (ValueError, TypeError) as exc:
        result = {"status": "generation_or_schema_error", "error": str(exc), "human_approved": False}
    write_json(directory / "test_plan.json", result)
    return directory, result


def case_to_regression(source_run, repaired_run=None, approve=False, reviewer=None):
    source_run = Path(source_run).resolve()
    origin = read_json(source_run / "manifest.json")
    if origin.get("source") != "pi_live":
        raise ValueError("只能从真实pi运行回流，不把参考实现或协议测试当线上失败")
    if not (source_run / "program_grades.json").exists():
        from .grading import grade_run
        grade_run(source_run)
    program = read_json(source_run / "program_grades.json")
    judge = read_json(source_run / "judge_grades.json") if (source_run / "judge_grades.json").exists() else {"checks": []}
    current = tree_hash(source_run / "workspace")
    if current != origin.get("final_tree_sha256") or current != program.get("tree_sha256"):
        raise ValueError("失败证据已过期，请对当前状态重新取证和评分")
    if judge.get("checks") and judge.get("tree_sha256") != current:
        raise ValueError("语义失败证据已过期，请重新评分")
    failures = [x for x in program["checks"] + judge.get("checks", []) if x.get("status") == "fail"]
    if not failures:
        raise ValueError("没有已确认失败检查项，不能生成失败回归任务")
    directory = ROOT / "cases" / ("case_" + origin["run_id"])
    if not approve and (directory / "case.json").exists():
        saved = read_json(directory / "case.json")
        if saved.get("state") == "active_regression":
            return directory, saved
    if not directory.exists():
        directory.mkdir(parents=True)
        shutil.copytree(source_run / "initial", directory / "fixture")
        write_json(directory / "origin_task.json", origin["task"])
    task = {**origin["task"], "id": "regression-" + origin["run_id"],
            "name": "回归：" + origin["task"]["name"], "version": "1",
            "fixture": (directory / "fixture").relative_to(ROOT).as_posix(), "origin_run": origin["run_id"]}
    write_json(directory / "task.json", task)
    result = {"state": "candidate", "origin_run": str(source_run), "failures": failures,
              "task_file": str(directory / "task.json"), "source_initial_tree": origin["initial_tree_sha256"],
              "human_review_required": True}
    if approve:
        if not repaired_run or not reviewer or not reviewer.strip():
            raise ValueError("纳入活动回归需要已确认失败、--repaired-run 和 --reviewer")
        repaired_run = Path(repaired_run).resolve()
        fixed = read_json(repaired_run / "manifest.json")
        from .grading import release_gate
        gate = release_gate(repaired_run, require_judge=True)
        if gate["decision"] != "accept" or fixed.get("source") != "pi_live":
            raise ValueError("修复运行尚未通过完整独立验收")
        if fixed["task"] != origin["task"] or fixed["initial_tree_sha256"] != origin["initial_tree_sha256"]:
            raise ValueError("修复验证必须使用相同任务与初始工程")
        result.update(state="active_regression", reviewer=reviewer, repaired_run=str(repaired_run), approved_at=utcnow())
        registry_path = ROOT / "cases/registry.json"
        registry = read_json(registry_path) if registry_path.exists() else {"tasks": []}
        name = task["fixture"].removesuffix("/fixture") + "/task.json"
        if name not in registry["tasks"]:
            registry["tasks"].append(name)
        write_json(registry_path, registry)
    write_json(directory / "case.json", result)
    return directory, result


def shadow_replay(source_run, variant="v2", use_judge=True):
    source_run = Path(source_run).resolve()
    old = read_json(source_run / "manifest.json")
    if old.get("source") != "pi_live":
        raise ValueError("需要一份真实pi任务运行包")
    directory = run_agent(old["task"], variant, workspace_source=source_run / "initial")
    gate = assess(directory, use_judge)
    result = {"mode": "isolated_replay_not_online_ab", "original_run": str(source_run),
              "candidate_run": str(directory), "gate": gate,
              "note": "只在独立工程副本中重放真实输入；不提交PR、不合并、不部署，不能证明真实用户收益。"}
    write_json(directory / "shadow.json", result)
    return directory, result
