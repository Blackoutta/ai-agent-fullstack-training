"""OpenAI-compatible streaming client, shared by DeepSeek and optional OpenAI."""
from __future__ import annotations

import json
import random
import time
import urllib.error
import urllib.request
from .config import settings
from .io import scrub, utcnow, write_json


def chat_json(system, data, trace_path=None, timeout=120, retries=1):
    cfg = settings()
    attempts, started = [], time.monotonic()
    body = {"model": cfg.model, "messages": [{"role": "system", "content": system},
              {"role": "user", "content": json.dumps(data, ensure_ascii=False)}],
            "temperature": cfg.temperature, "stream": True, "stream_options": {"include_usage": True},
            "max_tokens": cfg.max_output_tokens, "response_format": {"type": "json_object"}}
    if cfg.provider == "deepseek":
        body["thinking"] = {"type": "disabled"}
    outcome = {"status": "error", "content": "", "error": None}
    for index in range(retries + 1):
        attempt = {"started_at": utcnow(), "usage": None, "http_status": None, "error": None}
        text_parts = []
        retryable = False
        try:
            req = urllib.request.Request(cfg.base_url + "/chat/completions",
                data=json.dumps(body, ensure_ascii=False).encode(), method="POST",
                headers={"Authorization": "Bearer " + cfg.key, "Content-Type": "application/json"})
            with urllib.request.urlopen(req, timeout=timeout) as response:
                attempt["http_status"] = response.status
                attempt["request_id"] = response.headers.get("x-request-id")
                done = False
                while line := response.readline():
                    if time.monotonic() - started > timeout:
                        raise TimeoutError("Judge 总时间预算已耗尽")
                    line = line.decode("utf-8").strip()
                    if not line.startswith("data:"):
                        continue
                    chunk = line[5:].strip()
                    if chunk == "[DONE]":
                        done = True
                        break
                    item = json.loads(chunk)
                    if item.get("model"):
                        attempt["served_model"] = item["model"]
                    if item.get("error"):
                        raise ValueError(str(item["error"]))
                    if item.get("usage"):
                        attempt["usage"] = item["usage"]
                    for choice in item.get("choices", []):
                        delta = choice.get("delta", {})
                        if isinstance(delta.get("content"), str):
                            text_parts.append(delta["content"])
                if not done:
                    raise ValueError("流式响应缺少[DONE]，不能把部分输出当完整评分")
            outcome.update(status="ok", content="".join(text_parts), error=None)
        except urllib.error.HTTPError as exc:
            attempt.update(http_status=exc.code, error=scrub(exc.read(4000).decode("utf-8", "replace")))
            outcome["error"] = f"HTTP {exc.code}: {attempt['error']}"
            retryable = exc.code in {429, 500, 502, 503, 504}
        except (OSError, ValueError, TimeoutError) as exc:
            attempt["error"] = scrub(str(exc))
            outcome["error"] = attempt["error"]
            retryable = False  # Do not silently replay a partially consumed stream.
        attempts.append(attempt)
        if outcome["status"] == "ok" or not retryable or index == retries:
            break
        time.sleep(min(0.5 * 2**index + random.uniform(0, 0.2), 3))
    outcome["trace"] = {"provider": cfg.provider, "model": cfg.model, "request": scrub(body),
                        "attempts": attempts, "seconds": round(time.monotonic() - started, 4)}
    if trace_path:
        write_json(trace_path, {**outcome["trace"], "status": outcome["status"], "content": scrub(outcome["content"]), "error": outcome["error"]})
    return outcome


def parse_object(content):
    value = content.strip()
    if value.startswith("```") and value.endswith("```"):
        value = value.split("\n", 1)[1].rsplit("```", 1)[0].strip()
    result = json.loads(value)
    if not isinstance(result, dict):
        raise ValueError("模型输出必须是JSON对象")
    return result
