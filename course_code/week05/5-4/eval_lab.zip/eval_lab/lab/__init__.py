"""Reusable evaluation components; entry points live in step_*.py."""
