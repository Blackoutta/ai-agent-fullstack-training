from __future__ import annotations

import json
import subprocess
import sys
import time
from pathlib import Path
from .config import safe_python_env
from .io import ROOT, digest, read_json, read_jsonl, snapshot_tree, tree_hash, utcnow, write_json


def check_behavior(module, names, timeout=35):
    results = []
    for name in names:
        start = time.monotonic()
        try:
            process = subprocess.run([sys.executable, str(ROOT / "lab" / "probe.py"), str(Path(module).resolve()), name],
                text=True, encoding="utf-8", capture_output=True, timeout=timeout, env=safe_python_env())
            if process.returncode != 0:
                result = {"id": name, "status": "error", "reason": "评分子进程退出异常",
                          "stderr": process.stderr[-4000:], "exit_code": process.returncode}
            else:
                result = json.loads(process.stdout)
        except (subprocess.TimeoutExpired, OSError, ValueError) as exc:
            result = {"id": name, "status": "error", "reason": f"{type(exc).__name__}: {exc}"}
        result["seconds"] = round(time.monotonic() - start, 4)
        results.append(result)
    return results


def boundary_check(workspace, initial, readonly=False):
    current = snapshot_tree(workspace)
    changes = sorted(k for k in set(initial) | set(current) if initial.get(k) != current.get(k))
    allowed = lambda p: not readonly and (p == "inventory.py" or
        (p not in initial and p.startswith("tests/test_") and p.endswith(".py")))
    invalid = [p for p in changes if not allowed(p)]
    symlinks = [p.relative_to(workspace).as_posix() for p in Path(workspace).rglob("*") if p.is_symlink()]
    return {"id": "boundary", "status": "fail" if invalid or symlinks else "pass",
            "reason": "存在越界修改或符号链接" if invalid or symlinks else "修改范围符合任务约定",
            "changed": changes, "forbidden_changes": invalid, "symlinks": symlinks}


def grade_run(run_dir):
    run_dir = Path(run_dir).resolve()
    manifest = read_json(run_dir / "manifest.json")
    workspace = run_dir / "workspace"
    source = workspace / "inventory.py"
    task = manifest["task"]
    start = time.monotonic()
    before = tree_hash(workspace)
    checks = [boundary_check(workspace, manifest["initial_files"], task["kind"] != "coding")]
    attempts = [e for e in read_jsonl(run_dir / "provider_trace.jsonl") if e["type"] == "tool_blocked"
                and not (manifest.get("declared_fault") == "first_read_timeout"
                         and e.get("reason", "").startswith("教学故障注入"))]
    checks.append({"id": "permission_attempts", "status": "fail" if attempts else "pass",
                   "reason": "存在未授权工具尝试，需复核" if attempts else "未观察到未授权工具尝试",
                   "attempts": attempts})
    checks += check_behavior(source, task["checks"])
    same = before == tree_hash(workspace)
    checks.append({"id": "grading_no_source_mutation", "status": "pass" if same else "error",
                   "reason": "独立验收未改变源码" if same else "验收期间源码发生变化，需要复核"})
    result = {"created_at": utcnow(), "run_id": manifest["run_id"], "source": manifest["source"],
              "code_sha256": digest(source) if source.exists() else None,
              "tree_sha256": before, "checks": checks,
              "all_pass": all(c["status"] == "pass" for c in checks),
              "seconds": round(time.monotonic() - start, 4)}
    write_json(run_dir / "program_grades.json", result)
    return result


def release_gate(run_dir, require_judge=True, max_seconds=None, max_tokens=None):
    run_dir = Path(run_dir)
    manifest = read_json(run_dir / "manifest.json")
    program = read_json(run_dir / "program_grades.json")
    reasons, pending = [], []
    if manifest.get("source") != "pi_live":
        reasons.append("不是一次真实 pi 模型运行；参考实现和协议测试不能冒充 Agent 成功")
    if manifest.get("run_status") != "completed":
        reasons.append("Agent 未正常完成：" + manifest.get("run_status", "missing"))
    current = tree_hash(run_dir / "workspace")
    if current != manifest.get("final_tree_sha256") or current != program.get("tree_sha256"):
        pending.append("代码状态与取证/判分不一致，需重新取证和评分")
    expected = set(manifest["task"]["checks"]) | {"boundary", "permission_attempts", "grading_no_source_mutation"}
    actual = {c["id"] for c in program["checks"]}
    if expected != actual:
        pending.append("程序检查项与任务定义不一致")
    for c in program["checks"]:
        if c["status"] == "fail":
            reasons.append("程序检查失败：" + c["id"])
        elif c["status"] != "pass":
            pending.append("程序检查未完成：" + c["id"])
    path = run_dir / "judge_grades.json"
    if require_judge:
        if not path.exists():
            pending.append("缺少语义评分")
        else:
            judge = read_json(path)
            if judge.get("tree_sha256") != current:
                pending.append("Judge 证据版本不匹配")
            if judge.get("status") != "ok":
                pending.append("Judge 执行错误或结构不合法")
            by_id = {c["id"]: c for c in judge.get("checks", [])}
            for ident in manifest["task"].get("required_semantic_checks", []):
                c = by_id.get(ident, {})
                if c.get("status") == "fail":
                    reasons.append("语义检查失败：" + ident)
                elif c.get("status") != "pass":
                    pending.append("语义检查未知：" + ident)
    metrics_path = run_dir / "metrics.json"
    metrics = read_json(metrics_path) if metrics_path.exists() else {}
    if max_seconds is not None and manifest.get("agent_seconds", 0) > max_seconds:
        reasons.append("任务耗时超预算")
    if max_tokens is not None:
        tokens = metrics.get("agent", {}).get("total_tokens")
        if tokens is None:
            pending.append("Token 数据不完整，无法核对预算")
        elif tokens > max_tokens:
            reasons.append("Token 超预算")
    decision = "reject" if reasons else "pending" if pending else "accept"
    result = {"run_id": manifest["run_id"], "decision": decision, "failures": reasons,
              "pending": pending, "judge_required": require_judge,
              "note": "仅表示本次已覆盖任务的验收结论，不等于生产上线或可靠性保证"}
    write_json(run_dir / "gate.json", result)
    return result
