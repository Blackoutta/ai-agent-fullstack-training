from __future__ import annotations

import os
from pathlib import Path
from .config import settings
from .io import read_json, read_jsonl, write_json, tree_hash


def normalize_usage(raw):
    if not isinstance(raw, dict):
        return None
    if "prompt_tokens" in raw:
        inp, out = raw.get("prompt_tokens"), raw.get("completion_tokens")
        cached = raw.get("prompt_cache_hit_tokens", raw.get("prompt_tokens_details", {}).get("cached_tokens"))
    else:
        inp0, out = raw.get("input"), raw.get("output")
        cached = raw.get("cacheRead")
        inp = inp0 + (raw.get("cacheRead") or 0) + (raw.get("cacheWrite") or 0) if inp0 is not None else None
    if not isinstance(inp, (int, float)) or not isinstance(out, (int, float)):
        return None
    return {"input_tokens": int(inp), "output_tokens": int(out), "total_tokens": int(inp + out),
            "cached_input_tokens": int(cached) if cached is not None else None}


def estimate_cost(usage, cfg):
    if not usage or cfg.input_price is None or cfg.output_price is None:
        return None
    cached = usage.get("cached_input_tokens")
    if cached is None or (cached and cfg.cached_input_price is None):
        return None
    return round(((usage["input_tokens"]-cached)*cfg.input_price +
                  cached*(cfg.cached_input_price or 0) + usage["output_tokens"]*cfg.output_price)/1_000_000, 9)


def summarize_usage(calls, cfg):
    known = [x for x in calls if x is not None]
    incomplete = len(known) != len(calls) or not calls
    result = {"calls": len(calls), "unknown_usage_calls": len(calls)-len(known), "usage_complete": not incomplete}
    for key in ["input_tokens", "output_tokens", "total_tokens"]:
        result[key] = None if incomplete else sum(x[key] for x in known)
        result["known_" + key] = sum(x[key] for x in known)
    if incomplete or any(x["cached_input_tokens"] is None for x in known):
        result["cached_input_tokens"] = None
    else:
        result["cached_input_tokens"] = sum(x["cached_input_tokens"] for x in known)
    result["estimated_cost"] = estimate_cost(result, cfg) if not incomplete else None
    result["currency"] = os.environ.get("PRICE_CURRENCY") or None
    result["cost_is_estimate_not_invoice"] = True
    return result


def collect_evidence(run_dir):
    directory = Path(run_dir)
    manifest = read_json(directory / "manifest.json")
    events = read_jsonl(directory / "trace.jsonl")
    native = read_jsonl(directory / "provider_trace.jsonl")
    requests = [x for x in native if x["type"] == "provider_request"]
    usages = {x["request_index"]: normalize_usage(x.get("usage")) for x in native if x["type"] == "provider_usage"}
    messages = [x["event"]["message"] for x in events if x["event"].get("type") == "message_end"
                and x["event"].get("message", {}).get("role") == "assistant"]
    calls = []
    if requests:
        for i, req in enumerate(requests):
            usage = usages.get(req["request_index"])
            if usage is None and len(requests) == len(messages):
                msg = messages[i]
                if msg.get("stopReason") not in {"error", "aborted"}:
                    usage = normalize_usage(msg.get("usage"))
            calls.append(usage)
    else:
        calls = [normalize_usage(m.get("usage")) if m.get("stopReason") not in {"error", "aborted"} else None for m in messages]
    cfg = settings(require_key=False)
    agent = summarize_usage(calls, cfg)
    agent.update(seconds=manifest.get("agent_seconds"),
                 tool_call_count=len({x.get("toolCallId") for x in native if x["type"] == "tool_call"}),
                 blocked_calls=sum(x["type"] == "tool_blocked" for x in native),
                 provider_request_capture_available=bool(requests))
    tests = [x for x in native if x["type"] == "development_test"]
    final_files = __import__("lab.io", fromlist=["snapshot_tree"]).snapshot_tree(directory / "workspace")
    for test in tests:
        test["matches_final_files"] = test.get("tested_files") == final_files
    write_json(directory / "development_tests.json", tests)
    judge_path = directory / "judge_trace.json"
    judge = None
    if judge_path.exists():
        data = read_json(judge_path)
        judge = summarize_usage([normalize_usage(a.get("usage")) for a in data.get("attempts", [])], cfg)
        judge["seconds"] = data.get("seconds")
    metrics = {"run_id": manifest["run_id"], "agent": agent, "judge": judge,
               "independent_grader_seconds": read_json(directory / "program_grades.json").get("seconds")
                    if (directory / "program_grades.json").exists() else None,
               "notes": ["未知数据保留null。费用只使用显式价格配置，不使用Pi缺省零价格。",
                         "Agent秒数包括进程启动与关闭，不包含环境复制、独立判分与Judge。"]}
    write_json(directory / "metrics.json", metrics)
    return metrics


def judge_evidence(run_dir):
    d = Path(run_dir)
    m = read_json(d / "manifest.json")
    if not (d / "development_tests.json").exists():
        collect_evidence(d)
    evidence = {
        "task": m["task"], "report": (d / "artifacts/final_answer.md").read_text(encoding="utf-8"),
        "patch": (d / "artifacts/code.patch").read_text(encoding="utf-8"),
        "final_source": (d / "workspace/inventory.py").read_text(encoding="utf-8"),
        "sources.rules": (d / "initial/docs/rules.md").read_text(encoding="utf-8"),
        "sources.archive": (d / "initial/docs/archive_2024.md").read_text(encoding="utf-8"),
        "development_tests": read_json(d / "development_tests.json"),
        "execution": {k: m.get(k) for k in ["run_status", "error", "final_tree_sha256", "provider_request_capture_available"]},
    }
    if (d / "program_grades.json").exists():
        for check in read_json(d / "program_grades.json")["checks"]:
            evidence["program." + check["id"]] = check
    # Bounded evidence with explicit truncation: a Judge must not infer omitted content.
    truncated = []
    import json
    for k, v in list(evidence.items()):
        encoded = json.dumps(v, ensure_ascii=False)
        if len(encoded) > 24000:
            evidence[k] = {"truncated": True, "excerpt": encoded[:24000]}
            truncated.append(k)
    evidence["evidence_limits"] = {"truncated_fields": truncated, "missing_data_is_not_success": True}
    return evidence
