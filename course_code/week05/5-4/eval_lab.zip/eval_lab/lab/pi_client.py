"""Actual Pi RPC client. No canned agent replies or local agent loop."""
from __future__ import annotations

import json
import os
import queue
import signal
import subprocess
import threading
import time
from pathlib import Path
from .io import append_jsonl, scrub, utcnow


def execute_rpc(command, cwd, env, prompt, trace_path, timeout, display_stream=False):
    start = time.monotonic()
    events, error_lines, inbox = [], [], queue.Queue()
    result = {"run_status": "startup_error", "error": None, "final_answer": ""}
    process = subprocess.Popen(command, cwd=cwd, env=env, stdin=subprocess.PIPE,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=(os.name != "nt"))

    def consume_stdout():
        try:
            for raw in iter(process.stdout.readline, b""):
                try:
                    inbox.put(json.loads(raw.decode("utf-8")))
                except (UnicodeDecodeError, ValueError) as exc:
                    inbox.put({"type": "protocol_error", "error": str(exc), "raw": raw[:1000].decode("utf-8", "replace")})
        finally:
            inbox.put(None)

    def consume_stderr():
        for raw in iter(process.stderr.readline, b""):
            error_lines.append(scrub(raw.decode("utf-8", "replace")))

    readers = [threading.Thread(target=consume_stdout, daemon=True), threading.Thread(target=consume_stderr, daemon=True)]
    for reader in readers:
        reader.start()

    def send(data):
        process.stdin.write(json.dumps(data, ensure_ascii=False).encode() + b"\n")
        process.stdin.flush()

    deadline, aborted_at = start + timeout, None
    try:
        send({"id": "task-prompt", "type": "prompt", "message": prompt})
        result["run_status"] = "running"
        while True:
            now = time.monotonic()
            if now > deadline and aborted_at is None:
                result.update(run_status="timeout", error="任务超过总时间预算")
                aborted_at = now
                try:
                    send({"id": "deadline-abort", "type": "abort"})
                except (OSError, ValueError):
                    pass
            if aborted_at is not None and now - aborted_at > 3:
                break
            try:
                item = inbox.get(timeout=0.2)
            except queue.Empty:
                if process.poll() is not None:
                    if result["run_status"] == "running":
                        result.update(run_status="process_exit", error=f"Pi 未发送结束事件，exit={process.returncode}")
                    break
                continue
            if item is None:
                if result["run_status"] == "running":
                    result.update(run_status="process_exit", error="Pi stdout 提前关闭")
                break
            event = scrub(item)
            events.append(event)
            append_jsonl(trace_path, {"recorded_at": utcnow(), "event": event})
            kind = event.get("type")
            if kind == "protocol_error":
                result.update(run_status="protocol_error", error=event["error"])
                break
            if kind == "response" and event.get("id") == "task-prompt" and not event.get("success"):
                result.update(run_status="prompt_error", error=event.get("error", "prompt rejected"))
                break
            if kind == "message_end":
                message = event.get("message", {})
                if message.get("role") == "assistant":
                    content = message.get("content", [])
                    if isinstance(content, list):
                        texts = [p.get("text", "") for p in content if isinstance(p, dict) and p.get("type") == "text"]
                        if texts:
                            result["final_answer"] = "\n".join(texts)
                    if message.get("stopReason") in {"error", "aborted"}:
                        result["error"] = message.get("errorMessage") or message.get("stopReason")
            if display_stream and kind == "message_update":
                delta = event.get("assistantMessageEvent", {})
                if delta.get("type") == "text_delta":
                    print(delta.get("delta", ""), end="", flush=True)
            if kind == "agent_settled":
                if result["run_status"] == "running":
                    status = "aborted" if event.get("aborted") else "model_error" if result["error"] else "completed"
                    result["run_status"] = status
                break
    except KeyboardInterrupt:
        result.update(run_status="cancelled", error="人工取消")
        try:
            send({"type": "abort"})
        except (OSError, ValueError):
            pass
    except (OSError, ValueError) as exc:
        result.update(run_status="transport_error", error=str(exc))
    finally:
        try:
            process.stdin.close()
        except (OSError, ValueError):
            pass
        try:
            process.wait(timeout=2)
        except subprocess.TimeoutExpired:
            try:
                os.killpg(process.pid, signal.SIGKILL) if os.name != "nt" else process.kill()
            except ProcessLookupError:
                pass
            process.wait(timeout=3)
        for reader in readers:
            reader.join(timeout=1)
        process.stdout.close()
        process.stderr.close()
    result["agent_seconds"] = round(time.monotonic() - start, 4)
    result["stderr"] = "".join(error_lines)
    result["events"] = events
    return result
