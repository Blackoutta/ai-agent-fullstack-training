"""5.2/5.3：真实模型按Rubric核验报告与证据；程序事实仍由独立检查提供。"""
from lab.cli import emit, main, parser, resolve_run
from lab.judge import judge_run


def run():
    args = parser(__doc__, with_run=True).parse_args()
    result = judge_run(resolve_run(args.run))
    emit(result)
    return 0 if result["status"] == "ok" else 2


if __name__ == "__main__":
    raise SystemExit(main(run))
