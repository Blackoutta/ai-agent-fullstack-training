"""No external API keys needed. Reports component/protocol tests, never model quality."""
import platform
import subprocess
import sys
import unittest
from lab.config import settings
from lab.io import ROOT, utcnow, write_json


if __name__ == "__main__":
    suite = unittest.defaultTestLoader.discover(str(ROOT / "tests"))
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    cfg = settings(require_key=False)
    try:
        pi = subprocess.run(cfg.pi + ["--offline", "--version"], capture_output=True, text=True, timeout=15).stdout.strip()
    except (OSError, subprocess.SubprocessError):
        pi = None
    report = {"validated_at": utcnow(), "python": platform.python_version(), "pi": pi,
        "tests_run": result.testsRun, "failures": len(result.failures), "errors": len(result.errors),
        "skipped": len(result.skipped), "successful": result.wasSuccessful(),
        "real_openai_api_verified": False, "real_deepseek_api_verified": False,
        "scope": ["库存参考实现和缺陷实现的独立验收", "状态隔离与门禁", "JSONL与SSE协议",
                  "真实Pi子进程、工具执行与取证扩展（本地合成HTTP传输夹具）", "Judge结构与错误处理"],
        "limits": "本地传输夹具不是真实模型，不证明模型能修复任务；其运行标为protocol_test且被发布门禁拒绝。"}
    write_json(ROOT / "reports/local_validation.json", report)
    print("验证记录：reports/local_validation.json")
    raise SystemExit(0 if result.wasSuccessful() else 1)
