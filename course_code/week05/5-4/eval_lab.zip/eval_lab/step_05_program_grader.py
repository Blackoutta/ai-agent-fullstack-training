"""5.1：独立验证实际业务状态。--reference/--broken是评分器校验，不是Agent运行。"""
from lab.cli import emit, main, parser, resolve_run
from lab.grading import check_behavior, grade_run
from lab.io import ROOT
from lab.tasks import CHECKS


def run():
    p = parser(__doc__, with_run=True)
    group = p.add_mutually_exclusive_group()
    group.add_argument("--reference", action="store_true")
    group.add_argument("--broken", action="store_true")
    args = p.parse_args()
    if args.reference or args.broken:
        source = ROOT / ("references/inventory.py" if args.reference else "fixtures/project/inventory.py")
        checks = check_behavior(source, sorted(CHECKS))
        result = {"source": "known_reference" if args.reference else "known_broken", "checks": checks,
                  "all_pass": all(c["status"] == "pass" for c in checks)}
    else:
        result = grade_run(resolve_run(args.run))
    emit(result)
    return 0 if result["all_pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main(run))
