"""9.1/9.3：失败先进入候选池，真实修复验证+人工确认后才成为活动回归。"""
from lab.cli import emit, main, parser, resolve_run
from lab.workflows import case_to_regression


def run():
    p = parser(__doc__, with_run=True)
    p.add_argument("--approve", action="store_true")
    p.add_argument("--repaired-run")
    p.add_argument("--reviewer")
    args = p.parse_args()
    directory, result = case_to_regression(resolve_run(args.run), resolve_run(args.repaired_run) if args.repaired_run else None,
                                          args.approve, args.reviewer)
    emit({"case": directory, "result": result})


if __name__ == "__main__":
    raise SystemExit(main(run))
