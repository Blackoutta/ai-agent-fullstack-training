"""4.1—4.3：从干净工程真实启动pi，通过流式API执行任务。"""
from lab.cli import emit, main, parser
from lab.runner import run_agent
from lab.tasks import load_task
from lab.io import read_json


def run():
    p = parser(__doc__)
    p.add_argument("--task", default="inventory-refactor")
    p.add_argument("--task-file", help="自定义/回归任务JSON")
    p.add_argument("--variant", choices=["v1", "v2"], default="v2")
    p.add_argument("--timeout", type=float)
    p.add_argument("--stream", action="store_true", help="终端显示实时文本，API本身始终流式")
    p.add_argument("--inject-read-timeout", action="store_true", help="声明一次读取故障，用于观察恢复")
    args = p.parse_args()
    directory = run_agent(load_task(args.task, args.task_file), args.variant, args.timeout,
                          args.stream, inject_read_timeout=args.inject_read_timeout)
    manifest = read_json(directory / "manifest.json")
    emit({"run": str(directory), "run_status": manifest["run_status"], "error": manifest.get("error"),
          "note": "运行结束不是任务通过；继续执行step_04到step_07。"})
    return 0 if manifest["run_status"] == "completed" else 2


if __name__ == "__main__":
    raise SystemExit(main(run))
