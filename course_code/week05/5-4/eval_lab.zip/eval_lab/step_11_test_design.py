"""8.5：人工范围→风险→判定表→步骤→覆盖矩阵；生成不等于执行。"""
from lab.cli import emit, main, parser, resolve_run
from lab.workflows import test_design


def run():
    p = parser(__doc__)
    p.add_argument("--run", help="基于已有最终代码设计；不填则针对初始缺陷工程")
    args = p.parse_args()
    directory, result = test_design(resolve_run(args.run) if args.run else None)
    emit({"run": directory, "plan_file": directory / "test_plan.json", "result": result})
    return 0 if result["status"] == "designed_not_executed" else 2


if __name__ == "__main__":
    raise SystemExit(main(run))
