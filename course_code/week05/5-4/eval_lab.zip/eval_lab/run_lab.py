"""一条命令执行：真实pi任务→取证→程序验收→Judge→门禁。"""
from lab.cli import emit, main, parser
from lab.runner import run_agent
from lab.analysis import assess
from lab.tasks import load_task


def run():
    p = parser(__doc__)
    p.add_argument("--task", default="duplicate-repair")
    p.add_argument("--task-file")
    p.add_argument("--variant", choices=["v1", "v2"], default="v2")
    p.add_argument("--timeout", type=float)
    p.add_argument("--stream", action="store_true")
    p.add_argument("--program-only", action="store_true")
    args = p.parse_args()
    directory = run_agent(load_task(args.task, args.task_file), args.variant, args.timeout, args.stream)
    result = assess(directory, not args.program_only)
    emit({"run": directory, "gate": result})
    return {"accept": 0, "reject": 1, "pending": 2}[result["decision"]]


if __name__ == "__main__":
    raise SystemExit(main(run))
