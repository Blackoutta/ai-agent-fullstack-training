# Pi + DeepSeek Flash：Agent Eval 工程实战

本工程把课程中的任务设计、独立执行、证据采集、评分、归因、版本比较和失败回流连起来。
主线使用真实 **pi Coding Agent + DeepSeek Flash**，评测程序使用 **Python 3.10+ 标准库**。
同时提供 OpenAI-compatible 切换配置，方便先用其他可用模型检查接入，再切回 DeepSeek。

## 先看验证范围

- 本包带实际执行的本地验证记录：`reports/local_validation.json`。
- 已验证库存参考实现、缺陷识别、门禁、统计、JSONL/SSE，以及真实 pi 子进程中的工具与扩展。
- Pi 协议测试使用明确标记的**本地合成 HTTP 夹具**，不是 OpenAI 或 DeepSeek 的模型响应。
- 当前制作环境没有 OpenAI/DeepSeek API 凭据，因此**没有完成任一供应商的真实模型端到端验证**。
- 真实模型入口已实现；填写本机密钥后执行下文的真实运行命令。不要把本地组件测试当成 Agent 成绩。

## 1. 学什么：小节、程序与用途

|课程位置|程序|解释什么、读者学会什么|
|---|---|---|
|课前|`step_00_check_environment.py`|区分环境检查与模型调用，检查 Python、Node、pi、配置；`--api-check` 实际流式调用模型|
|2.3、2.4|`step_01_calibrate_rubric.py`|将人工标签留在评测端；真实调用 Judge 比较模糊/明确标准，检查一致率、误放行、误拒绝、未知|
|3.2、3.3|`step_02_validate_tasks.py`|把任务写成可执行规格；确认参考实现能过、已知缺陷不能混过关|
|4.1—4.3|`step_03_run_trial.py`|从独立工程/全新会话启动真实 pi，记录接受请求、真正结束、超时、取消和错误|
|4.4|`step_04_collect_evidence.py`|关联实际模型请求、工具、最终代码和测试指纹，统计消耗，未知值保留 null|
|5.1|`step_05_program_grader.py`|通过独立行为探针检查实际数据库结果、接口 Schema/Snapshot 与文件边界|
|5.2、5.3|`step_06_llm_judge.py`|用报告和执行证据做语义判断；校验结构、证据引用、未知项，导出人工复核材料|
|5.4、7.4|`step_07_release_gate.py`|区分硬门槛、失败、未知和执行错误，用退出码接入 CI|
|6.1—6.3|`step_08_diagnose_trace.py`|从失败项回到证据；事实与原因假设分开，可选择让模型辅助提出验证计划|
|7.1—7.3；8.2、8.3|`step_09_compare_versions.py`|真实交错运行新旧 Skill，逐题看改善与退化，保留未知，区分通过比例、pass@k、pass^k|
|8.1、8.4|`step_10_pre_pr_review.py`|限定范围扫描或只读审查 Diff，生成带依据的问题清单和 PR 草稿，由人核验风险|
|8.5|`step_11_test_design.py`|人工范围→风险→判定表→步骤→覆盖矩阵，明确“已设计”不等于“已执行/已通过”|
|9.1、9.3|`step_12_case_to_regression.py`|真实失败先进入候选池，真实修复验证和人工批准后加入活动回归|
|9.2拓展|`step_13_shadow_replay.py`|独立重放保存的真实任务输入，不修改原工作区，不冒充真实线上 A/B|

第一部分概念、9.4 建设阶段和最后总结不另写空洞脚本，直接解释以上程序产生的任务、证据和报告。

## 2. 运行结构

```mermaid
flowchart TD
    A[Python 评测入口] --> B[Pi RPC 子进程]
    B --> C[DeepSeek Flash 流式 API]
    B --> D[独立库存工程与开发测试]
    B --> E[Pi 原生取证扩展]
    D --> F[宿主独立程序验收]
    E --> G[运行证据包]
    F --> G
    G --> H[语义 Judge 与分层门禁]
```

Python 不重新实现 Agent Loop。pi 的 RPC 接受任务后继续流式输出事件；程序等待 `agent_settled`，不把 prompt 的 `success=true` 或单个 `agent_end` 当成任务完成。

唯一的原生适配文件是 `extensions/eval_trace.ts`：记录最终 provider payload、返回标识、工具事件，提供固定 `run_tests` 工具和文件访问拦截。pi 可直接加载，不需要手动编译 TS。
其余业务与评测入口全部是 Python。执行层使用 pi **1.2.0**，由 `package-lock.json` 固定安装，不改你的全局 pi。
运行时固定使用 pi 的 `--offline` 并关闭安装遥测，禁止启动阶段更新模型目录或检查版本；这不会禁止调用你配置的模型 API。本地协议测试的模型基址仅指向本机 HTTP 服务。

## 3. 安装与配置（macOS / Linux）

需要 Python 3.10+、Node.js 22+、npm、可用网络和你自己的模型 API key。

```bash
cd pi_deepseek_eval_lab
npm ci
cp .env.example .env
```

编辑 `.env`：默认填写 `DEEPSEEK_API_KEY`，模型默认 `deepseek-flash`。如果本机网关使用其他别名，设置 `LLM_MODEL`。
使用网关时填写 `LLM_GATEWAY_URL` 和 `LLM_GATEWAY_KEY`；URL 填 API 基址，不含 `/chat/completions`。
`.env` 由程序解析，不需要 `source`，不会执行其中的 shell 命令。已有进程环境变量优先于 `.env`。

```bash
python step_00_check_environment.py
python step_00_check_environment.py --api-check
```

第一条只检查本地环境，第二条会产生一次真实模型请求与 API 消耗。
Python 没有第三方依赖，不需要安装 OpenAI Python SDK 或 pytest。pi 的依赖由 npm 安装。

### 使用 OpenAI 验证，再切回 DeepSeek

把 `.env.openai.example` 的字段填到 `.env`，设置 `LLM_PROVIDER=openai`、自己的 `OPENAI_API_KEY`、可用模型和基址。
示例模型名为 `gpt-4.1-mini`，请使用你的账号实际有权限调用的模型。该 profile 走 Chat Completions 兼容接口，不发送 DeepSeek 的 `thinking` 参数。

切回时改为 `LLM_PROVIDER=deepseek`，填写 DeepSeek 基址/密钥/模型。**Agent 与 Judge 使用同一套配置，无须改业务代码。**
OpenAI 的行为结果不能作为 DeepSeek 的通过证明；切回后至少重新执行一轮目标任务、独立验收与 Judge。
README 的“未验证”状态不能因为切换配置就自动改为已验证，需保留真实运行包。

### 思考内容、流式和费用

- Agent 和 Judge 的 HTTP 请求都使用流式输出。DeepSeek profile 显式关闭 thinking，pi 使用 `--thinking off`。
- 不保存 reasoning_content、thought 或 thinking 内容；provider trace 是经过敏感/思考字段移除的实际请求记录。
- 记录配置模型名与接口实际返回的模型标识（若接口提供）。别名不保证底层权重永远不变。
- 未配置价格时费用为 `null`，不使用 pi 默认零价格冒充免费。价格配置只是估算，不是账单。
- usage 不完整时保留未知，同时单列已知部分；不把失败/重试消耗抹掉。

## 4. 先核对题目与评分器（不用模型）

```bash
python step_02_validate_tasks.py
python step_05_program_grader.py --reference
python step_05_program_grader.py --broken
```

参考实现应通过；缺陷实现应暴露重复预占、并发和回滚问题。最后一条返回非零是**正确识别缺陷**，不是演示程序损坏。
这些结果标记为 reference/known_broken，不是 Agent 成绩，也不能进入真实任务发布通过记录。

库存 API 是 `initialize(db_path, stock=10)` 与 `reserve(db_path, request_id, sku="sku-1", quantity=2, fail_at=None)`。
完整业务契约见 `fixtures/project/docs/rules.md`。本实验只覆盖单商品库存预占，不实现支付确认、释放、多仓库或生产压测。
SQLite 用于本机机制演示；并发与事务结论限于本实验，迁移生产数据库后需重新验证。

## 5. 最短真实运行路径

先从局部任务开始，减少首次调试成本：

```bash
python run_lab.py --task duplicate-repair --variant v2 --stream
```

这条命令实际执行：独立工作区 → pi/模型修复 → 证据采集 → 程序验收 → 模型 Judge → 门禁。
退出码 `0` 表示本次配置的完整检查通过，`1` 表示拒绝，`2` 表示待复核/错误。**不保证模型必然修好。**
若只想先观察独立行为检查，可以加 `--program-only`；报告会标记未要求语义评分，不能把它当作完整验收。

准备验证完整范围时：

```bash
python run_lab.py --task inventory-refactor --variant v2 --stream
```

不要把 Agent 自己的开发测试通过当作最终验收。初始 smoke 测试故意只覆盖正常请求，缺陷工程也会通过它。
独立验收放在工作区之外，检查重复请求、编号冲突、不同/相同请求并发、回滚、正常行为、非法输入与响应契约。

## 6. 按章节逐步观察同一次运行

```bash
python step_03_run_trial.py --task inventory-refactor --variant v2 --stream
python step_04_collect_evidence.py --run latest
python step_05_program_grader.py --run latest
python step_06_llm_judge.py --run latest
python step_07_release_gate.py --run latest
python step_08_diagnose_trace.py --run latest
```

`latest` 是最近创建的运行包。开始并行运行或执行预审后，建议改成明确运行目录/编号，避免拿错任务。
要让模型辅助归因，使用 `step_08_diagnose_trace.py --run <运行目录> --llm`，这会额外产生模型请求。
输出假设必须人工复核，不能把模型诊断文本当成已确认根因。

观察声明的一次读取故障：

```bash
python step_03_run_trial.py --task rule-retrieval --inject-read-timeout --stream
```

这属于明确标记的工具故障注入，后续读取恢复。它不是模型响应模拟，也不自动证明恢复合格；需要检查 Trace 与最终回答。

## 7. 校准 Judge

```bash
python step_01_calibrate_rubric.py --limit 2
python step_01_calibrate_rubric.py
```

人工标签在 `data/calibration_samples.json`，只保留在宿主统计端，不发送给模型。
同一份材料分别使用 vague/clear Rubric 真实评分。输出一致率、误放行、误拒绝、未知与执行错误。
材料是人工编写的教学校准样本，不是伪造的真实 Agent Trace。小样本不能证明通用可信度，明确标准也不保证分数必然更高。

Judge 只检查报告与证据、规则及引用的关系；库存数量等事实由程序验证。
结构非法、引用不存在的证据或请求失败，都不能转成“通过”。unknown 留给补证据/人工复核。

## 8. 新旧 Skill 的真实比较

```bash
python step_09_compare_versions.py --tasks duplicate-repair --trials 1
python step_09_compare_versions.py --tasks duplicate-repair inventory-refactor rule-retrieval --trials 3
```

第一条用于检查接入，不用于稳定性结论。第二条会执行 `3道题×2版本×3次=18次真实Agent任务`，默认还会运行18次 Judge，请自行控制预算。
每次从同一初始工程复制，不复用前次修复/会话/长期记忆。两个版本只改变指定 Skill，运行顺序交错。
v2 增加重复调用与证据要求，不内置参考答案，也不强制新版获胜。只读检索题不加载修复 Skill，可用于观察保持与波动。

报告单列逐题通过/失败/未知、具体失败和各次消耗。核心必过任务存在失败或未知时暂缓采用。
同题多次运行观察稳定性，不代表增加场景覆盖。

统计中 `c/n` 是观察到的通过比例；`pass@k` 是 k 次至少成功一次，`pass^k` 是 k 次全部成功。
组合估计仅在同题、同条件、独立尝试且没有未知项时给出。`n=k=3` 的“至少一次通过”即使为1，也只是这一组观察，不是实际成功概率100%的证明。
未知运行不从分母静默删除，存在未知时 k 估计保留 null。

## 9. AI Coding 的预审与测试设计

```bash
python step_10_pre_pr_review.py --mode scan
python step_10_pre_pr_review.py --mode pre-pr --run <修复运行目录>
python step_11_test_design.py --run <修复运行目录>
```

两种程序都通过真实 pi/模型读取工程，使用只读工具集，不修改输入工程。
预审候选发现包含位置、触发条件、证据和未验证点；由人决定优先级与业务取舍。
测试设计使用 `data/risk_scope.json` 的人工范围，输出判定表、步骤与覆盖矩阵。
生成状态固定标记为 `designed_not_executed`，需要人工确认、实现并执行，不能把矩阵存在当作测试通过。
`docs/inventory_sop.md` 是人工打样时可使用的 SOP 初稿；`skills/v1`、`skills/v2` 是 pi 原生 Skill，可对照正文理解经验如何进入执行。

## 10. 失败回流与回归注册

先挑选一份**真实观察到失败**的运行，不能拿参考实现、协议夹具或人为编造的成绩代替：

```bash
python step_12_case_to_regression.py --run <失败运行目录>
```

输出候选 Case：原任务、原初始工程、失败检查与证据位置。尚未修复的问题先留候选池。
使用相同任务和初始工程获得真实修复运行，并完成 step_04—07 后：

```bash
python step_12_case_to_regression.py --run <失败运行目录> --approve --repaired-run <修复运行目录> --reviewer Wilson
python step_09_compare_versions.py --tasks duplicate-repair --trials 3 --include-regression
```

只有完整验收通过、任务和初始状态一致且人工明确批准，才写入 `cases/registry.json`。
回归任务可以单独运行：`python run_lab.py --task-file <Case目录/task.json>`。
如果没有真实失败，就不创建假失败来演示飞轮；继续收集任务和运行。

## 11. 影子重放

```bash
python step_13_shadow_replay.py --source-run <真实运行目录> --variant v2
```

复制保存的初始工程与任务，候选版在独立副本执行。不会创建/发送 PR、合并代码或部署。
输出标记 `isolated_replay_not_online_ab`。真实 A/B 仍需要实际任务分流、用户结果与足够样本。

## 12. 运行包与取证边界

|内容|用途|
|---|---|
|`manifest.json`|任务、配置、pi与Skill版本、代码指纹、执行状态、预算与模型标识|
|`trace.jsonl`|Pi RPC消息与工具生命周期，按LF分帧，不用Unicode分隔符切JSON|
|`provider_trace.jsonl`|实际provider payload（去敏）、调用状态、原始usage、工具参数与阻断记录|
|`initial/`、`workspace/`|原始输入与独立执行产物|
|`artifacts/code.patch`、`final_answer.md`|最终修改和最终陈述|
|`development_tests.json`|开发测试结果与执行时文件指纹，标明是否仍匹配最终状态|
|`program_grades.json`|宿主行为探针的状态、实际观察与失败理由|
|`judge_grades.json`、`judge_trace.json`|语义判断、证据引用、Judge请求与消耗|
|`metrics.json`、`gate.json`|分阶段消耗与采用决定|
|`diagnosis.json`|事实、候选原因和验证计划|

评分后如果源码又变化，门禁会要求重新取证/评分。每个行为检查使用新数据库和独立进程，不依赖 Agent 的报告或开发测试名称。
程序检查的 fail、评分执行 error、Judge unknown 与运行超时分别记录，不混为同一种“模型能力差”。

### 实验隔离的范围

本地默认不开放任意 bash，只开放文件工具和固定 run_tests；扩展限制读写路径，保护已有文件，并拒绝工作区外访问。
**这些是教学工具边界与状态隔离，不是 OS 安全沙箱。** Python测试本身会执行候选代码，请只运行自己的教学工程；处理不可信代码时要接入前面课程的沙箱/容器与网络控制。
不把“独立目录”当成安全隔离，不把所有节点成功当成业务验收通过。

## 13. 本地自检

```bash
npm ci
python validate_local.py
```

使用 unittest，无外部 API key。包含真实 Pi 进程与本地合成 SSE 服务的协议测试；该测试数据始终标 `protocol_test`，门禁明确拒绝其作为真实 Agent 通过。
不安装 npm 依赖时，核心 Python 测试仍可运行，但 Pi 协议测试会明确 skip。制作包时已安装 pi 并运行，实际统计见验证报告。

## 14. 迁移到自己的 Agent

1. 把 `tasks/*.json` 的目标、初始工程、规则和成功条件换成自己的任务。
2. 替换 `lab/probe.py` 中的业务探针，先证明参考方案可通过、已知错误能被识别。
3. 在 `rubrics/clear.json` 中定义需要语义判断的维度，并准备人工校准样本。
4. 保留运行隔离、证据、未知处理、版本比较和门禁接口。
5. 从真实失败形成候选 Case，经验证后纳入回归。

这些步骤是工程迁移入口，不需要先建复杂平台。API账单、线上指标和生产数据库验证需接入自己的实际系统。

## 参考

- [Pi RPC](https://github.com/earendil-works/pi/blob/main/packages/coding-agent/docs/rpc.md)
- [Pi JSON events](https://github.com/earendil-works/pi/blob/main/packages/coding-agent/docs/json.md)
- [Pi extensions](https://github.com/earendil-works/pi/blob/main/packages/coding-agent/docs/extensions.md)
- [DeepSeek API](https://api-docs.deepseek.com/quick_start/agent_integrations/)

