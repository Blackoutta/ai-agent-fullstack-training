"""6.1—6.3：从失败项追到原始证据，模型建议只标记为假设。"""
from lab.cli import emit, main, parser, resolve_run
from lab.analysis import diagnose


def run():
    p = parser(__doc__, with_run=True)
    p.add_argument("--llm", action="store_true", help="额外真实调用模型辅助提出假设")
    args = p.parse_args()
    emit(diagnose(resolve_run(args.run), args.llm))


if __name__ == "__main__":
    raise SystemExit(main(run))
