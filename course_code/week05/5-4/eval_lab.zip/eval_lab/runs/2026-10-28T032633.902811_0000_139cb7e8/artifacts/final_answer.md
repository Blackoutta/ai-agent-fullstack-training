All 9 tests pass (exit code 0).

## 实际改动

**`inventory.py`（唯一修改的现有文件）**
- 幂等状态改为持久化：`reservations` 表新增唯一索引 `idx_reservations_request_id`（规则允许增加索引），去掉了每次调用重建的内存 `seen` 集合。
- 重复调用逻辑：先按 `request_id` 查已有预占记录；参数（sku、quantity）相同 → 返回 `replayed=true` 的成功响应，不再扣库存、不再写记录；参数不同 → 返回 `{"status":"conflict"}`，库存与记录均不变。
- 事务化：使用 `isolation_level=None` + `BEGIN IMMEDIATE`，把「查重 → 查库存 → 扣减 → 写预占」放在同一事务内，异常时显式 `ROLLBACK` 后重新抛出。
- `fail_at="after_inventory"` 现在在事务内、写预占记录之前抛出 `RuntimeError`，因此库存更新随事务回滚（原实现库存已提交）。
- 保持兼容：`initialize`/`reserve` 签名、表名与列、成功响应恰好 5 个字段、失败状态分类均未变；非法输入校验（非空字符串 request_id、`type(quantity) is int` 且 >0、未知 sku）保留。

**`tests/test_idempotency.py`（新增）** — 8 个用例：相同编号相同参数连续三次调用（第 1 次 `replayed=false`，后两次 `true`，库存 10→8，仅 1 条记录）、新连接下重放仍生效、同编号不同 quantity/sku 返回 conflict 且无副作用、不同编号各自生效、库存不足无副作用、非法输入、`fail_at` 回滚后重试仍为首次预占。

## 实际执行的验证

- `run_tests`（`python -m unittest discover -s tests -v`）共执行 2 次：
  - 第 1 次：exit_code=1，8 通过 / 1 失败。失败原因是我的测试把 `"   "` 当作非法 request_id，而规则只要求「非空字符串」，属测试断言错误，非实现缺陷。
  - 修正该断言后第 2 次：exit_code=0，9 个测试全部通过（含原有 `test_smoke.py`）。修改后已重新运行全部测试。

## 未验证 / 不声称的内容

- **并发未验证**：没有编写或运行多线程/多进程竞争测试。`BEGIN IMMEDIATE` + `busy_timeout` 只是设计意图，规则第 4、5 条（并发竞争、同编号并发重试）本次未实测，不能据此声称并发正确或生产可靠。
- **回滚仅覆盖 `fail_at` 注入路径**：该路径已测；其他异常路径（如磁盘错误、进程崩溃）未测。
- 未做性能、多仓库、支付确认/释放相关验证（不在本实验范围）。
- 独立验收由宿主执行，本报告不代替验收结果。