"""Idempotency and conflict tests for inventory.reserve."""
import tempfile
import unittest
from pathlib import Path

from inventory import initialize, reserve


class IdempotencyTest(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.path = str(Path(self._tmp.name) / "inventory.db")
        initialize(self.path, 10)

    def _available(self):
        import sqlite3
        with sqlite3.connect(self.path) as db:
            return db.execute("SELECT available FROM inventory WHERE sku='sku-1'").fetchone()[0]

    def _reservations(self):
        import sqlite3
        with sqlite3.connect(self.path) as db:
            return db.execute(
                "SELECT request_id, sku, quantity FROM reservations ORDER BY id").fetchall()

    def test_same_request_same_params_replays_once(self):
        first = reserve(self.path, "req-1", quantity=2)
        second = reserve(self.path, "req-1", quantity=2)
        third = reserve(self.path, "req-1", quantity=2)

        self.assertEqual(first, {"status": "reserved", "request_id": "req-1",
                                 "sku": "sku-1", "quantity": 2, "replayed": False})
        for replay in (second, third):
            self.assertEqual(replay, {"status": "reserved", "request_id": "req-1",
                                      "sku": "sku-1", "quantity": 2, "replayed": True})
        self.assertEqual(self._available(), 8)
        self.assertEqual(self._reservations(), [("req-1", "sku-1", 2)])

    def test_replay_survives_new_connection(self):
        reserve(self.path, "req-2", quantity=3)
        # A fresh call (new connection) must still see the persisted reservation.
        replay = reserve(self.path, "req-2", quantity=3)
        self.assertTrue(replay["replayed"])
        self.assertEqual(self._available(), 7)
        self.assertEqual(len(self._reservations()), 1)

    def test_same_request_different_quantity_conflicts(self):
        reserve(self.path, "req-3", quantity=2)
        result = reserve(self.path, "req-3", quantity=5)
        self.assertEqual(result, {"status": "conflict"})
        self.assertEqual(self._available(), 8)
        self.assertEqual(self._reservations(), [("req-3", "sku-1", 2)])

    def test_same_request_different_sku_conflicts(self):
        reserve(self.path, "req-4", quantity=2)
        result = reserve(self.path, "req-4", sku="sku-2", quantity=2)
        self.assertEqual(result, {"status": "conflict"})
        self.assertEqual(self._available(), 8)
        self.assertEqual(self._reservations(), [("req-4", "sku-1", 2)])

    def test_different_requests_both_apply(self):
        first = reserve(self.path, "req-5", quantity=2)
        second = reserve(self.path, "req-6", quantity=2)
        self.assertFalse(first["replayed"])
        self.assertFalse(second["replayed"])
        self.assertEqual(self._available(), 6)
        self.assertEqual(len(self._reservations()), 2)

    def test_insufficient_stock_does_not_record(self):
        result = reserve(self.path, "req-7", quantity=11)
        self.assertEqual(result, {"status": "insufficient_stock"})
        self.assertEqual(self._available(), 10)
        self.assertEqual(self._reservations(), [])

    def test_invalid_inputs(self):
        # Rules require a non-empty string; whitespace-only is still a non-empty string.
        for bad in ("", None, 5, 2.0, ["req"]):
            self.assertEqual(reserve(self.path, bad, quantity=1), {"status": "invalid_request"})
        for bad_qty in (0, -1, 1.5, True, "2", None):
            self.assertEqual(reserve(self.path, "req-8", quantity=bad_qty),
                             {"status": "invalid_request"})
        self.assertEqual(reserve(self.path, "req-9", sku="sku-unknown", quantity=1),
                         {"status": "invalid_request"})
        self.assertEqual(self._available(), 10)
        self.assertEqual(self._reservations(), [])

    def test_fail_at_after_inventory_rolls_back(self):
        with self.assertRaises(RuntimeError):
            reserve(self.path, "req-10", quantity=2, fail_at="after_inventory")
        self.assertEqual(self._available(), 10)
        self.assertEqual(self._reservations(), [])
        # The failed attempt must not be treated as a completed reservation.
        retry = reserve(self.path, "req-10", quantity=2)
        self.assertFalse(retry["replayed"])
        self.assertEqual(self._available(), 8)
        self.assertEqual(self._reservations(), [("req-10", "sku-1", 2)])


if __name__ == "__main__":
    unittest.main()
