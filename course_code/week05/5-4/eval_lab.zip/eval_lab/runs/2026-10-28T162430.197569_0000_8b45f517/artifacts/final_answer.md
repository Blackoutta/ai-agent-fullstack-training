13 个测试全部通过（退出码 0）。

## 实际改动

**`inventory.py`（重写 `reserve`，`initialize` 增加唯一索引）**
- 幂等状态持久化：`initialize` 新增 `CREATE UNIQUE INDEX IF NOT EXISTS idx_reservations_request_id ON reservations(request_id)`；去掉了每次调用都重建的内存 `seen` 集合。
- 重复请求：先在同一事务内按 `request_id` 查 `reservations`；参数（sku、quantity）相同返回 `replayed=True` 且不改库存、不新增记录；参数不同返回 `{"status":"conflict"}`。
- 事务边界：改用 `isolation_level=None` + `BEGIN IMMEDIATE`，把幂等检查、库存检查、扣减、写预占记录放在同一事务；`fail_at="after_inventory"` 在扣减后 `ROLLBACK` 再抛 `RuntimeError`（原来库存已提交）。
- 并发兜底：捕获唯一索引 `IntegrityError`，回滚后按已存在记录判定 `replayed=True` 或 `conflict`。
- 非法输入：`request_id` 非空字符串、`quantity` 为 `int` 且非 `bool` 且 > 0、`sku` 非空字符串；未知 sku 仍返回 `invalid_request`。成功响应仍恰好 5 个字段，失败响应只含 `status`。

**新增 `tests/test_reservation.py`**（12 个用例）：正常预占与字段集合、相同编号相同参数重复调用（含跨调用无内存状态的重放）、相同编号不同 quantity/sku 冲突、冲突后合法重放仍可用、库存不足且不消耗编号、9 组非法输入、`fail_at` 回滚、注入失败后重试成功。

## 验证情况
- 执行 `run_tests`（`python -m unittest discover -s tests -v`）：13 tests，OK，exit_code 0，含原有 `tests/test_smoke.py`。
- 未修改 `tests/test_smoke.py`、`docs/`、`contracts/`、`AGENTS.md`。

## 未验证内容
- 并发场景（规则 4、5：多线程/多进程竞争、相同编号并发重试）**未做任何测试**，代码中的 `BEGIN IMMEDIATE` 与唯一索引只是设计上的保障，不能声称已验证。
- 未做性能、跨进程崩溃恢复、SQLite 锁超时（`timeout=15`）等场景验证。
- 独立验收由宿主执行，本报告不替代验收结果。