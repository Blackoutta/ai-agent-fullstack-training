"""Single-SKU inventory reservation with persistent idempotency.

Business contract: docs/rules.md (version 1).
"""
import sqlite3

_DEFAULT_SKU = "sku-1"
_BUSY_TIMEOUT = 15.0


def _connect(db_path):
    db = sqlite3.connect(db_path, timeout=_BUSY_TIMEOUT, isolation_level=None)
    db.execute("PRAGMA busy_timeout = %d" % int(_BUSY_TIMEOUT * 1000))
    return db


def initialize(db_path, stock=10):
    with _connect(db_path) as db:
        db.executescript('''
            CREATE TABLE IF NOT EXISTS inventory(sku TEXT PRIMARY KEY, available INTEGER NOT NULL);
            CREATE TABLE IF NOT EXISTS reservations(
                id INTEGER PRIMARY KEY AUTOINCREMENT, request_id TEXT NOT NULL,
                sku TEXT NOT NULL, quantity INTEGER NOT NULL);
            CREATE UNIQUE INDEX IF NOT EXISTS idx_reservations_request_id
                ON reservations(request_id);
        ''')
        db.execute("INSERT OR REPLACE INTO inventory VALUES (?, ?)", (_DEFAULT_SKU, stock))


def _invalid():
    return {"status": "invalid_request"}


def reserve(db_path, request_id, sku="sku-1", quantity=2, fail_at=None):
    # --- validation (no side effects) ---
    if not isinstance(request_id, str) or not request_id:
        return _invalid()
    if not isinstance(sku, str) or not sku:
        return _invalid()
    if type(quantity) is not int or quantity <= 0:
        return _invalid()

    db = _connect(db_path)
    try:
        # BEGIN IMMEDIATE takes the write lock up front so the
        # read-check-write sequence below is serialized across processes.
        db.execute("BEGIN IMMEDIATE")
        try:
            # Idempotency is checked before SKU existence so that a repeated
            # request id with different parameters is always a conflict.
            existing = db.execute(
                "SELECT sku, quantity FROM reservations WHERE request_id=?",
                (request_id,)).fetchone()
            if existing is not None:
                db.execute("ROLLBACK")
                if existing[0] == sku and existing[1] == quantity:
                    return {"status": "reserved", "request_id": request_id,
                            "sku": sku, "quantity": quantity, "replayed": True}
                return {"status": "conflict"}

            row = db.execute(
                "SELECT available FROM inventory WHERE sku=?", (sku,)).fetchone()
            if row is None:
                db.execute("ROLLBACK")
                return _invalid()

            if row[0] < quantity:
                db.execute("ROLLBACK")
                return {"status": "insufficient_stock"}

            db.execute("UPDATE inventory SET available=available-? WHERE sku=?",
                       (quantity, sku))
            if fail_at == "after_inventory":
                raise RuntimeError("injected_after_inventory")
            db.execute(
                "INSERT INTO reservations(request_id,sku,quantity) VALUES(?,?,?)",
                (request_id, sku, quantity))
            db.execute("COMMIT")
        except BaseException:
            # Roll back the whole unit of work: inventory update and the
            # reservation row are committed together or not at all.
            try:
                db.execute("ROLLBACK")
            except sqlite3.Error:
                pass
            raise
    finally:
        db.close()

    return {"status": "reserved", "request_id": request_id, "sku": sku,
            "quantity": quantity, "replayed": False}
