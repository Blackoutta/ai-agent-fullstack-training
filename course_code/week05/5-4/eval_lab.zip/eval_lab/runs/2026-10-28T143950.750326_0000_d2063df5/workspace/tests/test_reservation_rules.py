"""Tests for docs/rules.md behaviour: idempotency, conflict, concurrency, rollback."""
import sqlite3
import tempfile
import threading
import unittest
from pathlib import Path

from inventory import initialize, reserve


def _available(path, sku="sku-1"):
    with sqlite3.connect(path) as db:
        return db.execute("SELECT available FROM inventory WHERE sku=?", (sku,)).fetchone()[0]


def _reservations(path):
    with sqlite3.connect(path) as db:
        return db.execute(
            "SELECT request_id, sku, quantity FROM reservations ORDER BY id").fetchall()


class Base(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.path = str(Path(self._tmp.name) / "inventory.db")
        initialize(self.path, 10)

    def tearDown(self):
        self._tmp.cleanup()


class NormalReservationTest(Base):
    def test_normal_reservation_state(self):
        result = reserve(self.path, "r1", quantity=2)
        self.assertEqual(result, {"status": "reserved", "request_id": "r1",
                                  "sku": "sku-1", "quantity": 2, "replayed": False})
        self.assertEqual(_available(self.path), 8)
        self.assertEqual(_reservations(self.path), [("r1", "sku-1", 2)])

    def test_success_has_exactly_five_keys(self):
        result = reserve(self.path, "r1")
        self.assertEqual(set(result), {"status", "request_id", "sku", "quantity", "replayed"})


class IdempotencyTest(Base):
    def test_same_request_same_params_replays(self):
        first = reserve(self.path, "dup", quantity=3)
        second = reserve(self.path, "dup", quantity=3)
        self.assertFalse(first["replayed"])
        self.assertTrue(second["replayed"])
        self.assertEqual(second, {"status": "reserved", "request_id": "dup",
                                  "sku": "sku-1", "quantity": 3, "replayed": True})
        self.assertEqual(_available(self.path), 7)
        self.assertEqual(_reservations(self.path), [("dup", "sku-1", 3)])

    def test_replay_after_many_repeats(self):
        for _ in range(5):
            reserve(self.path, "dup", quantity=1)
        self.assertEqual(_available(self.path), 9)
        self.assertEqual(len(_reservations(self.path)), 1)

    def test_same_id_different_quantity_conflicts(self):
        reserve(self.path, "dup", quantity=2)
        result = reserve(self.path, "dup", quantity=3)
        self.assertEqual(result, {"status": "conflict"})
        self.assertEqual(_available(self.path), 8)
        self.assertEqual(_reservations(self.path), [("dup", "sku-1", 2)])

    def test_same_id_different_sku_conflicts(self):
        reserve(self.path, "dup", quantity=2)
        result = reserve(self.path, "dup", sku="sku-2", quantity=2)
        self.assertEqual(result, {"status": "conflict"})
        self.assertEqual(_available(self.path), 8)
        self.assertEqual(len(_reservations(self.path)), 1)

    def test_idempotency_survives_reconnect(self):
        reserve(self.path, "dup", quantity=2)
        # A fresh call (new connection) must still see the stored reservation.
        self.assertTrue(reserve(self.path, "dup", quantity=2)["replayed"])
        self.assertEqual(_available(self.path), 8)


class InsufficientStockTest(Base):
    def test_insufficient_stock_no_side_effects(self):
        result = reserve(self.path, "big", quantity=11)
        self.assertEqual(result, {"status": "insufficient_stock"})
        self.assertEqual(_available(self.path), 10)
        self.assertEqual(_reservations(self.path), [])

    def test_exact_stock_succeeds(self):
        self.assertEqual(reserve(self.path, "all", quantity=10)["status"], "reserved")
        self.assertEqual(_available(self.path), 0)
        self.assertEqual(reserve(self.path, "more", quantity=1)["status"],
                         "insufficient_stock")


class ValidationTest(Base):
    def test_invalid_requests(self):
        cases = [
            dict(request_id=""),
            dict(request_id=None),
            dict(request_id=123),
            dict(request_id="x", quantity=0),
            dict(request_id="x", quantity=-1),
            dict(request_id="x", quantity=1.5),
            dict(request_id="x", quantity=True),
            dict(request_id="x", quantity="2"),
            dict(request_id="x", sku="sku-unknown"),
        ]
        for kwargs in cases:
            with self.subTest(kwargs=kwargs):
                self.assertEqual(reserve(self.path, **kwargs), {"status": "invalid_request"})
        self.assertEqual(_available(self.path), 10)
        self.assertEqual(_reservations(self.path), [])


class RollbackTest(Base):
    def test_fail_at_after_inventory_rolls_back(self):
        with self.assertRaises(RuntimeError):
            reserve(self.path, "boom", quantity=4, fail_at="after_inventory")
        self.assertEqual(_available(self.path), 10)
        self.assertEqual(_reservations(self.path), [])

    def test_retry_after_failure_is_not_replay(self):
        with self.assertRaises(RuntimeError):
            reserve(self.path, "boom", quantity=4, fail_at="after_inventory")
        result = reserve(self.path, "boom", quantity=4)
        self.assertFalse(result["replayed"])
        self.assertEqual(_available(self.path), 6)
        self.assertEqual(_reservations(self.path), [("boom", "sku-1", 4)])


class ConcurrencyTest(Base):
    def test_distinct_ids_do_not_oversell(self):
        results = []
        lock = threading.Lock()

        def worker(i):
            try:
                out = reserve(self.path, "c-%d" % i, quantity=2)
            except Exception as exc:  # pragma: no cover - surfaced via assertion
                out = {"status": "error", "error": repr(exc)}
            with lock:
                results.append(out)

        threads = [threading.Thread(target=worker, args=(i,)) for i in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        reserved = [r for r in results if r["status"] == "reserved"]
        self.assertEqual(len(reserved), 5, results)
        self.assertTrue(all(r["status"] in ("reserved", "insufficient_stock")
                            for r in results), results)
        self.assertEqual(_available(self.path), 0)
        self.assertEqual(sum(q for _, _, q in _reservations(self.path)), 10)

    def test_same_id_concurrent_retries_reserve_once(self):
        results = []
        lock = threading.Lock()

        def worker():
            out = reserve(self.path, "same", quantity=3)
            with lock:
                results.append(out)

        threads = [threading.Thread(target=worker) for _ in range(8)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        self.assertEqual(len(results), 8)
        self.assertTrue(all(r["status"] == "reserved" for r in results), results)
        self.assertEqual(sum(1 for r in results if r["replayed"] is False), 1, results)
        self.assertEqual(_available(self.path), 7)
        self.assertEqual(_reservations(self.path), [("same", "sku-1", 3)])


if __name__ == "__main__":
    unittest.main()
