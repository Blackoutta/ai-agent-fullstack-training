## 报告

### 实际改动

**`inventory.py`（唯一修改的现有文件）**

1. **幂等持久化**：删除每次调用重建的内存 `seen` 集合，改为在 `reservations` 表中按 `request_id` 查询既有记录；`initialize` 增加 `UNIQUE INDEX idx_reservations_request_id`（rules 允许增加索引，表名/列不变）。
2. **重复提交语义**：同编号同参数 → `replayed: true` 且不改库存；同编号不同 sku 或 quantity → `{"status": "conflict"}`，不改库存、不新增记录。幂等检查放在 SKU 存在性检查之前，否则同编号换 sku 会误返回 `invalid_request`（首次运行测试即暴露此问题，已修正）。
3. **并发竞争**：改用 `isolation_level=None` 手动事务 + `BEGIN IMMEDIATE` 提前取写锁，使「读库存→判断→扣减→写预占」串行化；设置 `busy_timeout`。原实现是两次独立连接、两次隐式提交，存在检查/更新竞态。
4. **异常回滚**：库存更新与预占写入在同一事务内，`fail_at="after_inventory"` 在 UPDATE 之后、INSERT 之前抛 `RuntimeError`，由 `except BaseException` 统一 `ROLLBACK` 后重新抛出，库存与记录均不落库。原实现库存已提交、异常后不回滚。
5. **接口兼容**：`initialize(db_path, stock=10)`、`reserve(db_path, request_id, sku="sku-1", quantity=2, fail_at=None)` 签名、表结构、成功响应五字段（status/request_id/sku/quantity/replayed）保持不变；校验顺序为 request_id 非空字符串 → sku 非空字符串 → quantity 为 `int` 且非 bool 且 > 0，未知 sku 返回 `invalid_request`。

**`tests/test_reservation_rules.py`（新增）**：15 个用例覆盖正常预占状态、成功响应恰好五字段、同编号同参数重复调用（含连续 5 次、跨连接）、同编号不同 quantity/sku 冲突、库存不足无副作用、恰好用尽库存、9 类非法输入、`fail_at` 回滚、失败后重试非 replay、10 线程不同编号不超卖、8 线程同编号只成功一次。

未修改 `tests/test_smoke.py`、`docs/`、`contracts/`、`AGENTS.md`。

### 实际执行的验证

- 第一次 `run_tests`：**失败**，`test_same_id_different_sku_conflicts` 返回 `invalid_request` 而非 `conflict`（exit_code=1，14 passed / 1 failed）。
- 修正检查顺序后再次 `run_tests`：**exit_code=0，Ran 15 tests，OK**（含原有 smoke 测试）。测试文件指纹 `5d068060…`，`inventory.py` 指纹 `18173b61…`。

### 未验证 / 不构成结论的部分

- 并发测试仅用线程 + 单进程 SQLite 文件，未验证多进程、跨主机或高负载下的行为；`BEGIN IMMEDIATE` 在极端锁竞争下可能抛 `database is locked`，此路径未测试。
- 未做性能/吞吐评估，rules 也未要求。
- 未验证 `initialize` 对已存在数据库的重复调用语义（会 `INSERT OR REPLACE` 重置库存，且保留旧预占记录）——rules 未定义该场景，未加测试。
- 独立验收由宿主执行，本报告不能替代。