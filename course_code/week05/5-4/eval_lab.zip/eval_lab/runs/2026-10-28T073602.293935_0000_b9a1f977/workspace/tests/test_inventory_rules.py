"""Tests for docs/rules.md version 1 behaviour."""
import tempfile
import threading
import unittest
from pathlib import Path

from inventory import initialize, reserve

SUCCESS_KEYS = {"status", "request_id", "sku", "quantity", "replayed"}


class InventoryTestCase(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.path = str(Path(self._tmp.name) / "inventory.db")
        initialize(self.path, 10)

    def available(self, sku="sku-1"):
        import sqlite3
        with sqlite3.connect(self.path) as db:
            return db.execute("SELECT available FROM inventory WHERE sku=?", (sku,)).fetchone()[0]

    def reservations(self):
        import sqlite3
        with sqlite3.connect(self.path) as db:
            return db.execute(
                "SELECT request_id, sku, quantity FROM reservations ORDER BY id"
            ).fetchall()


class NormalReservationTest(InventoryTestCase):
    def test_normal_reservation(self):
        result = reserve(self.path, "r1", quantity=2)
        self.assertEqual(result, {"status": "reserved", "request_id": "r1",
                                  "sku": "sku-1", "quantity": 2, "replayed": False})
        self.assertEqual(set(result), SUCCESS_KEYS)
        self.assertEqual(self.available(), 8)
        self.assertEqual(self.reservations(), [("r1", "sku-1", 2)])


class IdempotencyTest(InventoryTestCase):
    def test_same_request_id_same_params_replays(self):
        first = reserve(self.path, "dup", quantity=3)
        second = reserve(self.path, "dup", quantity=3)
        third = reserve(self.path, "dup", quantity=3)
        self.assertFalse(first["replayed"])
        self.assertTrue(second["replayed"])
        self.assertTrue(third["replayed"])
        self.assertEqual(set(second), SUCCESS_KEYS)
        self.assertEqual(second["request_id"], "dup")
        self.assertEqual(second["sku"], "sku-1")
        self.assertEqual(second["quantity"], 3)
        self.assertEqual(self.available(), 7)
        self.assertEqual(self.reservations(), [("dup", "sku-1", 3)])

    def test_same_request_id_different_quantity_conflicts(self):
        reserve(self.path, "dup", quantity=2)
        result = reserve(self.path, "dup", quantity=5)
        self.assertEqual(result, {"status": "conflict"})
        self.assertEqual(self.available(), 8)
        self.assertEqual(self.reservations(), [("dup", "sku-1", 2)])

    def test_same_request_id_different_sku_conflicts(self):
        reserve(self.path, "dup", quantity=2)
        result = reserve(self.path, "dup", sku="sku-2", quantity=2)
        self.assertEqual(result, {"status": "conflict"})
        self.assertEqual(self.available(), 8)
        self.assertEqual(self.reservations(), [("dup", "sku-1", 2)])

    def test_replay_after_stock_exhausted_still_replays(self):
        reserve(self.path, "dup", quantity=10)
        self.assertEqual(self.available(), 0)
        replay = reserve(self.path, "dup", quantity=10)
        self.assertEqual(replay["status"], "reserved")
        self.assertTrue(replay["replayed"])
        self.assertEqual(self.available(), 0)
        self.assertEqual(len(self.reservations()), 1)


class InsufficientStockTest(InventoryTestCase):
    def test_insufficient_stock(self):
        result = reserve(self.path, "big", quantity=11)
        self.assertEqual(result, {"status": "insufficient_stock"})
        self.assertEqual(self.available(), 10)
        self.assertEqual(self.reservations(), [])

    def test_insufficient_stock_does_not_block_later_request(self):
        self.assertEqual(reserve(self.path, "big", quantity=11)["status"], "insufficient_stock")
        self.assertEqual(reserve(self.path, "ok", quantity=1)["status"], "reserved")
        self.assertEqual(self.available(), 9)


class ValidationTest(InventoryTestCase):
    def test_invalid_request_ids(self):
        for bad in ("", None, 123, 1.5, b"bytes", ["x"]):
            with self.subTest(request_id=bad):
                self.assertEqual(reserve(self.path, bad)["status"], "invalid_request")
        self.assertEqual(self.available(), 10)
        self.assertEqual(self.reservations(), [])

    def test_invalid_quantities(self):
        for bad in (0, -1, 1.0, True, False, "2", None):
            with self.subTest(quantity=bad):
                self.assertEqual(
                    reserve(self.path, "q", quantity=bad)["status"], "invalid_request")
        self.assertEqual(self.available(), 10)
        self.assertEqual(self.reservations(), [])

    def test_unknown_sku(self):
        result = reserve(self.path, "r", sku="sku-404", quantity=1)
        self.assertEqual(result, {"status": "invalid_request"})
        self.assertEqual(self.reservations(), [])


class RollbackTest(InventoryTestCase):
    def test_fail_at_after_inventory_rolls_back(self):
        with self.assertRaises(RuntimeError):
            reserve(self.path, "boom", quantity=4, fail_at="after_inventory")
        self.assertEqual(self.available(), 10)
        self.assertEqual(self.reservations(), [])

    def test_retry_after_failure_succeeds_once(self):
        with self.assertRaises(RuntimeError):
            reserve(self.path, "boom", quantity=4, fail_at="after_inventory")
        result = reserve(self.path, "boom", quantity=4)
        self.assertEqual(result["status"], "reserved")
        self.assertFalse(result["replayed"])
        self.assertEqual(self.available(), 6)
        self.assertEqual(self.reservations(), [("boom", "sku-1", 4)])

    def test_unknown_fail_at_is_ignored(self):
        result = reserve(self.path, "r", quantity=1, fail_at="somewhere_else")
        self.assertEqual(result["status"], "reserved")
        self.assertEqual(self.available(), 9)


class ConcurrencyTest(InventoryTestCase):
    def _run_threads(self, targets):
        threads = [threading.Thread(target=t) for t in targets]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        return threads

    def test_distinct_request_ids_do_not_oversell(self):
        results = []
        lock = threading.Lock()

        def worker(index):
            outcome = reserve(self.path, f"c-{index}", quantity=2)
            with lock:
                results.append(outcome)

        self._run_threads([lambda i=i: worker(i) for i in range(12)])

        reserved = [r for r in results if r["status"] == "reserved"]
        self.assertEqual(len(reserved), 5)
        self.assertEqual(len([r for r in results if r["status"] == "insufficient_stock"]), 7)
        self.assertEqual(self.available(), 0)
        self.assertEqual(len(self.reservations()), 5)
        self.assertEqual(sum(q for _, _, q in self.reservations()), 10)

    def test_same_request_id_concurrent_retries_reserve_once(self):
        results = []
        lock = threading.Lock()

        def worker():
            outcome = reserve(self.path, "same", quantity=3)
            with lock:
                results.append(outcome)

        self._run_threads([worker for _ in range(10)])

        self.assertTrue(all(r["status"] == "reserved" for r in results))
        self.assertEqual(len([r for r in results if r["replayed"] is False]), 1)
        self.assertEqual(len([r for r in results if r["replayed"] is True]), 9)
        self.assertEqual(self.available(), 7)
        self.assertEqual(self.reservations(), [("same", "sku-1", 3)])


if __name__ == "__main__":
    unittest.main()
