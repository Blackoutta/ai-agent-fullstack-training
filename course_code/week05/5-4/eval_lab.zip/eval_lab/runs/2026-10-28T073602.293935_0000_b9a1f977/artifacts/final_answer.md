## 报告

### 实际改动

**`inventory.py`（重写，唯一修改的现有文件）**

| 缺陷 | 修复 |
|---|---|
| 幂等失效：`seen = set()` 每次调用重建 | 幂等状态持久化在 `reservations` 表，按 `request_id` 查询；新增 `UNIQUE INDEX idx_reservations_request_id` |
| 重复提交不返回 `replayed=true` | 命中已有记录且 sku/quantity 相同 → 返回 `replayed=True`，不改库存 |
| 同编号不同参数未返回 conflict | 命中已有记录但 sku 或 quantity 不同 → `{"status":"conflict"}`，不改库存、不新增记录 |
| 检查/更新竞态（`time.sleep` 暴露的 TOCTOU） | 整个读-判-改-写包在 `BEGIN IMMEDIATE` 事务内，`busy_timeout=30000`，串行化写者 |
| `fail_at="after_inventory"` 库存已提交 | 库存更新与预占插入在同一事务；注入异常后 `ROLLBACK`，整体回滚 |
| 校验不完整 | `request_id` 非空字符串；`quantity` 用 `type(x) is int`（排除 bool）且 >0；未知/非法 sku → `invalid_request` |
| 连接管理 | `isolation_level=None` 显式事务，`finally: db.close()` |

签名、表名、列、成功响应五字段（`status/request_id/sku/quantity/replayed`）保持兼容。

**`tests/test_inventory_rules.py`（新增）** — 15 个用例：正常预占、同编号同参数重复调用（含库存耗尽后重放）、同编号不同 quantity/sku 冲突、库存不足、非法 request_id/quantity（含 `True`/`False`/`1.0`/`"2"`）、未知 sku、`fail_at` 回滚与失败后重试、12 线程不同编号竞争（断言恰好 5 成功、7 不足、库存 0、预占总量 10）、10 线程同编号并发（断言恰好 1 次 `replayed=false`、9 次 `true`、仅 1 条记录）。

### 实际执行的测试

`run_tests`（`python -m unittest discover -s tests -v`）执行两次，均 **exit_code=0，Ran 16 tests, OK**（15 新增 + 1 既有 smoke）。两次运行结果一致，未观察到并发用例抖动。

### 未验证 / 限制

- 并发结论仅限本机 SQLite 单文件、12/10 线程的重复运行结果；**不构成生产并发或性能可靠性结论**。
- 未测试多进程并发、`initialize` 与 `reserve` 并发交错、数据库文件损坏、磁盘满等场景。
- 未测试 `sku` 为 `None`/非字符串以外的边界（如超长字符串）。
- 未验证 `fail_at` 其他取值语义（当前仅 `"after_inventory"` 触发，其余忽略，测试覆盖了忽略路径）。
- 未修改 `tests/test_smoke.py`、`docs/`、`contracts/`、`AGENTS.md`；未访问工程外路径或参考实现。