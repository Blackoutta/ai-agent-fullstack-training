11 个测试全部通过（退出码 0）。

## 实际改动

**`inventory.py`（重写）**
- 幂等状态改为持久化：`reservations` 表新增唯一索引 `idx_reservations_request_id`（`initialize` 中 `CREATE UNIQUE INDEX IF NOT EXISTS`，表名/列不变）。删除了每次调用都重建的内存 `seen` 集合。
- 重复调用：先按 `request_id` 查已有记录；sku 与 quantity 相同 → 返回 `replayed=true` 的成功响应，不改库存、不新增记录；不同 → 返回 `{"status":"conflict"}`，不改库存、不新增记录。
- 事务：`BEGIN IMMEDIATE` 把「幂等检查 + 库存检查 + 扣减 + 写预占」放在同一事务内，`COMMIT`/`ROLLBACK` 显式控制（`isolation_level=None`），异常路径统一回滚后重新抛出。
- `fail_at="after_inventory"` 仍在库存 UPDATE 之后、INSERT 之前抛 `RuntimeError`，但现在处于事务内，整体回滚。
- 校验顺序与契约保持：`request_id` 非空字符串、`quantity` 为正整数（`type(...) is int`，bool 被拒）、未知 sku → `invalid_request`；库存不足 → `insufficient_stock`；成功响应恰好 5 个字段。

**`tests/test_idempotency.py`（新增）**：10 个用例，覆盖正常预占契约、同编号同参数重复调用（连续 3 次，检查响应/库存/记录）、同编号不同 quantity、同编号不同 sku、冲突后不影响后续请求、库存不足、非法输入（含 bool/float/str/None/未知 sku）、`fail_at` 回滚、失败后重试成功、跨连接幂等。

## 实际执行的验证
- `run_tests`（`python -m unittest discover -s tests -v`）：11 tests，OK，exit_code 0。其中重复调用验证使用相同 `request_id` 与相同参数连续调用，并断言库存与 `reservations` 表内容。

## 未验证 / 不声称
- 并发（规则 4、5）未做并发测试，未验证；`BEGIN IMMEDIATE` 只是设计上的串行化手段，未实测。
- 未做多进程/多线程压测、生产可靠性或性能结论。
- 未修改 `tests/test_smoke.py`、docs、contracts、AGENTS.md；独立验收由宿主执行。