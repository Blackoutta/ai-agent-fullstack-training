## 实际改动

**`inventory.py`（唯一修改的现有文件）**

1. **幂等改为持久化判定**：删除每次调用重建的内存 `seen = set()`，改为在事务内查询 `reservations` 表按 `request_id` 判断是否已存在记录。
   - 已存在且 `sku`、`quantity` 相同 → 返回 `replayed=True`，不再扣减库存、不再插入记录。
   - 已存在但 `sku` 或 `quantity` 不同 → 返回 `{"status":"conflict"}`，库存与记录均不变。
2. **单事务原子性**：`BEGIN IMMEDIATE` 包裹「查重 → 查库存 → 扣减 → 写预占」，任何失败路径 `ROLLBACK`；`fail_at="after_inventory"` 在扣减后、写记录前抛 `RuntimeError`，整体回滚（原实现扣减已提交，无法回滚）。
3. **唯一索引**：`initialize` 增加 `UNIQUE INDEX idx_reservations_request_id`，作为数据库层兜底。
4. **保留契约**：函数签名、表名/列、成功响应五字段（status/request_id/sku/quantity/replayed）、`invalid_request`（空/非字符串 request_id、非正整数 quantity、bool、未知 sku）、`insufficient_stock` 均未改变。

**`tests/test_idempotency.py`（新增）**：11 个用例，覆盖相同编号相同参数重复调用（含第三次、穿插其他编号后重放）、同编号不同 quantity/sku 冲突、冲突不消耗库存、不同编号各自成功、库存不足无副作用、非法输入矩阵、未知 sku、`fail_at` 回滚后重试。

## 实际执行的测试

`run_tests`（`python -m unittest discover -s tests -v`），退出码 0：

- 12 个测试全部通过（新增 11 + 原有 `test_smoke.py` 1）。
- 幂等验证使用**相同 request_id 与相同参数**重复调用，断言第二次/第三次 `replayed=True`、库存仅扣一次、`reservations` 仅一条记录。

## 未验证内容

- **并发**：未做多线程/多进程竞争测试，`BEGIN IMMEDIATE` 的串行化效果未实测（规则第 4、5 条未验证）。
- **生产可靠性**：未验证高并发、锁超时、崩溃恢复等场景。
- 未运行独立验收（由宿主负责），未访问工程外参考实现或评分器。
- 未修改 `tests/test_smoke.py`、`docs/`、`contracts/`、`AGENTS.md`。