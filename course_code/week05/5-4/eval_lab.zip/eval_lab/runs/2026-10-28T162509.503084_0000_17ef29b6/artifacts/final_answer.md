All 14 tests pass (exit code 0).

## 实际改动

**`inventory.py`（重写 `reserve`，`initialize` 增加唯一索引）**

1. **重复扣减修复**：原实现每次调用都新建 `seen = set()`，幂等状态从未持久化。现改为在 `reservations` 表中按 `request_id` 查询已有记录：
   - 参数相同 → 返回 `replayed=True`，不再扣库存、不再写记录；
   - 参数不同（sku 或 quantity）→ 返回 `{"status":"conflict"}`，不改变库存与记录。
2. **事务与回滚**：改为 `isolation_level=None` + `BEGIN IMMEDIATE`，把幂等查询、库存检查、扣减、写预占放在同一事务内；`fail_at="after_inventory"` 在扣减后抛出 `RuntimeError`，异常路径统一 `ROLLBACK` 后重新抛出，因此库存与记录整体回滚。
3. **并发安全（实现层面）**：`BEGIN IMMEDIATE` 提前取写锁，配合 `reservations(request_id)` 唯一索引，避免同编号重复插入。**此项未做并发验证**（见下）。
4. 保持兼容：函数签名、表名与列不变（仅新增索引）；成功响应恰好 5 个字段；非法输入/未知 sku → `invalid_request`，库存不足 → `insufficient_stock`。

**新增 `tests/test_reservation.py`**（14 个用例中的 13 个）：重复调用（含多次重试、与其他请求交错、库存耗尽后重放、响应字段集合）、同编号不同参数冲突（quantity / sku / 库存耗尽时）、非法输入与未知 sku、库存不足、`fail_at` 回滚与失败后重试。

未修改 `tests/test_smoke.py`、`docs/`、`contracts/`、`AGENTS.md`。

## 实际执行的验证

- `run_tests`（`python -m unittest discover -s tests -v`）：**exit_code 0，Ran 14 tests, OK**，含原有 smoke 测试。

## 未验证内容

- **并发**：未编写或运行多线程/多进程竞争测试，规则第 4、5 条的并发行为仅由代码结构（写锁 + 唯一索引）推断，**未经验证**。
- **回滚**：`fail_at` 回滚有单线程测试覆盖并通过，但未在并发或进程崩溃场景下验证。
- 独立验收由宿主执行，本报告不代替其结论。