"""Tests for idempotent replay, conflict detection and input validation."""
import tempfile
import unittest
from pathlib import Path

from inventory import initialize, reserve


class ReserveTestCase(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.path = str(Path(self._tmp.name) / "inventory.db")
        initialize(self.path, 10)

    def available(self):
        import sqlite3
        with sqlite3.connect(self.path) as db:
            return db.execute("SELECT available FROM inventory WHERE sku='sku-1'").fetchone()[0]

    def reservation_count(self):
        import sqlite3
        with sqlite3.connect(self.path) as db:
            return db.execute("SELECT COUNT(*) FROM reservations").fetchone()[0]


class ReplayTest(ReserveTestCase):
    def test_duplicate_same_params_reserves_once(self):
        first = reserve(self.path, "req-1", quantity=2)
        second = reserve(self.path, "req-1", quantity=2)
        self.assertEqual(first, {"status": "reserved", "request_id": "req-1",
                                 "sku": "sku-1", "quantity": 2, "replayed": False})
        self.assertEqual(second, {"status": "reserved", "request_id": "req-1",
                                  "sku": "sku-1", "quantity": 2, "replayed": True})
        self.assertEqual(self.available(), 8)
        self.assertEqual(self.reservation_count(), 1)

    def test_many_duplicates_reserve_once(self):
        for _ in range(5):
            reserve(self.path, "req-dup", quantity=3)
        self.assertEqual(self.available(), 7)
        self.assertEqual(self.reservation_count(), 1)

    def test_replay_does_not_consume_stock_again(self):
        reserve(self.path, "req-a", quantity=4)
        reserve(self.path, "req-a", quantity=4)
        self.assertEqual(self.available(), 6)
        # A different request can still take the remaining stock.
        self.assertEqual(reserve(self.path, "req-b", quantity=6)["status"], "reserved")
        self.assertEqual(self.available(), 0)


class ConflictTest(ReserveTestCase):
    def test_same_id_different_quantity_conflicts(self):
        reserve(self.path, "req-1", quantity=2)
        result = reserve(self.path, "req-1", quantity=3)
        self.assertEqual(result, {"status": "conflict"})
        self.assertEqual(self.available(), 8)
        self.assertEqual(self.reservation_count(), 1)

    def test_same_id_different_sku_conflicts(self):
        reserve(self.path, "req-1", quantity=2)
        result = reserve(self.path, "req-1", sku="sku-2", quantity=2)
        self.assertEqual(result, {"status": "conflict"})
        self.assertEqual(self.available(), 8)
        self.assertEqual(self.reservation_count(), 1)

    def test_conflict_is_stable_after_replay(self):
        reserve(self.path, "req-1", quantity=2)
        self.assertEqual(reserve(self.path, "req-1", quantity=5), {"status": "conflict"})
        self.assertEqual(reserve(self.path, "req-1", quantity=2)["replayed"], True)
        self.assertEqual(self.available(), 8)


class ValidationTest(ReserveTestCase):
    def test_invalid_request_ids(self):
        for bad in ("", None, 123, 1.5, b"req"):
            self.assertEqual(reserve(self.path, bad, quantity=1), {"status": "invalid_request"})

    def test_invalid_quantities(self):
        for bad in (0, -1, 1.0, True, False, "2", None):
            self.assertEqual(reserve(self.path, "req-x", quantity=bad),
                             {"status": "invalid_request"})
        self.assertEqual(self.available(), 10)
        self.assertEqual(self.reservation_count(), 0)

    def test_unknown_sku(self):
        self.assertEqual(reserve(self.path, "req-x", sku="sku-9", quantity=1),
                         {"status": "invalid_request"})
        self.assertEqual(self.available(), 10)

    def test_insufficient_stock(self):
        self.assertEqual(reserve(self.path, "req-x", quantity=11),
                         {"status": "insufficient_stock"})
        self.assertEqual(self.available(), 10)
        self.assertEqual(self.reservation_count(), 0)

    def test_insufficient_stock_does_not_block_retry_with_smaller_quantity(self):
        self.assertEqual(reserve(self.path, "req-x", quantity=11)["status"],
                         "insufficient_stock")
        self.assertEqual(reserve(self.path, "req-x", quantity=1)["status"], "reserved")
        self.assertEqual(self.available(), 9)


class FailureInjectionTest(ReserveTestCase):
    def test_after_inventory_rolls_back(self):
        with self.assertRaises(RuntimeError):
            reserve(self.path, "req-fail", quantity=2, fail_at="after_inventory")
        self.assertEqual(self.available(), 10)
        self.assertEqual(self.reservation_count(), 0)

    def test_retry_after_failure_succeeds(self):
        with self.assertRaises(RuntimeError):
            reserve(self.path, "req-fail", quantity=2, fail_at="after_inventory")
        result = reserve(self.path, "req-fail", quantity=2)
        self.assertEqual(result["replayed"], False)
        self.assertEqual(self.available(), 8)
        self.assertEqual(self.reservation_count(), 1)


if __name__ == "__main__":
    unittest.main()
