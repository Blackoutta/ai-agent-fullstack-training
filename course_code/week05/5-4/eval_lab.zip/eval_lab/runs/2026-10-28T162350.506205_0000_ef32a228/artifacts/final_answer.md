## 报告

### 实际改动

**`inventory.py`（重写 `reserve`，`initialize` 增加唯一索引）**

1. **重复扣减修复**：原实现每次调用都新建 `seen = set()`，去重完全失效。现改为以 `reservations` 表为持久化幂等依据：在同一事务内先按 `request_id` 查询已有记录。
   - 参数相同 → 返回 `replayed=True`，不再改库存、不再插记录。
   - 参数不同（sku 或 quantity）→ 返回 `{"status": "conflict"}`，不改库存、不插记录。
2. **事务边界**：改用 `isolation_level=None` + 显式 `BEGIN IMMEDIATE`，把「查重 → 查库存 → 扣减 → 写预占」放在同一事务内；`fail_at="after_inventory"` 的 `RuntimeError` 在事务内抛出，由 `except BaseException` 统一 `ROLLBACK` 后重新抛出，因此库存更新被整体回滚（原实现是两次独立连接，库存已提交）。
3. **输入校验**：`request_id` 非空字符串、`sku` 非空字符串、`quantity` 为正整数（`type(...) is int`，排除 `bool`）；未知 sku 仍返回 `invalid_request`。
4. **契约保持**：成功响应仍恰好是 `status/request_id/sku/quantity/replayed` 五字段；失败状态仍为 `conflict` / `insufficient_stock` / `invalid_request`。表名与已有列未变，仅新增 `idx_reservations_request_id` 唯一索引（rules.md 允许增加索引）。

**新增 `tests/test_reserve_idempotency.py`**（14 个用例中的 13 个）：重复调用同参数只扣一次、多次重复、重放不重复占库存、同编号不同 quantity/sku 冲突、冲突后重放仍稳定、非法 request_id/quantity/未知 sku、库存不足、失败注入回滚、失败后重试成功。

未修改 `tests/test_smoke.py`、`docs/`、`contracts/`、`AGENTS.md`。

### 实际执行的测试

`run_tests`（`python -m unittest discover -s tests -v`），退出码 **0**，`Ran 14 tests ... OK`，包含原有 smoke 用例与新增 13 个用例。

### 未验证内容

- **并发场景未验证**：rules.md 第 4、5 条（不同编号并发竞争、相同编号并发重试）没有编写或执行任何多线程/多进程测试。代码使用 `BEGIN IMMEDIATE` 与唯一索引作为设计手段，但**未实测**，不能声称已验证。
- **回滚**：`fail_at="after_inventory"` 的单线程回滚已由测试覆盖并通过；但并发下的回滚行为未验证。
- 独立验收由宿主执行，本报告不代替验收结果。