## 结论（只读调查，未修改任何文件，未执行测试）

### 当前有效规则来源
- **`docs/rules.md`** — 标题即声明：“当前库存预占规则（本实验的有效业务契约，版本 1）”。
- **`AGENTS.md`** — “以 docs/rules.md 为当前业务依据。不要使用 docs/archive_2024.md 覆盖当前规则。”
- **`contracts/response.json`** — `"version": "1"`，与 rules.md 版本一致，列出成功键与四种 status。

### 1. 幂等规则（当前有效）
`docs/rules.md` 第 2、5 条：
- “同一请求编号和相同参数重复提交，只能产生一次有效预占。第一次 `replayed=false`，重试 `replayed=true`。”
- “相同编号并发重试也只能产生一次有效预占。”

即幂等键是 **request_id**（配合相同 sku/quantity），且必须跨进程/跨调用持久有效（第 2 条要求“持久化状态”，见历史文档说明）。成功响应必须“恰好包含 status、request_id、sku、quantity、replayed 五个字段”。

### 2. 编号冲突规则（当前有效）
`docs/rules.md` 第 3 条：
- “同一编号携带不同 sku 或 quantity 返回 `{"status":"conflict"}`，不能再次改变库存或记录。”

`contracts/response.json` 的 `statuses` 含 `"conflict"`，与之一致。

### 3. 回滚规则（当前有效）
`docs/rules.md` 第 8 条：
- “`fail_at="after_inventory"` 表示在库存更新之后、写入预占记录之前注入 RuntimeError。这次操作必须整体回滚；正常路径不能忽略此参数以绕过检查。”

配套约束：第 6 条“库存不足返回 `{"status":"insufficient_stock"}`，没有额外业务修改”；第 4 条“成功预占总量不能超过库存，且库存与有效预占总量一致”。

### 4. 历史文档是否仍有效
**`docs/archive_2024.md` 已失效，不可作为当前规则。** 原文：
- 标题：“历史文档：2024 版（已过期，不可作为当前规则）”
- “历史实现没有稳定的请求编号，曾按用户和商品做内存去重。”
- “当前实现必须遵循 docs/rules.md 的业务请求编号、持久化状态、并发与回滚要求。”

因此“按用户+商品内存去重”的旧做法**不是**有效规则；`AGENTS.md` 也明确禁止用它覆盖当前规则。

### 5. 与当前代码的对照（仅陈述观察，未修复）
`inventory.py` 自述为 “Teaching defect fixture. This is intentionally incorrect”。观察到的与上述规则的差距：
- 幂等：`seen = set()  # Bug: recreated for every invocation.` — 每次调用重建，且未持久化，违反第 2、5 条。
- 冲突：代码中**没有**任何 `conflict` 分支，违反第 3 条。
- 回滚：`raise RuntimeError(...)  # Bug: inventory was already committed.` — 库存更新已在独立连接中提交，违反第 8 条。
- 并发：`time.sleep(0.01)  # Simulated I/O exposes the check/update race` — 检查与更新非原子，违反第 4 条。
- 校验：`type(quantity) is not int` 已排除 bool，符合第 7 条；未知 sku 返回 `invalid_request`，符合第 7 条。

### 未验证项（明确说明）
- 我**没有**运行 `run_tests` 或任何测试，因此不对当前代码是否通过 smoke 测试作任何断言。
- 我**没有**修改 `inventory.py` 或新增测试文件，**未完成任何代码修复**。
- 上述“与代码的对照”仅为静态阅读结论，未经运行时验证。