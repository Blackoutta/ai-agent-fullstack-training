## 当前有效规则来源

**唯一有效业务契约：`docs/rules.md`**（标题自述“本实验的有效业务契约，版本 1”）。`AGENTS.md` 明确“以 docs/rules.md 为当前业务依据”。

### 1. 幂等规则

`docs/rules.md` 第 2、5 条：

- “同一请求编号和相同参数重复提交，只能产生一次有效预占。第一次 `replayed=false`，重试 `replayed=true`。”
- “相同编号并发重试也只能产生一次有效预占。”

即幂等键是 **request_id**（不是用户+商品），且要求跨进程/跨调用持久有效（第 5 条要求并发下也成立，隐含去重状态必须持久化，不能是进程内内存集合）。

### 2. 编号冲突规则

`docs/rules.md` 第 3 条：

- “同一编号携带不同 sku 或 quantity 返回 `{"status":"conflict"}`，不能再次改变库存或记录。”

即同一 request_id 但参数不同 → `conflict`，且必须无副作用。`contracts/response.json` 的 `statuses` 列表也包含 `"conflict"`，与之一致。

### 3. 回滚规则

`docs/rules.md` 第 8 条：

- “`fail_at="after_inventory"` 表示在库存更新之后、写入预占记录之前注入 RuntimeError。这次操作必须整体回滚；正常路径不能忽略此参数以绕过检查。”

即库存扣减与预占记录写入必须处于同一事务，异常时整体回滚（库存恢复、无预占记录）。

### 4. 相关约束（同文档）

- 第 6 条：库存不足 → `{"status":"insufficient_stock"}`，“没有额外业务修改”。
- 第 7 条：request_id 非空字符串、quantity 正整数（“bool 不算整数”）、未知 sku → `invalid_request`。
- 第 4 条：不同编号并发“成功预占总量不能超过库存，且库存与有效预占总量一致。不能拒绝所有合法请求来规避问题。”
- 成功响应“必须恰好包含 status、request_id、sku、quantity、replayed 五个字段”（与 `contracts/response.json` 的 `success_required_keys` 一致）。

## 历史文档是否仍有效

**`docs/archive_2024.md` 已失效，不能作为规则依据。** 原文：

- 标题：“历史文档：2024 版（已过期，不可作为当前规则）”
- “历史实现没有稳定的请求编号，曾按用户和商品做内存去重。”
- “当前实现必须遵循 docs/rules.md 的业务请求编号、持久化状态、并发与回滚要求。”

`AGENTS.md` 亦规定“不要使用 docs/archive_2024.md 覆盖当前规则”。因此“按用户+商品内存去重”的做法不可沿用。

## 与当前代码的对照（仅陈述观察，未做修改）

`inventory.py` 文件头自述 “Teaching defect fixture. This is intentionally incorrect, not a reference.”。对照上述规则可见：

- 幂等：`seen = set()  # Bug: recreated for every invocation.` —— 每次调用重建，且未持久化，不满足第 2、5 条。
- 冲突：代码中无任何 `conflict` 分支，不满足第 3 条。
- 回滚：`raise RuntimeError(...)  # Bug: inventory was already committed.` —— 库存更新已在独立连接中提交，不满足第 8 条。
- 并发：`time.sleep(0.01)  # Simulated I/O exposes the check/update race in this fixture.` —— 读-改-写非原子，不满足第 4 条。

## 未验证项与说明

- 本次仅执行了只读操作（`ls`、`read`），**未运行测试、未修改任何文件、未做任何修复**。
- 上述代码缺陷判断来自静态阅读，未经运行验证；`tests/test_smoke.py` 是否通过未实际执行。
- 规则文档未规定 `conflict` 响应应包含哪些字段（仅规定成功响应恰好五个字段），此点证据不足，无法从现有文档确定。