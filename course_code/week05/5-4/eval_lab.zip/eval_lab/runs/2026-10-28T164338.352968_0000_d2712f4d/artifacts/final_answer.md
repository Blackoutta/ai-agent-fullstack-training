# 只读风险扫描报告（库存请求 / 幂等 / 事务 / 接口）

## 0. 执行范围与证据边界

**实际执行的操作（全部只读）：**
- 读取 `AGENTS.md`、`docs/rules.md`、`docs/archive_2024.md`、`contracts/response.json`、`inventory.py`、`tests/test_smoke.py`
- 列目录：根目录仅 `AGENTS.md / contracts/ / docs/ / inventory.py / tests/`

**未执行的操作（明确声明）：**
- 未运行 `run_tests`，未运行任何 Python 代码，未做并发压测或性能测量
- 未访问工程外参考实现或评分器
- 未修改任何文件（本次为只读扫描）

**Diff 状态：** 当前工作区无变更（初始缺陷工程）。因此以下全部为**候选风险**，不是"已确认故障"。源码中 `# Bug:` 注释是作者自述，我按代码逻辑独立复核，但**未通过运行验证**。

**规则依据：** `docs/rules.md` v1（有效）。`docs/archive_2024.md` 自述已过期，仅用于确认"内存去重"是历史做法、不可作为当前依据。

---

## 1. 发现清单

### F1 — 幂等去重完全失效（内存 set 每次调用重建）

| 项 | 内容 |
|---|---|
| 位置 | `inventory.py:23` `seen = set()  # Bug: recreated for every invocation.`；`inventory.py:24-26` 判断；`inventory.py:38` `seen.add(request_id)` |
| 触发条件 | 任意同一 `request_id` 的第二次调用（顺序重试即可，无需并发） |
| 证据 | `seen` 是函数局部变量，每次调用新建空集合；`request_id in seen` 恒为 `False`；`seen.add` 结果随函数返回丢弃。`reservations` 表无 `request_id` 唯一约束（`inventory.py:11-13`） |
| 影响 | 违反规则 2（重试必须 `replayed=true` 且只产生一次有效预占）。重试会**再次扣减库存并插入第二条记录**，造成库存与预占记录双重不一致 |
| 待验证点 | 需运行验证：同参数二次调用返回 `replayed=false` 且 `available` 从 8 变 6、`reservations` 出现 2 行 |
| 性质 | **确认事实（代码静态可判定）**；具体数值影响为**风险假设**，待运行确认 |

### F2 — 无冲突检测（同编号不同参数）

| 项 | 内容 |
|---|---|
| 位置 | `inventory.py:22-26`（无任何按 `request_id` 查询既有记录的代码）；`inventory.py:36-38` 无条件 INSERT |
| 触发条件 | 同一 `request_id` 携带不同 `sku` 或 `quantity` |
| 证据 | 全函数无 `SELECT ... FROM reservations WHERE request_id=?`；`contracts/response.json` 声明 `conflict` 状态，但 `inventory.py` 中**从未出现** `"conflict"` 字符串 |
| 影响 | 违反规则 3。不同参数会各自扣库存并各插一条记录，且返回 `reserved` 而非 `conflict` |
| 待验证点 | 需运行验证：`reserve(p,"a",quantity=2)` 后 `reserve(p,"a",quantity=5)` 的返回与库存变化 |
| 性质 | **确认事实**（`conflict` 分支缺失，静态可判定） |

### F3 — 检查与更新非原子，存在超卖竞态

| 项 | 内容 |
|---|---|
| 位置 | `inventory.py:28-34`：`SELECT available` → `time.sleep(0.01)` → `UPDATE inventory SET available=available-?` |
| 触发条件 | 两个不同 `request_id` 并发进入，均读到同一 `available` 值 |
| 证据 | 读与写在**同一连接内但无锁**：`sqlite3` 默认 `isolation_level=""`（隐式事务），`SELECT` 不取写锁，`UPDATE` 才取 `RESERVED` 锁；`sleep(0.01)` 人为放大窗口。`UPDATE` 无 `WHERE available >= ?` 守卫，也无 `BEGIN IMMEDIATE` |
| 影响 | 违反规则 4：可能超卖（`available` 变负或预占总量 > 初始库存）。注意 `timeout=15` 只影响**锁等待**，不提供读一致性 |
| 待验证点 | 需运行验证：N 个线程各预占 2 件、库存 10 时，成功数与 `available` 是否满足 `10 - 2*成功数 == available`。**未做任何并发实测，不声称具体失败率** |
| 性质 | **风险假设（高置信）**——竞态窗口由代码结构决定，但实际是否触发取决于调度，未实测 |

### F4 — `fail_at="after_inventory"` 未回滚（跨事务提交）

| 项 | 内容 |
|---|---|
| 位置 | `inventory.py:28-35`（第一个 `with sqlite3.connect(...)` 块，退出即提交）→ `inventory.py:36-37` `raise RuntimeError` → `inventory.py:38-40`（**第二个独立连接**写预占） |
| 触发条件 | `fail_at="after_inventory"` |
| 证据 | 库存更新与预占插入分属**两个不同的 `sqlite3.connect`**，即两个独立事务。第一个 `with` 块正常退出时已 `COMMIT`，随后抛异常无法撤销已提交的库存扣减 |
| 影响 | 违反规则 8：库存被永久扣减但无预占记录，产生"幽灵扣减"，且异常向上传播。这是**数据一致性缺陷**，非仅测试问题 |
| 待验证点 | 需运行验证：捕获 `RuntimeError` 后检查 `available` 是否已减少、`reservations` 是否为空 |
| 性质 | **确认事实**（事务边界静态可判定：两个连接 = 两个事务） |

### F5 — 库存更新与预占写入不在同一事务（正常路径）

| 项 | 内容 |
|---|---|
| 位置 | 同 F4：`inventory.py:28-34` 与 `inventory.py:38-40` 两个连接 |
| 触发条件 | 正常路径下第二个连接 INSERT 失败（如磁盘满、锁超时、进程崩溃） |
| 证据 | 两段写操作无共同事务；`reservations` 表无 `UNIQUE(request_id)`，也无外键/约束兜底 |
| 影响 | 违反规则 4 后半句"库存与有效预占总量一致"。即使修好 F1/F3，此结构仍留下部分提交窗口 |
| 待验证点 | 需构造 INSERT 失败场景验证；当前未验证 |
| 性质 | **确认事实**（结构层面）；具体触发概率为**风险假设** |

### F6 — 接口：`invalid_request` 响应缺少必需字段（契约歧义）

| 项 | 内容 |
|---|---|
| 位置 | `inventory.py:22-23`、`inventory.py:31-32` 返回 `{"status": "invalid_request"}` |
| 触发条件 | 非法 `request_id`/`quantity`，或未知 `sku` |
| 证据 | `contracts/response.json` 的 `success_required_keys` 只约束**成功**响应；`docs/rules.md` 仅要求"失败响应的 status 必须符合业务分类"，未要求失败响应含五字段。故当前实现**不违反**明文契约 |
| 影响 | 无确认缺陷。但 `insufficient_stock`（`inventory.py:33`）同样只返回 status，若宿主验收对失败响应字段有额外期望，会不一致 |
| 待验证点 | 需人工确认：失败响应是否允许仅含 `status`。**这是契约解释问题，需人决定，不由我判定** |
| 性质 | **风险假设（低）**——按现有明文规则不构成违规 |

### F7 — 接口：`sku` 校验顺序与未知 sku 语义

| 项 | 内容 |
|---|---|
| 位置 | `inventory.py:22`（先校验 request_id/quantity）→ `inventory.py:29-32`（再查 sku） |
| 触发条件 | `sku` 为未知值，或 `sku` 为非字符串（如 `None`、`123`） |
| 证据 | 未知 sku 走 `row is None` → `invalid_request`，符合规则 7。但 `sku` 类型本身**未校验**；非字符串 sku 会作为参数绑定到 SQL（参数化，无注入风险），仅返回 `invalid_request` |
| 影响 | 行为符合规则 7 的明文要求；无注入风险（全部使用参数化查询，`inventory.py:29,34,39`） |
| 待验证点 | 若宿主验收要求"非字符串 sku 必须 invalid_request"，当前实现恰好满足；但若要求区分错误类型，则不足。**需人工确认** |
| 性质 | **风险假设（低）** |

### F8 — `initialize` 使用 `INSERT OR REPLACE`，重复初始化会重置库存但保留预占记录

| 项 | 内容 |
|---|---|
| 位置 | `inventory.py:14` `INSERT OR REPLACE INTO inventory VALUES (?, ?)` |
| 触发条件 | 对同一 `db_path` 重复调用 `initialize` |
| 证据 | `CREATE TABLE IF NOT EXISTS` 保留旧表；`INSERT OR REPLACE` 把 `available` 重置为 `stock`，但 `reservations` 表**不清空** |
| 影响 | 规则未规定重复初始化的语义，故**不构成明文违规**。但会造成"库存已重置、预占记录仍在"的不一致状态，可能干扰测试隔离（若多个用例复用同一路径） |
| 待验证点 | 需人工确认重复初始化是否属于支持场景。当前 `tests/test_smoke.py` 用 `TemporaryDirectory` 隔离，不受影响 |
| 性质 | **风险假设（低）**——超出规则明文范围 |

### F9 — `time.sleep(0.01)` 为教学注入，非性能问题

| 项 | 内容 |
|---|---|
| 位置 | `inventory.py:34` |
| 触发条件 | 每次成功路径调用 |
| 证据 | 注释自述"Simulated I/O exposes the check/update race" |
| 影响 | 仅放大 F3 竞态窗口。**我不做任何性能实测或耗时推断**；移除它不改变 F3 的根因（缺原子性），只缩小窗口 |
| 待验证点 | 无 |
| 性质 | **确认事实**（代码存在）；性能影响**未测量，不作声明** |

---

## 2. 确认事实 vs 风险假设汇总

**确认事实（静态可判定，无需运行）：**
- F1：`seen` 为局部变量，跨调用不保留 → 幂等必然失效
- F2：代码中不存在 `conflict` 分支，也不存在按 `request_id` 的查询
- F4/F5：库存更新与预占插入使用两个独立 `sqlite3.connect`，即两个事务
- 全部 SQL 使用参数化绑定，无 SQL 注入面
- `reservations` 表无 `request_id` 唯一约束

**风险假设（需运行或人工确认）：**
- F3：并发超卖是否实际触发、触发程度（**未实测**）
- F5：INSERT 失败导致部分提交的实际可达性
- F6/F7/F8：契约解释与超范围语义，需人工裁定

**明确未验证：** 所有运行时行为、并发行为、异常路径的实际表现。本报告不含任何性能实测数据。

---

## 3. 建议优先级（仅供参考，由人决定）

| 优先级 | 项 | 理由 |
|---|---|---|
| P0 | F4 | 数据永久不一致（幽灵扣减），且规则 8 明文要求整体回滚 |
| P0 | F1 | 规则 2/5 核心，重试即重复扣库存 |
| P0 | F3 | 规则 4 核心，超卖 |
| P1 | F2 | 规则 3 明文，`conflict` 分支缺失 |
| P1 | F5 | 与 F3/F4 同源，修事务边界时一并解决 |
| P2 | F6/F7/F8 | 契约解释问题，需人工裁定后再定 |

**结构性观察（供人工决策）：** F1/F2/F3/F4/F5 有共同根因——缺少"单事务 + 唯一约束 + 原子条件更新"。若分别打补丁，容易互相冲突；建议人工确认是否采用统一方案（`BEGIN IMMEDIATE` + `UNIQUE(request_id)` + `UPDATE ... WHERE available >= ?` + 单连接单事务）。**是否采纳由人决定，我不擅自实施。**

---

## 4. PR 草稿

> 说明：本次为**只读扫描**，未产生任何代码变更。以下 PR 草稿描述的是"若按建议实施"的框架，**实际修改为空**。

### 目标
消除库存预占在幂等、冲突检测、并发原子性、异常回滚四方面的缺陷，使实现满足 `docs/rules.md` v1 规则 1–8，同时保持函数签名、表名、已有列与返回结构兼容。

### 实际修改
**无。** 本次任务为只读风险扫描，未修改 `inventory.py`，未新增测试文件，未改动任何现有文件。

### 影响范围（若后续实施）
- 仅 `inventory.py`：`reserve` 的事务边界与去重逻辑；`initialize` 可能新增索引/唯一约束
- 可新增 `tests/test_*.py`
- 不改：`tests/test_smoke.py`、`docs/`、`contracts/`、`AGENTS.md`
- 兼容性约束：`reserve(db_path, request_id, sku="sku-1", quantity=2, fail_at=None)` 签名不变；`inventory(sku, available)`、`reservations(id, request_id, sku, quantity)` 列不变；成功响应五字段不变

### 验证证据
**本次无验证证据。** 未运行 `run_tests`，未执行任何代码，未做并发实测。所有结论均为静态代码阅读所得。

### 未验证
- 全部运行时行为（F1–F5 的实际表现）
- 并发超卖的实际触发情况与程度
- 异常注入路径的实际回滚状态
- 失败响应字段的验收期望（F6）
- 重复初始化语义（F8）
- 任何性能特征（未测量，不作声明）

### 重点 Review
1. **事务边界**：库存扣减与预占写入是否合并为单连接单事务；`fail_at` 注入点是否位于事务内且能触发整体回滚（F4/F5）
2. **幂等持久化**：去重依据是否为数据库状态而非内存；是否加 `UNIQUE(request_id)` 或等价约束（F1）
3. **冲突语义**：同编号不同参数是否返回 `conflict` 且不改库存、不新增记录（F2）
4. **并发原子性**：是否使用 `BEGIN IMMEDIATE` 或 `UPDATE ... WHERE available >= ?` 守卫；是否仍存在读-改-写窗口（F3）
5. **契约解释**：失败响应是否允许仅含 `status`——需人工裁定（F6）
6. **不扩大重构**：是否只改必要逻辑，未顺手改动无关代码

---

**需人工确认的关键取舍：** ①是否采用统一事务方案而非逐项打补丁；②失败响应字段要求；③重复初始化是否需支持；④`time.sleep` 是否保留（教学用途 vs 生产代码）。