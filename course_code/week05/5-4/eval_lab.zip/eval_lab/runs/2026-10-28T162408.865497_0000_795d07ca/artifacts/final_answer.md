## 报告

### 实际改动

**`inventory.py`（重写 `reserve`，`initialize` 增加唯一索引）**
- 幂等改为**持久化**：删除每次调用重建的内存 `seen = set()`，改为在 `reservations` 表中按 `request_id` 查询已有记录。
  - 同编号 + 同 sku/quantity → `{"status":"reserved", ..., "replayed": True}`，不再扣库存、不再插记录。
  - 同编号 + 不同 sku 或 quantity → `{"status":"conflict"}`，库存与记录均不变。
- 事务原子性：整个“查重 → 查库存 → 扣减 → 写预占”放在单个 `BEGIN IMMEDIATE` 事务中，异常路径显式 `ROLLBACK`。`fail_at="after_inventory"` 在扣减后、插入前抛 `RuntimeError`，现在会整体回滚（原实现已提交库存）。
- 校验：`request_id` 非空字符串、`quantity` 为正整数且 `type(...) is int`（排除 `bool`）、`sku` 非空字符串；未知 sku 仍返回 `invalid_request`。
- 新增 `UNIQUE INDEX idx_reservations_request_id`（规则允许增加索引），作为数据库层兜底。
- 表结构、列、函数签名、成功/失败响应结构保持不变（成功响应恰好 5 个字段）。

**新增 `tests/test_idempotency.py`**（未改动 `tests/test_smoke.py`、docs、contracts）

### 实际执行的测试

`run_tests`（`python -m unittest discover -s tests -v`），退出码 0，`Ran 9 tests ... OK`：
- `test_smoke.test_normal_reservation`（既有基线）
- `test_same_request_same_params_replays_once`：同编号同参数连续调用 3 次，第 1 次 `replayed=false`，第 2、3 次 `replayed=true`；库存 10→8，预占记录恰好 1 条
- `test_same_request_different_quantity_conflicts` / `test_same_request_different_sku_conflicts`：返回 `conflict`，库存与记录不变
- `test_conflict_does_not_consume_stock_for_later_request`：冲突后其他编号仍可正常预占
- `test_insufficient_stock_has_no_side_effects`：库存不足无副作用，且该编号未被占用可重试
- `test_invalid_requests`：空串/None/非字符串编号、0/负数/`True`/`2.0`/`"2"` 数量、未知 sku 全部 `invalid_request`，库存与记录不变
- `test_fail_at_after_inventory_rolls_back`：抛 `RuntimeError` 后库存仍为 10、无记录；随后同编号重试为全新预占
- `test_idempotency_survives_reconnect`：新连接（等价于新进程）仍识别为 `replayed=true`

### 未验证 / 不声称的内容

- **并发未验证**：规则第 4、5 条（不同编号并发竞争、同编号并发重试）本次未编写并发测试，也未执行。代码使用 `BEGIN IMMEDIATE` + 唯一索引作为设计上的保护，但**没有实测证据**，不能据此声称并发安全或生产可靠。
- 未做多进程/多线程压力测试、性能测试、崩溃恢复测试。
- 未验证 SQLite 在极端锁竞争下的 `busy_timeout` 行为。
- 独立验收由宿主执行，本报告不代替验收结论。