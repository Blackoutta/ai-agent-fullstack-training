"""Single-SKU inventory reservation service (see docs/rules.md, version 1)."""
import sqlite3

_SCHEMA = '''
    CREATE TABLE IF NOT EXISTS inventory(sku TEXT PRIMARY KEY, available INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS reservations(
        id INTEGER PRIMARY KEY AUTOINCREMENT, request_id TEXT NOT NULL,
        sku TEXT NOT NULL, quantity INTEGER NOT NULL);
    CREATE UNIQUE INDEX IF NOT EXISTS idx_reservations_request_id
        ON reservations(request_id);
'''


def initialize(db_path, stock=10):
    with sqlite3.connect(db_path) as db:
        db.executescript(_SCHEMA)
        db.execute("INSERT OR REPLACE INTO inventory VALUES (?, ?)", ("sku-1", stock))


def _connect(db_path):
    db = sqlite3.connect(db_path, timeout=15, isolation_level=None)
    db.execute("PRAGMA busy_timeout=15000")
    return db


def _existing_reservation(db, request_id):
    return db.execute(
        "SELECT sku, quantity FROM reservations WHERE request_id=?", (request_id,)
    ).fetchone()


def _replay(request_id, sku, quantity):
    return {"status": "reserved", "request_id": request_id, "sku": sku,
            "quantity": quantity, "replayed": True}


def reserve(db_path, request_id, sku="sku-1", quantity=2, fail_at=None):
    if (not isinstance(request_id, str) or not request_id
            or type(quantity) is not int or quantity <= 0
            or not isinstance(sku, str) or not sku):
        return {"status": "invalid_request"}

    db = _connect(db_path)
    try:
        # BEGIN IMMEDIATE serialises writers so the idempotency check, the stock
        # check and the writes below are one atomic unit.
        db.execute("BEGIN IMMEDIATE")
        try:
            existing = _existing_reservation(db, request_id)
            if existing is not None:
                db.execute("ROLLBACK")
                if existing[0] == sku and existing[1] == quantity:
                    return _replay(request_id, sku, quantity)
                return {"status": "conflict"}

            row = db.execute(
                "SELECT available FROM inventory WHERE sku=?", (sku,)
            ).fetchone()
            if row is None:
                db.execute("ROLLBACK")
                return {"status": "invalid_request"}
            if row[0] < quantity:
                db.execute("ROLLBACK")
                return {"status": "insufficient_stock"}

            db.execute(
                "UPDATE inventory SET available=available-? WHERE sku=?", (quantity, sku)
            )
            if fail_at == "after_inventory":
                raise RuntimeError("injected_after_inventory")
            db.execute(
                "INSERT INTO reservations(request_id,sku,quantity) VALUES(?,?,?)",
                (request_id, sku, quantity),
            )
            db.execute("COMMIT")
        except BaseException:
            try:
                db.execute("ROLLBACK")
            except sqlite3.Error:
                pass
            raise
    finally:
        db.close()

    return {"status": "reserved", "request_id": request_id, "sku": sku,
            "quantity": quantity, "replayed": False}
