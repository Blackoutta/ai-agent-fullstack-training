"""Idempotency / conflict / atomicity tests for inventory.reserve."""
import sqlite3
import tempfile
import unittest
from pathlib import Path

from inventory import initialize, reserve


def _db_state(path):
    with sqlite3.connect(path) as db:
        available = db.execute(
            "SELECT available FROM inventory WHERE sku='sku-1'").fetchone()[0]
        rows = db.execute(
            "SELECT request_id, sku, quantity FROM reservations ORDER BY id").fetchall()
    return available, rows


class IdempotencyTest(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.path = str(Path(self._tmp.name) / "inventory.db")
        initialize(self.path, 10)

    def tearDown(self):
        self._tmp.cleanup()

    def test_same_request_same_params_replays_once(self):
        first = reserve(self.path, "req-1", quantity=2)
        self.assertEqual(first, {"status": "reserved", "request_id": "req-1",
                                 "sku": "sku-1", "quantity": 2, "replayed": False})
        second = reserve(self.path, "req-1", quantity=2)
        self.assertEqual(second, {"status": "reserved", "request_id": "req-1",
                                  "sku": "sku-1", "quantity": 2, "replayed": True})
        third = reserve(self.path, "req-1", quantity=2)
        self.assertEqual(third, {"status": "reserved", "request_id": "req-1",
                                 "sku": "sku-1", "quantity": 2, "replayed": True})
        available, rows = _db_state(self.path)
        self.assertEqual(available, 8)
        self.assertEqual(rows, [("req-1", "sku-1", 2)])

    def test_same_request_different_quantity_conflicts(self):
        reserve(self.path, "req-2", quantity=2)
        result = reserve(self.path, "req-2", quantity=3)
        self.assertEqual(result, {"status": "conflict"})
        available, rows = _db_state(self.path)
        self.assertEqual(available, 8)
        self.assertEqual(rows, [("req-2", "sku-1", 2)])

    def test_same_request_different_sku_conflicts(self):
        reserve(self.path, "req-3", quantity=2)
        result = reserve(self.path, "req-3", sku="sku-2", quantity=2)
        self.assertEqual(result, {"status": "conflict"})
        available, rows = _db_state(self.path)
        self.assertEqual(available, 8)
        self.assertEqual(rows, [("req-3", "sku-1", 2)])

    def test_conflict_does_not_consume_stock_for_later_request(self):
        reserve(self.path, "req-4", quantity=2)
        self.assertEqual(reserve(self.path, "req-4", quantity=5), {"status": "conflict"})
        other = reserve(self.path, "req-5", quantity=8)
        self.assertEqual(other["status"], "reserved")
        self.assertFalse(other["replayed"])
        available, rows = _db_state(self.path)
        self.assertEqual(available, 0)
        self.assertEqual(rows, [("req-4", "sku-1", 2), ("req-5", "sku-1", 8)])

    def test_insufficient_stock_has_no_side_effects(self):
        reserve(self.path, "req-6", quantity=9)
        self.assertEqual(reserve(self.path, "req-7", quantity=2),
                         {"status": "insufficient_stock"})
        available, rows = _db_state(self.path)
        self.assertEqual(available, 1)
        self.assertEqual(rows, [("req-6", "sku-1", 9)])
        # The rejected request id was never recorded, so it can be retried.
        self.assertEqual(reserve(self.path, "req-7", quantity=1)["status"], "reserved")

    def test_invalid_requests(self):
        cases = [
            ("", 2, "sku-1"),
            (None, 2, "sku-1"),
            (123, 2, "sku-1"),
            ("req-8", 0, "sku-1"),
            ("req-8", -1, "sku-1"),
            ("req-8", True, "sku-1"),
            ("req-8", 2.0, "sku-1"),
            ("req-8", "2", "sku-1"),
            ("req-8", 2, "sku-unknown"),
        ]
        for request_id, quantity, sku in cases:
            with self.subTest(request_id=request_id, quantity=quantity, sku=sku):
                self.assertEqual(
                    reserve(self.path, request_id, sku=sku, quantity=quantity),
                    {"status": "invalid_request"})
        available, rows = _db_state(self.path)
        self.assertEqual(available, 10)
        self.assertEqual(rows, [])

    def test_fail_at_after_inventory_rolls_back(self):
        with self.assertRaises(RuntimeError):
            reserve(self.path, "req-9", quantity=2, fail_at="after_inventory")
        available, rows = _db_state(self.path)
        self.assertEqual(available, 10)
        self.assertEqual(rows, [])
        # The rolled-back request id is free, so a retry is a fresh reservation.
        retry = reserve(self.path, "req-9", quantity=2)
        self.assertEqual(retry, {"status": "reserved", "request_id": "req-9",
                                 "sku": "sku-1", "quantity": 2, "replayed": False})
        available, rows = _db_state(self.path)
        self.assertEqual(available, 8)
        self.assertEqual(rows, [("req-9", "sku-1", 2)])

    def test_idempotency_survives_reconnect(self):
        reserve(self.path, "req-10", quantity=2)
        # A second connection (fresh process equivalent) must still see the record.
        self.assertEqual(reserve(self.path, "req-10", quantity=2)["replayed"], True)
        available, rows = _db_state(self.path)
        self.assertEqual(available, 8)
        self.assertEqual(rows, [("req-10", "sku-1", 2)])


if __name__ == "__main__":
    unittest.main()
