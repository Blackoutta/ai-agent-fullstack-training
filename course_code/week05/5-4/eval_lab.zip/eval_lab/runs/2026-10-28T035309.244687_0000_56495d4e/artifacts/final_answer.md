## 报告

### 实际改动

**`inventory.py`（重写，唯一修改的现有文件）**
- 幂等去重改为**持久化**：以 `reservations.request_id` 为唯一索引（`idx_reservations_request_id`），不再使用每次调用重建的内存 `set`。
- 相同 `request_id` + 相同 `sku`/`quantity` → 返回 `replayed=True` 的成功响应，不再扣库存、不再插入记录。
- 相同 `request_id` + 不同 `sku` 或 `quantity` → 返回 `{"status": "conflict"}`，库存与记录均不变。
- 整个「查重 → 查库存 → 扣减 → 写记录」放在单个 `BEGIN IMMEDIATE` 事务中，异常时 `ROLLBACK`；`fail_at="after_inventory"` 在扣减后、写记录前抛 `RuntimeError`，事务整体回滚（原实现是两次独立连接，扣减已提交）。
- 校验保持：`request_id` 非空字符串、`quantity` 为正整数（`type(...) is int`，排除 `bool`）、未知 sku → `invalid_request`；库存不足 → `insufficient_stock`。
- 成功响应仍恰好是 `status/request_id/sku/quantity/replayed` 五个字段；函数签名、表名、已有列未变（仅新增索引）。

**`tests/test_idempotency.py`（新增）** — 12 个用例，覆盖：正常预占契约、同编号同参数重复调用（3 次，检查响应/库存/有效记录）、同编号不同 quantity、同编号不同 sku、conflict 不消耗库存、不同编号独立、库存不足无副作用、非法输入（含 `bool`/`float`/`str`/`None`/空串）、未知 sku、`fail_at` 回滚后可正常重试、跨连接（新连接）仍识别已存预占。

未修改 `tests/test_smoke.py`、`docs/`、`contracts/`、`AGENTS.md`。

### 实际执行的测试

`run_tests`（`python -m unittest discover -s tests -v`），退出码 0：

```
Ran 13 tests in 0.030s
OK
```

13 = 新增 12 + 原有 smoke 1，全部通过。幂等验证使用的是**相同编号、相同参数**的重复调用（`req-1`/`sku-1`/2 连续 3 次），并断言库存 8、`reservations` 仅 1 行。

### 未验证 / 不声称的内容

- **并发**：未做多线程/多进程竞争测试。`BEGIN IMMEDIATE` 只是设计上的串行化手段，未实测；规则第 4、5 条（并发竞争、同编号并发重试）**未验证**。
- **回滚**：`fail_at` 的顺序回滚有测试覆盖并通过，但未验证崩溃/进程中断等场景。
- 未做生产可靠性、性能或跨进程锁超时行为验证。
- 独立验收由宿主执行，本报告不代替验收结论。