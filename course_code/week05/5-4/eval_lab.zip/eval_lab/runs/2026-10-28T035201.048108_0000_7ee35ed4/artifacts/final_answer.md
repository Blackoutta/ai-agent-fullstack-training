## 报告

### 实际改动

**`inventory.py`（重写 `reserve`，`initialize` 增加唯一索引）**

1. **重复扣减修复**：删除每次调用都重建的内存 `seen = set()`，改为以 `reservations` 表为持久化幂等依据。先按 `request_id` 查询已有记录：
   - 存在且 `sku`/`quantity` 相同 → 返回 `replayed=true`，不再改库存、不再插记录。
   - 存在但参数不同 → 返回 `{"status":"conflict"}`，不改库存、不新增记录。
2. **同编号不同参数**：如上，`conflict` 分支在事务内先 `ROLLBACK` 再返回，因此不会污染后续相同参数的合法重放。
3. **`initialize`**：新增 `CREATE UNIQUE INDEX IF NOT EXISTS idx_reservations_request_id ON reservations(request_id)`（rules.md 允许增加索引），在数据库层兜底唯一性。表名与已有列未变。
4. **事务边界**：改用 `isolation_level=None` + 显式 `BEGIN IMMEDIATE`，把「查重 → 查库存 → 扣减 → 写记录」放在同一事务内；`fail_at="after_inventory"` 在扣减后、写记录前显式 `ROLLBACK` 再抛 `RuntimeError`，不再出现「库存已提交」的泄漏。异常路径统一回滚后重抛。
5. **契约保持**：成功响应仍恰好是 `status/request_id/sku/quantity/replayed` 五字段；失败响应仅 `{"status": ...}`；非法输入（空/非字符串 `request_id`、`bool`/`float`/`str`/非正 `quantity`、未知 sku）仍返回 `invalid_request`；库存不足仍返回 `insufficient_stock` 且无副作用。函数签名未变。

**新增 `tests/test_reservation_idempotency.py`**（12 个用例）：相同参数重复调用（含多次重试、低库存下重放）、不同编号各自预占、同编号不同 quantity/sku 冲突、冲突后合法重放仍可用、非法输入矩阵、库存不足、`fail_at` 回滚及失败后同编号不被误判为重放。

未修改 `tests/test_smoke.py`、`docs/`、`contracts/`、`AGENTS.md`。

### 实际执行的测试

`run_tests`（即 `python -m unittest discover -s tests -v`）：**exit_code 0，Ran 13 tests，OK**（12 个新增 + 1 个原有 smoke）。测试文件指纹已由工具返回。

### 未验证内容（明确声明）

- **并发**：未编写也未运行任何多线程/多进程竞争测试。`BEGIN IMMEDIATE` 的设计意图是串行化写入，但「不同编号并发不超卖」「相同编号并发只产生一次预占」**未经验证**，不能视为已满足。
- **回滚**：`fail_at` 的单线程回滚有测试覆盖并通过；但未验证真实崩溃/断电等场景下的持久化行为。
- 未做性能、多仓库、支付确认、释放等 rules.md 明确排除的能力。
- 独立验收由宿主执行，本报告不代替验收结论。