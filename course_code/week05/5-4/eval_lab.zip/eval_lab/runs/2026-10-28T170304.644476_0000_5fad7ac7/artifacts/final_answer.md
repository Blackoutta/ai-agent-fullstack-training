```json
{
  "scope": {
    "human_confirmed_scope": ["inventory.py 的预占、幂等、事务与接口响应"],
    "high_risks": ["相同请求重复业务效果", "并发超卖", "异常部分提交", "接口不兼容"],
    "out_of_scope": ["支付确认与释放", "多仓库", "生产压测结论"],
    "required_reviews": ["修改了什么", "关键分支在哪里", "旧调用是否兼容"],
    "status": "教学范围；迁移到实际项目时需业务负责人重新确认",
    "basis": "docs/rules.md（版本 1）为唯一业务依据；docs/archive_2024.md 已过期，不作为规则来源",
    "code_under_test": "inventory.py: initialize(db_path, stock=10) / reserve(db_path, request_id, sku='sku-1', quantity=2, fail_at=None)",
    "observed_defects_in_current_code": [
      "reserve 内 seen=set() 每次调用重建，幂等完全失效（规则2/5）",
      "库存检查与 UPDATE 之间无事务/无原子条件更新，存在 check-then-update 竞态（规则4）",
      "库存 UPDATE 与 reservations INSERT 分属两个连接、两次提交，fail_at='after_inventory' 时库存已提交（规则8）",
      "无 request_id 参数冲突检测，缺 conflict 分支（规则3）",
      "reservations 表无 request_id 唯一约束，无法在存储层兜底幂等",
      "quantity 用 type(quantity) is not int 校验，bool 被拒符合规则7，但 sku 未知与非法参数共用 invalid_request 分支需回归确认",
      "成功响应字段顺序/集合需与 contracts/response.json 对齐（规则：恰好 5 字段）"
    ]
  },
  "risk_review": [
    {
      "risk": "相同请求重复业务效果",
      "why": "幂等状态只存在于进程内局部变量，跨调用/跨进程/重启后全部丢失；且无唯一约束兜底",
      "impact": "重复扣减库存、重复预占记录，库存与有效预占总量不一致",
      "test_focus": ["顺序重复提交", "相同 request_id 不同参数", "跨连接/跨进程重复", "并发相同 request_id"],
      "not_collapsible": true
    },
    {
      "risk": "并发超卖",
      "why": "SELECT 与 UPDATE 之间无锁、无原子条件更新，sleep 放大窗口",
      "impact": "成功预占总量 > 初始库存，负库存",
      "test_focus": ["不同 request_id 并发", "并发后库存与记录总量一致性", "不得以全部拒绝规避"],
      "not_collapsible": true
    },
    {
      "risk": "异常部分提交",
      "why": "库存更新与预占写入分两次连接提交，fail_at 注入点在两次提交之间",
      "impact": "库存已扣但无预占记录，账实不符且不可恢复",
      "test_focus": ["fail_at='after_inventory' 回滚", "回滚后库存与记录均不变", "回滚后同 request_id 可正常重试"],
      "not_collapsible": true
    },
    {
      "risk": "接口不兼容",
      "why": "规则要求函数签名、表名/列、返回结构保持兼容；成功响应必须恰好 5 字段",
      "impact": "旧调用方解析失败、字段缺失或多出字段",
      "test_focus": ["成功响应键集合精确相等", "失败响应 status 分类", "签名与表结构不变", "可新增索引但不得改列"],
      "not_collapsible": true
    }
  ],
  "decision_table": {
    "note": "按业务判定维度分组；并发场景以“并发时序”为独立维度单列，不压成静态参数组合。",
    "groups": [
      {
        "group": "G1 参数合法性（规则7）",
        "conditions": ["request_id 为非空 str", "quantity 为正整数且非 bool", "sku 存在于 inventory"],
        "rules": [
          {"id": "G1-R1", "when": "三者均满足", "then": "进入预占主流程（G2/G3/G4）"},
          {"id": "G1-R2", "when": "request_id 为空串/None/非 str", "then": "invalid_request，无任何写入"},
          {"id": "G1-R3", "when": "quantity 为 0/负数/float/str/bool", "then": "invalid_request，无任何写入"},
          {"id": "G1-R4", "when": "sku 不存在", "then": "invalid_request，无任何写入"}
        ]
      },
      {
        "group": "G2 幂等与冲突（规则2、3）",
        "conditions": ["request_id 是否已存在有效预占", "本次 sku/quantity 是否与已存在记录一致"],
        "rules": [
          {"id": "G2-R1", "when": "不存在", "then": "正常预占，replayed=false"},
          {"id": "G2-R2", "when": "存在且参数一致", "then": "reserved + replayed=true，库存与记录均不变"},
          {"id": "G2-R3", "when": "存在且 sku 或 quantity 不同", "then": "conflict，库存与记录均不变"}
        ]
      },
      {
        "group": "G3 库存充足性（规则1、6）",
        "conditions": ["available 与 quantity 关系"],
        "rules": [
          {"id": "G3-R1", "when": "available >= quantity", "then": "reserved，available 减 quantity，新增 1 条记录"},
          {"id": "G3-R2", "when": "available < quantity", "then": "insufficient_stock，无任何写入"},
          {"id": "G3-R3", "when": "available == quantity（边界）", "then": "reserved，available 变为 0"}
        ]
      },
      {
        "group": "G4 事务与异常（规则8）",
        "conditions": ["fail_at 取值", "注入点相对提交的位置"],
        "rules": [
          {"id": "G4-R1", "when": "fail_at=None", "then": "正常提交，不得忽略参数语义"},
          {"id": "G4-R2", "when": "fail_at='after_inventory'", "then": "抛 RuntimeError 且整体回滚：库存与记录均回到调用前"},
          {"id": "G4-R3", "when": "回滚后同 request_id 再次提交", "then": "视为首次，replayed=false，正常预占"}
        ]
      },
      {
        "group": "G5 并发时序（规则4、5）——独立维度，不并入静态组合",
        "conditions": ["并发请求的 request_id 是否相同", "并发请求参数是否相同", "并发总量相对库存"],
        "rules": [
          {"id": "G5-R1", "when": "不同 request_id、总量 <= 库存", "then": "全部 reserved，不得拒绝合法请求"},
          {"id": "G5-R2", "when": "不同 request_id、总量 > 库存", "then": "成功数 * quantity <= 初始库存，其余 insufficient_stock，库存 >= 0 且与有效预占总量一致"},
          {"id": "G5-R3", "when": "相同 request_id、相同参数并发", "then": "恰好 1 条有效预占，replayed=false 恰好 1 次，其余 replayed=true"},
          {"id": "G5-R4", "when": "相同 request_id、不同参数并发", "then": "至多 1 条有效预占，其余 conflict 或 replayed=true，库存只扣一次"}
        ]
      },
      {
        "group": "G6 契约（contracts/response.json）",
        "conditions": ["响应类型", "字段集合", "status 取值"],
        "rules": [
          {"id": "G6-R1", "when": "成功", "then": "键集合恰为 {status, request_id, sku, quantity, replayed}，status='reserved'"},
          {"id": "G6-R2", "when": "失败", "then": "status ∈ {conflict, insufficient_stock, invalid_request}"},
          {"id": "G6-R3", "when": "任意调用", "then": "函数签名、表名、列名不变；可新增索引"}
        ]
      }
    ]
  },
  "cases": [
    {
      "name": "C01 正常预占（规则1）",
      "preconditions": ["initialize(db, 10)", "无既有预占"],
      "actions": ["reserve(db, 'req-1', sku='sku-1', quantity=2)"],
      "expected_response": {"status": "reserved", "request_id": "req-1", "sku": "sku-1", "quantity": 2, "replayed": false},
      "expected_inventory": "sku-1 available = 8",
      "expected_records": "reservations 中 request_id='req-1' 恰好 1 条，quantity=2",
      "risk": "接口不兼容（成功响应键集合）"
    },
    {
      "name": "C02 库存恰好用尽边界（规则1、6）",
      "preconditions": ["initialize(db, 2)"],
      "actions": ["reserve(db, 'req-edge', quantity=2)"],
      "expected_response": {"status": "reserved", "request_id": "req-edge", "sku": "sku-1", "quantity": 2, "replayed": false},
      "expected_inventory": "available = 0",
      "expected_records": "1 条记录",
      "risk": "边界条件（>= 与 > 混淆）"
    },
    {
      "name": "C03 库存不足（规则6）",
      "preconditions": ["initialize(db, 1)"],
      "actions": ["reserve(db, 'req-big', quantity=2)"],
      "expected_response": {"status": "insufficient_stock"},
      "expected_inventory": "available = 1（不变）",
      "expected_records": "0 条记录",
      "risk": "异常路径产生额外业务修改"
    },
    {
      "name": "C04 顺序重复提交相同参数（规则2）",
      "preconditions": ["initialize(db, 10)", "已成功执行 reserve(db,'req-dup',quantity=2)"],
      "actions": ["reserve(db, 'req-dup', sku='sku-1', quantity=2)"],
      "expected_response": {"status": "reserved", "request_id": "req-dup", "sku": "sku-1", "quantity": 2, "replayed": true},
      "expected_inventory": "available = 8（不再扣减）",
      "expected_records": "仍为 1 条记录",
      "risk": "相同请求重复业务效果（高风险）"
    },
    {
      "name": "C05 重复提交跨连接/跨进程（规则2）",
      "preconditions": ["initialize(db, 10)", "进程 A 已成功预占 'req-x' quantity=2", "进程 A 退出"],
      "actions": ["新进程 B 调用 reserve(db, 'req-x', quantity=2)"],
      "expected_response": {"status": "reserved", "request_id": "req-x", "sku": "sku-1", "quantity": 2, "replayed": true},
      "expected_inventory": "available = 8",
      "expected_records": "1 条记录",
      "risk": "相同请求重复业务效果（内存态幂等失效）"
    },
    {
      "name": "C06 相同 request_id 不同 quantity（规则3）",
      "preconditions": ["initialize(db, 10)", "已成功预占 'req-c' quantity=2"],
      "actions": ["reserve(db, 'req-c', sku='sku-1', quantity=5)"],
      "expected_response": {"status": "conflict"},
      "expected_inventory": "available = 8（不变）",
      "expected_records": "仍为 1 条，quantity=2",
      "risk": "参数冲突（高风险）"
    },
    {
      "name": "C07 相同 request_id 不同 sku（规则3）",
      "preconditions": ["initialize(db, 10)", "已成功预占 'req-s' sku='sku-1' quantity=2"],
      "actions": ["reserve(db, 'req-s', sku='sku-2', quantity=2)"],
      "expected_response": {"status": "conflict"},
      "expected_inventory": "sku-1 available = 8（不变）",
      "expected_records": "仍为 1 条记录",
      "risk": "参数冲突（高风险）"
    },
    {
      "name": "C08 非法 request_id（规则7）",
      "preconditions": ["initialize(db, 10)"],
      "actions": ["reserve(db, '')", "reserve(db, None)", "reserve(db, 123)"],
      "expected_response": {"status": "invalid_request"},
      "expected_inventory": "available = 10（不变）",
      "expected_records": "0 条记录",
      "risk": "契约（失败分类）"
    },
    {
      "name": "C09 非法 quantity 含 bool（规则7）",
      "preconditions": ["initialize(db, 10)"],
      "actions": ["reserve(db,'q0',quantity=0)", "reserve(db,'qneg',quantity=-1)", "reserve(db,'qfloat',quantity=2.0)", "reserve(db,'qstr',quantity='2')", "reserve(db,'qbool',quantity=True)"],
      "expected_response": {"status": "invalid_request"},
      "expected_inventory": "available = 10（不变）",
      "expected_records": "0 条记录",
      "risk": "契约（bool 是 int 子类的陷阱）"
    },
    {
      "name": "C10 未知 sku（规则7）",
      "preconditions": ["initialize(db, 10)"],
      "actions": ["reserve(db, 'req-unknown', sku='sku-404', quantity=2)"],
      "expected_response": {"status": "invalid_request"},
      "expected_inventory": "sku-1 available = 10（不变）",
      "expected_records": "0 条记录",
      "risk": "契约（失败分类）"
    },
    {
      "name": "C11 异常注入整体回滚（规则8）",
      "preconditions": ["initialize(db, 10)"],
      "actions": ["reserve(db, 'req-fail', quantity=2, fail_at='after_inventory')"],
      "expected_response": "抛出 RuntimeError（不得返回 reserved，也不得静默忽略 fail_at）",
      "expected_inventory": "available = 10（回滚，未扣减）",
      "expected_records": "0 条记录",
      "risk": "异常部分提交（高风险）"
    },
    {
      "name": "C12 回滚后同 request_id 重试（规则8）",
      "preconditions": ["initialize(db, 10)", "C11 已执行并回滚"],
      "actions": ["reserve(db, 'req-fail', quantity=2)"],
      "expected_response": {"status": "reserved", "request_id": "req-fail", "sku": "sku-1", "quantity": 2, "replayed": false},
      "expected_inventory": "available = 8",
      "expected_records": "1 条记录",
      "risk": "异常部分提交（残留状态导致误判 replayed）"
    },
    {
      "name": "C13 不同 request_id 并发，总量不超库存（规则4）",
      "preconditions": ["initialize(db, 10)", "5 个线程/进程，request_id 各不相同，各 quantity=2"],
      "actions": ["并发调用 reserve"],
      "expected_response": "5 个响应全部 status='reserved'，replayed=false（不得拒绝合法请求）",
      "expected_inventory": "available = 0",
      "expected_records": "5 条记录，quantity 合计 = 10",
      "risk": "并发超卖（高风险，同时校验不得以全拒规避）"
    },
    {
      "name": "C14 不同 request_id 并发，总量超库存（规则4）",
      "preconditions": ["initialize(db, 10)", "10 个线程/进程，request_id 各不相同，各 quantity=2"],
      "actions": ["并发调用 reserve"],
      "expected_response": "成功数 k 满足 k*2 <= 10；其余为 insufficient_stock；无其他 status",
      "expected_inventory": "available = 10 - 2k >= 0",
      "expected_records": "记录数 = k，quantity 合计 = 2k = 10 - available",
      "risk": "并发超卖（高风险）"
    },
    {
      "name": "C15 相同 request_id 相同参数并发（规则5）",
      "preconditions": ["initialize(db, 10)", "8 个线程/进程，request_id 均为 'req-same'，quantity=2"],
      "actions": ["并发调用 reserve"],
      "expected_response": "恰好 1 个 replayed=false，其余 replayed=true，status 均为 reserved",
      "expected_inventory": "available = 8（只扣一次）",
      "expected_records": "恰好 1 条记录",
      "risk": "相同请求重复业务效果（高风险，并发时序）"
    },
    {
      "name": "C16 相同 request_id 不同参数并发（规则3、5）",
      "preconditions": ["initialize(db, 10)", "并发提交 'req-mix' quantity=2 与 'req-mix' quantity=5"],
      "actions": ["并发调用 reserve"],
      "expected_response": "至多 1 个 reserved 且 replayed=false；其余为 conflict 或 replayed=true；不得出现两个不同 quantity 的 reserved",
      "expected_inventory": "available 只按胜出的 quantity 扣减一次（8 或 5）",
      "expected_records": "恰好 1 条记录，quantity 与胜出请求一致",
      "risk": "参数冲突 + 并发（高风险）"
    },
    {
      "name": "C17 成功响应键集合精确契约（contracts/response.json）",
      "preconditions": ["initialize(db, 10)"],
      "actions": ["reserve(db, 'req-contract', quantity=2)", "读取 contracts/response.json 的 success_required_keys"],
      "expected_response": "set(result.keys()) == {'status','request_id','sku','quantity','replayed'}，且 len(result)==5；status ∈ statuses",
      "expected_inventory": "available = 8",
      "expected_records": "1 条记录",
      "risk": "接口不兼容（多字段/少字段）"
    },
    {
      "name": "C18 签名与表结构兼容（规则：调用方式）",
      "preconditions": ["import inventory"],
      "actions": ["inspect.signature(initialize)", "inspect.signature(reserve)", "PRAGMA table_info(inventory)", "PRAGMA table_info(reservations)"],
      "expected_response": "initialize(db_path, stock=10)；reserve(db_path, request_id, sku='sku-1', quantity=2, fail_at=None)；status 取值 ⊆ contracts 的 statuses",
      "expected_inventory": "inventory 列含 sku, available；reservations 列含 id, request_id, sku, quantity（允许新增索引，不得删改列）",
      "expected_records": "既有 test_smoke.py 仍通过",
      "risk": "接口不兼容（旧调用方）"
    },
    {
      "name": "C19 幂等与库存一致性交叉校验（规则2、4）",
      "preconditions": ["initialize(db, 10)", "混合序列：'a' 成功、'a' 重试、'b' 成功、'b' 冲突参数、'c' 库存不足"],
      "actions": ["按序调用 reserve"],
      "expected_response": "依次为 reserved(false)、reserved(true)、reserved(false)、conflict、insufficient_stock",
      "expected_inventory": "available = 10 - qa - qb",
      "expected_records": "记录数 = 2，且 SUM(quantity) == 10 - available",
      "risk": "相同请求重复业务效果 + 账实一致性"
    }
  ],
  "coverage_matrix": [
    {"dimension": "正常", "cases": ["C01", "C02", "C19"], "covered": true},
    {"dimension": "重复（顺序/跨进程）", "cases": ["C04", "C05"], "covered": true},
    {"dimension": "参数冲突", "cases": ["C06", "C07"], "covered": true},
    {"dimension": "不同请求并发", "cases": ["C13", "C14"], "covered": true},
    {"dimension": "相同请求并发", "cases": ["C15", "C16"], "covered": true},
    {"dimension": "异常回滚", "cases": ["C11", "C12"], "covered": true},
    {"dimension": "契约（响应/签名/表结构）", "cases": ["C08", "C09", "C10", "C17", "C18"], "covered": true},
    {"dimension": "库存不足与边界", "cases": ["C02", "C03"], "covered": true},
    {"dimension": "账实一致性（库存 vs 有效预占总量）", "cases": ["C14", "C15", "C16", "C19"], "covered": true},
    {"dimension": "out_of_scope：支付确认/释放", "cases": [], "covered": false, "reason": "人工范围明确排除"},
    {"dimension": "out_of_scope：多仓库", "cases": [], "covered": false, "reason": "人工范围明确排除"},
    {"dimension": "out_of_scope：生产压测结论", "cases": [], "covered": false, "reason": "并发用例只验证正确性不变量，不产出性能结论"}
  ],
  "open_questions": [
    "conflict 响应的字段集合未在 contracts/response.json 中定义：是否只含 status，还是也需 request_id/sku/quantity？需业务负责人确认。",
    "insufficient_stock 与 invalid_request 是否允许携带额外诊断字段（如 available）？当前契约只约束成功响应恰好 5 字段。",
    "同一 request_id 已存在但本次参数非法（如 quantity=0）时，优先级是 invalid_request 还是 conflict？规则未定义判定顺序。",
    "并发相同 request_id 不同参数时，胜出者是否必须为“先到达者”？规则只要求至多一次有效预占，未规定确定性胜出规则。",
    "fail_at 除 'after_inventory' 外的其他取值（如未知字符串）应视为无效参数、忽略还是报错？规则未定义。",
    "fail_at='after_inventory' 时抛出的 RuntimeError 消息文本是否属于契约（是否需保持 'injected_after_inventory'）？",
    "reservations 表是否允许新增 UNIQUE(request_id) 索引？规则写“可以增加索引”，但若历史数据已有重复 request_id，迁移策略未定义。",
    "initialize 使用 INSERT OR REPLACE 会重置库存：对已存在数据库重复调用 initialize 的语义（重置 vs 保留）未在规则中明确。",
    "并发用例的进程/线程模型与超时阈值未规定；本设计只断言不变量，不规定具体并发实现方式。",
    "规则未说明 request_id 的长度/字符集上限，是否需要额外校验。"
  ]
}
```