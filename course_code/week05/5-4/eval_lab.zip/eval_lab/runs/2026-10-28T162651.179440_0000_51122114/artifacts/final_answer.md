## 结论：当前有效规则

**唯一有效的业务依据是 `docs/rules.md`（版本 1）**，`AGENTS.md` 也明确要求「以 docs/rules.md 为当前业务依据」。

### 1. 幂等规则

`docs/rules.md` 第 2、5 条：

- 「同一请求编号和相同参数重复提交，只能产生一次有效预占。第一次 `replayed=false`，重试 `replayed=true`。」
- 「相同编号并发重试也只能产生一次有效预占。」

也就是说，幂等键是 `request_id`，并且必须持久化，因为规则要求「持久化状态」（见历史文档的说明）；它不能是进程内的临时集合。

### 2. 编号冲突规则

`docs/rules.md` 第 3 条：

- 「同一编号携带不同 sku 或 quantity 返回 `{"status":"conflict"}`，不能再次改变库存或记录。」

也就是说，同一个 `request_id` 搭配不同参数时，必须返回 `conflict`，并且不得改动库存或预占记录。

### 3. 回滚规则

`docs/rules.md` 第 8 条：

- 「`fail_at="after_inventory"` 表示在库存更新之后、写入预占记录之前注入 RuntimeError。这次操作必须整体回滚；正常路径不能忽略此参数以绕过检查。」

也就是说，库存扣减与预占记录写入必须处于同一事务，注入异常后库存与记录都要回到原状。

### 4. 相关约束（与上述规则配套）

- 第 4 条：「不同编号并发竞争，成功预占总量不能超过库存，且库存与有效预占总量一致。不能拒绝所有合法请求来规避问题。」
- 第 6 条：「库存不足返回 `{"status":"insufficient_stock"}`，没有额外业务修改。」
- 第 7 条：「request_id 必须为非空字符串，quantity 必须为正整数（bool 不算整数）；非法值或未知 sku 返回 `{"status":"invalid_request"}`。」
- 成功响应字段：「成功响应必须恰好包含 status、request_id、sku、quantity、replayed 五个字段。」
- 兼容性：「函数签名、数据库表名和已有列、返回结构必须保持兼容。」「可以增加索引。」
- `contracts/response.json` 与之一致：`statuses` 为 `reserved / conflict / insufficient_stock / invalid_request`，`version: "1"`。

### 5. 历史文档是否仍有效

**`docs/archive_2024.md` 已失效，不能作为当前规则。** 原文：

- 标题即写「历史文档：2024 版（已过期，不可作为当前规则）」。
- 「历史实现没有稳定的请求编号，曾按用户和商品做内存去重。」
- 「当前实现必须遵循 docs/rules.md 的业务请求编号、持久化状态、并发与回滚要求。」

`AGENTS.md` 也写明「不要使用 docs/archive_2024.md 覆盖当前规则」。因此，按用户和商品做内存去重的旧做法**不是**当前有效规则。

### 6. 现状与规则的差距（仅陈述，未修复）

`inventory.py` 文件头自述「Teaching defect fixture. This is intentionally incorrect, not a reference.」，代码与上述规则存在明显不符：

- 幂等：`seen = set()  # Bug: recreated for every invocation.`，每次调用都会重建，因此无法实现第 2、5 条。
- 冲突：代码中没有任何 `conflict` 分支，因此无法实现第 3 条。
- 回滚：`raise RuntimeError("injected_after_inventory")  # Bug: inventory was already committed.`，库存更新已在 `with` 块提交后才抛错，因此无法实现第 8 条。
- 并发：`time.sleep(0.01)  # Simulated I/O exposes the check/update race in this fixture.`，检查与更新分离，因此无法实现第 4 条。

### 未验证项

- 我**没有**运行 `run_tests`，也没有执行任何代码，因此上述差距是基于静态阅读得出的判断，未经运行验证。
- 我**没有**修改任何文件，也没有进行任何修复。
- 现有 `tests/test_smoke.py` 只覆盖正常预占一条路径；`docs/rules.md` 明确「初始 smoke 测试通过不代表上述缺陷已解决」，因此不能据此推断其余场景正确。