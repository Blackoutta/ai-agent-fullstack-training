"""Single-SKU inventory reservation with persistent idempotency.

Business rules: docs/rules.md (version 1).
"""
import sqlite3

_UNIQUE_INDEX = (
    "CREATE UNIQUE INDEX IF NOT EXISTS idx_reservations_request_id "
    "ON reservations(request_id)"
)


def _connect(db_path):
    return sqlite3.connect(db_path, timeout=15, isolation_level=None)


def initialize(db_path, stock=10):
    with sqlite3.connect(db_path) as db:
        db.executescript('''
            CREATE TABLE IF NOT EXISTS inventory(sku TEXT PRIMARY KEY, available INTEGER NOT NULL);
            CREATE TABLE IF NOT EXISTS reservations(
                id INTEGER PRIMARY KEY AUTOINCREMENT, request_id TEXT NOT NULL,
                sku TEXT NOT NULL, quantity INTEGER NOT NULL);
        ''')
        db.execute(_UNIQUE_INDEX)
        db.execute("INSERT OR REPLACE INTO inventory VALUES (?, ?)", ("sku-1", stock))


def _valid_request(request_id, quantity):
    return (
        isinstance(request_id, str)
        and request_id != ""
        and type(quantity) is int
        and quantity > 0
    )


def _existing_reservation(db, request_id):
    return db.execute(
        "SELECT sku, quantity FROM reservations WHERE request_id=?", (request_id,)
    ).fetchone()


def reserve(db_path, request_id, sku="sku-1", quantity=2, fail_at=None):
    if not _valid_request(request_id, quantity):
        return {"status": "invalid_request"}

    db = _connect(db_path)
    try:
        # BEGIN IMMEDIATE takes the write lock up front so the idempotency check,
        # the stock check and the writes are one atomic unit.
        db.execute("BEGIN IMMEDIATE")
        try:
            existing = _existing_reservation(db, request_id)
            if existing is not None:
                db.execute("ROLLBACK")
                if existing[0] == sku and existing[1] == quantity:
                    return {"status": "reserved", "request_id": request_id,
                            "sku": sku, "quantity": quantity, "replayed": True}
                return {"status": "conflict"}

            row = db.execute(
                "SELECT available FROM inventory WHERE sku=?", (sku,)
            ).fetchone()
            if row is None:
                db.execute("ROLLBACK")
                return {"status": "invalid_request"}
            if row[0] < quantity:
                db.execute("ROLLBACK")
                return {"status": "insufficient_stock"}

            db.execute(
                "UPDATE inventory SET available=available-? WHERE sku=?",
                (quantity, sku),
            )
            if fail_at == "after_inventory":
                raise RuntimeError("injected_after_inventory")
            db.execute(
                "INSERT INTO reservations(request_id,sku,quantity) VALUES(?,?,?)",
                (request_id, sku, quantity),
            )
            db.execute("COMMIT")
        except BaseException:
            try:
                db.execute("ROLLBACK")
            except sqlite3.Error:
                pass
            raise
    finally:
        db.close()

    return {"status": "reserved", "request_id": request_id, "sku": sku,
            "quantity": quantity, "replayed": False}
