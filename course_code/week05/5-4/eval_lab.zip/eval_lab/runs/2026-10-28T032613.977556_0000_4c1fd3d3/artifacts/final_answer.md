12 个测试全部通过（退出码 0）。

## 实际改动

**`inventory.py`（重写）**
- 删除每次调用都重建的 `seen = set()`（这是重复扣减的根因），改为以 `reservations` 表为持久化幂等依据。
- `initialize` 增加 `CREATE UNIQUE INDEX IF NOT EXISTS idx_reservations_request_id ON reservations(request_id)`（规则允许增加索引，表名/列不变）。
- `reserve` 改为单连接、`BEGIN IMMEDIATE` 事务内完成：查已有预占 → 参数比对 → 库存检查 → 扣减 → 写预占 → `COMMIT`。
  - 同编号同参数：返回 `replayed=True`，不再扣减、不再插入。
  - 同编号不同 `sku`/`quantity`：返回 `{"status":"conflict"}`，库存与记录均不变。
  - 库存不足 / 未知 sku / 非法入参：先 `ROLLBACK` 再返回，无副作用。
  - `fail_at="after_inventory"`：在扣减后、插入前抛 `RuntimeError`，异常路径统一 `ROLLBACK`，整体回滚。
- 保留原函数签名、返回字段（成功恰好 5 个字段）与状态分类；移除了 `time.sleep` 模拟延迟。

**新增 `tests/test_reservation.py`**（12 个用例中的 11 个）：正常预占、库存不足、同编号重复调用（2 次/3 次、跨其他请求）、不同 quantity/sku 冲突、冲突不消耗库存、8 种非法入参、未知 sku、`fail_at` 回滚、失败后重试成功。

## 实际执行的验证

- `run_tests`（`python -m unittest discover -s tests -v`）：12 tests，OK，exit_code 0。包含原有 `tests/test_smoke.py` 未修改且通过。
- 未修改 `tests/test_smoke.py`、`docs/`、`contracts/`、`AGENTS.md`。

## 未验证 / 明确说明

- **并发未验证**：规则第 4、5 条（多线程/多进程竞争、同编号并发重试）没有编写或运行并发测试。实现使用 `BEGIN IMMEDIATE` + 唯一索引作为设计上的保障，但**未实测**，不能声称已验证。
- 未做性能、跨进程锁超时、数据库损坏等场景验证。
- 独立验收由宿主执行，本报告不代替验收。