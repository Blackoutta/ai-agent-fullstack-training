```json
{
  "scope": {
    "human_confirmed_scope": [
      "inventory.py 的预占、幂等、事务与接口响应"
    ],
    "in_scope_objects": [
      "inventory.initialize(db_path, stock=10)",
      "inventory.reserve(db_path, request_id, sku='sku-1', quantity=2, fail_at=None)",
      "表 inventory(sku, available) 与 reservations(id, request_id, sku, quantity) 的可见状态",
      "reserve 返回 dict 的字段集合与 status 取值"
    ],
    "out_of_scope": [
      "支付确认与释放",
      "多仓库",
      "生产压测结论"
    ],
    "out_of_scope_notes": [
      "不设计 release/confirm 类用例；不设计多 sku 仓库维度用例（仅保留未知 sku 的 invalid_request 契约用例）",
      "不把并发用例的结论表述为性能或吞吐结论，只验证业务不变量（不超卖、库存与有效预占一致）",
      "docs/archive_2024.md 已过期，不作为规则来源；其“按用户+商品内存去重”不得作为期望行为"
    ],
    "rules_source": "docs/rules.md（版本 1）+ contracts/response.json",
    "status": "教学范围；迁移到实际项目时需业务负责人重新确认"
  },

  "risk_review": {
    "required_reviews": [
      {
        "review": "修改了什么",
        "review_targets": [
          "幂等判定是否改为持久化（reservations 表或唯一约束），而非函数内局部变量",
          "库存扣减与预占记录写入是否在同一事务内（同一连接、同一 commit 边界）",
          "fail_at='after_inventory' 注入点是否位于事务内部，异常是否触发整体回滚",
          "并发控制手段（BEGIN IMMEDIATE / 唯一索引 / 条件 UPDATE ... WHERE available>=?）是否覆盖 check-then-act 窗口",
          "是否新增索引或唯一约束（rules 允许增加索引，需确认是否也允许唯一约束）"
        ]
      },
      {
        "review": "关键分支在哪里",
        "review_targets": [
          "参数校验分支：request_id 非空字符串、quantity 为正整数且 bool 排除、sku 存在性",
          "幂等命中分支：同 request_id 同参数 → replayed=true；同 request_id 不同参数 → conflict",
          "库存不足分支：available < quantity → insufficient_stock，且无任何写入",
          "正常扣减分支：available -= quantity 且插入一条 reservations",
          "异常注入分支：fail_at='after_inventory' → RuntimeError 且库存与记录均回滚",
          "并发分支：不同 request_id 竞争同一 sku；相同 request_id 并发重试"
        ]
      },
      {
        "review": "旧调用是否兼容",
        "review_targets": [
          "函数签名与默认参数（sku='sku-1', quantity=2, fail_at=None）保持不变",
          "表名与已有列名保持不变（可加索引，不可改列语义）",
          "成功响应恰好 5 个字段：status/request_id/sku/quantity/replayed",
          "失败响应 status 取值限定在 reserved/conflict/insufficient_stock/invalid_request",
          "initialize 重复调用与 stock 参数语义保持可用（现有 smoke 用例依赖）"
        ]
      }
    ],
    "high_risks": [
      {
        "risk": "相同请求重复业务效果",
        "current_defect_evidence": "reserve 内 `seen = set()` 每次调用重建，且 `seen.add` 在函数末尾，进程内去重完全失效；reservations 表无 request_id 唯一约束",
        "failure_mode": "重复提交重复扣减库存并插入多条 reservations",
        "detection": "串行重复提交后比对 available 与 reservations 行数；并发重复提交后比对有效预占总量"
      },
      {
        "risk": "并发超卖",
        "current_defect_evidence": "SELECT available 与 UPDATE 之间无事务锁，且存在 time.sleep(0.01) 放大 check-then-act 窗口",
        "failure_mode": "多个不同 request_id 同时通过库存检查，available 变为负数或库存与预占总量不一致",
        "detection": "多线程不同 request_id 并发后校验 available >= 0 且 available + sum(有效预占) == 初始库存"
      },
      {
        "risk": "异常部分提交",
        "current_defect_evidence": "库存 UPDATE 在第一个 with 块内已提交，RuntimeError 在第二个连接插入 reservations 之前抛出",
        "failure_mode": "库存被扣减但无预占记录，形成不可追溯的库存泄漏",
        "detection": "fail_at='after_inventory' 后校验 available 未变且 reservations 无新增"
      },
      {
        "risk": "接口不兼容",
        "current_defect_evidence": "成功响应字段集合需与 contracts/response.json 完全一致；失败响应当前仅返回 status",
        "failure_mode": "字段缺失/多余、status 取值越界、签名或表结构变更导致旧调用方失败",
        "detection": "字段集合精确比对、status 白名单比对、签名与表结构反射检查"
      }
    ],
    "risk_to_case_mapping": {
      "相同请求重复业务效果": ["DT1-R1", "DT1-R2", "DT1-R3", "DT5-S1", "DT5-S2"],
      "并发超卖": ["DT4-D1", "DT4-D2", "DT4-D3", "DT4-D4"],
      "异常部分提交": ["DT6-E1", "DT6-E2", "DT6-E3"],
      "接口不兼容": ["DT7-C1", "DT7-C2", "DT7-C3", "DT7-C4", "DT7-C5"]
    }
  },

  "decision_table": {
    "note": "并发场景不压成静态组合：DT4/DT5 以“时序阶段”描述，每个阶段单独给期望不变量，而非把线程交错写成条件列。",
    "DT1_idempotency_serial": {
      "description": "串行重复提交：request_id 是否已存在 × 参数是否一致",
      "conditions": [
        "C1: request_id 在 reservations 中已存在",
        "C2: 本次 sku 与已存在记录一致",
        "C3: 本次 quantity 与已存在记录一致"
      ],
      "rules": [
        {"rule": "R1", "C1": "否", "C2": "-", "C3": "-", "status": "reserved", "replayed": false, "inventory_effect": "扣减 quantity", "record_effect": "新增 1 条"},
        {"rule": "R2", "C1": "是", "C2": "是", "C3": "是", "status": "reserved", "replayed": true, "inventory_effect": "无", "record_effect": "无新增"},
        {"rule": "R3", "C1": "是", "C2": "否", "C3": "-", "status": "conflict", "replayed": "不适用", "inventory_effect": "无", "record_effect": "无新增"},
        {"rule": "R4", "C1": "是", "C2": "是", "C3": "否", "status": "conflict", "replayed": "不适用", "inventory_effect": "无", "record_effect": "无新增"}
      ]
    },
    "DT2_stock_sufficiency": {
      "description": "库存充足性 × 请求合法性（合法性优先于库存判断）",
      "conditions": [
        "C1: 参数合法（request_id 非空 str、quantity 正整数非 bool、sku 存在）",
        "C2: available >= quantity"
      ],
      "rules": [
        {"rule": "R1", "C1": "否", "C2": "-", "status": "invalid_request", "inventory_effect": "无", "record_effect": "无"},
        {"rule": "R2", "C1": "是", "C2": "是", "status": "reserved", "inventory_effect": "扣减 quantity", "record_effect": "新增 1 条"},
        {"rule": "R3", "C1": "是", "C2": "否", "status": "insufficient_stock", "inventory_effect": "无", "record_effect": "无"}
      ]
    },
    "DT3_parameter_validation": {
      "description": "参数冲突与非法值分类",
      "conditions": [
        "C1: request_id 类型/取值",
        "C2: quantity 类型/取值",
        "C3: sku 是否存在于 inventory"
      ],
      "rules": [
        {"rule": "R1", "C1": "非空 str", "C2": "正整数（非 bool）", "C3": "存在", "status": "reserved 或 insufficient_stock（取决于库存）"},
        {"rule": "R2", "C1": "非空 str", "C2": "正整数（非 bool）", "C3": "不存在", "status": "invalid_request"},
        {"rule": "R3", "C1": "空串 / 非 str / None", "C2": "任意", "C3": "任意", "status": "invalid_request"},
        {"rule": "R4", "C1": "非空 str", "C2": "0 / 负数 / bool / float / str", "C3": "任意", "status": "invalid_request"}
      ]
    },
    "DT4_concurrent_distinct_requests": {
      "description": "不同 request_id 并发竞争同一 sku：按阶段给不变量，不枚举线程交错",
      "phases": [
        {"phase": "P1 竞争前", "invariant": "available == 初始库存，reservations 为空"},
        {"phase": "P2 竞争窗口", "invariant": "库存检查与扣减必须原子；不允许两个请求同时基于同一 available 快照通过检查"},
        {"phase": "P3 竞争后", "invariant": "available >= 0；available + sum(成功预占 quantity) == 初始库存；成功数 + insufficient_stock 数 == 总请求数；无异常逃逸"},
        {"phase": "P4 反规避", "invariant": "当总需求 <= 库存时，全部请求必须成功（不得以拒绝所有请求规避超卖）"}
      ],
      "rules": [
        {"rule": "D1", "scenario": "总需求 <= 库存（如 5 请求 × 2 件，库存 10）", "expected": "全部 reserved，available == 0，5 条记录"},
        {"rule": "D2", "scenario": "总需求 > 库存（如 10 请求 × 2 件，库存 10）", "expected": "恰好 5 个 reserved、5 个 insufficient_stock，available == 0，5 条记录"},
        {"rule": "D3", "scenario": "单请求 quantity > 库存", "expected": "insufficient_stock，available 不变"},
        {"rule": "D4", "scenario": "混合 quantity 并发（1/2/3 件）", "expected": "available >= 0 且 available + sum(成功) == 初始库存"}
      ]
    },
    "DT5_concurrent_same_request": {
      "description": "相同 request_id 并发重试：按阶段给不变量",
      "phases": [
        {"phase": "P1 并发前", "invariant": "reservations 中无该 request_id"},
        {"phase": "P2 并发窗口", "invariant": "同一 request_id 的写入必须互斥或由唯一约束兜底，不得产生两条记录"},
        {"phase": "P3 并发后", "invariant": "reservations 中该 request_id 恰好 1 条；available 只被扣减一次；所有返回中恰好 1 个 replayed=false，其余为 replayed=true 或 conflict（见 open_questions）"}
      ],
      "rules": [
        {"rule": "S1", "scenario": "N 个线程同 request_id 同参数", "expected": "1 条记录，扣减一次，1 个 replayed=false"},
        {"rule": "S2", "scenario": "N 个线程同 request_id 不同 quantity", "expected": "1 条记录，扣减一次，其余 conflict，库存与记录一致"}
      ]
    },
    "DT6_transaction_rollback": {
      "description": "异常注入与回滚",
      "conditions": [
        "C1: fail_at 取值",
        "C2: 注入点相对事务边界的位置"
      ],
      "rules": [
        {"rule": "E1", "C1": "after_inventory", "C2": "事务内、库存更新后、记录写入前", "expected": "抛出 RuntimeError；available 与 reservations 均回到调用前状态"},
        {"rule": "E2", "C1": "after_inventory 且库存不足", "C2": "未进入扣减", "expected": "insufficient_stock（不抛异常），无写入"},
        {"rule": "E3", "C1": "after_inventory 且参数非法", "C2": "未进入事务", "expected": "invalid_request（不抛异常），无写入"},
        {"rule": "E4", "C1": "None", "C2": "不注入", "expected": "正常 reserved，不得忽略 fail_at 参数"}
      ]
    },
    "DT7_contract": {
      "description": "接口契约兼容性",
      "rules": [
        {"rule": "C1", "check": "成功响应键集合 == {status, request_id, sku, quantity, replayed}", "expected": "精确相等，无多余/缺失键"},
        {"rule": "C2", "check": "status ∈ {reserved, conflict, insufficient_stock, invalid_request}", "expected": "无越界取值"},
        {"rule": "C3", "check": "reserve/initialize 签名与默认值不变", "expected": "inspect.signature 与 rules 一致"},
        {"rule": "C4", "check": "表名与列名不变", "expected": "inventory(sku, available)、reservations(id, request_id, sku, quantity) 均存在"},
        {"rule": "C5", "check": "replayed 为 bool 且首次为 False", "expected": "类型与取值正确"}
      ]
    }
  },

  "cases": [
    {
      "name": "DT1-R1 首次预占成功",
      "preconditions": ["initialize(db, 10)", "reservations 为空"],
      "actions": ["reserve(db, 'req-1', quantity=2)"],
      "expected_response": {"status": "reserved", "request_id": "req-1", "sku": "sku-1", "quantity": 2, "replayed": false},
      "expected_inventory": {"available": 8},
      "expected_records": {"reservations_count": 1, "rows": [{"request_id": "req-1", "sku": "sku-1", "quantity": 2}]},
      "risk": "基线；同时是 DT7-C1/C5 的字段与类型校验载体"
    },
    {
      "name": "DT1-R2 同 request_id 同参数重复提交",
      "preconditions": ["initialize(db, 10)", "已成功 reserve(db, 'req-1', quantity=2)"],
      "actions": ["reserve(db, 'req-1', quantity=2)", "reserve(db, 'req-1', quantity=2)"],
      "expected_response": {"status": "reserved", "request_id": "req-1", "sku": "sku-1", "quantity": 2, "replayed": true},
      "expected_inventory": {"available": 8},
      "expected_records": {"reservations_count": 1},
      "risk": "相同请求重复业务效果（当前 seen 集合每次重建，必然失败）"
    },
    {
      "name": "DT1-R3 同 request_id 不同 sku",
      "preconditions": ["initialize(db, 10)", "已成功 reserve(db, 'req-1', sku='sku-1', quantity=2)"],
      "actions": ["reserve(db, 'req-1', sku='sku-2', quantity=2)"],
      "expected_response": {"status": "conflict"},
      "expected_inventory": {"available": 8},
      "expected_records": {"reservations_count": 1, "no_row_with": {"request_id": "req-1", "sku": "sku-2"}},
      "risk": "参数冲突；注意 sku-2 不存在时 invalid_request 与 conflict 的优先级见 open_questions"
    },
    {
      "name": "DT1-R4 同 request_id 不同 quantity",
      "preconditions": ["initialize(db, 10)", "已成功 reserve(db, 'req-1', quantity=2)"],
      "actions": ["reserve(db, 'req-1', quantity=3)"],
      "expected_response": {"status": "conflict"},
      "expected_inventory": {"available": 8},
      "expected_records": {"reservations_count": 1},
      "risk": "参数冲突；不得因新 quantity 更大而二次扣减"
    },
    {
      "name": "DT1-R4b 冲突后原请求仍可重放",
      "preconditions": ["initialize(db, 10)", "已成功 reserve(db, 'req-1', quantity=2)", "已发生一次 conflict 调用"],
      "actions": ["reserve(db, 'req-1', quantity=2)"],
      "expected_response": {"status": "reserved", "request_id": "req-1", "sku": "sku-1", "quantity": 2, "replayed": true},
      "expected_inventory": {"available": 8},
      "expected_records": {"reservations_count": 1},
      "risk": "conflict 不得污染或删除原记录"
    },
    {
      "name": "DT2-R3 库存不足",
      "preconditions": ["initialize(db, 10)", "已成功 reserve(db, 'req-a', quantity=9)"],
      "actions": ["reserve(db, 'req-b', quantity=2)"],
      "expected_response": {"status": "insufficient_stock"},
      "expected_inventory": {"available": 1},
      "expected_records": {"reservations_count": 1, "no_row_with_request_id": "req-b"},
      "risk": "库存不足不得产生额外业务修改"
    },
    {
      "name": "DT2-R3b 恰好等于库存边界",
      "preconditions": ["initialize(db, 10)"],
      "actions": ["reserve(db, 'req-a', quantity=10)"],
      "expected_response": {"status": "reserved", "request_id": "req-a", "sku": "sku-1", "quantity": 10, "replayed": false},
      "expected_inventory": {"available": 0},
      "expected_records": {"reservations_count": 1},
      "risk": "边界条件 available == quantity 必须成功（off-by-one）"
    },
    {
      "name": "DT2-R3c 库存为 0 后再预占",
      "preconditions": ["initialize(db, 10)", "已成功 reserve(db, 'req-a', quantity=10)"],
      "actions": ["reserve(db, 'req-b', quantity=1)"],
      "expected_response": {"status": "insufficient_stock"},
      "expected_inventory": {"available": 0},
      "expected_records": {"reservations_count": 1},
      "risk": "库存归零后不得出现负库存"
    },
    {
      "name": "DT3-R3 request_id 非法值",
      "preconditions": ["initialize(db, 10)"],
      "actions": ["reserve(db, '', quantity=2)", "reserve(db, None, quantity=2)", "reserve(db, 123, quantity=2)"],
      "expected_response": {"status": "invalid_request"},
      "expected_inventory": {"available": 10},
      "expected_records": {"reservations_count": 0},
      "risk": "参数校验；None/非 str 不得触发 TypeError 逃逸"
    },
    {
      "name": "DT3-R4 quantity 非法值（含 bool）",
      "preconditions": ["initialize(db, 10)"],
      "actions": ["reserve(db, 'req-1', quantity=0)", "reserve(db, 'req-1', quantity=-1)", "reserve(db, 'req-1', quantity=True)", "reserve(db, 'req-1', quantity=2.0)", "reserve(db, 'req-1', quantity='2')"],
      "expected_response": {"status": "invalid_request"},
      "expected_inventory": {"available": 10},
      "expected_records": {"reservations_count": 0},
      "risk": "bool 是 int 子类，必须显式排除；float/str 不得被隐式转换"
    },
    {
      "name": "DT3-R2 未知 sku",
      "preconditions": ["initialize(db, 10)"],
      "actions": ["reserve(db, 'req-1', sku='sku-404', quantity=2)"],
      "expected_response": {"status": "invalid_request"},
      "expected_inventory": {"available": 10},
      "expected_records": {"reservations_count": 0},
      "risk": "未知 sku 不得创建 inventory 行或 reservations 行"
    },
    {
      "name": "DT4-D1 不同 request_id 并发，总需求 <= 库存",
      "preconditions": ["initialize(db, 10)", "5 个不同 request_id，各 quantity=2"],
      "actions": ["5 个线程同时调用 reserve（用 barrier 对齐起跑）"],
      "expected_response": {"all_status": "reserved", "all_replayed": false},
      "expected_inventory": {"available": 0},
      "expected_records": {"reservations_count": 5, "sum_quantity": 10},
      "risk": "并发超卖 + 反规避（不得拒绝所有请求）"
    },
    {
      "name": "DT4-D2 不同 request_id 并发，总需求 > 库存",
      "preconditions": ["initialize(db, 10)", "10 个不同 request_id，各 quantity=2"],
      "actions": ["10 个线程同时调用 reserve（barrier 对齐）"],
      "expected_response": {"reserved_count": 5, "insufficient_stock_count": 5, "no_exception": true},
      "expected_inventory": {"available": 0, "available_gte_zero": true},
      "expected_records": {"reservations_count": 5, "sum_quantity": 10, "invariant": "available + sum_quantity == 10"},
      "risk": "并发超卖（当前 sleep 窗口下必然出现负库存或记录数超限）"
    },
    {
      "name": "DT4-D3 并发中单请求 quantity 超库存",
      "preconditions": ["initialize(db, 10)", "请求 A quantity=11，请求 B quantity=1"],
      "actions": ["A、B 并发调用"],
      "expected_response": {"A": "insufficient_stock", "B": "reserved"},
      "expected_inventory": {"available": 9},
      "expected_records": {"reservations_count": 1, "request_ids": ["B"]},
      "risk": "并发超卖；大额请求不得部分扣减"
    },
    {
      "name": "DT4-D4 混合 quantity 并发不变量",
      "preconditions": ["initialize(db, 10)", "6 个不同 request_id，quantity 分别为 1,2,3,1,2,3"],
      "actions": ["6 个线程并发调用"],
      "expected_response": {"statuses_subset_of": ["reserved", "insufficient_stock"], "no_exception": true},
      "expected_inventory": {"available_gte_zero": true, "invariant": "available + sum(成功 quantity) == 10"},
      "expected_records": {"reservations_count": "== 成功请求数", "sum_quantity": "== 10 - available"},
      "risk": "并发超卖；不预设具体成功组合，只校验不变量"
    },
    {
      "name": "DT5-S1 相同 request_id 并发重试（同参数）",
      "preconditions": ["initialize(db, 10)", "5 个线程使用同一 request_id='req-dup'，quantity=2"],
      "actions": ["5 个线程并发调用 reserve（barrier 对齐）"],
      "expected_response": {"replayed_false_count": 1, "other_statuses_subset_of": ["reserved(replayed=true)", "conflict"], "no_exception": true},
      "expected_inventory": {"available": 8},
      "expected_records": {"reservations_count": 1, "sum_quantity": 2},
      "risk": "相同请求重复业务效果（并发路径）；replayed 计数口径见 open_questions"
    },
    {
      "name": "DT5-S2 相同 request_id 并发但 quantity 不同",
      "preconditions": ["initialize(db, 10)", "3 个线程使用同一 request_id='req-dup'，quantity 分别为 2,3,4"],
      "actions": ["3 个线程并发调用"],
      "expected_response": {"reserved_count": 1, "conflict_count": 2},
      "expected_inventory": {"available": "== 10 - 胜出请求的 quantity"},
      "expected_records": {"reservations_count": 1, "quantity": "== 胜出请求的 quantity"},
      "risk": "参数冲突 + 并发；库存与记录必须一致，不得出现两条记录"
    },
    {
      "name": "DT6-E1 异常注入整体回滚",
      "preconditions": ["initialize(db, 10)"],
      "actions": ["reserve(db, 'req-1', quantity=2, fail_at='after_inventory')"],
      "expected_response": {"raises": "RuntimeError"},
      "expected_inventory": {"available": 10},
      "expected_records": {"reservations_count": 0},
      "risk": "异常部分提交（当前库存已提交，必然失败）"
    },
    {
      "name": "DT6-E1b 回滚后同 request_id 可正常预占",
      "preconditions": ["initialize(db, 10)", "已发生一次 fail_at='after_inventory' 的 RuntimeError"],
      "actions": ["reserve(db, 'req-1', quantity=2)"],
      "expected_response": {"status": "reserved", "request_id": "req-1", "sku": "sku-1", "quantity": 2, "replayed": false},
      "expected_inventory": {"available": 8},
      "expected_records": {"reservations_count": 1},
      "risk": "回滚必须彻底，不得残留半成品记录导致误判 replayed=true"
    },
    {
      "name": "DT6-E2 库存不足时注入参数不生效",
      "preconditions": ["initialize(db, 10)", "已成功 reserve(db, 'req-a', quantity=9)"],
      "actions": ["reserve(db, 'req-b', quantity=5, fail_at='after_inventory')"],
      "expected_response": {"status": "insufficient_stock"},
      "expected_inventory": {"available": 1},
      "expected_records": {"reservations_count": 1},
      "risk": "异常注入不得改变业务分类"
    },
    {
      "name": "DT6-E3 参数非法时注入参数不生效",
      "preconditions": ["initialize(db, 10)"],
      "actions": ["reserve(db, '', quantity=2, fail_at='after_inventory')", "reserve(db, 'req-1', quantity=0, fail_at='after_inventory')"],
      "expected_response": {"status": "invalid_request"},
      "expected_inventory": {"available": 10},
      "expected_records": {"reservations_count": 0},
      "risk": "校验先于事务，不得抛 RuntimeError"
    },
    {
      "name": "DT6-E4 fail_at=None 正常路径不被忽略",
      "preconditions": ["initialize(db, 10)"],
      "actions": ["reserve(db, 'req-1', quantity=2, fail_at=None)"],
      "expected_response": {"status": "reserved", "request_id": "req-1", "sku": "sku-1", "quantity": 2, "replayed": false},
      "expected_inventory": {"available": 8},
      "expected_records": {"reservations_count": 1},
      "risk": "防止用“忽略 fail_at”绕过回滚检查"
    },
    {
      "name": "DT7-C1 成功响应键集合精确匹配",
      "preconditions": ["initialize(db, 10)"],
      "actions": ["reserve(db, 'req-1', quantity=2)", "set(result.keys()) 与 contracts/response.json 比对"],
      "expected_response": {"keys": ["status", "request_id", "sku", "quantity", "replayed"], "exact_match": true},
      "expected_inventory": {"available": 8},
      "expected_records": {"reservations_count": 1},
      "risk": "接口不兼容（多余字段同样视为不兼容）"
    },
    {
      "name": "DT7-C2 status 取值白名单",
      "preconditions": ["initialize(db, 10)"],
      "actions": ["分别触发 reserved / conflict / insufficient_stock / invalid_request 四条路径，收集 status"],
      "expected_response": {"statuses_subset_of": ["reserved", "conflict", "insufficient_stock", "invalid_request"]},
      "expected_inventory": {"按各路径分别校验"},
      "expected_records": {"按各路径分别校验"},
      "risk": "接口不兼容（新增 status 会破坏调用方分支）"
    },
    {
      "name": "DT7-C3 函数签名与默认值不变",
      "preconditions": ["import inventory"],
      "actions": ["inspect.signature(inventory.reserve)", "inspect.signature(inventory.initialize)"],
      "expected_response": {"reserve": "(db_path, request_id, sku='sku-1', quantity=2, fail_at=None)", "initialize": "(db_path, stock=10)"},
      "expected_inventory": {"不适用"},
      "expected_records": {"不适用"},
      "risk": "接口不兼容（旧调用方按位置/关键字传参）"
    },
    {
      "name": "DT7-C4 表结构与列名不变",
      "preconditions": ["initialize(db, 10)"],
      "actions": ["PRAGMA table_info(inventory)", "PRAGMA table_info(reservations)"],
      "expected_response": {"inventory_columns": ["sku", "available"], "reservations_columns": ["id", "request_id", "sku", "quantity"]},
      "expected_inventory": {"available": 10},
      "expected_records": {"reservations_count": 0},
      "risk": "接口不兼容（允许加索引，不允许改列语义）"
    },
    {
      "name": "DT7-C5 失败响应结构",
      "preconditions": ["initialize(db, 10)"],
      "actions": ["触发 insufficient_stock / invalid_request / conflict 各一次，检查返回 dict"],
      "expected_response": {"status_present": true, "status_in_whitelist": true, "no_success_only_keys_required": true},
      "expected_inventory": {"按各路径分别校验"},
      "expected_records": {"按各路径分别校验"},
      "risk": "接口不兼容；失败响应是否允许携带额外字段见 open_questions"
    },
    {
      "name": "DT7-C6 initialize 幂等与 stock 参数",
      "preconditions": ["空目录"],
      "actions": ["initialize(db, 10)", "initialize(db, 5)", "reserve(db, 'req-1', quantity=2)"],
      "expected_response": {"status": "reserved", "request_id": "req-1", "sku": "sku-1", "quantity": 2, "replayed": false},
      "expected_inventory": {"available": 3},
      "expected_records": {"reservations_count": 1},
      "risk": "旧调用兼容；重复 initialize 的语义（重置库存 vs 保留记录）见 open_questions"
    }
  ],

  "coverage_matrix": {
    "note": "覆盖矩阵表示“设计上已覆盖”，不代表已执行或已通过。",
    "rows": [
      {"category": "正常", "cases": ["DT1-R1", "DT2-R3b", "DT6-E4", "DT7-C6"], "covered": true},
      {"category": "重复", "cases": ["DT1-R2", "DT1-R4b", "DT5-S1"], "covered": true},
      {"category": "参数冲突", "cases": ["DT1-R3", "DT1-R4", "DT5-S2", "DT3-R2", "DT3-R3", "DT3-R4"], "covered": true},
      {"category": "不同请求并发", "cases": ["DT4-D1", "DT4-D2", "DT4-D3", "DT4-D4"], "covered": true},
      {"category": "相同请求并发", "cases": ["DT5-S1", "DT5-S2"], "covered": true},
      {"category": "异常回滚", "cases": ["DT6-E1", "DT6-E1b", "DT6-E2", "DT6-E3"], "covered": true},
      {"category": "契约", "cases": ["DT7-C1", "DT7-C2", "DT7-C3", "DT7-C4", "DT7-C5", "DT7-C6"], "covered": true}
    ],
    "risk_coverage": [
      {"risk": "相同请求重复业务效果", "cases": ["DT1-R2", "DT1-R4b", "DT5-S1", "DT5-S2"], "covered": true},
      {"risk": "并发超卖", "cases": ["DT4-D1", "DT4-D2", "DT4-D3", "DT4-D4"], "covered": true},
      {"risk": "异常部分提交", "cases": ["DT6-E1", "DT6-E1b", "DT6-E2", "DT6-E3"], "covered": true},
      {"risk": "接口不兼容", "cases": ["DT7-C1", "DT7-C2", "DT7-C3", "DT7-C4", "DT7-C5", "DT7-C6"], "covered": true}
    ],
    "known_gaps": [
      "未设计跨进程并发用例（仅线程级），SQLite 文件锁在跨进程下的行为未覆盖",
      "未设计数据库文件被删除/损坏、磁盘只读等基础设施异常用例",
      "未设计 reservations 表已存在历史脏数据（重复 request_id）时的迁移行为",
      "未设计 fail_at 传入未知字符串值的行为（见 open_questions）",
      "并发用例的线程数与 sleep 时序为教学规模，不构成生产压测结论（out_of_scope）"
    ]
  },

  "open_questions": [
    {
      "id": "Q1",
      "question": "同一 request_id 并发重试时，未抢到写入的线程应返回 reserved(replayed=true) 还是 conflict？",
      "why": "rules 第 5 条只要求“