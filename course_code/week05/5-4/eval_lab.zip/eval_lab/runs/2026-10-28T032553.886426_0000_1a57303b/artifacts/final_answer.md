12 个测试全部通过（exit_code=0）。

## 实际改动

**`inventory.py`（唯一修改的现有文件）**
- 删除每次调用都重建的 `seen = set()` 内存去重，改为在 `reservations` 表中持久化查询 `request_id`。
- 幂等判定：同编号 + 同 sku/quantity → 返回 `replayed=True` 的成功响应，不改库存、不新增记录；同编号 + 不同 sku 或 quantity → `{"status":"conflict"}`，不改库存、不新增记录。
- `initialize` 增加 `CREATE UNIQUE INDEX IF NOT EXISTS idx_reservations_request_id ON reservations(request_id)`（规则允许增加索引），作为持久化幂等的兜底约束。
- 库存检查、扣减、预占写入放入同一 `BEGIN IMMEDIATE` 事务，`fail_at="after_inventory"` 的 `RuntimeError` 在事务内抛出并 `ROLLBACK`，库存与记录整体回滚；正常路径不再忽略该参数。
- 非法输入校验保持并补充：`request_id` 非空字符串、`quantity` 为正整数且 `bool` 不算整数、`sku` 非空字符串；未知 sku 返回 `invalid_request`。
- 成功响应仍恰好包含 `status/request_id/sku/quantity/replayed` 五个字段；失败响应仅含 `status`。

**`tests/test_idempotency.py`（新增）**：11 个用例，覆盖同编号同参数重复调用（含 5 次循环）、同编号不同 quantity/sku 冲突、冲突不消耗库存、成功响应字段集合、库存不足无副作用、8 种非法输入、未知 sku、`fail_at` 回滚、失败后重试成功。

## 实际执行的验证

`run_tests`（`python -m unittest discover -s tests -v`）：12 个测试，全部 OK，退出码 0。其中幂等验证使用相同编号 `req-1` 与相同参数连续调用两次，断言第一次 `replayed=false`、第二次 `replayed=true`、库存 8、有效预占记录仅 1 条。

## 未验证内容

- 并发（多线程/多进程竞争、同编号并发重试）未测试，也未声称已验证；`BEGIN IMMEDIATE` 只是设计上的串行化手段。
- 未做生产可靠性、性能或跨进程锁行为的验证。
- 独立验收由宿主执行，本报告不代替其结论。