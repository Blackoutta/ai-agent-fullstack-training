"""Idempotency and contract tests for inventory.reserve."""
import sqlite3
import tempfile
import unittest
from pathlib import Path

from inventory import initialize, reserve

SUCCESS_KEYS = {"status", "request_id", "sku", "quantity", "replayed"}


class InventoryTestCase(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.path = str(Path(self._tmp.name) / "inventory.db")
        initialize(self.path, 10)

    def available(self, sku="sku-1"):
        with sqlite3.connect(self.path) as db:
            return db.execute("SELECT available FROM inventory WHERE sku=?", (sku,)).fetchone()[0]

    def reservations(self):
        with sqlite3.connect(self.path) as db:
            return db.execute(
                "SELECT request_id, sku, quantity FROM reservations ORDER BY id").fetchall()


class IdempotencyTest(InventoryTestCase):
    def test_same_request_id_same_params_replays_once(self):
        first = reserve(self.path, "req-1", quantity=2)
        second = reserve(self.path, "req-1", quantity=2)

        self.assertEqual(first, {"status": "reserved", "request_id": "req-1",
                                 "sku": "sku-1", "quantity": 2, "replayed": False})
        self.assertEqual(second, {"status": "reserved", "request_id": "req-1",
                                  "sku": "sku-1", "quantity": 2, "replayed": True})
        self.assertEqual(self.available(), 8)
        self.assertEqual(self.reservations(), [("req-1", "sku-1", 2)])

    def test_repeated_calls_do_not_drain_stock(self):
        for _ in range(5):
            reserve(self.path, "req-loop", quantity=3)
        self.assertEqual(self.available(), 7)
        self.assertEqual(len(self.reservations()), 1)

    def test_same_request_id_different_quantity_conflicts(self):
        reserve(self.path, "req-2", quantity=2)
        result = reserve(self.path, "req-2", quantity=3)

        self.assertEqual(result, {"status": "conflict"})
        self.assertEqual(self.available(), 8)
        self.assertEqual(self.reservations(), [("req-2", "sku-1", 2)])

    def test_same_request_id_different_sku_conflicts(self):
        reserve(self.path, "req-3", quantity=2)
        result = reserve(self.path, "req-3", sku="sku-2", quantity=2)

        self.assertEqual(result, {"status": "conflict"})
        self.assertEqual(self.available(), 8)
        self.assertEqual(self.reservations(), [("req-3", "sku-1", 2)])

    def test_conflict_does_not_consume_stock_for_later_requests(self):
        reserve(self.path, "req-4", quantity=2)
        reserve(self.path, "req-4", quantity=5)
        self.assertEqual(reserve(self.path, "req-5", quantity=8)["status"], "reserved")
        self.assertEqual(self.available(), 0)


class ContractTest(InventoryTestCase):
    def test_success_response_has_exact_keys(self):
        result = reserve(self.path, "req-keys", quantity=1)
        self.assertEqual(set(result), SUCCESS_KEYS)

    def test_insufficient_stock_changes_nothing(self):
        result = reserve(self.path, "req-big", quantity=11)
        self.assertEqual(result, {"status": "insufficient_stock"})
        self.assertEqual(self.available(), 10)
        self.assertEqual(self.reservations(), [])

    def test_invalid_inputs(self):
        cases = [
            ("", 2),
            (None, 2),
            (123, 2),
            ("req-x", 0),
            ("req-x", -1),
            ("req-x", 1.5),
            ("req-x", True),
            ("req-x", "2"),
        ]
        for request_id, quantity in cases:
            with self.subTest(request_id=request_id, quantity=quantity):
                self.assertEqual(reserve(self.path, request_id, quantity=quantity),
                                 {"status": "invalid_request"})
        self.assertEqual(self.available(), 10)
        self.assertEqual(self.reservations(), [])

    def test_unknown_sku_is_invalid(self):
        self.assertEqual(reserve(self.path, "req-sku", sku="sku-9", quantity=1),
                         {"status": "invalid_request"})
        self.assertEqual(self.available(), 10)
        self.assertEqual(self.reservations(), [])

    def test_fail_at_after_inventory_rolls_back(self):
        with self.assertRaises(RuntimeError):
            reserve(self.path, "req-fail", quantity=2, fail_at="after_inventory")
        self.assertEqual(self.available(), 10)
        self.assertEqual(self.reservations(), [])

    def test_retry_after_failure_succeeds(self):
        with self.assertRaises(RuntimeError):
            reserve(self.path, "req-fail2", quantity=2, fail_at="after_inventory")
        result = reserve(self.path, "req-fail2", quantity=2)
        self.assertEqual(result["replayed"], False)
        self.assertEqual(self.available(), 8)
        self.assertEqual(self.reservations(), [("req-fail2", "sku-1", 2)])


if __name__ == "__main__":
    unittest.main()
