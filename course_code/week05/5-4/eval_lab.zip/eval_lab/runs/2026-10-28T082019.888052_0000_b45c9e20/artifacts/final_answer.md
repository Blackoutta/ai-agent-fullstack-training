## 实际改动

**`inventory.py`（唯一修改的现有文件）**

1. **幂等改为持久化判定**：删除每次调用重建的内存 `seen = set()`。改为在 `reservations` 表中按 `request_id` 查询已有记录，因此重复调用（含跨进程/跨连接）都能识别。
2. **同编号不同参数 → conflict**：查到已有记录后，若 `sku` 与 `quantity` 均相同返回 `replayed=true` 的成功响应；任一不同返回 `{"status":"conflict"}`，且不修改库存、不新增记录。
3. **单事务原子性**：库存检查、扣减、预占写入放在同一个 `BEGIN IMMEDIATE` 事务内，`fail_at="after_inventory"` 的 `RuntimeError` 在事务内抛出，由 `except` 分支 `ROLLBACK` 后重新抛出，库存与记录整体回滚（原实现库存已提交、记录未写）。
4. **唯一索引**：`initialize` 增加 `CREATE UNIQUE INDEX IF NOT EXISTS idx_reservations_request_id ON reservations(request_id)`（规则允许增加索引），作为幂等的数据库层兜底。
5. **保持契约**：函数签名、表名/列名、成功响应恰好 5 个字段、失败状态分类（`conflict` / `insufficient_stock` / `invalid_request`）均未变；非法输入校验逻辑保持原语义（`bool` 不算整数、`request_id` 非空字符串、未知 sku 返回 `invalid_request`）。

**`tests/test_idempotency.py`（新增）** — 8 个用例，均使用**相同编号 + 相同参数**重复调用，并同时断言响应、`inventory.available` 与 `reservations` 有效记录：
- 同编号同参数两次调用：首次 `replayed=false`、重试 `replayed=true`，库存 10→8，仅 1 条记录
- 同编号连续 5 次调用：仅 1 条记录，库存 7
- 同编号不同 quantity → `conflict`，库存与记录不变
- 同编号不同 sku → `conflict`，库存与记录不变
- 先 `insufficient_stock` 再用同编号成功预占，再重试 → 重试为 `replayed=true`，仅 1 条记录
- 不同编号各自正常预占（`replayed=false`）
- 非法输入（空/None/非字符串 request_id、0、负数、`True`、`1.5`、`"2"`、未知 sku）→ `invalid_request`，库存与记录不变
- `fail_at="after_inventory"` 抛 `RuntimeError` 后库存与记录回滚，随后同编号正常预占 `replayed=false`

## 实际执行的测试

`run_tests`（`python -m unittest discover -s tests -v`），退出码 **0**，`Ran 9 tests ... OK`：
- 新增 `test_idempotency.py` 8 个用例全部通过
- 原有 `test_smoke.py::test_normal_reservation` 通过（未修改该文件）

## 未验证内容（明确声明）

- **并发**：未编写也未运行任何多线程/多进程测试。`BEGIN IMMEDIATE` 串行化写入是设计意图，但规则第 4、5 条（不同编号并发不超卖、同编号并发只产生一次预占）**未经验证**，不能从顺序重试通过推断并发正确。
- **生产可靠性**：未做任何性能、锁等待、`database is locked` 重试或长时间运行验证。
- **回滚的完整覆盖**：仅验证了 `fail_at="after_inventory"` 这一注入点；其他异常路径（如磁盘错误、进程崩溃）未验证。
- 未运行独立验收/评分器（按约束不访问工程外实现）。