## 当前有效规则（唯一依据：`docs/rules.md`）

`AGENTS.md` 明确指定：「以 docs/rules.md 为当前业务依据。不要使用 docs/archive_2024.md 覆盖当前规则。」

### 1. 幂等规则
- `docs/rules.md` 第 2 条：「同一请求编号和相同参数重复提交，只能产生一次有效预占。第一次 `replayed=false`，重试 `replayed=true`。」
- 第 5 条：「相同编号并发重试也只能产生一次有效预占。」
- 幂等键是 **request_id**（不是用户或商品），且状态必须持久化：表结构固定为 `reservations(id, request_id, sku, quantity)`，规则允许「可以增加索引」。
- 成功响应字段固定：「成功响应必须恰好包含 status、request_id、sku、quantity、replayed 五个字段。」

### 2. 编号冲突规则
- `docs/rules.md` 第 3 条：「同一编号携带不同 sku 或 quantity 返回 `{"status":"conflict"}`，不能再次改变库存或记录。」
- 即：同编号 + 同参数 → 幂等重放；同编号 + 不同参数 → conflict，且不得产生副作用。
- 状态取值集合见 `contracts/response.json`：`["reserved", "conflict", "insufficient_stock", "invalid_request"]`，`version: "1"`。

### 3. 回滚规则
- `docs/rules.md` 第 8 条：「`fail_at="after_inventory"` 表示在库存更新之后、写入预占记录之前注入 RuntimeError。这次操作必须整体回滚；正常路径不能忽略此参数以绕过检查。」
- 关联约束：第 4 条要求「库存与有效预占总量一致」，第 6 条要求库存不足时「没有额外业务修改」——都要求库存更新与预占写入处于同一事务边界。

### 4. 其他相关约束
- 第 7 条：`request_id` 非空字符串；`quantity` 为正整数且「bool 不算整数」；非法值或未知 sku → `invalid_request`。
- 兼容性：「函数签名、数据库表名和已有列、返回结构必须保持兼容。」

## 历史文档是否仍有效

**无效。** `docs/archive_2024.md` 标题即写明「历史文档：2024 版（已过期，不可作为当前规则）」，正文称「历史实现没有稳定的请求编号，曾按用户和商品做内存去重」，并要求「当前实现必须遵循 docs/rules.md 的业务请求编号、持久化状态、并发与回滚要求」。因此按用户/商品内存去重的旧做法不能作为当前依据。

## 与当前代码的对照（仅陈述观察，未做任何修改）

`inventory.py` 文件头自述「Teaching defect fixture. This is intentionally incorrect, not a reference.」观察到的与上述规则不符之处：

- 幂等：`seen = set()  # Bug: recreated for every invocation.` —— 去重集合每次调用重建，且未持久化，无法满足第 2、5 条。
- 冲突：代码中不存在 `conflict` 分支，同编号不同参数不会被识别。
- 回滚：`db.execute("UPDATE inventory ...")` 在 `with` 块内提交后，才在块外 `raise RuntimeError`，注释亦写明「Bug: inventory was already committed.」，违反第 8 条。
- 并发：`time.sleep(0.01)` 处注释称「exposes the check/update race」，读-改-写无事务/锁保护，与第 4 条一致性要求存在冲突风险。

## 未验证项与说明

- 本次仅执行了只读操作：`ls`、`read`（AGENTS.md、docs/rules.md、docs/archive_2024.md、inventory.py、contracts/response.json、tests/test_smoke.py）。
- **未运行任何测试**（未执行 `python -m unittest`），因此上述代码问题均为静态阅读结论，未经运行时验证。
- 未修改任何文件，未做任何修复，也不声称已修复。
- 关于并发与回滚的实际行为（如 SQLite 默认隔离级别下的具体表现）证据不足，需实际运行才能确认。