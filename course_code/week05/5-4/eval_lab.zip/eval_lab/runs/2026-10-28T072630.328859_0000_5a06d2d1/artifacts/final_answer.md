## 报告

### 实际改动

**`inventory.py`（重写，唯一修改的现有文件）**

| 缺陷 | 修复 |
|---|---|
| 幂等失效：`seen = set()` 每次调用重建 | 幂等状态改为持久化在 `reservations` 表，按 `request_id` 查询；`initialize` 增加 `UNIQUE INDEX idx_reservations_request_id` |
| 无冲突检测 | 同 `request_id` 但 `sku`/`quantity` 不同 → `{"status":"conflict"}`，不改库存、不写记录 |
| 并发竞争（check-then-update 跨连接） | 单连接 + `BEGIN IMMEDIATE` 先取写锁，读-改-写在同一事务内完成；`busy_timeout=15s` 让并发写序列化而非报错 |
| 异常不回滚：库存更新已提交后才抛错 | 库存更新与预占插入同处一个显式事务；`fail_at="after_inventory"` 在两者之间 `ROLLBACK` 后抛 `RuntimeError`；`except` 分支兜底回滚 |
| 参数校验 | `request_id` 非空 `str`；`quantity` 用 `type(...) is int`（排除 `bool`）且 `> 0`；未知 sku → `invalid_request` |
| 接口兼容 | 签名、表名、列、返回结构不变；成功响应恰好 5 个字段 |

**`tests/test_inventory_rules.py`（新增）** — 14 个用例：正常预占、同编号同参数重复调用（3 次，检查响应/库存/记录）、同编号不同 quantity/sku 冲突、重连后仍幂等、库存不足、恰好用尽、非法 request_id/quantity（含 `True`/`False`/`1.0`/`"2"`）、未知 sku、`fail_at` 回滚、失败后重试成功、12 线程不同编号并发不超卖、8 线程同编号并发只产生一次有效预占。

未修改：`tests/test_smoke.py`、`docs/`、`contracts/`、`AGENTS.md`。

### 实际执行的测试

`run_tests`（`python -m unittest discover -s tests -v`），共执行 2 次：

1. 第 1 次：**失败 1 项** — `test_same_request_id_concurrently_reserves_once` 断言 `1 != 8`。原因是我的测试用 `dict` 按 `request_id` 收集结果，8 个相同编号塌缩成 1 条，属测试缺陷而非实现缺陷。
2. 修正测试收集方式（改为 list + 锁）后第 2 次：**15 tests, OK，exit_code=0**（14 新增 + 1 原有 smoke）。

### 验证结果

- 幂等验证按要求用**相同编号 + 相同参数**重复调用：第 1 次 `replayed=false`，第 2、3 次 `replayed=true`，库存只减一次，`reservations` 只有 1 行。
- 并发用例实际通过，但仅代表本机 8/12 线程、单进程、SQLite 文件锁场景下的顺序/并发重试结果。

### 未验证内容

- 未做多进程、跨机器或高并发压测；不构成生产可靠性结论。
- 未验证 `fail_at` 取其他值时的行为（规则只定义 `"after_inventory"`，实现中其他值按正常路径处理）。
- 未验证数据库文件损坏、磁盘满、锁超时耗尽等异常路径。
- 独立验收由宿主执行，本报告不替代。