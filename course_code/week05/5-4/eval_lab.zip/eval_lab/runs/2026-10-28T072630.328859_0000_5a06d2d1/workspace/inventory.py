"""Single-SKU inventory reservation with idempotent, transactional semantics.

Business rules: docs/rules.md (version 1).
"""
import sqlite3

DEFAULT_SKU = "sku-1"
_BUSY_TIMEOUT = 15.0


def _connect(db_path):
    """Open a connection with a busy timeout so concurrent writers serialize."""
    db = sqlite3.connect(db_path, timeout=_BUSY_TIMEOUT, isolation_level=None)
    db.execute("PRAGMA busy_timeout = %d" % int(_BUSY_TIMEOUT * 1000))
    return db


def initialize(db_path, stock=10):
    with _connect(db_path) as db:
        db.executescript('''
            CREATE TABLE IF NOT EXISTS inventory(sku TEXT PRIMARY KEY, available INTEGER NOT NULL);
            CREATE TABLE IF NOT EXISTS reservations(
                id INTEGER PRIMARY KEY AUTOINCREMENT, request_id TEXT NOT NULL,
                sku TEXT NOT NULL, quantity INTEGER NOT NULL);
            CREATE UNIQUE INDEX IF NOT EXISTS idx_reservations_request_id
                ON reservations(request_id);
        ''')
        db.execute("INSERT OR REPLACE INTO inventory VALUES (?, ?)", (DEFAULT_SKU, stock))


def _valid_request(request_id, quantity):
    if not isinstance(request_id, str) or not request_id:
        return False
    if type(quantity) is not int or quantity <= 0:
        return False
    return True


def _success(request_id, sku, quantity, replayed):
    return {"status": "reserved", "request_id": request_id, "sku": sku,
            "quantity": quantity, "replayed": replayed}


def reserve(db_path, request_id, sku=DEFAULT_SKU, quantity=2, fail_at=None):
    if not _valid_request(request_id, quantity):
        return {"status": "invalid_request"}

    db = _connect(db_path)
    try:
        # BEGIN IMMEDIATE takes the write lock up front, so the
        # check-then-update sequence cannot interleave with another writer.
        db.execute("BEGIN IMMEDIATE")

        existing = db.execute(
            "SELECT sku, quantity FROM reservations WHERE request_id=?",
            (request_id,)).fetchone()
        if existing is not None:
            db.execute("ROLLBACK")
            if existing[0] == sku and existing[1] == quantity:
                return _success(request_id, sku, quantity, True)
            return {"status": "conflict"}

        row = db.execute("SELECT available FROM inventory WHERE sku=?", (sku,)).fetchone()
        if row is None:
            db.execute("ROLLBACK")
            return {"status": "invalid_request"}
        if row[0] < quantity:
            db.execute("ROLLBACK")
            return {"status": "insufficient_stock"}

        db.execute("UPDATE inventory SET available=available-? WHERE sku=?", (quantity, sku))

        if fail_at == "after_inventory":
            # Injected failure between the stock update and the reservation
            # insert: the whole transaction must roll back.
            db.execute("ROLLBACK")
            raise RuntimeError("injected_after_inventory")

        db.execute("INSERT INTO reservations(request_id,sku,quantity) VALUES(?,?,?)",
                   (request_id, sku, quantity))
        db.execute("COMMIT")
        return _success(request_id, sku, quantity, False)
    except Exception:
        try:
            db.execute("ROLLBACK")
        except sqlite3.Error:
            pass
        raise
    finally:
        db.close()
