"""Behavioral tests for docs/rules.md (version 1)."""
import sqlite3
import tempfile
import threading
import unittest
from pathlib import Path

from inventory import initialize, reserve

SUCCESS_KEYS = {"status", "request_id", "sku", "quantity", "replayed"}


def _db_path(directory):
    return str(Path(directory) / "inventory.db")


def _available(path, sku="sku-1"):
    with sqlite3.connect(path) as db:
        row = db.execute("SELECT available FROM inventory WHERE sku=?", (sku,)).fetchone()
    return None if row is None else row[0]


def _reservations(path):
    with sqlite3.connect(path) as db:
        return db.execute(
            "SELECT request_id, sku, quantity FROM reservations ORDER BY id").fetchall()


class NormalReservationTest(unittest.TestCase):
    def test_normal_reservation_updates_stock_and_records_once(self):
        with tempfile.TemporaryDirectory() as directory:
            path = _db_path(directory)
            initialize(path, 10)
            result = reserve(path, "req-1", quantity=2)
            self.assertEqual(result, {"status": "reserved", "request_id": "req-1",
                                      "sku": "sku-1", "quantity": 2, "replayed": False})
            self.assertEqual(set(result), SUCCESS_KEYS)
            self.assertEqual(_available(path), 8)
            self.assertEqual(_reservations(path), [("req-1", "sku-1", 2)])


class IdempotencyTest(unittest.TestCase):
    def test_same_request_id_and_params_replays_without_side_effects(self):
        with tempfile.TemporaryDirectory() as directory:
            path = _db_path(directory)
            initialize(path, 10)
            first = reserve(path, "dup-1", quantity=3)
            second = reserve(path, "dup-1", quantity=3)
            third = reserve(path, "dup-1", quantity=3)

            self.assertFalse(first["replayed"])
            self.assertTrue(second["replayed"])
            self.assertTrue(third["replayed"])
            self.assertEqual(set(second), SUCCESS_KEYS)
            self.assertEqual(second["request_id"], "dup-1")
            self.assertEqual(second["sku"], "sku-1")
            self.assertEqual(second["quantity"], 3)
            self.assertEqual(_available(path), 7)
            self.assertEqual(_reservations(path), [("dup-1", "sku-1", 3)])

    def test_same_request_id_different_quantity_conflicts(self):
        with tempfile.TemporaryDirectory() as directory:
            path = _db_path(directory)
            initialize(path, 10)
            reserve(path, "dup-2", quantity=2)
            result = reserve(path, "dup-2", quantity=5)
            self.assertEqual(result, {"status": "conflict"})
            self.assertEqual(_available(path), 8)
            self.assertEqual(_reservations(path), [("dup-2", "sku-1", 2)])

    def test_same_request_id_different_sku_conflicts(self):
        with tempfile.TemporaryDirectory() as directory:
            path = _db_path(directory)
            initialize(path, 10)
            reserve(path, "dup-3", quantity=2)
            result = reserve(path, "dup-3", sku="sku-2", quantity=2)
            self.assertEqual(result, {"status": "conflict"})
            self.assertEqual(_available(path), 8)
            self.assertEqual(_reservations(path), [("dup-3", "sku-1", 2)])

    def test_idempotency_survives_reconnect(self):
        with tempfile.TemporaryDirectory() as directory:
            path = _db_path(directory)
            initialize(path, 10)
            reserve(path, "dup-4", quantity=1)
            # A fresh call (new connection) must still see the stored request.
            result = reserve(path, "dup-4", quantity=1)
            self.assertTrue(result["replayed"])
            self.assertEqual(_available(path), 9)
            self.assertEqual(len(_reservations(path)), 1)


class InsufficientStockTest(unittest.TestCase):
    def test_insufficient_stock_leaves_state_untouched(self):
        with tempfile.TemporaryDirectory() as directory:
            path = _db_path(directory)
            initialize(path, 3)
            result = reserve(path, "big", quantity=4)
            self.assertEqual(result, {"status": "insufficient_stock"})
            self.assertEqual(_available(path), 3)
            self.assertEqual(_reservations(path), [])

    def test_exact_stock_is_allowed_then_exhausted(self):
        with tempfile.TemporaryDirectory() as directory:
            path = _db_path(directory)
            initialize(path, 2)
            self.assertEqual(reserve(path, "exact", quantity=2)["status"], "reserved")
            self.assertEqual(_available(path), 0)
            self.assertEqual(reserve(path, "more", quantity=1)["status"], "insufficient_stock")
            self.assertEqual(_available(path), 0)


class ValidationTest(unittest.TestCase):
    def test_invalid_request_ids(self):
        with tempfile.TemporaryDirectory() as directory:
            path = _db_path(directory)
            initialize(path, 10)
            for bad in ("", None, 123, b"bytes", ["x"]):
                with self.subTest(request_id=bad):
                    self.assertEqual(reserve(path, bad, quantity=1),
                                     {"status": "invalid_request"})
            self.assertEqual(_available(path), 10)
            self.assertEqual(_reservations(path), [])

    def test_invalid_quantities(self):
        with tempfile.TemporaryDirectory() as directory:
            path = _db_path(directory)
            initialize(path, 10)
            for bad in (0, -1, 1.0, True, False, "2", None):
                with self.subTest(quantity=bad):
                    self.assertEqual(reserve(path, "q", quantity=bad),
                                     {"status": "invalid_request"})
            self.assertEqual(_available(path), 10)
            self.assertEqual(_reservations(path), [])

    def test_unknown_sku_is_invalid_request(self):
        with tempfile.TemporaryDirectory() as directory:
            path = _db_path(directory)
            initialize(path, 10)
            self.assertEqual(reserve(path, "sku-x", sku="sku-9", quantity=1),
                             {"status": "invalid_request"})
            self.assertEqual(_available(path), 10)
            self.assertEqual(_reservations(path), [])


class RollbackTest(unittest.TestCase):
    def test_fail_at_after_inventory_rolls_back_everything(self):
        with tempfile.TemporaryDirectory() as directory:
            path = _db_path(directory)
            initialize(path, 10)
            with self.assertRaises(RuntimeError):
                reserve(path, "boom", quantity=4, fail_at="after_inventory")
            self.assertEqual(_available(path), 10)
            self.assertEqual(_reservations(path), [])

    def test_retry_after_injected_failure_succeeds(self):
        with tempfile.TemporaryDirectory() as directory:
            path = _db_path(directory)
            initialize(path, 10)
            with self.assertRaises(RuntimeError):
                reserve(path, "boom-2", quantity=4, fail_at="after_inventory")
            result = reserve(path, "boom-2", quantity=4)
            self.assertEqual(result["status"], "reserved")
            self.assertFalse(result["replayed"])
            self.assertEqual(_available(path), 6)
            self.assertEqual(_reservations(path), [("boom-2", "sku-1", 4)])


class ConcurrencyTest(unittest.TestCase):
    def _run_threads(self, path, requests):
        results = []
        errors = []
        lock = threading.Lock()
        barrier = threading.Barrier(len(requests))

        def worker(request_id, quantity):
            try:
                barrier.wait()
                result = reserve(path, request_id, quantity=quantity)
                with lock:
                    results.append(result)
            except BaseException as exc:  # pragma: no cover - surfaced below
                with lock:
                    errors.append(exc)

        threads = [threading.Thread(target=worker, args=req) for req in requests]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join()
        return results, errors

    def test_distinct_request_ids_never_oversell(self):
        with tempfile.TemporaryDirectory() as directory:
            path = _db_path(directory)
            initialize(path, 10)
            requests = [("c-%d" % i, 2) for i in range(12)]
            results, errors = self._run_threads(path, requests)
            self.assertEqual(errors, [])

            reserved = [r for r in results if r["status"] == "reserved"]
            rejected = [r for r in results if r["status"] == "insufficient_stock"]
            self.assertEqual(len(reserved) + len(rejected), 12)
            total = sum(r["quantity"] for r in reserved)
            self.assertLessEqual(total, 10)
            self.assertGreater(len(reserved), 0, "must not reject every valid request")
            self.assertEqual(_available(path), 10 - total)

            rows = _reservations(path)
            self.assertEqual(len(rows), len(reserved))
            self.assertEqual(sum(q for _, _, q in rows), total)

    def test_same_request_id_concurrently_reserves_once(self):
        with tempfile.TemporaryDirectory() as directory:
            path = _db_path(directory)
            initialize(path, 10)
            requests = [("same", 3) for _ in range(8)]
            results, errors = self._run_threads(path, requests)
            self.assertEqual(errors, [])

            statuses = [r["status"] for r in results]
            self.assertEqual(statuses.count("reserved"), 8)
            replayed = [r["replayed"] for r in results]
            self.assertEqual(replayed.count(False), 1)
            self.assertEqual(replayed.count(True), 7)
            self.assertEqual(_available(path), 7)
            self.assertEqual(_reservations(path), [("same", "sku-1", 3)])


if __name__ == "__main__":
    unittest.main()
