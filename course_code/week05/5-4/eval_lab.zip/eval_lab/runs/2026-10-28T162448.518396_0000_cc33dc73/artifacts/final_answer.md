## 报告

### 实际改动

**`inventory.py`（重写 `reserve`，`initialize` 增加唯一索引）**
- 幂等状态改为持久化：以 `reservations.request_id` 为唯一键（新增 `CREATE UNIQUE INDEX IF NOT EXISTS idx_reservations_request_id`），不再使用每次调用重建的内存 `set`。
- 重复调用逻辑：先按 `request_id` 查已有预占记录；`sku` 与 `quantity` 都相同 → 返回 `replayed=True` 的成功响应，不改库存、不新增记录；任一不同 → 返回 `{"status":"conflict"}`，不改库存、不新增记录。
- 事务化：`BEGIN IMMEDIATE` 后在同一事务内完成「幂等查询 → 库存检查 → 扣减 → 写预占」，异常路径统一 `ROLLBACK` 后重新抛出，因此 `fail_at="after_inventory"` 的 RuntimeError 会整体回滚（原实现库存已提交、记录未写）。
- 保留原有契约：函数签名、表名与列不变；成功响应恰好 5 个字段；`invalid_request`（含非字符串/空 `request_id`、`bool`/非 `int`/非正 `quantity`、未知 sku）、`insufficient_stock` 分类不变。

**新增 `tests/test_idempotency.py`**（未修改 `tests/test_smoke.py`、docs、contracts）

### 实际执行的验证

执行 `run_tests`（`python -m unittest discover -s tests -v`），退出码 0，`Ran 10 tests ... OK`：

- `test_same_request_same_params_is_replayed_once`：**相同编号 + 相同参数连续调用 3 次**，第 1 次 `replayed=False`，第 2、3 次 `replayed=True`；库存 10→8 只扣一次，`reservations` 仅 1 条 `("req-1","sku-1",2)`。
- `test_same_request_different_quantity_conflicts` / `test_same_request_different_sku_conflicts`：同编号不同参数返回 `{"status":"conflict"}`，库存与记录均未变化。
- `test_normal_reservation_state`：正常预占库存 8、1 条记录、`replayed=False`。
- `test_different_requests_both_apply`：不同编号各自生效（库存 5，2 条记录）。
- `test_insufficient_stock_does_not_record`：`insufficient_stock`，无副作用。
- `test_invalid_requests`：空串/None/整数 id、quantity 为 0/-1/1.5/True/"2"、未知 sku 均返回 `invalid_request`，无副作用。
- `test_fail_at_after_inventory_rolls_back`：注入 RuntimeError 后库存仍为 10、无记录；随后同编号正常请求可成功且 `replayed=False`。
- `test_replay_survives_new_connection`：重新 `initialize` 后同编号重试仍判定为重放（证明状态持久化，非进程内内存）。
- `test_normal_reservation`（原有 smoke）：通过。

### 未验证 / 不声称的内容

- **并发未验证**：未编写也未运行多线程/多进程竞争测试。`BEGIN IMMEDIATE` + `busy_timeout` 的设计意图是串行化，但「并发下不超卖、同编号并发只产生一次预占」**没有实测证据**，不能据此声称规则 4、5 已满足。
- **回滚仅覆盖 `fail_at="after_inventory"` 这一注入点**；其他异常路径（如磁盘错误、进程崩溃）未测试。
- 未做性能、多仓库、支付确认/释放相关验证（不在本实验范围）。
- 独立验收由宿主执行，本报告不替代它。