"""Single-SKU inventory reservation with persistent idempotency.

Business rules: docs/rules.md (version 1).
"""
import sqlite3
import time

DEFAULT_SKU = "sku-1"


def _connect(db_path):
    db = sqlite3.connect(db_path, timeout=15, isolation_level=None)
    db.execute("PRAGMA busy_timeout=15000")
    return db


def initialize(db_path, stock=10):
    with _connect(db_path) as db:
        db.executescript('''
            CREATE TABLE IF NOT EXISTS inventory(sku TEXT PRIMARY KEY, available INTEGER NOT NULL);
            CREATE TABLE IF NOT EXISTS reservations(
                id INTEGER PRIMARY KEY AUTOINCREMENT, request_id TEXT NOT NULL,
                sku TEXT NOT NULL, quantity INTEGER NOT NULL);
            CREATE UNIQUE INDEX IF NOT EXISTS idx_reservations_request_id
                ON reservations(request_id);
        ''')
        db.execute("INSERT OR REPLACE INTO inventory VALUES (?, ?)", (DEFAULT_SKU, stock))


def _success(request_id, sku, quantity, replayed):
    return {"status": "reserved", "request_id": request_id, "sku": sku,
            "quantity": quantity, "replayed": replayed}


def _is_valid_request(request_id, quantity):
    return (isinstance(request_id, str) and bool(request_id)
            and type(quantity) is int and quantity > 0)


def reserve(db_path, request_id, sku=DEFAULT_SKU, quantity=2, fail_at=None):
    if not _is_valid_request(request_id, quantity):
        return {"status": "invalid_request"}

    db = _connect(db_path)
    try:
        # BEGIN IMMEDIATE takes the write lock up front so the idempotency
        # lookup, stock check and writes happen in one serialized transaction.
        db.execute("BEGIN IMMEDIATE")
        try:
            existing = db.execute(
                "SELECT sku, quantity FROM reservations WHERE request_id=?",
                (request_id,)).fetchone()
            if existing is not None:
                db.execute("ROLLBACK")
                if existing[0] == sku and existing[1] == quantity:
                    return _success(request_id, sku, quantity, True)
                return {"status": "conflict"}

            row = db.execute("SELECT available FROM inventory WHERE sku=?", (sku,)).fetchone()
            if row is None:
                db.execute("ROLLBACK")
                return {"status": "invalid_request"}
            if row[0] < quantity:
                db.execute("ROLLBACK")
                return {"status": "insufficient_stock"}

            time.sleep(0.01)  # Simulated I/O; kept inside the transaction on purpose.
            db.execute("UPDATE inventory SET available=available-? WHERE sku=?",
                       (quantity, sku))
            if fail_at == "after_inventory":
                raise RuntimeError("injected_after_inventory")
            db.execute("INSERT INTO reservations(request_id,sku,quantity) VALUES(?,?,?)",
                       (request_id, sku, quantity))
            db.execute("COMMIT")
        except BaseException:
            try:
                db.execute("ROLLBACK")
            except sqlite3.Error:
                pass
            raise
    finally:
        db.close()

    return _success(request_id, sku, quantity, False)
