"""Tests for idempotent reservation, conflict detection and contract shape."""
import tempfile
import unittest
from pathlib import Path

from inventory import initialize, reserve

SUCCESS_KEYS = {"status", "request_id", "sku", "quantity", "replayed"}


class ReservationTestCase(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.path = str(Path(self._tmp.name) / "inventory.db")
        initialize(self.path, 10)

    def available(self, sku="sku-1"):
        import sqlite3

        with sqlite3.connect(self.path) as db:
            return db.execute(
                "SELECT available FROM inventory WHERE sku=?", (sku,)
            ).fetchone()[0]

    def reservations(self):
        import sqlite3

        with sqlite3.connect(self.path) as db:
            return db.execute(
                "SELECT request_id, sku, quantity FROM reservations ORDER BY id"
            ).fetchall()


class NormalReservationTest(ReservationTestCase):
    def test_normal_reservation(self):
        result = reserve(self.path, "req-1", quantity=2)
        self.assertEqual(
            result,
            {
                "status": "reserved",
                "request_id": "req-1",
                "sku": "sku-1",
                "quantity": 2,
                "replayed": False,
            },
        )
        self.assertEqual(set(result), SUCCESS_KEYS)
        self.assertEqual(self.available(), 8)
        self.assertEqual(self.reservations(), [("req-1", "sku-1", 2)])

    def test_distinct_request_ids_both_apply(self):
        first = reserve(self.path, "req-a", quantity=2)
        second = reserve(self.path, "req-b", quantity=3)
        self.assertFalse(first["replayed"])
        self.assertFalse(second["replayed"])
        self.assertEqual(self.available(), 5)
        self.assertEqual(len(self.reservations()), 2)


class IdempotencyTest(ReservationTestCase):
    def test_same_request_id_same_params_replays(self):
        first = reserve(self.path, "dup-1", quantity=2)
        second = reserve(self.path, "dup-1", quantity=2)
        third = reserve(self.path, "dup-1", quantity=2)

        self.assertEqual(first["status"], "reserved")
        self.assertFalse(first["replayed"])
        for replay in (second, third):
            self.assertEqual(
                replay,
                {
                    "status": "reserved",
                    "request_id": "dup-1",
                    "sku": "sku-1",
                    "quantity": 2,
                    "replayed": True,
                },
            )
            self.assertEqual(set(replay), SUCCESS_KEYS)

        self.assertEqual(self.available(), 8)
        self.assertEqual(self.reservations(), [("dup-1", "sku-1", 2)])

    def test_replay_does_not_consume_stock_after_other_reservations(self):
        reserve(self.path, "dup-2", quantity=2)
        reserve(self.path, "other", quantity=4)
        replay = reserve(self.path, "dup-2", quantity=2)
        self.assertTrue(replay["replayed"])
        self.assertEqual(self.available(), 4)
        self.assertEqual(len(self.reservations()), 2)

    def test_replay_succeeds_even_when_stock_would_be_insufficient(self):
        reserve(self.path, "dup-3", quantity=8)
        replay = reserve(self.path, "dup-3", quantity=8)
        self.assertEqual(replay["status"], "reserved")
        self.assertTrue(replay["replayed"])
        self.assertEqual(self.available(), 2)
        self.assertEqual(len(self.reservations()), 1)


class ConflictTest(ReservationTestCase):
    def test_same_request_id_different_quantity_conflicts(self):
        reserve(self.path, "conf-1", quantity=2)
        result = reserve(self.path, "conf-1", quantity=3)
        self.assertEqual(result, {"status": "conflict"})
        self.assertEqual(self.available(), 8)
        self.assertEqual(self.reservations(), [("conf-1", "sku-1", 2)])

    def test_same_request_id_different_sku_conflicts(self):
        reserve(self.path, "conf-2", quantity=2)
        result = reserve(self.path, "conf-2", sku="sku-2", quantity=2)
        self.assertEqual(result, {"status": "conflict"})
        self.assertEqual(self.available(), 8)
        self.assertEqual(self.reservations(), [("conf-2", "sku-1", 2)])

    def test_conflict_is_stable_on_repeat(self):
        reserve(self.path, "conf-3", quantity=2)
        self.assertEqual(reserve(self.path, "conf-3", quantity=5), {"status": "conflict"})
        self.assertEqual(reserve(self.path, "conf-3", quantity=5), {"status": "conflict"})
        self.assertEqual(self.available(), 8)
        self.assertEqual(len(self.reservations()), 1)


class InvalidRequestTest(ReservationTestCase):
    def test_invalid_request_ids(self):
        for bad in ("", None, 123, b"bytes", ["list"]):
            with self.subTest(request_id=bad):
                self.assertEqual(
                    reserve(self.path, bad, quantity=1), {"status": "invalid_request"}
                )
        self.assertEqual(self.available(), 10)
        self.assertEqual(self.reservations(), [])

    def test_invalid_quantities(self):
        for bad in (0, -1, 1.5, "2", True, False, None):
            with self.subTest(quantity=bad):
                self.assertEqual(
                    reserve(self.path, "inv-q", quantity=bad),
                    {"status": "invalid_request"},
                )
        self.assertEqual(self.available(), 10)
        self.assertEqual(self.reservations(), [])

    def test_unknown_sku(self):
        self.assertEqual(
            reserve(self.path, "inv-sku", sku="sku-404", quantity=1),
            {"status": "invalid_request"},
        )
        self.assertEqual(self.available(), 10)
        self.assertEqual(self.reservations(), [])


class InsufficientStockTest(ReservationTestCase):
    def test_insufficient_stock(self):
        self.assertEqual(
            reserve(self.path, "big", quantity=11), {"status": "insufficient_stock"}
        )
        self.assertEqual(self.available(), 10)
        self.assertEqual(self.reservations(), [])

    def test_insufficient_stock_does_not_block_later_valid_request(self):
        reserve(self.path, "big-2", quantity=9)
        self.assertEqual(
            reserve(self.path, "big-3", quantity=5), {"status": "insufficient_stock"}
        )
        ok = reserve(self.path, "small", quantity=1)
        self.assertEqual(ok["status"], "reserved")
        self.assertEqual(self.available(), 0)
        self.assertEqual(len(self.reservations()), 2)


class FailAtTest(ReservationTestCase):
    def test_fail_at_after_inventory_rolls_back(self):
        with self.assertRaises(RuntimeError):
            reserve(self.path, "boom", quantity=2, fail_at="after_inventory")
        self.assertEqual(self.available(), 10)
        self.assertEqual(self.reservations(), [])

    def test_retry_after_injected_failure_succeeds_once(self):
        with self.assertRaises(RuntimeError):
            reserve(self.path, "boom-2", quantity=2, fail_at="after_inventory")
        result = reserve(self.path, "boom-2", quantity=2)
        self.assertEqual(result["status"], "reserved")
        self.assertFalse(result["replayed"])
        self.assertEqual(self.available(), 8)
        self.assertEqual(self.reservations(), [("boom-2", "sku-1", 2)])


if __name__ == "__main__":
    unittest.main()
