## 报告

### 实际改动

**`inventory.py`（唯一修改的现有文件）**

1. **幂等修复**：删除每次调用都重建的 `seen = set()`（原缺陷根因），改为以持久化的 `reservations` 表作为幂等依据。`initialize` 增加 `UNIQUE INDEX idx_reservations_request_id`（rules.md 允许增加索引）。
2. **同编号不同参数**：先按 `request_id` 查已有记录；sku 与 quantity 都相同 → 返回 `replayed=True` 的成功响应；任一不同 → `{"status":"conflict"}`，不改库存、不新增记录。
3. **原子性**：改用 `isolation_level=None` + 显式 `BEGIN IMMEDIATE`，把「查重 → 查库存 → 扣减 → 写预占」放进同一事务，`COMMIT` 一次提交。原实现是两次独立连接、库存先提交。
4. **`fail_at="after_inventory"`**：在库存 UPDATE 之后、INSERT 之前 `ROLLBACK` 再抛 `RuntimeError`，库存与记录整体回滚（原实现库存已提交）。
5. **契约保持**：函数签名、表名/列名、成功响应恰好 5 个字段、失败 status 分类均未变；`invalid_request` 校验（非空 str、`type(quantity) is int` 且 >0、未知 sku）逻辑保留并集中到 `_valid_request`。

**`tests/test_reservation_idempotency.py`（新增）**：16 个用例中的 15 个，覆盖正常预占、不同编号各自生效、**相同编号相同参数重复调用 3 次**（校验响应、库存 8、仅 1 条记录）、重放不消耗库存、重放不受库存不足影响、同编号不同 quantity/sku 冲突且可重复稳定、非法 request_id/quantity（含 `True`/`False`）、未知 sku、库存不足、`fail_at` 回滚及失败后重试。

未修改：`tests/test_smoke.py`、`docs/*`、`contracts/*`、`AGENTS.md`。

### 实际执行的测试

`run_tests`（`python -m unittest discover -s tests -v`），exit_code = 0，`Ran 16 tests ... OK`，耗时 0.247s。包含原有 smoke 测试 1 个 + 新增 15 个。测试文件指纹已由工具返回，改动后未再修改代码。

### 已验证

- 相同编号 + 相同参数重复调用：第 1 次 `replayed=false`，第 2、3 次 `replayed=true`，库存只扣一次，`reservations` 只有 1 条。
- 相同编号 + 不同 sku/quantity：返回 `conflict`，库存与记录不变。
- 正常预占、非法输入、库存不足、`fail_at` 回滚：均按 rules.md 行为通过。
- 成功响应字段集合恰为 5 个。

### 未验证 / 明确不声称

- **并发**（rules.md 第 4、5 条）：代码使用 `BEGIN IMMEDIATE` 与唯一索引作为设计手段，但**没有编写或运行任何多线程/多进程并发测试**，因此并发正确性未经验证。
- **生产可靠性、性能、跨进程崩溃恢复**：未验证。
- 独立验收由宿主执行，本报告不代替验收结论。