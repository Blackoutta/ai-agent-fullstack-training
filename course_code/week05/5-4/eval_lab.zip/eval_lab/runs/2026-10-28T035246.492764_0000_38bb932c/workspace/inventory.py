"""Single-SKU inventory reservation with persistent idempotency.

Business contract: docs/rules.md (version 1).
"""
import sqlite3

DEFAULT_SKU = "sku-1"


def _connect(db_path):
    return sqlite3.connect(db_path, timeout=15, isolation_level=None)


def initialize(db_path, stock=10):
    with _connect(db_path) as db:
        db.executescript('''
            CREATE TABLE IF NOT EXISTS inventory(sku TEXT PRIMARY KEY, available INTEGER NOT NULL);
            CREATE TABLE IF NOT EXISTS reservations(
                id INTEGER PRIMARY KEY AUTOINCREMENT, request_id TEXT NOT NULL,
                sku TEXT NOT NULL, quantity INTEGER NOT NULL);
            CREATE UNIQUE INDEX IF NOT EXISTS idx_reservations_request_id
                ON reservations(request_id);
        ''')
        db.execute("INSERT OR REPLACE INTO inventory VALUES (?, ?)", (DEFAULT_SKU, stock))


def _invalid():
    return {"status": "invalid_request"}


def _reserved(request_id, sku, quantity, replayed):
    return {"status": "reserved", "request_id": request_id, "sku": sku,
            "quantity": quantity, "replayed": replayed}


def reserve(db_path, request_id, sku=DEFAULT_SKU, quantity=2, fail_at=None):
    if not isinstance(request_id, str) or not request_id:
        return _invalid()
    if type(quantity) is not int or quantity <= 0:
        return _invalid()
    if not isinstance(sku, str) or not sku:
        return _invalid()

    db = _connect(db_path)
    try:
        # BEGIN IMMEDIATE takes the write lock up front so the read-check-write
        # sequence below cannot interleave with a competing reservation.
        db.execute("BEGIN IMMEDIATE")

        # Idempotency is checked before sku validation so that a retry with a
        # different sku is reported as a conflict, not as an invalid request.
        existing = db.execute(
            "SELECT sku, quantity FROM reservations WHERE request_id=?", (request_id,)
        ).fetchone()
        if existing is not None:
            db.execute("ROLLBACK")
            if existing[0] == sku and existing[1] == quantity:
                return _reserved(request_id, sku, quantity, True)
            return {"status": "conflict"}

        row = db.execute("SELECT available FROM inventory WHERE sku=?", (sku,)).fetchone()
        if row is None:
            db.execute("ROLLBACK")
            return _invalid()

        if row[0] < quantity:
            db.execute("ROLLBACK")
            return {"status": "insufficient_stock"}

        db.execute("UPDATE inventory SET available=available-? WHERE sku=?", (quantity, sku))
        if fail_at == "after_inventory":
            raise RuntimeError("injected_after_inventory")
        db.execute("INSERT INTO reservations(request_id,sku,quantity) VALUES(?,?,?)",
                   (request_id, sku, quantity))
        db.execute("COMMIT")
        return _reserved(request_id, sku, quantity, False)
    except BaseException:
        # Any failure (including the injected one) rolls the whole operation back.
        try:
            db.execute("ROLLBACK")
        except sqlite3.Error:
            pass
        raise
    finally:
        db.close()
