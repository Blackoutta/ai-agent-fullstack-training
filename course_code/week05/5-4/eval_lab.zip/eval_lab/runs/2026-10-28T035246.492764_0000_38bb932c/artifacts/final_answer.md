## 报告

### 实际改动

**`inventory.py`（重写 `reserve`，`initialize` 增加唯一索引）**
- 幂等状态改为持久化：去掉了每次调用都重建的内存 `seen` 集合，改为查询 `reservations` 表中该 `request_id` 的已有记录。
- 相同 `request_id` 且 `sku`、`quantity` 相同 → 返回 `replayed=True`，不再扣库存、不再写记录。
- 相同 `request_id` 但 `sku` 或 `quantity` 不同 → 返回 `{"status": "conflict"}`，库存与记录不变。
- 幂等检查放在 sku 存在性校验之前，因此“同编号换 sku”返回 `conflict` 而不是 `invalid_request`（这是首轮测试失败后修正的点）。
- 库存检查、扣减、写预占记录合并进单个 `BEGIN IMMEDIATE` 事务；任何异常（含 `fail_at="after_inventory"` 注入的 `RuntimeError`）统一 `ROLLBACK` 后重新抛出，不再出现“库存已提交但记录未写”。
- `initialize` 增加 `UNIQUE INDEX idx_reservations_request_id`（规则允许增加索引），作为数据库层的兜底约束。
- 保留原有函数签名、表名/列、成功响应五字段与失败 status 分类；`fail_at` 参数保留且正常路径不忽略。

**新增 `tests/test_reservation.py`**（15 个用例中的 14 个，另 1 个为原 smoke）：正常预占与响应字段精确性、重复调用重放、多次重试仍单条记录、跨连接重放、同编号不同 quantity/sku 冲突、不同编号各自生效、库存不足、非法 request_id、非法 quantity（含 `True`/`False`/`1.5`/`"2"`）、未知 sku、`fail_at` 回滚、注入失败后重试成功。

未修改 `tests/test_smoke.py`、`docs/`、`contracts/`、`AGENTS.md`。

### 实际执行的测试
`run_tests`（`python -m unittest discover -s tests -v`）执行两次：
1. 第一次：15 个用例，1 个失败（`test_same_request_different_sku_conflicts`，返回 `invalid_request` 而非 `conflict`）。
2. 修正检查顺序后第二次：15 个用例全部通过，exit_code=0，耗时 0.035s。

### 未验证内容（明确声明）
- **并发**（规则 4、5）：代码使用了 `BEGIN IMMEDIATE` 与唯一索引，但**没有编写或运行任何多线程/多进程并发测试**，因此并发正确性未经验证，不能声称已满足。
- **回滚**：仅验证了 `fail_at="after_inventory"` 这一注入路径的回滚；其他异常路径（如磁盘错误、进程崩溃）未测试。
- 未做性能、跨进程锁竞争、数据库损坏等场景验证。
- 独立验收由宿主执行，本报告不代替验收结论。