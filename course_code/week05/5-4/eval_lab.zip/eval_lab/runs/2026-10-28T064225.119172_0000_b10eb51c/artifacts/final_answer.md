# 提交前预审报告（只读，未修改任何文件）

## 0. 执行范围与限制（先声明）

**实际执行的操作**：读取 `AGENTS.md`、`docs/rules.md`、`docs/archive_2024.md`、`contracts/response.json`、`inventory.py`、`tests/test_smoke.py`。

**未执行的操作**：
- 未运行 `run_tests`（本会话无该工具可用，且任务要求只读预审）。
- 未运行任何并发/复现脚本。
- 因此**本报告不含任何实测结论**，全部为静态代码阅读得出的候选风险。凡涉及"会发生"的表述均为**风险假设**，需人工或后续实测确认。

**Diff 状态**：确认事实——当前工作区为初始缺陷工程，`inventory.py` 无任何变更（文件头自述 "intentionally incorrect"）。故本报告不构成"变更审查"，而是**基线缺陷清单 + 修复方案预审**。

---

## 1. 确认事实（代码可直接读出，无需运行）

### F1 幂等去重完全失效
- **位置**：`inventory.py:20` `seen = set()  # Bug: recreated for every invocation.`；`inventory.py:21-23` 的 `if request_id in seen` 分支。
- **触发条件**：任何重复提交（顺序重试或并发重试）。
- **证据**：`seen` 是函数局部变量，每次调用重建；`seen.add` 在 `inventory.py:36` 只影响本次调用的对象，跨调用不可见。数据库 `reservations` 表虽有 `request_id` 列，但**无唯一约束**，且查询路径从不读取该表。
- **影响**：规则 2（重放返回 `replayed=true`）与规则 5（并发同号只生效一次）必然不满足；重复提交会重复扣减库存并插入多条记录。
- **待验证点**：需实测确认重复提交后 `available` 与 `reservations` 行数。

### F2 无冲突检测（规则 3 未实现）
- **位置**：`inventory.py:19-37` 全函数。
- **触发条件**：同一 `request_id` 携带不同 `sku` 或 `quantity`。
- **证据**：代码中不存在任何 `conflict` 字符串或分支；`contracts/response.json` 声明 `conflict` 为合法状态，但实现从未返回。
- **影响**：规则 3 必然不满足；同号不同参数会被当作新请求再次扣库存。
- **待验证点**：确认修复后 `conflict` 分支不产生任何写操作。

### F3 事务边界错误：库存更新与预占记录不在同一事务
- **位置**：`inventory.py:24-31`（第一个 `with sqlite3.connect(...)` 块，含 `UPDATE`）与 `inventory.py:32-35`（第二个 `with` 块，含 `INSERT`）。
- **触发条件**：任意两次写之间发生异常或进程中断。
- **证据**：两个独立 `sqlite3.connect` 上下文；第一个 `with` 退出时提交 `UPDATE`，第二个 `with` 才插入记录。
- **影响**：库存与预占记录可能不一致（规则 4 的"库存与有效预占总量一致"不满足）。
- **待验证点**：确认 `sqlite3` 连接上下文管理器在无异常时提交、异常时回滚的语义（Python 标准库行为，但需以实测确认本环境版本行为）。

### F4 `fail_at="after_inventory"` 不回滚
- **位置**：`inventory.py:32-33` `raise RuntimeError(...)`，注释自述 "Bug: inventory was already committed."
- **触发条件**：`fail_at="after_inventory"`。
- **证据**：`raise` 发生在第一个 `with` 块**之后**，此时 `UPDATE` 已提交；异常抛出时无任何回滚路径。
- **影响**：规则 8 必然不满足——库存被扣减但无预占记录，且异常向外传播（是否应传播需按规则确认：规则只说"整体回滚"，未明确异常是否必须抛出，属**待人工确认的契约歧义**）。

### F5 并发竞态：check-then-update 非原子
- **位置**：`inventory.py:25-31`（`SELECT available` → `time.sleep(0.01)` → `UPDATE ... available=available-?`）。
- **触发条件**：不同 `request_id` 并发。
- **证据**：读与写分离，`UPDATE` 无 `WHERE available >= ?` 守卫；默认 SQLite 事务为 deferred，`SELECT` 不加写锁。`time.sleep(0.01)` 人为放大窗口。
- **影响**：规则 4 可能被违反（超卖 / 库存为负）。**这是风险假设**，需并发实测确认；静态阅读只能说明窗口存在。
- **待验证点**：并发 N 个请求后校验 `available >= 0` 且 `available + SUM(quantity) == 初始库存`。

### F6 参数校验不完整
- **位置**：`inventory.py:19`。
- **证据**：`type(quantity) is not int` 已正确排除 `bool`（`type(True) is bool`，非 `int`），符合规则 7；`request_id` 非空字符串校验存在。但 `sku` 未做类型校验，仅靠 `inventory.py:26-27` 的 `row is None` 兜底。
- **影响**：`sku` 为非字符串（如 `None`、`123`）时走 `row is None` → 返回 `invalid_request`，结果**可能**符合规则 7；但 `sku` 为不可哈希/异常类型时 `db.execute` 可能抛 `sqlite3.InterfaceError` 而非返回 `invalid_request`。**风险假设**，需实测。
- **另**：`quantity` 为 `True` 时 `type(True) is not int` 为 `True`，故被拒——符合规则 7，属确认事实。

### F7 成功响应字段
- **位置**：`inventory.py:22-23`、`inventory.py:37-38`。
- **证据**：两处成功返回均恰好含 `status/request_id/sku/quantity/replayed` 五键，与 `contracts/response.json` 一致。
- **影响**：规则"成功响应必须恰好包含五个字段"在**当前可达路径**上满足。注意 `inventory.py:22-23` 的重放分支实际不可达（见 F1），修复时须保留该字段结构。

### F8 表结构与签名兼容
- **位置**：`inventory.py:7-16`、`inventory.py:18`。
- **证据**：`inventory(sku, available)`、`reservations(id, request_id, sku, quantity)` 与规则一致；`initialize(db_path, stock=10)`、`reserve(db_path, request_id, sku="sku-1", quantity=2, fail_at=None)` 签名一致。
- **影响**：确认事实——签名与表名/列名兼容，修复时不得改动。规则允许**增加索引**（如 `reservations(request_id)` 唯一索引），这是修复 F1/F2 的合规手段。

### F9 `initialize` 的 `INSERT OR REPLACE` 语义
- **位置**：`inventory.py:16`。
- **证据**：`INSERT OR REPLACE INTO inventory VALUES (?, ?)` 会重置 `available`，但**不清空 `reservations`**。
- **影响**：若在同一 `db_path` 上重复 `initialize`，库存被重置而历史预占记录保留，导致"库存 + 预占总量"不自洽。规则未明确 `initialize` 是否需清空预占表，属**待人工确认的契约歧义**；测试若复用同一路径可能产生假阴性/假阳性。

---

## 2. 风险假设（需实测或人工确认，不可当作结论）

| 编号 | 假设 | 为何未确认 |
|---|---|---|
| A1 | 并发下会超卖（F5） | 未运行并发测试；SQLite 锁行为与 `timeout=15` 的重试语义需实测 |
| A2 | 非字符串 `sku` 可能抛 `sqlite3.InterfaceError` 而非返回 `invalid_request`（F6） | 未实测 |
| A3 | `fail_at` 异常是否应向外传播（F4） | 规则 8 只要求"整体回滚"，未规定异常传播与否 |
| A4 | `initialize` 是否应清空 `reservations`（F9） | 规则未规定 |
| A5 | 并发同号重试在唯一索引下会抛 `IntegrityError`，需转为 `replayed=true` 而非报错 | 需实测确认捕获路径 |
| A6 | `time.sleep(0.01)` 是否应保留 | 规则未提及；保留会拖慢测试，删除会改变"缺陷可复现性"，属人工取舍 |

---

## 3. 修复方案预审（建议，非决定）

**建议优先级（由人决定）**：
1. **P0** F3+F4：合并为单一事务，`fail_at` 注入点置于事务内、`INSERT` 之前，异常触发回滚。
2. **P0** F1+F2：以 `reservations.request_id` 唯一索引 + 事务内先查后写实现幂等与冲突判定；`IntegrityError` 映射为 `replayed=true`（需先比对参数，不同则 `conflict`）。
3. **P0** F5：`UPDATE inventory SET available=available-? WHERE sku=? AND available>=?`，以 `rowcount==0` 判定 `insufficient_stock`，消除 check-then-update 窗口。
4. **P1** F6：显式校验 `sku` 为字符串（或至少捕获 `sqlite3.InterfaceError` 映射为 `invalid_request`）。
5. **P2** F9/A3/A4/A6：需人工确认契约后再动，**不建议**在未确认前修改。

**约束提醒**：只改 `inventory.py`，可新增 `tests/test_*.py`；不得改 `test_smoke.py`、`docs`、`contracts`、`AGENTS.md`。`docs/archive_2024.md` 明确过期，其"内存去重"思路**不得**作为修复依据。

---

## 4. PR 草稿

### 目标
使 `inventory.py` 满足 `docs/rules.md` v1 的 8 条行为要求，重点为幂等、冲突检测、事务原子性与并发安全；保持函数签名、表名/列名、返回结构兼容。

### 实际修改
**无。** 本次为只读预审，未修改任何文件，未新增测试。上文第 3 节为**建议方案**，尚未实施。

### 影响范围
- 若按建议实施：仅 `inventory.py`（`reserve` 函数体、`initialize` 可能新增索引），以及新增 `tests/test_*.py`。
- 对外接口（签名、表结构、响应字段）保持不变。
- 不涉及支付确认、释放、多仓库（规则明确排除）。

### 验证证据
**无实测证据。** 未运行 `run_tests`，未运行并发脚本，未复现任何缺陷。本报告全部结论来自静态阅读。

### 未验证
- 规则 1–8 全部条目均**未实测**。
- 并发超卖（A1）、`sku` 类型异常（A2）、`fail_at` 异常传播（A3）、`initialize` 重置语义（A4）、唯一索引下并发重试的异常映射（A5）均未验证。
- 未确认 `sqlite3` 上下文管理器在本环境 Python 版本下的提交/回滚语义。

### 重点 Review
1. **事务边界**：库存扣减与预占插入必须在同一事务内，`fail_at` 注入点必须在事务内且早于 `INSERT`。
2. **幂等与冲突的判定顺序**：先按 `request_id` 查已有记录 → 参数一致则 `replayed=true`、不一致则 `conflict`；唯一索引作为并发兜底，`IntegrityError` 需回查后分类，不能直接抛给调用方。
3. **并发扣减**：`UPDATE ... WHERE available >= ?` + `rowcount` 判定，禁止先 `SELECT` 再 `UPDATE`。
4. **契约歧义需人工拍板**：`fail_at` 异常是否向外传播（A3）、`initialize` 是否清空 `reservations`（A4）、`time.sleep(0.01)` 去留（A6）。
5. **测试不得只覆盖 happy path**：需覆盖重放、冲突、并发同号、并发异号、库存不足、非法参数、`fail_at` 回滚，且断言"无额外业务修改"（库存与记录均不变）。
6. **不要用 smoke 通过推断缺陷已修复**——`test_smoke.py` 仅覆盖规则 1 的正常路径。