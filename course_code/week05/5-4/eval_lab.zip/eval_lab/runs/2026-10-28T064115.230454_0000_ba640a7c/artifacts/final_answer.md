# 只读风险扫描报告（库存请求 / 幂等 / 事务 / 接口）

## 0. 执行范围与已做操作

实际执行（只读）：

- 读取 `AGENTS.md`、`docs/rules.md`、`docs/archive_2024.md`、`contracts/response.json`、`inventory.py`、`tests/test_smoke.py`
- 列目录：`docs/`、`contracts/`、`tests/`、工程根

未执行（明确说明）：

- **未运行任何测试**（未调用 run_tests，未执行 `python -m unittest`）
- **未做任何性能测量**，下文不出现任何耗时/吞吐数字
- 未修改任何文件（本次为只读扫描，Diff 为空，与题述"初始缺陷工程，尚无变更"一致）

规则依据：`docs/rules.md`（v1）。`docs/archive_2024.md` 已过期，仅用于确认"内存去重"是历史做法、不是当前契约，未用于覆盖当前规则。

---

## 1. 确认事实（代码可直接读出，无需运行）

| # | 位置 | 事实 |
|---|---|---|
| F1 | `inventory.py:24` | `seen = set()` 在每次 `reserve` 调用内新建，函数返回即丢弃；无任何持久化幂等状态 |
| F2 | `inventory.py:25-28` | `if request_id in seen` 分支在新建空集合后立即判断，恒为假，是死代码 |
| F3 | `inventory.py:29-36` | 读库存（`SELECT`）与扣减（`UPDATE`）在**同一个** `with sqlite3.connect(...)` 块内，但中间有 `time.sleep(0.01)`；该块结束时提交 |
| F4 | `inventory.py:37-38` | `fail_at == "after_inventory"` 的 `RuntimeError` 在**第一个** `with` 块退出（已提交）之后才抛出 |
| F5 | `inventory.py:39-42` | 预占记录 `INSERT` 在**第二个独立连接/事务**中执行，与库存扣减不在同一事务 |
| F6 | `inventory.py:43` | `seen.add(request_id)` 写入的是即将被丢弃的局部集合，无持久效果 |
| F7 | `inventory.py:24` | 校验只覆盖 `request_id` 非空字符串、`quantity` 为 `int` 且 `>0`；`type(quantity) is int` 已排除 `bool`（符合规则 7 的 bool 要求） |
| F8 | `inventory.py:31-33` | 未知 sku 走 `row is None` → `invalid_request`，符合规则 7 |
| F9 | `inventory.py:34-35` | 库存不足返回 `insufficient_stock`，且此时未做任何写操作 |
| F10 | `inventory.py:44-45` | 成功响应恰好 5 个字段，与 `contracts/response.json` 的 `success_required_keys` 一致 |
| F11 | `inventory.py:6-14` | `initialize` 用 `INSERT OR REPLACE` 重置 `sku-1` 库存；表结构 `inventory(sku, available)`、`reservations(id, request_id, sku, quantity)` 与规则一致，无索引 |
| F12 | `inventory.py:29` | 连接使用 `timeout=15`，未设置 `isolation_level`、未显式 `BEGIN IMMEDIATE`、未设 WAL |
| F13 | 全文件 | 无 `UNIQUE` 约束、无 `PRIMARY KEY`/唯一索引在 `reservations.request_id` 上 |

---

## 2. 风险发现（按规则条目对齐）

### R1 — 幂等完全失效（规则 2、5）｜确认事实 + 风险假设

- **代码位置**：`inventory.py:24-28`、`inventory.py:43`
- **触发条件**：同一 `request_id` 相同参数重复提交（串行或并发）
- **证据**：F1/F2/F6 —— `seen` 是函数局部变量，跨调用不共享；`seen.add` 无持久化
- **影响**：每次重试都会再次扣库存并再插一条 `reservations` 行；`replayed` 永远为 `false`。规则 2 的"只能产生一次有效预占"与规则 5 的并发重试唯一性均不满足
- **待验证点**：需实测确认重复调用后 `available` 递减次数与 `reservations` 行数（本次未运行）

### R2 — 无冲突检测（规则 3）｜确认事实

- **代码位置**：`inventory.py:24-45`（全函数无 `conflict` 分支）
- **触发条件**：同一 `request_id` 携带不同 `sku` 或 `quantity`
- **证据**：源码中不存在返回 `{"status":"conflict"}` 的路径；`contracts/response.json` 的 `statuses` 含 `conflict`，但实现未产出
- **影响**：同号不同参数会被当作新请求再次扣库存，违反规则 3"不能再次改变库存或记录"
- **待验证点**：需实测确认同号不同 quantity 后库存变化

### R3 — 检查/扣减竞态（规则 4）｜确认事实（结构）+ 风险假设（实际超卖幅度）

- **代码位置**：`inventory.py:30-36`（`SELECT` → `sleep` → `UPDATE`）
- **触发条件**：不同 `request_id` 并发调用
- **证据**：F3/F12 —— 默认 `isolation_level` 下 `SELECT` 不取写锁，`UPDATE` 才取锁；`sleep(0.01)` 位于两者之间，放大窗口；`UPDATE` 无 `available >= ?` 守卫条件
- **影响**：多个事务可同时读到相同 `available`，各自扣减，导致 `available` 变负、成功预占总量超过初始库存，违反规则 4
- **待验证点**：并发线程数、SQLite 版本、是否出现 `database is locked` 均未验证；**不做性能推断**，仅指出逻辑窗口存在

### R4 — 事务边界错误 / 回滚不成立（规则 8）｜确认事实

- **代码位置**：`inventory.py:29-38`（库存提交）与 `inventory.py:39-42`（记录插入）
- **触发条件**：`fail_at="after_inventory"`
- **证据**：F4/F5 —— 库存扣减在第一个 `with` 块退出时已提交；`RuntimeError` 在其后抛出，此时无活动事务可回滚；预占记录在第二个连接中写入，与库存扣减原子性无关
- **影响**：注入异常后库存已永久减少且无预占记录，库存与有效预占总量不一致，违反规则 8"必须整体回滚"
- **待验证点**：需实测确认异常后 `available` 与 `reservations` 行数（本次未运行）

### R5 — 库存与记录可能不一致（规则 4 后半）｜确认事实（结构）

- **代码位置**：`inventory.py:36` vs `inventory.py:40-41`
- **触发条件**：第二个 `with` 块内 `INSERT` 失败（如磁盘错误、锁超时、进程中断）
- **证据**：F5 —— 两个独立事务，无补偿逻辑
- **影响**：库存已扣但无预占记录，或（在 R3 场景下）记录数与扣减量不匹配
- **待验证点**：故障注入未执行，属结构性风险

### R6 — 缺少数据库级唯一约束（规则 2、5 的兜底）｜确认事实

- **代码位置**：`inventory.py:8-12`（建表语句）
- **证据**：F13 —— `reservations.request_id` 无 `UNIQUE`
- **影响**：即使应用层加了幂等查询，并发下仍可能双写；规则允许"可以增加索引"，故加唯一索引在允许范围内
- **待验证点**：加唯一索引后需确认 `initialize` 对已存在旧库的兼容行为（`CREATE TABLE IF NOT EXISTS` 不会补索引，需单独 `CREATE UNIQUE INDEX IF NOT EXISTS`）

### R7 — 接口契约：失败响应字段（规则"成功响应必须恰好包含…"）｜风险假设

- **代码位置**：`inventory.py:25`、`inventory.py:32`、`inventory.py:35`
- **证据**：失败响应仅含 `status` 单字段；规则只对**成功**响应规定"恰好五个字段"，对失败响应只规定 `status` 分类，故当前形态**不构成确认违规**
- **影响**：无确认影响；若宿主验收对失败响应字段有额外期望，则可能不符
- **待验证点**：需人工确认失败响应是否允许仅含 `status`（规则文本未要求更多字段）

### R8 — `initialize` 的 `INSERT OR REPLACE` 语义｜风险假设

- **代码位置**：`inventory.py:14`
- **证据**：F11 —— 重复调用 `initialize` 会把库存重置为 `stock`，但**不清空** `reservations`
- **影响**：若测试在同一 db 上重复 `initialize`，会出现"库存重置但历史预占记录仍在"的不一致；规则未定义 `initialize` 的重复调用语义
- **待验证点**：需人工确认该行为是否属于契约范围；本次不视为确认缺陷

### R9 — 校验顺序与 sku 类型｜风险假设

- **代码位置**：`inventory.py:24`、`inventory.py:31`
- **证据**：`sku` 未做类型校验，非字符串 sku 会走到 `row is None` → `invalid_request`，结果仍符合规则 7
- **影响**：无确认影响；仅提示 `sku=None` 等输入依赖 SQL 参数绑定行为
- **待验证点**：未实测非字符串 sku

---

## 3. 优先级建议（AI 建议，人工决定）

| 建议序 | 项 | 理由 |
|---|---|---|
| P0 | R4（事务/回滚） | 规则 8 明确要求整体回滚，当前结构上不可能满足 |
| P0 | R1 + R2 + R6（幂等/冲突/唯一约束） | 规则 2、3、5 的核心；需持久化幂等状态 + 唯一索引兜底 |
| P0 | R3（竞态） | 规则 4 明确要求不超卖且不拒绝全部合法请求 |
| P2 | R5 | 随 R4 的单事务化自然收敛 |
| P3 | R7、R8、R9 | 需人工确认契约边界后再决定是否处理 |

以上排序仅为建议，最终取舍由人决定。

---

## 4. PR 草稿

### 目标

在 `docs/rules.md` v1 契约下，修复 `inventory.py` 的库存预占缺陷：请求幂等、同号冲突检测、并发不超卖、异常整体回滚，同时保持函数签名、表名、已有列与返回结构兼容。

### 实际修改

**无。** 本次为只读风险扫描，未修改 `inventory.py`，未新增测试文件，未改动 `tests/test_smoke.py`、`docs/`、`contracts/`、`AGENTS.md`。Diff 为空。

### 影响范围（基于源码静态分析，非运行验证）

- 唯一待改文件：`inventory.py`（`initialize`、`reserve`）
- 可能新增：`tests/test_*.py`（幂等、冲突、并发、回滚、非法输入）
- 不改动：`tests/test_smoke.py`、`docs/rules.md`、`docs/archive_2024.md`、`contracts/response.json`、`AGENTS.md`
- 对外接口：`initialize(db_path, stock=10)`、`reserve(db_path, request_id, sku="sku-1", quantity=2, fail_at=None)` 签名与成功响应五字段保持不变

### 验证证据

- 已执行：源码与规则、契约、基线测试文件的静态阅读（见第 0 节）
- **未执行任何测试**，因此**没有任何运行证据**支持"缺陷已复现"或"缺陷已修复"
- 未做性能测量，报告中不含性能结论

### 未验证

1. 规则 2/3/5 的幂等与冲突行为未实测
2. 规则 4 的并发超卖未实测（线程数、SQLite 版本、锁超时行为均未知）
3. 规则 8 的 `fail_at="after_inventory"` 回滚未实测
4. 失败响应是否允许仅含 `status`（R7）未获人工确认
5. `initialize` 重复调用语义（R8）未获人工确认
6. 非字符串 `sku` 行为（R9）未实测
7. 基线 `tests/test_smoke.py` 是否通过未运行确认

### 重点 Review

1. **事务边界**：库存扣减与预占记录写入是否合并为单一事务，`fail_at` 注入点是否位于事务内、异常是否触发回滚
2. **幂等状态持久化**：是否以数据库为唯一事实源（而非进程内集合），重放判定是否读取已存记录并比对 `sku`/`quantity`
3. **并发正确性**：是否使用 `BEGIN IMMEDIATE` 或带 `available >= ?` 守卫的条件更新，是否避免"拒绝所有请求"式规避
4. **唯一约束**：`reservations.request_id` 唯一索引的创建方式与旧库兼容性
5. **契约兼容**：成功响应恰好五字段、失败 `status` 分类、函数签名与表结构不变
6. **范围控制**：是否只改 `inventory.py` 并新增 `tests/test_*.py`，未触碰只读文件