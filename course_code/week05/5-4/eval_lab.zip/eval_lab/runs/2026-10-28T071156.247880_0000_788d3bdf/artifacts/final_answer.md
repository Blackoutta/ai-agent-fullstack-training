```json
{
  "scope": {
    "confirmed_scope": ["inventory.py 的预占、幂等、事务与接口响应"],
    "high_risks": ["相同请求重复业务效果", "并发超卖", "异常部分提交", "接口不兼容"],
    "out_of_scope": ["支付确认与释放", "多仓库", "生产压测结论"],
    "required_reviews": ["修改了什么", "关键分支在哪里", "旧调用是否兼容"],
    "status": "教学范围；迁移到实际项目时需业务负责人重新确认",
    "basis": "docs/rules.md（版本 1）+ contracts/response.json；docs/archive_2024.md 明确过期，不作为依据",
    "read_only_artifacts": ["docs/rules.md", "docs/archive_2024.md", "contracts/response.json", "tests/test_smoke.py", "AGENTS.md"],
    "editable_artifacts": ["inventory.py", "新增 tests/test_*.py"],
    "note": "本文件仅为测试设计，未执行任何测试，也未修改任何代码"
  },
  "risk_review": [
    {
      "risk": "相同请求重复业务效果",
      "code_evidence": "reserve() 内 `seen = set()` 每次调用重建，`if request_id in seen` 恒为假；`seen.add(request_id)` 只作用于局部变量",
      "consequence": "同一 request_id 重复提交会重复扣减库存并插入多条 reservations 记录，replayed 永远为 false",
      "rule_ref": "rules.md 第 2 条",
      "severity": "high",
      "detection": "串行重复提交 + 相同 request_id 并发提交，断言库存与记录数"
    },
    {
      "risk": "并发超卖",
      "code_evidence": "SELECT available 与 UPDATE available=available-? 之间无事务锁、无 `WHERE available>=?` 条件更新，且中间有 time.sleep(0.01) 放大窗口；sqlite3 默认隔离级别下 SELECT 不持写锁",
      "consequence": "多个不同 request_id 并发时都读到旧库存，全部通过检查，最终 available 变负、有效预占总量超过初始库存",
      "rule_ref": "rules.md 第 4 条",
      "severity": "high",
      "detection": "多线程不同 request_id 并发，断言 available>=0 且 初始库存-available == 有效预占总量，且成功数>0"
    },
    {
      "risk": "异常部分提交",
      "code_evidence": "库存 UPDATE 在第一个 `with sqlite3.connect(...)` 块内提交；fail_at='after_inventory' 的 RuntimeError 在块外抛出，此时库存已落库，reservations 未写入",
      "consequence": "注入异常后库存被扣但无预占记录，库存与记录不一致，且该 request_id 未持久化，重试会再次扣减",
      "rule_ref": "rules.md 第 8 条",
      "severity": "high",
      "detection": "fail_at='after_inventory' 断言抛 RuntimeError，且库存与记录均未变化；随后同 request_id 正常重试应成功且只扣一次"
    },
    {
      "risk": "接口不兼容",
      "code_evidence": "成功响应字段集合需恰好为 5 个；失败响应需为单键 status；函数签名/表名/列名需保持",
      "consequence": "新增字段、改字段名、改 status 取值、改表结构都会破坏既有调用方与 contracts/response.json",
      "rule_ref": "rules.md 调用方式 + contracts/response.json",
      "severity": "high",
      "detection": "键集合精确断言、status 枚举断言、签名与 schema 断言、旧调用（位置参数/默认参数）回归"
    },
    {
      "risk": "参数冲突未识别",
      "code_evidence": "当前实现完全没有 conflict 分支，任何参数组合都走扣减路径",
      "consequence": "同一 request_id 换 quantity/sku 会再次扣库存，产生语义冲突的重复业务效果",
      "rule_ref": "rules.md 第 3 条",
      "severity": "high",
      "detection": "同 request_id 不同 quantity / 不同 sku 串行与并发，断言 status=conflict 且库存与记录不变"
    },
    {
      "risk": "参数校验缺口",
      "code_evidence": "`type(quantity) is not int` 已排除 bool；但 request_id 空白字符串（如 ' '）未判空；未知 sku 返回 invalid_request 已实现",
      "consequence": "空白 request_id 可能被当作合法请求写入记录，形成不可重放的脏数据",
      "rule_ref": "rules.md 第 7 条",
      "severity": "medium",
      "detection": "参数化非法输入矩阵，断言 invalid_request 且无副作用"
    },
    {
      "risk": "库存不足路径副作用",
      "code_evidence": "不足分支在 UPDATE 之前 return，当前无副作用；但修复并发时若改为条件更新需保证不写记录",
      "consequence": "修复后可能引入「不足也写记录」或「不足也扣库存」",
      "rule_ref": "rules.md 第 6 条",
      "severity": "medium",
      "detection": "边界 quantity == available、quantity == available+1，断言库存与记录数"
    },
    {
      "risk": "以拒绝合法请求规避并发问题",
      "code_evidence": "无（当前实现相反：全部放行）",
      "consequence": "修复时若用全局锁+直接拒绝或串行化后误判不足，会牺牲可用性",
      "rule_ref": "rules.md 第 4 条「不能拒绝所有合法请求来规避问题」",
      "severity": "medium",
      "detection": "并发用例断言成功数 == floor(初始库存/quantity) 且 > 0"
    }
  ],
  "decision_table": [
    {
      "group": "DT-1 单次请求参数与库存判定（串行）",
      "conditions": ["request_id 合法性", "quantity 合法性", "sku 存在性", "available 与 quantity 关系"],
      "rules": [
        {"id": "R1", "when": "request_id 非空字符串 且 quantity 正整数 且 sku 存在 且 available >= quantity", "status": "reserved", "replayed": false, "inventory_delta": "-quantity", "record_delta": "+1"},
        {"id": "R2", "when": "request_id 非空字符串 且 quantity 正整数 且 sku 存在 且 available < quantity", "status": "insufficient_stock", "inventory_delta": "0", "record_delta": "0"},
        {"id": "R3", "when": "request_id 非字符串/空串/空白串", "status": "invalid_request", "inventory_delta": "0", "record_delta": "0"},
        {"id": "R4", "when": "quantity 非 int（含 bool、float、str、None）或 <= 0", "status": "invalid_request", "inventory_delta": "0", "record_delta": "0"},
        {"id": "R5", "when": "sku 不存在", "status": "invalid_request", "inventory_delta": "0", "record_delta": "0"}
      ]
    },
    {
      "group": "DT-2 幂等与冲突判定（同一 request_id 再次到达，串行）",
      "conditions": ["该 request_id 是否已有有效预占记录", "sku 是否相同", "quantity 是否相同"],
      "rules": [
        {"id": "R6", "when": "无既有记录", "status": "按 DT-1 判定", "replayed": false, "inventory_delta": "按 DT-1", "record_delta": "按 DT-1"},
        {"id": "R7", "when": "有既有记录 且 sku 相同 且 quantity 相同", "status": "reserved", "replayed": true, "inventory_delta": "0", "record_delta": "0"},
        {"id": "R8", "when": "有既有记录 且 (sku 不同 或 quantity 不同)", "status": "conflict", "replayed": "不适用（失败响应无此字段）", "inventory_delta": "0", "record_delta": "0"}
      ]
    },
    {
      "group": "DT-3 事务与异常注入判定",
      "conditions": ["fail_at 取值", "异常发生位置"],
      "rules": [
        {"id": "R9", "when": "fail_at=None", "status": "按 DT-1/DT-2 判定", "inventory_delta": "按 DT-1/DT-2", "record_delta": "按 DT-1/DT-2"},
        {"id": "R10", "when": "fail_at='after_inventory' 且请求本应成功", "status": "抛出 RuntimeError", "inventory_delta": "0（整体回滚）", "record_delta": "0（整体回滚）"},
        {"id": "R11", "when": "fail_at='after_inventory' 且请求本应 insufficient_stock/invalid_request/conflict", "status": "按原判定返回，不抛异常（无库存更新可注入）", "inventory_delta": "0", "record_delta": "0"}
      ]
    },
    {
      "group": "DT-4 并发判定（时序维度，独立于静态组合）",
      "conditions": ["并发请求的 request_id 关系", "并发请求的参数关系", "初始库存与总需求关系"],
      "rules": [
        {"id": "R12", "when": "不同 request_id，参数合法，总需求 <= 库存", "status": "全部 reserved", "invariant": "available == 初始库存 - Σquantity；有效记录数 == 请求数；available >= 0"},
        {"id": "R13", "when": "不同 request_id，参数合法，总需求 > 库存", "status": "部分 reserved + 部分 insufficient_stock", "invariant": "成功数 == floor(初始库存/quantity) 且 > 0；available >= 0；Σ成功quantity == 初始库存 - available"},
        {"id": "R14", "when": "相同 request_id，参数完全相同，N 个并发", "status": "恰好 1 个 replayed=false，其余 reserved 且 replayed=true（或等价的一次有效效果）", "invariant": "有效记录数 == 1；库存只扣一次"},
        {"id": "R15", "when": "相同 request_id，参数不同（quantity 或 sku 不同），并发", "status": "至多 1 个 reserved，其余 conflict", "invariant": "有效记录数 == 1；库存只扣一次"}
      ]
    },
    {
      "group": "DT-5 契约判定",
      "conditions": ["响应类型", "字段集合", "status 取值", "函数签名/表结构"],
      "rules": [
        {"id": "R16", "when": "成功响应", "assert": "键集合恰好 == {status, request_id, sku, quantity, replayed}；status == 'reserved'；request_id/sku/quantity 回显入参；replayed 为 bool"},
        {"id": "R17", "when": "失败响应", "assert": "键集合恰好 == {status}；status ∈ {conflict, insufficient_stock, invalid_request}"},
        {"id": "R18", "when": "签名与 schema", "assert": "reserve(db_path, request_id, sku='sku-1', quantity=2, fail_at=None)；initialize(db_path, stock=10)；表 inventory(sku, available)、reservations(id, request_id, sku, quantity) 均存在且列不缺失"}
      ]
    }
  ],
  "cases": [
    {
      "name": "TC-01 正常预占（基线回归）",
      "preconditions": ["initialize(db_path, 10)", "无既有记录"],
      "actions": ["reserve(db_path, 'req-1', quantity=2)"],
      "expected_response": {"status": "reserved", "request_id": "req-1", "sku": "sku-1", "quantity": 2, "replayed": false},
      "expected_inventory": "available == 8",
      "expected_records": "reservations 中 request_id='req-1' 恰好 1 行，quantity=2",
      "risk": "接口不兼容（基线）"
    },
    {
      "name": "TC-02 相同 request_id 相同参数串行重复提交",
      "preconditions": ["initialize(db_path, 10)", "已成功执行 reserve(db_path,'req-1',quantity=2)"],
      "actions": ["reserve(db_path, 'req-1', quantity=2)"],
      "expected_response": {"status": "reserved", "request_id": "req-1", "sku": "sku-1", "quantity": 2, "replayed": true},
      "expected_inventory": "available == 8（不再扣减）",
      "expected_records": "reservations 中 request_id='req-1' 仍为 1 行",
      "risk": "相同请求重复业务效果"
    },
    {
      "name": "TC-03 相同 request_id 相同参数连续三次提交",
      "preconditions": ["initialize(db_path, 10)"],
      "actions": ["reserve(db_path,'req-1',quantity=2)", "reserve(db_path,'req-1',quantity=2)", "reserve(db_path,'req-1',quantity=2)"],
      "expected_response": "第 1 次 replayed=false；第 2、3 次 replayed=true，status 均为 reserved",
      "expected_inventory": "available == 8",
      "expected_records": "request_id='req-1' 恰好 1 行",
      "risk": "相同请求重复业务效果"
    },
    {
      "name": "TC-04 相同 request_id 不同 quantity 串行",
      "preconditions": ["initialize(db_path, 10)", "已成功执行 reserve(db_path,'req-1',quantity=2)"],
      "actions": ["reserve(db_path, 'req-1', quantity=5)"],
      "expected_response": {"status": "conflict"},
      "expected_inventory": "available == 8",
      "expected_records": "request_id='req-1' 仍为 1 行，quantity=2",
      "risk": "相同请求重复业务效果 / 参数冲突"
    },
    {
      "name": "TC-05 相同 request_id 不同 sku 串行",
      "preconditions": ["initialize(db_path, 10)", "已成功执行 reserve(db_path,'req-1',quantity=2)"],
      "actions": ["reserve(db_path, 'req-1', sku='sku-2', quantity=2)"],
      "expected_response": {"status": "conflict"},
      "expected_inventory": "sku-1 available == 8；sku-2 不存在（不新增行）",
      "expected_records": "reservations 总行数仍为 1",
      "risk": "相同请求重复业务效果 / 参数冲突"
    },
    {
      "name": "TC-06 库存不足（available < quantity）",
      "preconditions": ["initialize(db_path, 3)"],
      "actions": ["reserve(db_path, 'req-1', quantity=4)"],
      "expected_response": {"status": "insufficient_stock"},
      "expected_inventory": "available == 3",
      "expected_records": "reservations 为 0 行",
      "risk": "库存不足路径副作用"
    },
    {
      "name": "TC-07 库存边界（quantity == available）",
      "preconditions": ["initialize(db_path, 2)"],
      "actions": ["reserve(db_path, 'req-1', quantity=2)"],
      "expected_response": {"status": "reserved", "request_id": "req-1", "sku": "sku-1", "quantity": 2, "replayed": false},
      "expected_inventory": "available == 0",
      "expected_records": "reservations 1 行",
      "risk": "库存不足路径副作用（边界误判）"
    },
    {
      "name": "TC-08 库存边界（quantity == available + 1）",
      "preconditions": ["initialize(db_path, 2)"],
      "actions": ["reserve(db_path, 'req-1', quantity=3)"],
      "expected_response": {"status": "insufficient_stock"},
      "expected_inventory": "available == 2",
      "expected_records": "reservations 0 行",
      "risk": "库存不足路径副作用"
    },
    {
      "name": "TC-09 非法 request_id 矩阵",
      "preconditions": ["initialize(db_path, 10)"],
      "actions": ["reserve(db_path, '')", "reserve(db_path, None)", "reserve(db_path, 123)", "reserve(db_path, '   ')"],
      "expected_response": "每次均返回 {'status': 'invalid_request'}",
      "expected_inventory": "available == 10（全部无副作用）",
      "expected_records": "reservations 0 行",
      "risk": "参数校验缺口（空白串为待确认项，见 open_questions）"
    },
    {
      "name": "TC-10 非法 quantity 矩阵（含 bool）",
      "preconditions": ["initialize(db_path, 10)"],
      "actions": ["reserve(db_path,'req-1',quantity=0)", "reserve(db_path,'req-2',quantity=-1)", "reserve(db_path,'req-3',quantity=True)", "reserve(db_path,'req-4',quantity=2.0)", "reserve(db_path,'req-5',quantity='2')", "reserve(db_path,'req-6',quantity=None)"],
      "expected_response": "每次均返回 {'status': 'invalid_request'}",
      "expected_inventory": "available == 10",
      "expected_records": "reservations 0 行",
      "risk": "参数校验缺口"
    },
    {
      "name": "TC-11 未知 sku",
      "preconditions": ["initialize(db_path, 10)"],
      "actions": ["reserve(db_path, 'req-1', sku='sku-unknown', quantity=1)"],
      "expected_response": {"status": "invalid_request"},
      "expected_inventory": "sku-1 available == 10；不新增 sku 行",
      "expected_records": "reservations 0 行",
      "risk": "参数校验缺口"
    },
    {
      "name": "TC-12 异常注入 after_inventory 整体回滚",
      "preconditions": ["initialize(db_path, 10)"],
      "actions": ["reserve(db_path, 'req-1', quantity=2, fail_at='after_inventory')"],
      "expected_response": "抛出 RuntimeError（消息含 injected_after_inventory）",
      "expected_inventory": "available == 10（库存更新已回滚）",
      "expected_records": "reservations 0 行",
      "risk": "异常部分提交"
    },
    {
      "name": "TC-13 异常注入后同 request_id 重试",
      "preconditions": ["initialize(db_path, 10)", "TC-12 已执行并回滚"],
      "actions": ["reserve(db_path, 'req-1', quantity=2)"],
      "expected_response": {"status": "reserved", "request_id": "req-1", "sku": "sku-1", "quantity": 2, "replayed": false},
      "expected_inventory": "available == 8（只扣一次）",
      "expected_records": "request_id='req-1' 恰好 1 行",
      "risk": "异常部分提交 / 相同请求重复业务效果"
    },
    {
      "name": "TC-14 异常注入不掩盖正常路径（fail_at 不被忽略）",
      "preconditions": ["initialize(db_path, 10)"],
      "actions": ["reserve(db_path,'req-1',quantity=2,fail_at='after_inventory')", "reserve(db_path,'req-2',quantity=2,fail_at=None)"],
      "expected_response": "第 1 次抛 RuntimeError；第 2 次返回 reserved 且 replayed=false",
      "expected_inventory": "available == 8",
      "expected_records": "仅 request_id='req-2' 1 行",
      "risk": "异常部分提交"
    },
    {
      "name": "TC-15 异常注入 + 库存不足（无更新可注入）",
      "preconditions": ["initialize(db_path, 1)"],
      "actions": ["reserve(db_path, 'req-1', quantity=5, fail_at='after_inventory')"],
      "expected_response": {"status": "insufficient_stock"} ,
      "expected_inventory": "available == 1",
      "expected_records": "reservations 0 行",
      "risk": "异常部分提交（分支顺序）"
    },
    {
      "name": "TC-16 不同 request_id 并发，总需求 <= 库存",
      "preconditions": ["initialize(db_path, 10)", "N=5 个不同 request_id，各 quantity=2"],
      "actions": ["5 个线程同时调用 reserve(db_path, f'req-{i}', quantity=2)，用 Barrier 对齐起跑"],
      "expected_response": "5 个响应全部 status='reserved'，replayed 均为 false",
      "expected_inventory": "available == 0 且 available >= 0",
      "expected_records": "reservations 5 行，Σquantity == 10 == 初始库存 - available",
      "risk": "并发超卖"
    },
    {
      "name": "TC-17 不同 request_id 并发，总需求 > 库存（超卖检测）",
      "preconditions": ["initialize(db_path, 10)", "N=10 个不同 request_id，各 quantity=2（总需求 20）"],
      "actions": ["10 个线程同时调用 reserve(db_path, f'req-{i}', quantity=2)，Barrier 对齐"],
      "expected_response": "成功数 == 5（floor(10/2)）且 > 0；其余为 insufficient_stock；无其他 status",
      "expected_inventory": "available == 0 且 available >= 0（不得为负）",
      "expected_records": "有效记录数 == 5；Σ记录 quantity == 10 == 初始库存 - available",
      "risk": "并发超卖"
    },
    {
      "name": "TC-18 不同 request_id 并发，quantity 不等且总需求 > 库存",
      "preconditions": ["initialize(db_path, 10)", "request_id 与 quantity 混合：2,3,5,4,6"],
      "actions": ["5 个线程同时调用 reserve，Barrier 对齐"],
      "expected_response": "成功集合的 Σquantity <= 10；失败均为 insufficient_stock",
      "expected_inventory": "available == 10 - Σ成功quantity 且 >= 0",
      "expected_records": "记录数 == 成功数；Σ记录 quantity == 10 - available",
      "risk": "并发超卖"
    },
    {
      "name": "TC-19 相同 request_id 相同参数并发（N=8）",
      "preconditions": ["initialize(db_path, 10)", "同一 request_id='req-dup'，quantity=2"],
      "actions": ["8 个线程同时调用 reserve(db_path, 'req-dup', quantity=2)，Barrier 对齐"],
      "expected_response": "恰好 1 个 replayed=false，其余 status='reserved' 且 replayed=true（或等价：所有响应 status 均为 reserved，replayed=false 计数 == 1）",
      "expected_inventory": "available == 8（只扣一次）",
      "expected_records": "request_id='req-dup' 恰好 1 行",
      "risk": "相同请求重复业务效果 / 并发"
    },
    {
      "name": "TC-20 相同 request_id 不同参数并发（冲突竞争）",
      "preconditions": ["initialize(db_path, 10)", "同一 request_id='req-x'，quantity 分别为 2 与 5"],
      "actions": ["2 个线程同时调用 reserve(db_path,'req-x',quantity=2) 与 reserve(db_path,'req-x',quantity=5)，Barrier 对齐"],
      "expected_response": "恰好 1 个 status='reserved'，另 1 个 status='conflict'",
      "expected_inventory": "available == 10 - 获胜请求的 quantity（8 或 5），且只扣一次",
      "expected_records": "request_id='req-x' 恰好 1 行，quantity 与获胜请求一致",
      "risk": "相同请求重复业务效果 / 参数冲突 / 并发"
    },
    {
      "name": "TC-21 并发 + 异常注入混合（回滚不破坏并发一致性）",
      "preconditions": ["initialize(db_path, 10)", "3 个不同 request_id，其中 1 个 fail_at='after_inventory'"],
      "actions": ["3 个线程同时调用 reserve，Barrier 对齐"],
      "expected_response": "注入线程抛 RuntimeError；其余 2 个 status='reserved'",
      "expected_inventory": "available == 6 且 >= 0",
      "expected_records": "reservations 2 行，不含注入线程的 request_id",
      "risk": "异常部分提交 / 并发超卖"
    },
    {
      "name": "TC-22 契约：成功响应键集合精确匹配",
      "preconditions": ["initialize(db_path, 10)"],
      "actions": ["reserve(db_path, 'req-1', quantity=2)", "reserve(db_path, 'req-1', quantity=2)"],
      "expected_response": "两次响应 set(keys) == {'status','request_id','sku','quantity','replayed'}；无多余/缺失键；replayed 为 bool 类型",
      "expected_inventory": "available == 8",
      "expected_records": "1 行",
      "risk": "接口不兼容"
    },
    {
      "name": "TC-23 契约：失败响应键集合与 status 枚举",
      "preconditions": ["initialize(db_path, 1)"],
      "actions": ["reserve(db_path,'req-1',quantity=5)", "reserve(db_path,'req-2',quantity=0)", "reserve(db_path,'req-3',sku='nope')", "reserve(db_path,'req-4',quantity=1) 后再 reserve(db_path,'req-4',quantity=2)"],
      "expected_response": "每个失败响应 set(keys) == {'status'}；status ∈ {'insufficient_stock','invalid_request','conflict'}，与 contracts/response.json 的 statuses 一致",
      "expected_inventory": "available == 0（仅 req-4 首次成功扣 1）",
      "expected_records": "1 行（req-4）",
      "risk": "接口不兼容"
    },
    {
      "name": "TC-24 契约：旧调用兼容（位置参数与默认参数）",
      "preconditions": ["initialize(db_path) 使用默认 stock=10"],
      "actions": ["reserve(db_path, 'req-1')", "reserve(db_path, 'req-2', 'sku-1')", "reserve(db_path, 'req-3', 'sku-1', 3)", "reserve(db_path, 'req-4', 'sku-1', 1, None)"],
      "expected_response": "全部 status='reserved'，replayed=false；quantity 回显为 2/2/3/1",
      "expected_inventory": "available == 10 - (2+2+3+1) == 2",
      "expected_records": "4 行",
      "risk": "接口不兼容"
    },
    {
      "name": "TC-25 契约：表结构与列不缺失",
      "preconditions": ["initialize(db_path, 10)"],
      "actions": ["PRAGMA table_info(inventory)", "PRAGMA table_info(reservations)"],
      "expected_response": "inventory 含 sku、available；reservations 含 id、request_id、sku、quantity（允许新增索引，不允许缺失既有列）",
      "expected_inventory": "available == 10",
      "expected_records": "reservations 0 行",
      "risk": "接口不兼容"
    },
    {
      "name": "TC-26 契约：initialize 幂等与库存重置语义",
      "preconditions": ["initialize(db_path, 10)", "reserve(db_path,'req-1',quantity=2)"],
      "actions": ["initialize(db_path, 10)"],
      "expected_response": "不抛异常",
      "expected_inventory": "available == 10（INSERT OR REPLACE 重置）",
      "expected_records": "reservations 行数保持（initialize 不清理记录）—— 该语义待确认，见 open_questions",
      "risk": "接口不兼容 / 状态一致性"
    }
  ],
  "coverage_matrix": [
    {"dimension": "正常", "cases": ["TC-01", "TC-07", "TC-24"], "decision_rules": ["R1", "R16"]},
    {"dimension": "重复（幂等）", "cases": ["TC-02", "TC-03", "TC-19"], "decision_rules": ["R7", "R14"]},
    {"dimension": "参数冲突", "cases": ["TC-04", "TC-05", "TC-20"], "decision_rules": ["R8", "R15"]},
    {"dimension": "参数校验/边界", "cases": ["TC-06", "TC-08", "TC-09", "TC-10", "TC-11"], "decision_rules": ["R2", "R3", "R4", "R5"]},
    {"dimension": "不同请求并发", "cases": ["TC-16", "TC-17", "TC-18"], "decision_rules": ["R12", "R13"]},
    {"dimension": "相同请求并发", "cases": ["TC-19", "TC-20"], "decision_rules": ["R14", "R15"]},
    {"dimension": "异常回滚", "cases": ["TC-12", "TC-13", "TC-14", "TC-15", "TC-21"], "decision_rules": ["R10", "R11"]},
    {"dimension": "契约", "cases": ["TC-22", "TC-23", "TC-24", "TC-25", "TC-26"], "decision_rules": ["R16", "R17", "R18"]},
    {"dimension": "高风险项保留检查", "cases": ["相同请求重复业务效果→TC-02/03/04/05/19/20", "并发超卖→TC-16/17/18/21", "异常部分提交→TC-12/13/14/15/21", "接口不兼容→TC-22/23/24/25/26"], "note": "四类高风险均有 ≥2 个独立用例，未因数量裁剪"},
    {"dimension": "并发时序独立性", "cases": ["TC-16", "TC-17", "TC-18", "TC-19", "TC-20", "TC-21"], "note": "并发用例以 Barrier 对齐起跑并断言不变量（库存非负、Σ记录==初始-剩余、成功数上界），不压缩为静态参数组合；允许合法交错，只断言不变量"},
    {"dimension": "out_of_scope 排除", "cases": [], "note": "支付确认/释放、多仓库、生产压测结论均不设计用例"}
  ],
  "open_questions": [
    {"id": "Q1", "question": "request_id 为纯空白字符串（如 '   '）是否应视为 invalid_request？rules.md 只写「非空字符串」，未明确是否 strip。", "impact": "TC-09 中空白串的期望值", "current_assumption": "按 invalid_request 设计，需业务确认"},
    {"id": "Q2", "question": "相同 request_id 并发重试时，未获胜的并发请求应返回 replayed=true 的 reserved，还是允许返回 conflict/其他？rules.md 第 5 条只要求「只产生一次有效预占」。", "impact": "TC-19 的期望响应集合", "current_assumption": "允许两种等价表述，但 replayed=false 计数必须恰好为 1"},
    {"id": "Q3", "question": "conflict 响应是否允许携带 request_id 等附加字段？contracts/response.json 只规定成功响应 5 键，未规定失败响应键集合。", "impact": "TC-23 的键集合断言严格度", "current_assumption": "按恰好 {'status'} 设计（与当前实现一致），需确认"},
    {"id": "Q4", "question": "initialize 重复调用时是否应清空 reservations 表？当前实现只重置 inventory。", "impact": "TC-26 的记录期望", "current_assumption": "保持现状（不清空），需确认是否为预期语义"},
    {"id": "Q5", "question": "fail_at 传入未知值（如 'after_reservation'）时应忽略还是报错？rules.md 只定义 'after_inventory'。", "impact": "未设计用例，待确认后补充", "current_assumption": "暂不设计用例"},
    {"id": "Q6", "question": "并发场景下 SQLite 写锁竞争导致 OperationalError(database is locked) 时，期望是重试、返回 insufficient_stock，还是向上抛出？rules.md 未定义。", "impact": "TC-16~TC-21 的失败模式判定", "current_assumption": "期望实现内部处理（重试/串行化），不向调用方抛锁错误；需确认"},
    {"id": "Q7", "question": "库存是否允许为负（作为超卖信号）还是必须硬性禁止？rules.md 第 4 条隐含禁止，但未写约束。", "impact": "TC-17/TC-18 断言强度", "current_assumption": "必须 available >= 0"},
    {"id": "Q8", "question": "「有效预占记录」是否等于 reservations 表行数？是否需要额外状态列区分有效/已释放？rules.md 表结构无状态列。", "impact": "expected_records 的统计口径", "current_assumption": "行数即有效记录数（out_of_scope 无释放）"}
  ]
}
```