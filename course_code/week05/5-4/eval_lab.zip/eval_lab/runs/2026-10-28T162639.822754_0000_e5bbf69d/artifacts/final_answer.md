## 当前有效规则来源

**`docs/rules.md`** 是唯一有效的业务契约（标题即写明“本实验的有效业务契约，版本 1”）。`AGENTS.md` 也确认了这一点：“以 docs/rules.md 为当前业务依据。不要使用 docs/archive_2024.md 覆盖当前规则。”

### 1. 幂等规则

- 相同参数重放：`docs/rules.md` 第 2 条：“同一请求编号和相同参数重复提交，只能产生一次有效预占。第一次 `replayed=false`，重试 `replayed=true`。”
- 并发重试：第 5 条：“相同编号并发重试也只能产生一次有效预占。”
- 幂等键是 `request_id`，且必须持久化：表定义“reservations(id, request_id, sku, quantity)”，第 7 条要求“request_id 必须为非空字符串”。
- 成功响应字段固定：`docs/rules.md` 末段“成功响应必须恰好包含 status、request_id、sku、quantity、replayed 五个字段”；`contracts/response.json` 的 `success_required_keys` 与 `statuses`（reserved/conflict/insufficient_stock/invalid_request）一致。

### 2. 编号冲突规则

- `docs/rules.md` 第 3 条：“同一编号携带不同 sku 或 quantity 返回 `{"status":"conflict"}`，不能再次改变库存或记录。”
- 即冲突判定维度是 (request_id) 对 (sku, quantity) 的比对；冲突时既不改库存，也不新增记录。

### 3. 回滚规则

- `docs/rules.md` 第 8 条：“`fail_at="after_inventory"` 表示在库存更新之后、写入预占记录之前注入 RuntimeError。这次操作必须整体回滚；正常路径不能忽略此参数以绕过检查。”
- 相关一致性要求：第 4 条“库存与有效预占总量一致”；第 6 条库存不足时“没有额外业务修改”。

### 4. 历史文档是否仍有效

**无效。** `docs/archive_2024.md` 标题即“历史文档：2024 版（已过期，不可作为当前规则）”，正文：“历史实现没有稳定的请求编号，曾按用户和商品做内存去重。当前实现必须遵循 docs/rules.md 的业务请求编号、持久化状态、并发与回滚要求。”因此“按用户+商品内存去重”的旧做法不能作为依据。

## 与当前代码的对照（仅陈述，未修改）

`inventory.py` 文件头自述“Teaching defect fixture. This is intentionally incorrect, not a reference.”，与上述规则存在明显差距：

- 幂等：`seen = set()  # Bug: recreated for every invocation.` —— 去重集合每次调用重建，且未查询 `reservations` 表，无法满足第 2、5 条。
- 冲突：代码中不存在 `conflict` 分支，无法满足第 3 条。
- 回滚：`raise RuntimeError(...)  # Bug: inventory was already committed.` —— 库存更新已在独立连接中提交，`fail_at` 路径不会整体回滚，违反第 8 条。
- 并发：`time.sleep(0.01)  # Simulated I/O exposes the check/update race` —— 读-改-写跨连接且无事务/锁，违反第 4 条。

## 未验证项

- 我**未运行** `run_tests`，也未执行任何 Python 代码；上述代码问题来自静态阅读，不是测试结论。
- 未验证 `contracts/response.json` 是否被任何代码或测试实际加载（仅在 `tests/test_smoke.py` 中未见引用）。
- 未评估 `initialize` 的 `INSERT OR REPLACE` 在重复初始化时对既有预占记录的影响（规则未明确要求，证据不足）。

本次操作仅为读取文件，未修改任何文件，也未进行代码修复。