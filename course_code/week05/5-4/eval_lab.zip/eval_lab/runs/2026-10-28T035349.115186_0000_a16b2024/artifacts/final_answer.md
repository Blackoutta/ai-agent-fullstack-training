## 报告

### 实际改动

**`inventory.py`（重写 `reserve`，`initialize` 增加唯一索引）**
- 幂等改为**持久化**：删除每次调用重建的内存 `seen = set()`，改为查询 `reservations` 表中该 `request_id` 的既有记录。
  - 同编号 + 同 sku/quantity → 返回 `replayed: true`，不再扣库存、不再插记录。
  - 同编号 + 不同 sku 或 quantity → 返回 `{"status": "conflict"}`，库存与记录均不变。
- `initialize` 增加 `UNIQUE INDEX idx_reservations_request_id ON reservations(request_id)`（规则允许增加索引），作为并发下的兜底；`IntegrityError` 分支按同参数/不同参数分别返回 `replayed: true` / `conflict`。
- 事务化：`isolation_level=None` + 显式 `BEGIN IMMEDIATE`，把「幂等检查 → 库存检查 → 扣减 → 写记录」放进同一事务；`fail_at="after_inventory"` 在扣减后 `ROLLBACK` 再抛 `RuntimeError`，不再出现「库存已提交但记录未写」。
- 保留原有签名、表名/列、成功响应五字段（status、request_id、sku、quantity、replayed）与失败状态分类；`quantity` 仍用 `type(...) is int` 排除 bool；未知 sku 仍返回 `invalid_request`。

**新增 `tests/test_idempotency.py`**（未修改 `tests/test_smoke.py`、docs、contracts、AGENTS.md）

### 实际执行的测试
`run_tests`（`python -m unittest discover -s tests -v`），退出码 0，`Ran 14 tests ... OK`：
- 幂等：同编号同参数重复调用（首次 `replayed=false`、重试 `replayed=true`，库存 10→8，仅 1 条记录）；连续 5 次重复；低库存下重放不扣库存；显式传默认参数的重放。
- 冲突：同编号不同 quantity、不同 sku 均返回 `conflict` 且库存/记录不变；冲突后原参数仍可重放。
- 校验：空/非字符串 request_id、0/负数/浮点/bool/字符串 quantity、未知 sku → `invalid_request`；库存不足 → `insufficient_stock` 且无副作用，之后用合法数量重试可成功。
- 回滚：`fail_at="after_inventory"` 抛 `RuntimeError` 后库存仍为 10、无记录；失败后重试成功且只产生一条记录。
- 原有 `test_smoke.test_normal_reservation` 仍通过。

### 未验证 / 不声称的内容
- **并发未验证**：没有编写或运行多线程/多进程测试。`BEGIN IMMEDIATE` + 唯一索引只是设计上的串行化手段，未实测；规则第 4、5 条（并发竞争、同编号并发重试）**未验证**。
- 未做生产可靠性、性能、超时/锁等待（`timeout=15` 下的 `database is locked` 行为）验证。
- 未验证多进程共享同一 db 文件、WAL 模式、崩溃恢复等场景。
- 独立验收由宿主执行，本报告不代替验收结论。