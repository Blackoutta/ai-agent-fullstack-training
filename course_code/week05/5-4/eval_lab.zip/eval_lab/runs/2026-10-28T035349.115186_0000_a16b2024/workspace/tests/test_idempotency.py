"""Idempotency / conflict / rollback tests for inventory.reserve."""
import sqlite3
import tempfile
import unittest
from pathlib import Path

from inventory import initialize, reserve

SUCCESS_KEYS = {"status", "request_id", "sku", "quantity", "replayed"}


class InventoryTestCase(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.path = str(Path(self._tmp.name) / "inventory.db")
        initialize(self.path, 10)

    def available(self, sku="sku-1"):
        with sqlite3.connect(self.path) as db:
            return db.execute("SELECT available FROM inventory WHERE sku=?", (sku,)).fetchone()[0]

    def reservations(self):
        with sqlite3.connect(self.path) as db:
            return db.execute(
                "SELECT request_id, sku, quantity FROM reservations ORDER BY id"
            ).fetchall()


class IdempotencyTest(InventoryTestCase):
    def test_same_request_same_params_replays_once(self):
        first = reserve(self.path, "req-1", quantity=2)
        second = reserve(self.path, "req-1", quantity=2)

        self.assertEqual(first, {"status": "reserved", "request_id": "req-1",
                                 "sku": "sku-1", "quantity": 2, "replayed": False})
        self.assertEqual(second, {"status": "reserved", "request_id": "req-1",
                                  "sku": "sku-1", "quantity": 2, "replayed": True})
        self.assertEqual(set(first), SUCCESS_KEYS)
        self.assertEqual(set(second), SUCCESS_KEYS)
        self.assertEqual(self.available(), 8)
        self.assertEqual(self.reservations(), [("req-1", "sku-1", 2)])

    def test_replay_after_many_repeats_keeps_single_record(self):
        for _ in range(5):
            reserve(self.path, "req-2", quantity=3)
        self.assertEqual(self.available(), 7)
        self.assertEqual(self.reservations(), [("req-2", "sku-1", 3)])

    def test_replay_does_not_consume_stock_when_stock_is_low(self):
        reserve(self.path, "req-3", quantity=8)
        self.assertEqual(self.available(), 2)
        replay = reserve(self.path, "req-3", quantity=8)
        self.assertEqual(replay["replayed"], True)
        self.assertEqual(self.available(), 2)
        self.assertEqual(len(self.reservations()), 1)

    def test_replay_with_explicit_default_params(self):
        reserve(self.path, "req-4")
        replay = reserve(self.path, "req-4", sku="sku-1", quantity=2)
        self.assertEqual(replay, {"status": "reserved", "request_id": "req-4",
                                  "sku": "sku-1", "quantity": 2, "replayed": True})
        self.assertEqual(self.available(), 8)


class ConflictTest(InventoryTestCase):
    def test_same_id_different_quantity_conflicts(self):
        reserve(self.path, "req-5", quantity=2)
        result = reserve(self.path, "req-5", quantity=3)
        self.assertEqual(result, {"status": "conflict"})
        self.assertEqual(self.available(), 8)
        self.assertEqual(self.reservations(), [("req-5", "sku-1", 2)])

    def test_same_id_different_sku_conflicts(self):
        reserve(self.path, "req-6", quantity=2)
        result = reserve(self.path, "req-6", sku="sku-2", quantity=2)
        self.assertEqual(result, {"status": "conflict"})
        self.assertEqual(self.available(), 8)
        self.assertEqual(self.reservations(), [("req-6", "sku-1", 2)])

    def test_conflict_then_original_params_still_replays(self):
        reserve(self.path, "req-7", quantity=2)
        self.assertEqual(reserve(self.path, "req-7", quantity=5), {"status": "conflict"})
        replay = reserve(self.path, "req-7", quantity=2)
        self.assertEqual(replay["replayed"], True)
        self.assertEqual(self.available(), 8)
        self.assertEqual(len(self.reservations()), 1)


class ValidationTest(InventoryTestCase):
    def test_invalid_inputs(self):
        cases = [
            ("", 2),
            (None, 2),
            (123, 2),
            ("req-8", 0),
            ("req-8", -1),
            ("req-8", 1.5),
            ("req-8", True),
            ("req-8", "2"),
        ]
        for request_id, quantity in cases:
            with self.subTest(request_id=request_id, quantity=quantity):
                self.assertEqual(reserve(self.path, request_id, quantity=quantity),
                                 {"status": "invalid_request"})
        self.assertEqual(self.available(), 10)
        self.assertEqual(self.reservations(), [])

    def test_unknown_sku_is_invalid(self):
        self.assertEqual(reserve(self.path, "req-9", sku="sku-404", quantity=1),
                         {"status": "invalid_request"})
        self.assertEqual(self.available(), 10)
        self.assertEqual(self.reservations(), [])

    def test_insufficient_stock_changes_nothing(self):
        self.assertEqual(reserve(self.path, "req-10", quantity=11),
                         {"status": "insufficient_stock"})
        self.assertEqual(self.available(), 10)
        self.assertEqual(self.reservations(), [])

    def test_insufficient_stock_does_not_block_later_retry(self):
        self.assertEqual(reserve(self.path, "req-11", quantity=11),
                         {"status": "insufficient_stock"})
        result = reserve(self.path, "req-11", quantity=2)
        self.assertEqual(result["replayed"], False)
        self.assertEqual(self.available(), 8)


class RollbackTest(InventoryTestCase):
    def test_fail_at_after_inventory_rolls_back(self):
        with self.assertRaises(RuntimeError):
            reserve(self.path, "req-12", quantity=2, fail_at="after_inventory")
        self.assertEqual(self.available(), 10)
        self.assertEqual(self.reservations(), [])

    def test_retry_after_injected_failure_succeeds_once(self):
        with self.assertRaises(RuntimeError):
            reserve(self.path, "req-13", quantity=2, fail_at="after_inventory")
        result = reserve(self.path, "req-13", quantity=2)
        self.assertEqual(result["replayed"], False)
        self.assertEqual(self.available(), 8)
        self.assertEqual(self.reservations(), [("req-13", "sku-1", 2)])


if __name__ == "__main__":
    unittest.main()
