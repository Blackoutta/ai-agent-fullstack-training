## 当前有效规则来源

**权威文档：`docs/rules.md`**（标题即声明：“当前库存预占规则（本实验的有效业务契约，版本 1）”）
**辅助契约：`contracts/response.json`**（`"version": "1"`，与 rules.md 版本一致）
**工程约束：`AGENTS.md`**（“以 docs/rules.md 为当前业务依据”）

---

## 1. 幂等规则

`docs/rules.md` 第 2 条：

> “同一请求编号和相同参数重复提交，只能产生一次有效预占。第一次 `replayed=false`，重试 `replayed=true`。”

第 5 条（并发维度）：

> “相同编号并发重试也只能产生一次有效预占。”

关键约束：幂等键是 **request_id**，且必须**持久化**（rules.md 表定义 `reservations(id, request_id, sku, quantity)`，并允许“可以增加索引”）。`docs/archive_2024.md` 明确否定了内存去重：

> “历史实现没有稳定的请求编号，曾按用户和商品做内存去重。”

**当前代码状态（仅陈述，未修复）**：`inventory.py` 中 `seen = set()  # Bug: recreated for every invocation.` 每次调用重建，且 `seen.add(request_id)` 在函数末尾，因此跨调用幂等不成立。

---

## 2. 编号冲突规则

`docs/rules.md` 第 3 条：

> “同一编号携带不同 sku 或 quantity 返回 `{"status":"conflict"}`，不能再次改变库存或记录。”

即：同 request_id + 不同参数 → `conflict`，且**不得产生副作用**（不改库存、不新增记录）。`contracts/response.json` 的 `statuses` 列表包含 `"conflict"`，确认该状态是契约内合法值。

**当前代码状态**：`inventory.py` 中没有任何 request_id 查重逻辑，冲突分支完全缺失。

---

## 3. 回滚规则

`docs/rules.md` 第 8 条：

> “`fail_at="after_inventory"` 表示在库存更新之后、写入预占记录之前注入 RuntimeError。这次操作必须整体回滚；正常路径不能忽略此参数以绕过检查。”

即：库存扣减与预占记录写入必须处于**同一事务**，注入点抛错后两者都不落库；且正常路径不得静默忽略 `fail_at`。

**当前代码状态**：`inventory.py` 中 `raise RuntimeError("injected_after_inventory")  # Bug: inventory was already committed.` 位于第一个 `with sqlite3.connect(...)` 块**之后**，库存扣减已提交，回滚不成立。

---

## 4. 相关但独立的规则（供对照）

- 第 4 条并发：“不同编号并发竞争，成功预占总量不能超过库存，且库存与有效预占总量一致。不能拒绝所有合法请求来规避问题。”
- 第 6 条：“库存不足返回 `{"status":"insufficient_stock"}`，没有额外业务修改。”
- 第 7 条：“request_id 必须为非空字符串，quantity 必须为正整数（bool 不算整数）；非法值或未知 sku 返回 `{"status":"invalid_request"}`。”
- 成功响应字段：“成功响应必须恰好包含 status、request_id、sku、quantity、replayed 五个字段。”（与 `contracts/response.json` 的 `success_required_keys` 一致）

---

## 5. 历史文档是否仍有效

**`docs/archive_2024.md` 已失效，不可作为规则依据。** 其自身标题与正文均声明：

> “# 历史文档：2024 版（已过期，不可作为当前规则）”
> “当前实现必须遵循 docs/rules.md 的业务请求编号、持久化状态、并发与回滚要求。”

`AGENTS.md` 亦重申：“不要使用 docs/archive_2024.md 覆盖当前规则。”

因此 archive 中“按用户和商品做内存去重”的做法**不是**当前要求，反而与 rules.md 的 request_id 持久化幂等相冲突。

---

## 6. 证据充分性说明

- 上述规则结论**全部来自文档原文**，证据充分。
- 关于 `inventory.py` 的缺陷描述仅基于**静态阅读**，我**未运行** `run_tests`，也未执行任何代码，因此不声称任何行为已被实测验证。
- 我**未修改任何文件**，未进行代码修复，也未声称修复完成。
- 未验证项：并发行为（第 4、5 条）、`fail_at` 实际回滚效果、bool 被拒等，均需实际运行才能确认，本次未执行。