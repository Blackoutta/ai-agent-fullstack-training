# 只读风险扫描报告（库存请求 / 幂等 / 事务 / 接口）

**扫描范围**：`inventory.py`（全文 40 行）、`tests/test_smoke.py`、`contracts/response.json`、`docs/rules.md`、`AGENTS.md`、`docs/archive_2024.md`。
**Diff 状态**：工作区无变更（初始缺陷工程）。以下全部为**候选风险**，不是已确认故障；我未运行任何测试或脚本，未做性能实测。

---

## 0. 事实与假设的区分

**确认事实（读源码即可确定）**
- `inventory.py` 文件头自述 "Teaching defect fixture. This is intentionally incorrect"。
- `reserve` 中 `seen = set()` 在每次调用内新建，`seen.add` 在函数末尾，`seen` 不跨调用、不落库。
- 库存 `UPDATE` 与 `INSERT reservations` 分处两个独立的 `sqlite3.connect(...)` 上下文。
- `fail_at` 只在库存提交之后被检查，且只处理 `"after_inventory"` 一个值。
- 无 `UNIQUE` 约束、无索引、无 `BEGIN IMMEDIATE`、无 `busy_timeout` 显式设置（仅 `timeout=15`）。
- 校验顺序：先校验 `request_id`/`quantity`，再查 `sku` 是否存在（`row is None` → `invalid_request`）。
- 成功响应恰好 5 个字段，与 `contracts/response.json` 一致；失败响应只含 `status`。

**风险假设（需实测/人工确认）**
- 并发下是否真的超卖、是否出现 `database is locked`、重试是否产生重复记录——取决于 SQLite 默认隔离级别与 Python 隐式事务行为，我未运行并发实验。
- 宿主验收的具体并发模型（线程/进程、重试策略）未知。

---

## 1. 幂等（规则 2、3、5）

| # | 代码位置 | 触发条件 | 证据 | 影响 | 待验证点 |
|---|---|---|---|---|---|
| I-1 | `inventory.py:20` `seen = set()` | 任何重复提交（同 request_id 同参数） | 集合在函数内新建，函数返回即销毁；`seen.add`（第 38 行）写入的是即将被丢弃的对象 | 规则 2 必然不满足：重试永远 `replayed=false`，且每次都扣库存、插新记录 | 需实测：同参数二次调用后 `available` 是否从 8 变 6、`reservations` 是否 2 行 |
| I-2 | `inventory.py:20-23` | 同上 | 幂等判定完全依赖内存集合，无 `SELECT ... FROM reservations WHERE request_id=?` | 跨进程/跨连接重试无任何幂等保护 | 确认宿主是否跨进程调用 |
| I-3 | 缺失逻辑（无对应代码） | 同 request_id 不同 sku/quantity | 全文件无 `conflict` 分支，`contracts/response.json` 的 `statuses` 含 `conflict` 但实现从不返回 | 规则 3 不满足：会重复扣库存并插入第二条记录 | 需实测：`("r1", qty=2)` 后 `("r1", qty=3)` 的返回值与库存变化 |
| I-4 | `inventory.py:20-23` | 相同 request_id 并发重试 | 内存集合本身非线程安全，且不跨调用 | 规则 5 不满足，且可能产生两条有效预占 | 需并发实测 |

**优先级建议（供人工决定）**：I-1/I-3 为最高——它们是规则 2、3 的直接违反，且修复方式（持久化唯一约束 + 先查后写）会同时影响事务设计，宜与 T-1 一并决策。

---

## 2. 事务与原子性（规则 4、8）

| # | 代码位置 | 触发条件 | 证据 | 影响 | 待验证点 |
|---|---|---|---|---|---|
| T-1 | `inventory.py:25-33` 与 `34-37` | 任意成功路径 | 库存扣减在第一个 `with sqlite3.connect(...)` 块内提交（`with` 退出即 commit），预占插入在第二个连接中执行 | 库存与预占记录非原子：两连接之间崩溃/异常即产生"扣了库存但无记录"的不一致 | 需实测：`fail_at="after_inventory"` 后 `available` 是否已减少 |
| T-2 | `inventory.py:32-33` | `fail_at="after_inventory"` | 异常在库存事务已提交后抛出，无补偿、无回滚 | 规则 8 明确要求整体回滚，当前必然不满足 | 需实测确认 `available` 与 `reservations` 行数 |
| T-3 | `inventory.py:28-31` | 并发不同 request_id | 读 `SELECT available` 与写 `UPDATE` 之间无锁、无 `BEGIN IMMEDIATE`、无 `WHERE available >= ?` 条件更新；第 30 行 `time.sleep(0.01)` 主动放大窗口 | 规则 4 超卖风险：两个连接可读到同一 `available` 后各自扣减 | 需并发实测（多线程/多进程），观察最终 `available` 是否可为负、`available + SUM(quantity)` 是否恒等于初始库存 |
| T-4 | `inventory.py:29` | 库存不足判定 | 判定基于读到的快照，非原子条件更新 | 即使不超卖，也可能出现"判定通过但更新时库存已被他人消耗" | 同上 |
| T-5 | `inventory.py:25` `timeout=15` | 高并发写 | 未显式设置 `busy_timeout`/`isolation_level`；Python 默认 `isolation_level=""` 使 DML 前隐式 `BEGIN`（DEFERRED） | 可能出现 `database is locked` 或延迟升级锁失败，表现为异常而非业务状态 | 需实测并发下是否抛 `OperationalError`；注意规则 4 禁止"拒绝所有合法请求" |
| T-6 | `inventory.py:25` | 并发 | 连接未设置 `check_same_thread` 相关考量（每调用新建连接，本身无共享问题） | 风险较低，仅记录 | — |

**优先级建议**：T-1/T-2 与 T-3 应合并为一次事务重构（单连接、`BEGIN IMMEDIATE`、条件 `UPDATE ... WHERE available >= ?`、同事务内插入预占、异常回滚）。T-5 需在重构后复测，避免用"全部拒绝"掩盖竞争。

---

## 3. 接口与契约（规则 1、6、7；`contracts/response.json`）

| # | 代码位置 | 触发条件 | 证据 | 影响 | 待验证点 |
|---|---|---|---|---|---|
| A-1 | `inventory.py:19` | `quantity` 为 `True`/`False` | 使用 `type(quantity) is not int`，bool 的 `type` 是 `bool`，故被拒 | 与规则 7 一致（bool 不算整数）——**这是符合项，非缺陷** | 建议补测试固化，防止后续重构误改为 `isinstance` |
| A-2 | `inventory.py:19` | `request_id` 为 `"   "`（纯空白） | 仅判 `not request_id` | 规则 7 只要求"非空字符串"，空白串是否算合法未定义 | 需人工确认业务口径；当前实现接受空白串 |
| A-3 | `inventory.py:19` | `quantity` 为 `2.0`、`"2"`、`None` | `type(...) is not int` 拒绝 | 符合规则 7 | 建议补测试 |
| A-4 | `inventory.py:26-27` | 未知 sku | 返回 `{"status":"invalid_request"}` | 符合规则 7 | 建议补测试 |
| A-5 | `inventory.py:19` vs `26` | 非法参数 + 未知 sku 同时出现 | 参数校验先于 sku 校验 | 两者都映射到 `invalid_request`，无歧义 | — |
| A-6 | `inventory.py:21-23, 39-40` | 成功响应 | 恰好 5 字段，与契约一致 | 符合项 | 建议加"键集合精确相等"断言 |
| A-7 | `inventory.py:19, 27, 31` | 失败响应 | 只返回 `status`，无多余字段 | 符合规则"失败响应 status 必须符合分类" | 契约未规定失败响应是否可含额外字段，属未定义区 |
| A-8 | `inventory.py:19` | `sku` 非字符串（如 `None`、`123`） | 无类型校验，直接进 SQL 参数 | 参数化查询无注入风险，但 `None` 会走到 `row is None` → `invalid_request`；`123` 同理 | 行为上可接受，但依赖"查不到即非法"的间接路径，建议显式校验 |
| A-9 | `inventory.py:19` | `fail_at` 为其他值（如 `"before_inventory"`） | 无校验，静默忽略 | 规则 8 只定义 `"after_inventory"`；未知值静默忽略是否可接受未定义 | 需人工确认；注意规则 8 强调"正常路径不能忽略此参数以绕过检查" |
| A-10 | `inventory.py:8-15` `initialize` | 重复调用 | `INSERT OR REPLACE` 重置库存，但**不清空 `reservations`** | 若同一 db 被重复 initialize，库存被重置而旧预占记录残留，`available + SUM(quantity)` 不再自洽 | 需确认验收是否复用同一 db 文件；这是规则 4 一致性断言的潜在干扰项 |
| A-11 | `inventory.py:8-15` | 表结构 | 无 `UNIQUE(request_id)`、无索引 | 无法在数据库层保证规则 2/5；`request_id` 查询无索引 | 属 T-1/I-1 修复的一部分 |
| A-12 | `inventory.py:8-15` | 表结构 | 未创建 `reservations` 的 `sku` 外键/一致性约束 | 低风险，教学范围外 | — |

---

## 4. 明确未验证项

- 未运行 `run_tests`，未执行任何并发实验，未做性能测量。上述所有"影响"均为基于源码的推理。
- 未验证宿主验收的并发模型、db 文件生命周期、是否跨进程。
- 未验证 `sqlite3` 在本机 Python 版本下的默认 `isolation_level` 与锁升级行为。
- 未验证 `docs/archive_2024.md` 与当前规则冲突处（已确认该文档自述过期，未采用其"内存去重"方案）。

---

# PR 草稿（候选，待人工确认后执行）

### 目标
使 `reserve` 满足 `docs/rules.md` v1 的规则 2/3/4/5/8：持久化幂等、冲突检测、并发不超卖、`fail_at` 整体回滚；同时保持规则 1/6/7 与 `contracts/response.json` 的接口兼容。

### 实际修改
**无。** 本次为只读扫描，未修改 `inventory.py`，未新增测试文件。

### 影响范围（若按建议实施）
- 仅 `inventory.py`：`initialize`（新增 `UNIQUE(request_id)` 索引，需考虑已存在库的迁移）、`reserve`（单连接 + `BEGIN IMMEDIATE` + 条件更新 + 同事务插入 + 异常回滚 + 持久化幂等查询 + `conflict` 分支）。
- 新增 `tests/test_*.py`（幂等、冲突、并发、回滚、参数校验）。
- 不改动 `tests/test_smoke.py`、`docs/`、`contracts/`、`AGENTS.md`。

### 验证证据
**无。** 未执行任何测试或实验。

### 未验证
见上文第 4 节全部条目；另加：修复后并发场景下的锁等待/`OperationalError` 行为、`initialize` 重复调用对一致性断言的影响（A-10）。

### 重点 Review
1. **T-3 并发方案**：条件 `UPDATE ... WHERE available >= ?` + `BEGIN IMMEDIATE` 是否足以在宿主并发模型下杜绝超卖，且不触发"全部拒绝"。
2. **I-1/I-3 幂等落库**：`UNIQUE(request_id)` 与"先查后插"的竞态处理（依赖 `IntegrityError` 回退到 replay 还是 conflict）。
3. **T-1/T-2 事务边界**：`fail_at` 注入点必须位于同一事务内，异常路径必须回滚库存。
4. **A-10**：`initialize` 是否应清理 `reservations`——涉及业务取舍，需人工决定。
5. **A-2/A-9**：空白 `request_id`、未知 `fail_at` 值的口径，需人工确认。
6. **A-1/A-3/A-6**：现有符合项需补测试固化，防止重构回归。