## 当前有效规则来源

**唯一有效业务依据：`docs/rules.md`**（标题即声明：“当前库存预占规则（本实验的有效业务契约，版本 1）”）

`AGENTS.md` 明确指向它：“以 docs/rules.md 为当前业务依据。不要使用 docs/archive_2024.md 覆盖当前规则。”

`contracts/response.json` 与 rules.md 一致（`"version": "1"`，成功键 `["status","request_id","sku","quantity","replayed"]`，状态集 `reserved/conflict/insufficient_stock/invalid_request`）。

## 1. 幂等规则

`docs/rules.md` 第 2 条：
> “同一请求编号和相同参数重复提交，只能产生一次有效预占。第一次 `replayed=false`，重试 `replayed=true`。”

第 5 条（并发维度）：
> “相同编号并发重试也只能产生一次有效预占。”

第 3 条给出幂等的边界（同编号不同参数不是重放）：
> “同一编号携带不同 sku 或 quantity 返回 `{"status":"conflict"}`，不能再次改变库存或记录。”

支撑约束：表结构固定为 `reservations(id, request_id, sku, quantity)`，且“可以增加索引”——即幂等判定必须落在持久化状态上（rules.md 未直接规定唯一索引，但“持久化状态”由 archive 文档的措辞与表结构共同指向；见下）。

## 2. 编号冲突规则

`docs/rules.md` 第 3 条（上文已引）：同 `request_id` + 不同 `sku` 或 `quantity` → `{"status":"conflict"}`，且“不能再次改变库存或记录”。

注意：rules.md 只把 **sku 或 quantity 不同** 定义为冲突；对“同编号同参数”则要求走重放路径（第 2 条）。文档未规定冲突响应是否携带额外字段——成功响应五字段要求仅适用于成功响应（“成功响应必须恰好包含 status、request_id、sku、quantity、replayed 五个字段”）。

## 3. 回滚规则

`docs/rules.md` 第 8 条：
> “`fail_at="after_inventory"` 表示在库存更新之后、写入预占记录之前注入 RuntimeError。这次操作必须整体回滚；正常路径不能忽略此参数以绕过检查。”

即库存扣减与预占记录写入必须处于同一事务边界，注入点位于两者之间，异常时两者都不保留。第 6 条补充了另一类“无副作用”要求：
> “库存不足返回 `{"status":"insufficient_stock"}`，没有额外业务修改。”

## 4. 历史文档是否仍有效

**`docs/archive_2024.md` 已失效，不可作为规则依据。** 其自身标题即声明：
> “历史文档：2024 版（已过期，不可作为当前规则）”

正文：
> “历史实现没有稳定的请求编号，曾按用户和商品做内存去重。当前实现必须遵循 docs/rules.md 的业务请求编号、持久化状态、并发与回滚要求。”

`AGENTS.md` 再次确认不得用它覆盖当前规则。因此“按用户+商品内存去重”的做法**不是**当前有效规则；当前要求是基于 `request_id` 的持久化去重。

## 5. 与当前代码的对照（仅陈述观察，未做任何修改）

`inventory.py` 文件头自述为 “Teaching defect fixture. This is intentionally incorrect, not a reference.” 对照规则可见的偏差（**仅阅读代码得出，未运行验证**）：

- 幂等：`seen = set()  # Bug: recreated for every invocation.` —— 每次调用重建，第 2/5 条无法满足。
- 冲突：代码中不存在任何 `"conflict"` 分支，第 3 条未实现。
- 回滚：`fail_at` 检查发生在 `with sqlite3.connect(...)` 块**之后**，注释自述 “Bug: inventory was already committed.”，第 8 条未满足。
- 并发：`time.sleep(0.01)` 位于读与写之间，且无事务/锁保护，第 4 条存在竞争风险。

## 未验证 / 证据不足项

- 我**没有运行** `run_tests`，也没有执行任何 Python 代码；上述代码偏差来自静态阅读，未经运行时确认。
- `docs/rules.md` 未规定：冲突响应是否需含 `replayed` 字段、`reservations` 是否应加唯一索引、`initialize` 重复调用的语义（代码用 `INSERT OR REPLACE`，文档未表态）。
- 本次任务为只读调查，**未修改任何文件，未进行代码修复**。