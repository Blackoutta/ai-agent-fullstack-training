17 个测试全部通过（exit_code=0）。

## 实际改动

**`inventory.py`（重写）**
- 幂等状态改为持久化：`reservations.request_id` 上建唯一索引 `idx_reservations_request_id`，不再使用每次调用都重建的内存 `set`。
- 重复请求处理：先按 `request_id` 查已有记录；`sku` 与 `quantity` 都相同 → 返回 `replayed=True` 的成功响应，不再扣库存、不再插记录；任一不同 → 返回 `{"status": "conflict"}`，不改库存与记录。
- 事务化：`BEGIN IMMEDIATE` 包住「查重 → 查库存 → 扣减 → 写预占」，异常路径统一 `ROLLBACK` 后重新抛出；`fail_at="after_inventory"` 现在在事务内抛出，库存更新随之回滚。
- 校验保持：`request_id` 非空字符串、`quantity` 为 `int` 且 `> 0`（`type(...) is int` 排除 `bool`）、未知 sku → `invalid_request`；库存不足 → `insufficient_stock`。
- 成功响应仍恰好 5 个字段；函数签名、表名与已有列未变（仅新增索引）。

**`tests/test_reservation.py`（新增）**：16 个用例，覆盖正常预占契约、库存不足不改状态、重复调用（同参数多次、跨连接、不重复扣减）、同编号不同 quantity/sku 冲突、冲突后仍可正常重放、不同编号各自预占、非法 request_id/quantity/未知 sku、非法输入不产生幂等记录、`fail_at` 回滚与失败后重试。

## 实际执行的验证
- 执行 `run_tests`（`python -m unittest discover -s tests -v`）：17 tests，OK，exit_code=0，含原有 `test_smoke.py`。
- 未修改 `tests/test_smoke.py`、`docs/`、`contracts/`、`AGENTS.md`。

## 未验证内容
- 并发场景（规则 4、5 的多线程/多进程竞争）未编写也未运行测试，仅通过 `BEGIN IMMEDIATE` + 唯一索引做了设计层面的处理，**不声称已验证**。
- 未做性能、长时间运行或跨平台（非 SQLite 默认配置）验证。
- 独立验收由宿主执行，本报告不代替其结论。