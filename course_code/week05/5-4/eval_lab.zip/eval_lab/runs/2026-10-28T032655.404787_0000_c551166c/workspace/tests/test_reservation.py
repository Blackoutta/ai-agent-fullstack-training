"""Tests for idempotent reservation, conflict detection and rollback."""
import sqlite3
import tempfile
import unittest
from pathlib import Path

from inventory import initialize, reserve


class ReservationTestCase(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.path = str(Path(self._tmp.name) / "inventory.db")
        initialize(self.path, 10)

    def available(self, sku="sku-1"):
        with sqlite3.connect(self.path) as db:
            return db.execute(
                "SELECT available FROM inventory WHERE sku=?", (sku,)
            ).fetchone()[0]

    def reservation_rows(self):
        with sqlite3.connect(self.path) as db:
            return db.execute(
                "SELECT request_id, sku, quantity FROM reservations ORDER BY id"
            ).fetchall()


class NormalReservationTest(ReservationTestCase):
    def test_normal_reservation_contract(self):
        result = reserve(self.path, "req-1", quantity=2)
        self.assertEqual(
            result,
            {
                "status": "reserved",
                "request_id": "req-1",
                "sku": "sku-1",
                "quantity": 2,
                "replayed": False,
            },
        )
        self.assertEqual(set(result), {"status", "request_id", "sku", "quantity", "replayed"})
        self.assertEqual(self.available(), 8)
        self.assertEqual(self.reservation_rows(), [("req-1", "sku-1", 2)])

    def test_insufficient_stock_does_not_modify_state(self):
        result = reserve(self.path, "req-big", quantity=11)
        self.assertEqual(result, {"status": "insufficient_stock"})
        self.assertEqual(self.available(), 10)
        self.assertEqual(self.reservation_rows(), [])

    def test_insufficient_stock_after_partial_use(self):
        reserve(self.path, "req-a", quantity=8)
        result = reserve(self.path, "req-b", quantity=3)
        self.assertEqual(result, {"status": "insufficient_stock"})
        self.assertEqual(self.available(), 2)
        self.assertEqual(self.reservation_rows(), [("req-a", "sku-1", 8)])


class DuplicateRequestTest(ReservationTestCase):
    def test_same_request_same_params_is_replayed_once(self):
        first = reserve(self.path, "dup", quantity=2)
        second = reserve(self.path, "dup", quantity=2)
        third = reserve(self.path, "dup", quantity=2)

        self.assertFalse(first["replayed"])
        self.assertTrue(second["replayed"])
        self.assertTrue(third["replayed"])
        self.assertEqual(second["status"], "reserved")
        self.assertEqual(third["status"], "reserved")
        self.assertEqual(self.available(), 8)
        self.assertEqual(self.reservation_rows(), [("dup", "sku-1", 2)])

    def test_replay_does_not_consume_stock_again(self):
        reserve(self.path, "dup", quantity=4)
        for _ in range(5):
            reserve(self.path, "dup", quantity=4)
        self.assertEqual(self.available(), 6)
        self.assertEqual(len(self.reservation_rows()), 1)

    def test_replay_survives_new_connection(self):
        reserve(self.path, "dup", quantity=2)
        # A fresh call uses a new connection; state must come from the database.
        result = reserve(self.path, "dup", quantity=2)
        self.assertTrue(result["replayed"])
        self.assertEqual(self.available(), 8)

    def test_same_request_different_quantity_is_conflict(self):
        reserve(self.path, "dup", quantity=2)
        result = reserve(self.path, "dup", quantity=3)
        self.assertEqual(result, {"status": "conflict"})
        self.assertEqual(self.available(), 8)
        self.assertEqual(self.reservation_rows(), [("dup", "sku-1", 2)])

    def test_same_request_different_sku_is_conflict(self):
        reserve(self.path, "dup", quantity=2)
        result = reserve(self.path, "dup", sku="sku-2", quantity=2)
        self.assertEqual(result, {"status": "conflict"})
        self.assertEqual(self.available(), 8)
        self.assertEqual(self.reservation_rows(), [("dup", "sku-1", 2)])

    def test_conflict_does_not_block_later_replay(self):
        reserve(self.path, "dup", quantity=2)
        self.assertEqual(reserve(self.path, "dup", quantity=5), {"status": "conflict"})
        self.assertTrue(reserve(self.path, "dup", quantity=2)["replayed"])
        self.assertEqual(self.available(), 8)

    def test_different_request_ids_both_reserve(self):
        self.assertFalse(reserve(self.path, "a", quantity=2)["replayed"])
        self.assertFalse(reserve(self.path, "b", quantity=2)["replayed"])
        self.assertEqual(self.available(), 6)
        self.assertEqual(len(self.reservation_rows()), 2)


class InvalidInputTest(ReservationTestCase):
    def test_invalid_request_ids(self):
        for bad in ("", None, 123, b"bytes", ["x"]):
            with self.subTest(request_id=bad):
                self.assertEqual(reserve(self.path, bad), {"status": "invalid_request"})
        self.assertEqual(self.available(), 10)
        self.assertEqual(self.reservation_rows(), [])

    def test_invalid_quantities(self):
        for bad in (0, -1, 1.5, "2", True, False, None):
            with self.subTest(quantity=bad):
                self.assertEqual(
                    reserve(self.path, "q", quantity=bad), {"status": "invalid_request"}
                )
        self.assertEqual(self.available(), 10)
        self.assertEqual(self.reservation_rows(), [])

    def test_unknown_sku(self):
        result = reserve(self.path, "sku-x", sku="sku-404", quantity=1)
        self.assertEqual(result, {"status": "invalid_request"})
        self.assertEqual(self.reservation_rows(), [])

    def test_invalid_input_does_not_create_idempotency_record(self):
        self.assertEqual(reserve(self.path, "r", quantity=0), {"status": "invalid_request"})
        result = reserve(self.path, "r", quantity=2)
        self.assertEqual(result["status"], "reserved")
        self.assertFalse(result["replayed"])
        self.assertEqual(self.available(), 8)


class RollbackTest(ReservationTestCase):
    def test_fail_at_after_inventory_rolls_back(self):
        with self.assertRaises(RuntimeError):
            reserve(self.path, "boom", quantity=3, fail_at="after_inventory")
        self.assertEqual(self.available(), 10)
        self.assertEqual(self.reservation_rows(), [])

    def test_retry_after_failure_succeeds_normally(self):
        with self.assertRaises(RuntimeError):
            reserve(self.path, "boom", quantity=3, fail_at="after_inventory")
        result = reserve(self.path, "boom", quantity=3)
        self.assertEqual(result["status"], "reserved")
        self.assertFalse(result["replayed"])
        self.assertEqual(self.available(), 7)
        self.assertEqual(self.reservation_rows(), [("boom", "sku-1", 3)])


if __name__ == "__main__":
    unittest.main()
