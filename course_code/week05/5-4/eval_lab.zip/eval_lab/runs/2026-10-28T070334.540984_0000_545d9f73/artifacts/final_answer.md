```json
{
  "scope": {
    "human_confirmed_scope": [
      "inventory.py 的预占、幂等、事务与接口响应"
    ],
    "high_risks": [
      "相同请求重复业务效果",
      "并发超卖",
      "异常部分提交",
      "接口不兼容"
    ],
    "out_of_scope": [
      "支付确认与释放",
      "多仓库",
      "生产压测结论"
    ],
    "required_reviews": [
      "修改了什么",
      "关键分支在哪里",
      "旧调用是否兼容"
    ],
    "status": "教学范围；迁移到实际项目时需业务负责人重新确认",
    "basis": "docs/rules.md（版本 1）为唯一有效业务契约；docs/archive_2024.md 不作为依据",
    "code_under_test": "inventory.py: initialize(db_path, stock=10) / reserve(db_path, request_id, sku='sku-1', quantity=2, fail_at=None)",
    "observed_defect_surfaces": [
      "reserve 内 seen = set() 每次调用重建，幂等分支不可达（重复请求会二次扣减）",
      "库存检查与 UPDATE 之间无事务/无原子条件更新，且 time.sleep(0.01) 放大 check-then-act 竞态",
      "fail_at='after_inventory' 在库存已提交后才抛错，预占记录未写入，形成部分提交",
      "reservations 表无 request_id 唯一约束，无法在数据库层兜底幂等",
      "conflict 分支完全缺失：同 request_id 不同 sku/quantity 不会返回 conflict",
      "quantity 校验用 type(quantity) is not int，bool 会被拒绝（符合规则），但 sku 非字符串/未知 sku 的判定路径需逐项确认",
      "成功响应字段目前恰好 5 个，但失败响应仅含 status，需确认与 contracts/response.json 的兼容边界"
    ]
  },
  "risk_review": [
    {
      "risk": "相同请求重复业务效果",
      "why": "seen 集合为局部变量，幂等判断永远为假；重复提交会再次扣库存并插入第二条 reservations 记录",
      "impact": "库存被重复扣减，有效预占总量与库存不一致，重试语义（replayed=true）失效",
      "detection": "顺序重复提交 + 相同 request_id 并发提交 + 直接查询 reservations 行数与 available",
      "priority": "P0"
    },
    {
      "risk": "并发超卖",
      "why": "SELECT available 与 UPDATE 分属不同连接/不同事务，无 WHERE available>=? 条件更新，无 BEGIN IMMEDIATE，sleep 放大窗口",
      "impact": "available 变为负数或成功预占总量超过初始库存",
      "detection": "不同 request_id 多线程并发，断言 sum(quantity of reservations) <= stock 且 available == stock - sum",
      "priority": "P0"
    },
    {
      "risk": "异常部分提交",
      "why": "库存 UPDATE 在第一个 with 块内已提交，fail_at 抛错发生在第二个连接之前",
      "impact": "库存被扣但无预占记录，重试会再次扣减，账实不符",
      "detection": "fail_at='after_inventory' 后断言 available 与 reservations 均回到调用前状态，且异常向上抛出",
      "priority": "P0"
    },
    {
      "risk": "接口不兼容",
      "why": "成功响应必须恰好 5 个字段；失败 status 必须落在 4 个分类内；函数签名/表名/列名不得变更",
      "impact": "旧调用方解析失败或误判业务结果",
      "detection": "键集合精确断言、status 枚举断言、签名与表结构断言、旧 smoke 调用方式回归",
      "priority": "P0"
    },
    {
      "risk": "参数冲突未拦截",
      "why": "conflict 分支缺失，同 request_id 不同参数会走正常预占路径",
      "impact": "同一业务请求产生两笔预占，库存被多扣",
      "detection": "同 request_id 不同 sku / 不同 quantity 的顺序与并发提交",
      "priority": "P0"
    },
    {
      "risk": "非法参数与未知 sku 分类错误",
      "why": "sku 未知时返回 invalid_request 依赖 row is None 分支，但 sku 类型异常、空串、None 等路径未显式覆盖",
      "impact": "错误分类导致调用方重试策略错误",
      "detection": "参数化非法输入矩阵，断言 status 且断言无副作用",
      "priority": "P1"
    },
    {
      "risk": "库存不足路径产生副作用",
      "why": "insufficient_stock 分支在 UPDATE 之前返回，理论上无副作用，但需验证不写 reservations、不改 available",
      "impact": "虚假预占记录",
      "detection": "库存不足调用后断言 available 不变、reservations 行数不变",
      "priority": "P1"
    },
    {
      "risk": "以拒绝所有请求规避并发问题",
      "why": "规则明确禁止用全量拒绝来规避超卖",
      "impact": "看似不超卖但业务不可用",
      "detection": "并发用例断言成功笔数 > 0 且成功总量等于库存可容纳量（在库存充足场景下应全部成功）",
      "priority": "P1"
    }
  ],
  "decision_table": [
    {
      "group": "DT-1 单次调用参数合法性（顺序执行，无并发）",
      "conditions": ["request_id 合法", "quantity 合法", "sku 已知", "库存充足"],
      "rules": [
        {"id": "R1.1", "request_id": "非空字符串", "quantity": "正整数", "sku": "sku-1", "stock": ">= quantity", "expected_status": "reserved", "replayed": false, "side_effect": "available -= quantity；新增 1 条 reservations"},
        {"id": "R1.2", "request_id": "非空字符串", "quantity": "正整数", "sku": "sku-1", "stock": "< quantity", "expected_status": "insufficient_stock", "replayed": null, "side_effect": "无任何修改"},
        {"id": "R1.3", "request_id": "非空字符串", "quantity": "正整数", "sku": "未知 sku", "stock": "任意", "expected_status": "invalid_request", "replayed": null, "side_effect": "无任何修改"},
        {"id": "R1.4", "request_id": "空字符串 / 非字符串 / None", "quantity": "任意", "sku": "任意", "stock": "任意", "expected_status": "invalid_request", "replayed": null, "side_effect": "无任何修改"},
        {"id": "R1.5", "request_id": "非空字符串", "quantity": "0 / 负数 / bool / float / 字符串 / None", "sku": "任意", "stock": "任意", "expected_status": "invalid_request", "replayed": null, "side_effect": "无任何修改"}
      ]
    },
    {
      "group": "DT-2 幂等重放（顺序执行，同 request_id）",
      "conditions": ["首次调用已成功", "第二次调用参数是否一致"],
      "rules": [
        {"id": "R2.1", "second_call": "同 request_id + 同 sku + 同 quantity", "expected_status": "reserved", "replayed": true, "side_effect": "available 不变；reservations 行数不变"},
        {"id": "R2.2", "second_call": "同 request_id + 不同 quantity", "expected_status": "conflict", "replayed": null, "side_effect": "available 不变；reservations 行数不变"},
        {"id": "R2.3", "second_call": "同 request_id + 不同 sku", "expected_status": "conflict", "replayed": null, "side_effect": "available 不变；reservations 行数不变"},
        {"id": "R2.4", "second_call": "同 request_id + 同参数，但首次为 insufficient_stock", "expected_status": "待确认（见 open_questions Q1）", "replayed": null, "side_effect": "待确认"}
      ]
    },
    {
      "group": "DT-3 并发：不同 request_id 竞争同一库存（时序敏感，单独成组，不并入静态组合）",
      "conditions": ["N 个不同 request_id", "同一 sku", "总需求 vs 库存"],
      "rules": [
        {"id": "R3.1", "N": "N * quantity <= stock", "expected": "全部 reserved，replayed=false", "invariant": "available == stock - N*quantity；reservations 行数 == N"},
        {"id": "R3.2", "N": "N * quantity > stock", "expected": "成功数 == floor(stock/quantity)，其余 insufficient_stock", "invariant": "available >= 0；sum(reservations.quantity) == stock - available；成功数 > 0（禁止全量拒绝）"},
        {"id": "R3.3", "N": "N * quantity == stock 边界", "expected": "全部 reserved", "invariant": "available == 0；sum(reservations.quantity) == stock"}
      ]
    },
    {
      "group": "DT-4 并发：相同 request_id 重试（时序敏感，单独成组）",
      "conditions": ["M 个线程使用同一 request_id 与相同参数"],
      "rules": [
        {"id": "R4.1", "M": "M >= 2，参数完全一致", "expected": "恰好 1 个 replayed=false，其余 replayed=true 或 conflict（待确认 Q2）", "invariant": "available == stock - quantity；reservations 中该 request_id 行数 == 1"},
        {"id": "R4.2", "M": "M >= 2，参数不一致（同 id 不同 quantity）", "expected": "至多 1 个 reserved，其余 conflict", "invariant": "reservations 中该 request_id 行数 <= 1；available 只被扣减一次"}
      ]
    },
    {
      "group": "DT-5 异常与回滚",
      "conditions": ["fail_at 取值", "调用前状态"],
      "rules": [
        {"id": "R5.1", "fail_at": "after_inventory", "expected": "RuntimeError 向上抛出", "invariant": "available == 调用前值；reservations 行数 == 调用前行数（整体回滚）"},
        {"id": "R5.2", "fail_at": "after_inventory 后重试同 request_id 同参数", "expected": "reserved, replayed=false", "invariant": "available == stock - quantity；reservations 行数 == 1（证明回滚未留下脏状态）"},
        {"id": "R5.3", "fail_at": "None（正常路径）", "expected": "reserved", "invariant": "不得因忽略 fail_at 参数而绕过注入检查"},
        {"id": "R5.4", "fail_at": "未知值（如 'after_reservation'）", "expected": "待确认（见 open_questions Q3）", "invariant": "待确认"}
      ]
    },
    {
      "group": "DT-6 接口契约",
      "conditions": ["响应类型", "字段集合", "签名与表结构"],
      "rules": [
        {"id": "R6.1", "case": "成功响应", "expected": "dict，键集合恰好 {status, request_id, sku, quantity, replayed}", "invariant": "status == 'reserved'；request_id/sku/quantity 回显入参；replayed 为 bool"},
        {"id": "R6.2", "case": "失败响应", "expected": "dict，status ∈ {conflict, insufficient_stock, invalid_request}", "invariant": "status 不得为 reserved 或未定义值"},
        {"id": "R6.3", "case": "函数签名", "expected": "initialize(db_path, stock=10)；reserve(db_path, request_id, sku='sku-1', quantity=2, fail_at=None)", "invariant": "参数名与默认值不变，旧位置参数调用可用"},
        {"id": "R6.4", "case": "表结构", "expected": "inventory(sku, available)；reservations(id, request_id, sku, quantity)", "invariant": "已有列不删不改名；允许新增索引"},
        {"id": "R6.5", "case": "旧调用兼容", "expected": "tests/test_smoke.py 的调用方式（initialize(path,10) + reserve(path,'smoke',quantity=2)）仍返回原期望 dict", "invariant": "不得修改 test_smoke.py"}
      ]
    }
  ],
  "cases": [
    {
      "name": "TC-01 正常预占（基线）",
      "preconditions": ["initialize(db, stock=10)", "无历史预占"],
      "actions": ["reserve(db, 'req-1', sku='sku-1', quantity=2)"],
      "expected_response": {"status": "reserved", "request_id": "req-1", "sku": "sku-1", "quantity": 2, "replayed": false},
      "expected_inventory": {"available": 8},
      "expected_records": {"reservations_count": 1, "rows": [{"request_id": "req-1", "sku": "sku-1", "quantity": 2}]},
      "risk": "接口不兼容（成功响应字段集合）"
    },
    {
      "name": "TC-02 库存恰好等于需求量（边界）",
      "preconditions": ["initialize(db, stock=2)"],
      "actions": ["reserve(db, 'req-edge', quantity=2)"],
      "expected_response": {"status": "reserved", "request_id": "req-edge", "sku": "sku-1", "quantity": 2, "replayed": false},
      "expected_inventory": {"available": 0},
      "expected_records": {"reservations_count": 1},
      "risk": "边界条件（>= 与 > 判定）"
    },
    {
      "name": "TC-03 库存不足",
      "preconditions": ["initialize(db, stock=1)"],
      "actions": ["reserve(db, 'req-short', quantity=2)"],
      "expected_response": {"status": "insufficient_stock"},
      "expected_inventory": {"available": 1},
      "expected_records": {"reservations_count": 0},
      "risk": "库存不足路径产生副作用"
    },
    {
      "name": "TC-04 库存耗尽后再请求",
      "preconditions": ["initialize(db, stock=2)", "已成功预占 2 件（req-a）"],
      "actions": ["reserve(db, 'req-b', quantity=1)"],
      "expected_response": {"status": "insufficient_stock"},
      "expected_inventory": {"available": 0},
      "expected_records": {"reservations_count": 1, "only_request_id": "req-a"},
      "risk": "库存不足路径产生副作用"
    },
    {
      "name": "TC-05 相同 request_id 相同参数重复提交（顺序）",
      "preconditions": ["initialize(db, stock=10)", "已成功预占 req-dup quantity=2"],
      "actions": ["reserve(db, 'req-dup', sku='sku-1', quantity=2)"],
      "expected_response": {"status": "reserved", "request_id": "req-dup", "sku": "sku-1", "quantity": 2, "replayed": true},
      "expected_inventory": {"available": 8},
      "expected_records": {"reservations_count": 1},
      "risk": "相同请求重复业务效果（P0）"
    },
    {
      "name": "TC-06 相同 request_id 重复提交三次（顺序）",
      "preconditions": ["initialize(db, stock=10)", "已成功预占 req-dup3 quantity=2"],
      "actions": ["reserve(db, 'req-dup3', quantity=2)", "reserve(db, 'req-dup3', quantity=2)"],
      "expected_response": {"first_retry": {"status": "reserved", "replayed": true}, "second_retry": {"status": "reserved", "replayed": true}},
      "expected_inventory": {"available": 8},
      "expected_records": {"reservations_count": 1},
      "risk": "相同请求重复业务效果（P0）"
    },
    {
      "name": "TC-07 相同 request_id 不同 quantity（参数冲突）",
      "preconditions": ["initialize(db, stock=10)", "已成功预占 req-c1 quantity=2"],
      "actions": ["reserve(db, 'req-c1', sku='sku-1', quantity=3)"],
      "expected_response": {"status": "conflict"},
      "expected_inventory": {"available": 8},
      "expected_records": {"reservations_count": 1, "rows": [{"request_id": "req-c1", "quantity": 2}]},
      "risk": "参数冲突未拦截（P0）"
    },
    {
      "name": "TC-08 相同 request_id 不同 sku（参数冲突）",
      "preconditions": ["initialize(db, stock=10)", "已成功预占 req-c2 sku='sku-1' quantity=2"],
      "actions": ["reserve(db, 'req-c2', sku='sku-2', quantity=2)"],
      "expected_response": {"status": "conflict"},
      "expected_inventory": {"available": 8, "sku_2_available": "不存在或未变"},
      "expected_records": {"reservations_count": 1},
      "risk": "参数冲突未拦截（P0）"
    },
    {
      "name": "TC-09 冲突请求不得改变库存（冲突后再次同参数重放）",
      "preconditions": ["initialize(db, stock=10)", "已成功预占 req-c3 quantity=2", "已发生一次 conflict（quantity=5）"],
      "actions": ["reserve(db, 'req-c3', quantity=2)"],
      "expected_response": {"status": "reserved", "replayed": true},
      "expected_inventory": {"available": 8},
      "expected_records": {"reservations_count": 1},
      "risk": "参数冲突未拦截 + 幂等状态被污染"
    },
    {
      "name": "TC-10 非法 request_id：空字符串",
      "preconditions": ["initialize(db, stock=10)"],
      "actions": ["reserve(db, '', quantity=2)"],
      "expected_response": {"status": "invalid_request"},
      "expected_inventory": {"available": 10},
      "expected_records": {"reservations_count": 0},
      "risk": "非法参数分类错误"
    },
    {
      "name": "TC-11 非法 request_id：None / 非字符串",
      "preconditions": ["initialize(db, stock=10)"],
      "actions": ["reserve(db, None, quantity=2)", "reserve(db, 123, quantity=2)"],
      "expected_response": {"status": "invalid_request"},
      "expected_inventory": {"available": 10},
      "expected_records": {"reservations_count": 0},
      "risk": "非法参数分类错误"
    },
    {
      "name": "TC-12 非法 quantity 矩阵",
      "preconditions": ["initialize(db, stock=10)"],
      "actions": ["reserve(db, 'q-0', quantity=0)", "reserve(db, 'q-neg', quantity=-1)", "reserve(db, 'q-bool', quantity=True)", "reserve(db, 'q-float', quantity=2.0)", "reserve(db, 'q-str', quantity='2')", "reserve(db, 'q-none', quantity=None)"],
      "expected_response": {"each": {"status": "invalid_request"}},
      "expected_inventory": {"available": 10},
      "expected_records": {"reservations_count": 0},
      "risk": "非法参数分类错误（bool 不算整数）"
    },
    {
      "name": "TC-13 未知 sku",
      "preconditions": ["initialize(db, stock=10)"],
      "actions": ["reserve(db, 'sku-x', sku='sku-999', quantity=2)"],
      "expected_response": {"status": "invalid_request"},
      "expected_inventory": {"available": 10},
      "expected_records": {"reservations_count": 0},
      "risk": "非法参数分类错误"
    },
    {
      "name": "TC-14 不同 request_id 并发，总需求小于库存",
      "preconditions": ["initialize(db, stock=10)", "N=4 个不同 request_id，quantity=2"],
      "actions": ["4 线程同时 reserve(db, f'req-p{i}', quantity=2)"],
      "expected_response": {"all": {"status": "reserved", "replayed": false}},
      "expected_inventory": {"available": 2},
      "expected_records": {"reservations_count": 4, "sum_quantity": 8},
      "risk": "并发超卖（P0）+ 禁止全量拒绝"
    },
    {
      "name": "TC-15 不同 request_id 并发，总需求超过库存（超卖核心用例）",
      "preconditions": ["initialize(db, stock=10)", "N=8 个不同 request_id，quantity=2（总需求 16）"],
      "actions": ["8 线程同时 reserve(db, f'req-o{i}', quantity=2)"],
      "expected_response": {"reserved_count": 5, "insufficient_stock_count": 3},
      "expected_inventory": {"available": 0, "assert_available_gte_0": true},
      "expected_records": {"reservations_count": 5, "sum_quantity": 10, "invariant": "sum(reservations.quantity) == 10 - available"},
      "risk": "并发超卖（P0）"
    },
    {
      "name": "TC-16 不同 request_id 并发，总需求恰好等于库存（边界）",
      "preconditions": ["initialize(db, stock=10)", "N=5 个不同 request_id，quantity=2"],
      "actions": ["5 线程同时 reserve(db, f'req-e{i}', quantity=2)"],
      "expected_response": {"all": {"status": "reserved"}},
      "expected_inventory": {"available": 0},
      "expected_records": {"reservations_count": 5, "sum_quantity": 10},
      "risk": "并发超卖（P0）+ 边界"
    },
    {
      "name": "TC-17 相同 request_id 相同参数并发重试",
      "preconditions": ["initialize(db, stock=10)", "M=6 线程使用同一 request_id 'req-same'，quantity=2"],
      "actions": ["6 线程同时 reserve(db, 'req-same', quantity=2)"],
      "expected_response": {"exactly_one": {"status": "reserved", "replayed": false}, "others": "reserved+replayed=true 或 conflict（见 Q2）"},
      "expected_inventory": {"available": 8},
      "expected_records": {"reservations_count": 1, "rows_for_request_id": 1},
      "risk": "相同请求重复业务效果（P0）+ 并发"
    },
    {
      "name": "TC-18 相同 request_id 不同参数并发（冲突竞态）",
      "preconditions": ["initialize(db, stock=10)", "M=4 线程：2 个 quantity=2，2 个 quantity=3，同一 request_id 'req-mix'"],
      "actions": ["4 线程同时 reserve(db, 'req-mix', quantity=2 或 3)"],
      "expected_response": {"reserved_count": 1, "conflict_count": 3},
      "expected_inventory": {"available": "10 - 胜出请求的 quantity（8 或 7）"},
      "expected_records": {"reservations_count": 1, "rows_for_request_id": 1},
      "risk": "参数冲突未拦截（P0）+ 并发"
    },
    {
      "name": "TC-19 异常注入 after_inventory 整体回滚",
      "preconditions": ["initialize(db, stock=10)", "无历史预占"],
      "actions": ["reserve(db, 'req-fail', quantity=2, fail_at='after_inventory')"],
      "expected_response": {"raises": "RuntimeError"},
      "expected_inventory": {"available": 10},
      "expected_records": {"reservations_count": 0},
      "risk": "异常部分提交（P0）"
    },
    {
      "name": "TC-20 异常回滚后同 request_id 重试",
      "preconditions": ["initialize(db, stock=10)", "TC-19 已执行并回滚"],
      "actions": ["reserve(db, 'req-fail', quantity=2)"],
      "expected_response": {"status": "reserved", "request_id": "req-fail", "sku": "sku-1", "quantity": 2, "replayed": false},
      "expected_inventory": {"available": 8},
      "expected_records": {"reservations_count": 1},
      "risk": "异常部分提交（P0）+ 幂等状态污染"
    },
    {
      "name": "TC-21 异常注入不得被正常路径忽略",
      "preconditions": ["initialize(db, stock=10)"],
      "actions": ["reserve(db, 'req-fail2', quantity=2, fail_at='after_inventory')", "reserve(db, 'req-ok', quantity=2, fail_at=None)"],
      "expected_response": {"first": "RuntimeError", "second": {"status": "reserved", "replayed": false}},
      "expected_inventory": {"available": 8},
      "expected_records": {"reservations_count": 1, "only_request_id": "req-ok"},
      "risk": "异常部分提交（P0）+ 绕过检查"
    },
    {
      "name": "TC-22 异常注入与并发混合（回滚不污染其他请求）",
      "preconditions": ["initialize(db, stock=10)", "1 线程 fail_at='after_inventory'，3 线程正常 quantity=2"],
      "actions": ["4 线程同时调用 reserve（不同 request_id）"],
      "expected_response": {"fail_thread": "RuntimeError", "normal_threads": {"status": "reserved"}},
      "expected_inventory": {"available": 4},
      "expected_records": {"reservations_count": 3, "no_row_for_failed_request_id": true},
      "risk": "异常部分提交（P0）+ 并发超卖（P0）"
    },
    {
      "name": "TC-23 成功响应字段集合精确匹配",
      "preconditions": ["initialize(db, stock=10)"],
      "actions": ["reserve(db, 'req-contract', quantity=2)"],
      "expected_response": {"type": "dict", "keys_exactly": ["status", "request_id", "sku", "quantity", "replayed"], "status": "reserved", "replayed_type": "bool"},
      "expected_inventory": {"available": 8},
      "expected_records": {"reservations_count": 1},
      "risk": "接口不兼容（P0）"
    },
    {
      "name": "TC-24 失败响应 status 枚举合法",
      "preconditions": ["initialize(db, stock=1)", "已成功预占 req-e1 quantity=1"],
      "actions": ["reserve(db, 'req-e2', quantity=1)", "reserve(db, '', quantity=1)", "reserve(db, 'req-e1', quantity=2)"],
      "expected_response": {"statuses": ["insufficient_stock", "invalid_request", "conflict"], "all_in_enum": ["reserved", "conflict", "insufficient_stock", "invalid_request"]},
      "expected_inventory": {"available": 0},
      "expected_records": {"reservations_count": 1},
      "risk": "接口不兼容（P0）"
    },
    {
      "name": "TC-25 函数签名与默认值兼容",
      "preconditions": ["导入 inventory 模块"],
      "actions": ["inspect.signature(initialize)", "inspect.signature(reserve)"],
      "expected_response": {"initialize": "(db_path, stock=10)", "reserve": "(db_path, request_id, sku='sku-1', quantity=2, fail_at=None)"},
      "expected_inventory": {"n_a": true},
      "expected_records": {"n_a": true},
      "risk": "接口不兼容（P0）"
    },
    {
      "name": "TC-26 表结构与已有列兼容",
      "preconditions": ["initialize(db, stock=10)"],
      "actions": ["PRAGMA table_info(inventory)", "PRAGMA table_info(reservations)"],
      "expected_response": {"inventory_columns": ["sku", "available"], "reservations_columns": ["id", "request_id", "sku", "quantity"], "extra_indexes_allowed": true},
      "expected_inventory": {"available": 10},
      "expected_records": {"reservations_count": 0},
      "risk": "接口不兼容（P0）"
    },
    {
      "name": "TC-27 旧调用方式回归（等价 test_smoke 场景）",
      "preconditions": ["initialize(path, 10)"],
      "actions": ["reserve(path, 'smoke', quantity=2)"],
      "expected_response": {"status": "reserved", "request_id": "smoke", "sku": "sku-1", "quantity": 2, "replayed": false},
      "expected_inventory": {"available": 8},
      "expected_records": {"reservations_count": 1},
      "risk": "接口不兼容（P0）+ 旧调用兼容"
    },
    {
      "name": "TC-28 位置参数调用兼容",
      "preconditions": ["initialize(db, stock=10)"],
      "actions": ["reserve(db, 'req-pos', 'sku-1', 2)"],
      "expected_response": {"status": "reserved", "request_id": "req-pos", "sku": "sku-1", "quantity": 2, "replayed": false},
      "expected_inventory": {"available": 8},
      "expected_records": {"reservations_count": 1},
      "risk": "接口不兼容（P0）"
    },
    {
      "name": "TC-29 多请求顺序混合后账实一致",
      "preconditions": ["initialize(db, stock=10)"],
      "actions": ["reserve(db,'m1',quantity=2)", "reserve(db,'m2',quantity=3)", "reserve(db,'m1',quantity=2)", "reserve(db,'m3',quantity=6)", "reserve(db,'m2',quantity=3)"],
      "expected_response": {"m1_first": "reserved", "m2_first": "reserved", "m1_retry": "reserved+replayed=true", "m3": "insufficient_stock", "m2_retry": "reserved+replayed=true"},
      "expected_inventory": {"available": 5},
      "expected_records": {"reservations_count": 2, "sum_quantity": 5, "invariant": "sum(reservations.quantity) == 10 - available"},
      "risk": "相同请求重复业务效果（P0）+ 库存不足副作用"
    },
    {
      "name": "TC-30 幂等状态跨连接持久（新连接重放）",
      "preconditions": ["initialize(db, stock=10)", "已成功预占 req-persist quantity=2"],
      "actions": ["关闭并重新打开数据库连接后 reserve(db, 'req-persist', quantity=2)"],
      "expected_response": {"status": "reserved", "replayed": true},
      "expected_inventory": {"available": 8},
      "expected_records": {"reservations_count": 1},
      "risk": "相同请求重复业务效果（P0）——幂等状态必须持久化而非进程内内存"
    }
  ],
  "coverage_matrix": [
    {"category": "正常", "cases": ["TC-01", "TC-02", "TC-27", "TC-28"], "covered_risks": ["接口不兼容"], "status": "设计完成，未执行"},
    {"category": "重复（幂等）", "cases": ["TC-05", "TC-06", "TC-29", "TC-30"], "covered_risks": ["相同请求重复业务效果"], "status": "设计完成，未执行"},
    {"category": "参数冲突", "cases": ["TC-07", "TC-08", "TC-09", "TC-18"], "covered_risks": ["参数冲突未拦截", "相同请求重复业务效果"], "status": "设计完成，未执行"},
    {"category": "不同请求并发", "cases": ["TC-14", "TC-15", "TC-16"], "covered_risks": ["并发超卖", "禁止全量拒绝"], "status": "设计完成，未执行"},
    {"category": "相同请求并发", "cases": ["TC-17", "TC-18"], "covered_risks": ["相同请求重复业务效果", "参数冲突未拦截"], "status": "设计完成，未执行"},
    {"category": "异常回滚", "cases": ["TC-19", "TC-20", "TC-21", "TC-22"], "covered_risks": ["异常部分提交"], "status": "设计完成，未执行"},
    {"category": "契约", "cases": ["TC-23", "TC-24", "TC-25", "TC-26", "TC-27", "TC-28"], "covered_risks": ["接口不兼容"], "status": "设计完成，未执行"},
    {"category": "非法参数/未知 sku", "cases": ["TC-10", "TC-11", "TC-12", "TC-13"], "covered_risks": ["非法参数分类错误"], "status": "设计完成，未执行"},
    {"category": "库存不足", "cases": ["TC-03", "TC-04", "TC-29"], "covered_risks": ["库存不足路径产生副作用"], "status": "设计完成，未执行"},
    {"category": "账实一致不变量", "cases": ["TC-15", "TC-16", "TC-22", "TC-29"], "covered_risks": ["并发超卖", "异常部分提交"], "status": "设计完成，未执行"}
  ],
  "open_questions": [
    {
      "id": "Q1",
      "question": "首次调用因 insufficient_stock 失败后，同一 request_id 在库存恢复（或后续补货）后再次提交，应返回 reserved(replayed=false) 还是视为已处理返回 conflict/insufficient_stock？",
      "why_it_matters": "决定失败请求是否占用 request_id 幂等键，直接影响 DT-2 R2.4 与重试语义",
      "current_rule_coverage": "docs/rules.md 第 2、6 条未覆盖失败请求的幂等状态