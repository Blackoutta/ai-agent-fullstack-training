All 14 tests pass (exit code 0).

## 实际改动

**`inventory.py`（唯一修改的现有文件）**
- 幂等去重改为持久化：`initialize` 增加 `UNIQUE INDEX idx_reservations_request_id ON reservations(request_id)`（规则允许增加索引），`reserve` 在事务内查询 `reservations` 判断该 `request_id` 是否已存在，不再使用每次调用重建的内存 `set`。
- 相同编号 + 相同 `sku`/`quantity` → 返回 `replayed=True`，不重复扣减、不新增记录；相同编号 + 不同 `sku` 或 `quantity` → `{"status": "conflict"}`，库存与记录不变。
- 整个「查重 → 查库存 → 扣减 → 写预占」放入单个 `BEGIN IMMEDIATE` 事务，显式 `COMMIT`/`ROLLBACK`，异常路径回滚后重新抛出；移除了原先两次独立连接导致的「库存已提交、记录未写入」问题，`fail_at="after_inventory"` 现在整体回滚。
- 校验保持/收紧：`request_id` 非空字符串；`quantity` 必须为正整数且 `bool` 不算整数（原实现用 `type(quantity) is not int` 已排除 bool，现改为显式 `isinstance(quantity, bool)` 判断，语义不变）；未知 sku → `invalid_request`；库存不足 → `insufficient_stock`。
- 成功响应仍恰好包含 `status, request_id, sku, quantity, replayed` 五个字段；函数签名、表名与列未变。

**新增 `tests/test_reservation.py`**（13 个用例）：重复调用/多次重试只扣一次、库存耗尽后重放不扣减、成功响应字段集合、同编号不同 quantity/sku 冲突且不改状态、冲突后合法重放仍可用、非法 request_id/quantity（含 bool）、未知 sku、库存不足、`fail_at` 回滚、失败后同编号重试成功。

## 实际执行的验证

- `run_tests`（`python -m unittest discover -s tests -v`）：14 个测试全部通过，退出码 0，包含原有 `tests/test_smoke.py::test_normal_reservation`。
- 未修改 `tests/test_smoke.py`、`docs/`、`contracts/`、`AGENTS.md`（指纹见工具输出）。

## 未验证内容

- **并发**：规则第 4、5 条（多线程/多进程竞争、同编号并发重试）未编写也未执行并发测试，`BEGIN IMMEDIATE` + 唯一索引只是设计上的防护，未实测。
- **回滚**：仅验证了 `fail_at="after_inventory"` 这一注入路径的回滚；其他异常/崩溃场景未测。
- 独立验收由宿主执行，本报告不代替验收结论。