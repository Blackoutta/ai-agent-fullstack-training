## 当前有效规则（只读调查结果）

### 权威来源与效力

| 文档 | 效力 | 依据原文 |
|---|---|---|
| `docs/rules.md` | **当前有效**（版本 1） | “当前库存预占规则（本实验的有效业务契约，版本 1）” |
| `contracts/response.json` | 当前有效（与 rules.md 一致） | `"version": "1"`，`statuses: reserved/conflict/insufficient_stock/invalid_request` |
| `docs/archive_2024.md` | **已过期，不可作为规则** | 标题即“历史文档：2024 版（已过期，不可作为当前规则）”；“当前实现必须遵循 docs/rules.md 的业务请求编号、持久化状态、并发与回滚要求。” |
| `AGENTS.md` | 当前有效（工程约束） | “以 docs/rules.md 为当前业务依据。不要使用 docs/archive_2024.md 覆盖当前规则。” |

历史文档是否仍有效：**否**。它只说明旧实现“没有稳定的请求编号，曾按用户和商品做内存去重”，属于背景信息，不能用来推导当前行为。

### 1. 幂等规则

- 规则 2（`docs/rules.md`）：“同一请求编号和相同参数重复提交，只能产生一次有效预占。第一次 `replayed=false`，重试 `replayed=true`。”
- 规则 5：“相同编号并发重试也只能产生一次有效预占。”
- 规则 3 界定了幂等的边界：“同一编号携带不同 sku 或 quantity 返回 `{"status":"conflict"}`，不能再次改变库存或记录。”
- 持久化要求（archive 文档的指向句）：“持久化状态”——即去重状态必须落在 SQLite 中，不能是进程内内存。

### 2. 编号冲突规则

- 冲突判定键 = `request_id` + `sku` + `quantity`；参数不同即冲突，且**不得**再改库存或写记录（规则 3）。
- 冲突响应只要求 `status` 为 `conflict`；成功响应才强制“恰好包含 status、request_id、sku、quantity、replayed 五个字段”。
- 校验优先级：规则 7 要求 `request_id` 为非空字符串、`quantity` 为正整数且“bool 不算整数”，非法值或未知 sku → `invalid_request`。

### 3. 回滚规则

- 规则 8：“`fail_at="after_inventory"` 表示在库存更新之后、写入预占记录之前注入 RuntimeError。这次操作必须整体回滚；正常路径不能忽略此参数以绕过检查。”
- 规则 6 补充无副作用要求：“库存不足返回 `{"status":"insufficient_stock"}`，没有额外业务修改。”
- 规则 4 要求并发下“库存与有效预占总量一致”，即库存扣减与预占记录必须原子提交。

### 4. 与当前代码的差距（仅陈述，未修改任何文件）

`inventory.py` 自述为 “Teaching defect fixture. This is intentionally incorrect, not a reference.”，与上述规则存在明显不符：

- 幂等：`seen = set()  # Bug: recreated for every invocation.` —— 去重集合每次调用重建，规则 2/5 无法满足。
- 冲突：代码中不存在任何 `conflict` 分支，规则 3 未实现。
- 回滚：`raise RuntimeError(...)  # Bug: inventory was already committed.` —— 库存更新已在独立连接中提交，规则 8 的“整体回滚”未实现。
- 并发：`time.sleep(0.01)  # Simulated I/O exposes the check/update race` —— 读-改-写非原子，规则 4 存在超卖风险。
- 校验：`type(quantity) is not int` 恰好排除了 bool，符合规则 7；但未知 sku 的判定依赖 `inventory` 表查询，未做 sku 白名单校验。

### 未验证项（明确说明）

- 我**未运行**任何测试（包括 `run_tests`），因此上述代码差距是基于静态阅读的推断，不是执行结果。
- 我**未修改** `inventory.py`、`tests/`、`docs/`、`contracts/`、`AGENTS.md`，也未声称完成任何修复。
- 规则 4/5 的并发行为、规则 8 的回滚行为均未实测；`tests/test_smoke.py` 仅覆盖规则 1 的正常路径，通过与否不能代表其余规则成立（`docs/rules.md`：“初始 smoke 测试通过不代表上述缺陷已解决。”）。