## 结论：当前有效规则来源

**唯一有效业务契约：`docs/rules.md`（标题自述“本实验的有效业务契约，版本 1”）**
辅助证据：`contracts/response.json`（`"version": "1"`，状态枚举与成功字段列表）、`AGENTS.md`（“以 docs/rules.md 为当前业务依据”）。

### 1. 幂等规则

`docs/rules.md` 第 2、5 条：
- “同一请求编号和相同参数重复提交，只能产生一次有效预占。第一次 `replayed=false`，重试 `replayed=true`。”
- “相同编号并发重试也只能产生一次有效预占。”

要点：幂等键是 **request_id**（不是用户+商品），且必须跨进程/跨调用持久有效（第 5 条要求并发下也成立，因此内存 `set` 不满足）。成功响应必须恰好含 `status, request_id, sku, quantity, replayed` 五个字段（rules.md “成功响应必须恰好包含…”；contracts/response.json `success_required_keys`）。

### 2. 编号冲突规则

`docs/rules.md` 第 3 条：
- “同一编号携带不同 sku 或 quantity 返回 `{"status":"conflict"}`，不能再次改变库存或记录。”

即：同 request_id + 相同参数 → 幂等重放（`replayed=true`）；同 request_id + 不同 sku/quantity → `conflict`，且不得产生任何库存或记录副作用。`conflict` 属于合法状态枚举（contracts/response.json `statuses`）。

### 3. 回滚规则

`docs/rules.md` 第 8 条：
- “`fail_at="after_inventory"` 表示在库存更新之后、写入预占记录之前注入 RuntimeError。这次操作必须整体回滚；正常路径不能忽略此参数以绕过检查。”

即库存扣减与预占记录写入必须在同一事务内，异常时整体回滚（不能出现“库存已提交、记录未写”的中间态）。

### 4. 相关约束（与上述规则耦合）

- 第 4 条：“不同编号并发竞争，成功预占总量不能超过库存，且库存与有效预占总量一致。不能拒绝所有合法请求来规避问题。”
- 第 6 条：库存不足 → `{"status":"insufficient_stock"}`，“没有额外业务修改”。
- 第 7 条：request_id 非空字符串、quantity 正整数（“bool 不算整数”）、未知 sku → `{"status":"invalid_request"}`。
- “函数签名、数据库表名和已有列、返回结构必须保持兼容。…可以增加索引。”

### 5. 历史文档是否仍有效

**`docs/archive_2024.md` 已失效，不可作为规则依据。** 原文：
- 标题：“历史文档：2024 版（已过期，不可作为当前规则）”
- “历史实现没有稳定的请求编号，曾按用户和商品做内存去重。”
- “当前实现必须遵循 docs/rules.md 的业务请求编号、持久化状态、并发与回滚要求。”

`AGENTS.md` 亦明确：“不要使用 docs/archive_2024.md 覆盖当前规则。”因此“按用户+商品内存去重”的旧做法与现行规则直接冲突，必须弃用。

### 6. 现状与规则的差距（仅陈述，未修改任何文件）

`inventory.py` 文件首行自述 “Teaching defect fixture. This is intentionally incorrect, not a reference.”，代码中可见与上述规则不符之处：
- `seen = set()  # Bug: recreated for every invocation.` → 幂等不成立（违反第 2、5 条）。
- 无任何 `conflict` 分支 → 违反第 3 条。
- 库存 UPDATE 与 reservations INSERT 分属两个 `sqlite3.connect` 事务，`fail_at="after_inventory"` 在库存已提交后抛错（注释 “Bug: inventory was already committed.”）→ 违反第 8 条。
- 无并发保护（`time.sleep(0.01)` 暴露 check/update 竞态）→ 违反第 4 条。

### 未验证项（明确说明）

- 我**未执行**任何测试（未运行 `python -m unittest discover -s tests -v`），因此不对当前代码是否通过 `tests/test_smoke.py` 或任何场景作断言。
- 上述差距来自静态阅读代码与文档，未做运行时验证。
- 本次为只读调查：**未修改任何文件，未执行修复**。