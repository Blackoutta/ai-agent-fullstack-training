## 当前有效规则（依据 `docs/rules.md`，版本 1）

`docs/rules.md` 开头明确说明它是“本实验的有效业务契约，版本 1”。`AGENTS.md` 也规定“以 docs/rules.md 为当前业务依据”。

### 1. 幂等规则
- 规则 2：“同一请求编号和相同参数重复提交，只能产生一次有效预占。第一次 `replayed=false`，重试 `replayed=true`。”
- 规则 5：“相同编号并发重试也只能产生一次有效预占。”
- 规则 3 界定了幂等的边界：“同一编号携带不同 sku 或 quantity 返回 `{"status":"conflict"}`，不能再次改变库存或记录。”
- 支撑幂等的持久化结构来自“调用方式”一节：“表：inventory(sku, available)，reservations(id, request_id, sku, quantity)。可以增加索引。”也就是说，去重状态必须落在数据库中，不能只放在进程内存里。

### 2. 编号冲突规则
- 冲突判定依据是 `request_id` 相同，但 `sku` 或 `quantity` 不同，见规则 3 的原文（同上）。
- 冲突的后果是“不能再次改变库存或记录”，即冲突请求不得写入库存，也不得新增预占行。
- 失败响应的 status 必须落在 `contracts/response.json` 列出的集合内：`["reserved", "conflict", "insufficient_stock", "invalid_request"]`，其中 `conflict` 是独立分类，不能与 `invalid_request` 混用。
- 成功响应字段约束：“成功响应必须恰好包含 status、request_id、sku、quantity、replayed 五个字段。”（`contracts/response.json` 的 `success_required_keys` 与此一致。）

### 3. 回滚规则
- 规则 8：“`fail_at="after_inventory"` 表示在库存更新之后、写入预占记录之前注入 RuntimeError。这次操作必须整体回滚；正常路径不能忽略此参数以绕过检查。”
- 规则 6 补充了无副作用要求：“库存不足返回 `{"status":"insufficient_stock"}`，没有额外业务修改。”
- 规则 4 要求库存与记录一致：“成功预占总量不能超过库存，且库存与有效预占总量一致。不能拒绝所有合法请求来规避问题。”

### 4. 历史文档是否仍有效
`docs/archive_2024.md` **已失效**，不能作为规则依据。原文标题即写明：“历史文档：2024 版（已过期，不可作为当前规则）”；正文说明“历史实现没有稳定的请求编号，曾按用户和商品做内存去重”，并要求“当前实现必须遵循 docs/rules.md 的业务请求编号、持久化状态、并发与回滚要求”。因此，按用户和商品做内存去重的旧做法不能作为当前幂等依据。

## 与当前代码的对照（仅陈述观察，未做任何修改）
`inventory.py` 文件头自述为 “Teaching defect fixture. This is intentionally incorrect, not a reference.”，与上述规则存在明显差距：
- 幂等：`seen = set()  # Bug: recreated for every invocation.`，去重集合在每次调用时重建，因此规则 2 和规则 5 无法满足。
- 冲突：代码中没有任何 `conflict` 分支，规则 3 未实现。
- 回滚：`raise RuntimeError(...)  # Bug: inventory was already committed.`，库存更新已在 `with` 块内提交，规则 8 的“整体回滚”未实现。
- 并发：`time.sleep(0.01)  # Simulated I/O exposes the check/update race in this fixture.`，检查与更新之间存在竞态，规则 4 未保证。

## 未验证项与说明
- 本次仅执行了只读操作（列目录、读取 `AGENTS.md`、`docs/rules.md`、`docs/archive_2024.md`、`inventory.py`、`contracts/response.json`、`tests/test_smoke.py`）。
- **未运行任何测试**（未执行 `run_tests` 或 `python -m unittest`），因此不对当前测试通过或失败状态作任何断言。
- 未修改任何文件，未进行代码修复。
- 规则 1、7 的具体实现细节（如 `bool` 不算整数、未知 sku 判定）在代码中部分可见，但未通过运行验证。