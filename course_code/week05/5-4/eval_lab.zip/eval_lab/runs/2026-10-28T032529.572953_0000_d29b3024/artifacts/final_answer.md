## 报告

### 实际改动

**`inventory.py`（唯一修改的现有文件）**
- 删除每次调用都重建的内存 `seen = set()`，改为以 `reservations` 表为持久化幂等依据：在事务内先按 `request_id` 查询已有记录。
  - 参数（sku、quantity）一致 → 返回 `replayed=true`，不再扣库存、不再插入记录。
  - 参数不一致 → 返回 `{"status":"conflict"}`，库存与记录均不变。
- 冲突判定放在 sku 存在性检查之前，保证“同编号不同 sku”返回 `conflict` 而非 `invalid_request`。
- 库存检查、扣减、预占插入合并进单个 `BEGIN IMMEDIATE` 事务（`isolation_level=None` 手动控制），异常路径显式 `ROLLBACK` 后重新抛出，因此 `fail_at="after_inventory"` 的 RuntimeError 会整体回滚。
- `initialize` 增加 `reservations(request_id)` 唯一索引（规则允许增加索引），表名/列名/函数签名/返回结构保持不变。
- 非法输入校验保留并补充 sku 类型/非空校验；成功响应仍恰好 5 个字段。

**新增 `tests/test_reservation_idempotency.py`**（12 个用例中的 11 个）：重复相同参数只扣一次、多次重放稳定、库存为 0 时重放不扣减、成功响应字段集合、同编号不同 quantity/sku 冲突且不改状态、冲突后相同参数仍可重放、不同编号各自预占、库存不足无副作用、非法输入（空/None/非字符串 request_id，0/负数/浮点/bool/字符串 quantity，未知 sku）、`fail_at` 回滚后重试为全新预占。

### 实际执行的测试
- `run_tests`（`python -m unittest discover -s tests -v`）第 1 次：**失败**，`test_same_request_different_sku_conflicts` 返回 `invalid_request` 而非 `conflict`（sku 存在性检查先于幂等检查）。
- 修正检查顺序后第 2 次：**12 tests, OK**（exit_code 0），含原有 `tests/test_smoke.py`。

### 未验证 / 说明
- 并发场景（规则 4、5：不同编号竞争、相同编号并发重试）**未验证**：没有编写多线程/多进程测试，也未实际运行；`BEGIN IMMEDIATE` + 唯一索引只是设计意图，不能声称已验证。
- 回滚仅验证了 `fail_at="after_inventory"` 这一注入点；其他异常路径未单独测试。
- 未修改 `tests/test_smoke.py`、`docs/`、`contracts/`、`AGENTS.md`；未访问工程外路径或参考实现。独立验收由宿主执行。