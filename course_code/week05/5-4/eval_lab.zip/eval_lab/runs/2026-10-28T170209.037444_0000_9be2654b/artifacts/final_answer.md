```json
{
  "scope": {
    "human_confirmed_scope": ["inventory.py 的预占、幂等、事务与接口响应"],
    "in_scope_files": ["inventory.py", "tests/test_*.py（仅新增）"],
    "read_only_references": ["docs/rules.md（版本1，唯一有效业务契约）", "contracts/response.json", "tests/test_smoke.py", "AGENTS.md"],
    "explicitly_not_authoritative": ["docs/archive_2024.md（已过期，不得作为规则来源）"],
    "out_of_scope": ["支付确认与释放", "多仓库", "生产压测结论"],
    "status": "教学范围；迁移到实际项目时需业务负责人重新确认",
    "test_design_only": "本输出为测试设计，未执行任何用例，不含已执行/已通过结论"
  },

  "risk_review": {
    "review_answers": {
      "修改了什么": "设计层面要求：任何修复必须限定在 inventory.py；表名/列名/函数签名/返回结构不变；允许新增索引。测试需能定位改动是否越界（例如新增列、改返回键、改默认参数）。",
      "关键分支在哪里": [
        "参数校验分支：request_id 非空字符串、quantity 为正整数且 bool 不算整数、未知 sku",
        "幂等判定分支：request_id 已存在且参数相同 → replayed=true；参数不同 → conflict",
        "库存判定分支：available < quantity → insufficient_stock",
        "库存更新与预占记录写入的事务边界（含 fail_at='after_inventory' 注入点）",
        "并发分支：不同 request_id 竞争同一 sku 行；相同 request_id 并发重试"
      ],
      "旧调用是否兼容": "需验证：reserve(db_path, request_id) 仅传两个位置参数仍可用；sku/quantity/fail_at 关键字调用仍可用；initialize(db_path) 默认 stock=10；返回字典键集合与 contracts/response.json 一致；reservations 表既有列仍存在。"
    },
    "risk_items": [
      {
        "id": "R1",
        "risk": "相同请求重复业务效果（幂等失效）",
        "code_evidence": "reserve 内 `seen = set()` 每次调用重建，且 `seen.add(request_id)` 只作用于本次调用的局部变量；进程内去重永远不命中，跨调用无持久化幂等键。",
        "impact": "同一 request_id 重复提交会重复扣减库存并插入多条 reservations 记录，直接违反规则2。",
        "severity": "high",
        "covered_by_cases": ["C-IDEM-01", "C-IDEM-02", "C-IDEM-03", "C-CONC-SAME-01", "C-CONC-SAME-02"]
      },
      {
        "id": "R2",
        "risk": "并发超卖（check-then-act 竞态）",
        "code_evidence": "先 SELECT available 判断，再 `time.sleep(0.01)`，再无条件 `UPDATE inventory SET available=available-?`；无事务级锁、无 `WHERE available>=?` 条件更新、无 BEGIN IMMEDIATE。",
        "impact": "多个不同 request_id 并发时都读到旧库存，全部通过校验，最终 available 变负或与有效预占总量不一致，违反规则4。",
        "severity": "high",
        "covered_by_cases": ["C-CONC-DIFF-01", "C-CONC-DIFF-02", "C-CONC-DIFF-03", "C-CONC-DIFF-04"]
      },
      {
        "id": "R3",
        "risk": "异常部分提交（事务不原子）",
        "code_evidence": "库存 UPDATE 在第一个 `with sqlite3.connect(...)` 块内提交；`fail_at='after_inventory'` 的 RuntimeError 在块外抛出，此时库存已扣减但 reservations 未写入。",
        "impact": "注入异常后库存永久少扣、无对应预占记录，库存与记录不一致，违反规则8。",
        "severity": "high",
        "covered_by_cases": ["C-TX-01", "C-TX-02", "C-TX-03", "C-TX-04"]
      },
      {
        "id": "R4",
        "risk": "接口不兼容（返回结构/签名/表结构漂移）",
        "code_evidence": "当前成功响应恰好 5 键；修复幂等/并发时容易新增字段（如 id、created_at）或改 status 取值，破坏 contracts/response.json。",
        "impact": "旧调用方按固定键集合或 status 枚举解析会失败，违反规则「成功响应必须恰好包含五个字段」。",
        "severity": "high",
        "covered_by_cases": ["C-CONTRACT-01", "C-CONTRACT-02", "C-CONTRACT-03", "C-CONTRACT-04", "C-CONTRACT-05"]
      },
      {
        "id": "R5",
        "risk": "参数冲突未识别（同编号不同参数被当作重放）",
        "code_evidence": "当前无任何持久化 request_id 查询，conflict 分支不可达；若修复时只按 request_id 判重而不比对 sku/quantity，会把冲突误判为 replayed=true。",
        "impact": "不同业务意图被静默合并，库存与记录语义错误，违反规则3。",
        "severity": "high",
        "covered_by_cases": ["C-CONFLICT-01", "C-CONFLICT-02", "C-CONFLICT-03", "C-CONFLICT-04"]
      },
      {
        "id": "R6",
        "risk": "参数校验漏洞（bool 被当作整数、未知 sku 分类错误）",
        "code_evidence": "`type(quantity) is not int` 已排除 bool（True 的 type 是 bool），但未知 sku 与非法参数共用 invalid_request，需确认分类边界；quantity=0/负数/浮点/字符串需逐一验证。",
        "impact": "非法请求可能进入扣减路径或返回错误 status，违反规则7。",
        "severity": "medium",
        "covered_by_cases": ["C-VALID-01", "C-VALID-02", "C-VALID-03", "C-VALID-04", "C-VALID-05", "C-VALID-06"]
      },
      {
        "id": "R7",
        "risk": "以拒绝所有请求规避并发问题",
        "code_evidence": "规则4明确「不能拒绝所有合法请求来规避问题」；若用全局锁+直接返回 insufficient_stock 或 invalid_request 可让并发测试「看起来一致」。",
        "impact": "库存充足时合法请求被拒，业务不可用。",
        "severity": "medium",
        "covered_by_cases": ["C-CONC-DIFF-02", "C-CONC-DIFF-03"]
      },
      {
        "id": "R8",
        "risk": "fail_at 参数被忽略以绕过回滚检查",
        "code_evidence": "规则8要求正常路径不能忽略 fail_at；若修复时删除注入点，C-TX-01 会「通过」但检查失效。",
        "impact": "回滚能力无法被验证，异常部分提交风险被掩盖。",
        "severity": "high",
        "covered_by_cases": ["C-TX-01", "C-TX-02", "C-TX-03"]
      },
      {
        "id": "R9",
        "risk": "库存不足路径产生副作用",
        "code_evidence": "insufficient_stock 分支在 UPDATE 之前 return，当前无副作用；但若修复改为「先写记录后校验」会引入脏记录。",
        "impact": "失败请求留下 reservations 记录或改动库存，违反规则6。",
        "severity": "medium",
        "covered_by_cases": ["C-STOCK-01", "C-STOCK-02", "C-STOCK-03"]
      },
      {
        "id": "R10",
        "risk": "测试自身不可靠（并发用例偶发通过、断言只看返回值不看库状态）",
        "code_evidence": "并发用例若只断言返回 status 而不校验 available 与 SUM(quantity) 一致性，会漏掉超卖。",
        "impact": "假阴性，风险被误判为已覆盖。",
        "severity": "medium",
        "covered_by_cases": ["C-CONC-DIFF-01", "C-CONC-DIFF-04", "C-CONC-SAME-01"]
      }
    ]
  },

  "decision_table": {
    "note": "按业务判定维度分组。并发维度不压成静态组合：并发用例以「时序/交错」为独立分组，用屏障与重复轮次表达，而非把并发折叠成参数组合。",
    "groups": [
      {
        "group": "DT-1 参数校验与请求合法性",
        "conditions": ["request_id 为非空字符串", "quantity 为正整数且非 bool", "sku 存在于 inventory"],
        "rules": [
          {"rule": "DT1-R1", "request_id": "合法", "quantity": "合法", "sku": "存在", "expected_status": "reserved 或 insufficient_stock（取决于库存）", "side_effect": "按正常路径"},
          {"rule": "DT1-R2", "request_id": "空字符串/None/非字符串", "quantity": "任意", "sku": "任意", "expected_status": "invalid_request", "side_effect": "无库存改动、无记录"},
          {"rule": "DT1-R3", "request_id": "合法", "quantity": "0/负数/浮点/字符串/bool", "sku": "任意", "expected_status": "invalid_request", "side_effect": "无库存改动、无记录"},
          {"rule": "DT1-R4", "request_id": "合法", "quantity": "合法", "sku": "不存在", "expected_status": "invalid_request", "side_effect": "无库存改动、无记录"}
        ]
      },
      {
        "group": "DT-2 幂等与冲突（同一 request_id 的重复提交，串行）",
        "conditions": ["request_id 是否已存在有效预占", "本次 sku 与已存记录是否相同", "本次 quantity 与已存记录是否相同"],
        "rules": [
          {"rule": "DT2-R1", "already_reserved": false, "sku_same": "n/a", "qty_same": "n/a", "expected_status": "reserved", "replayed": false, "side_effect": "扣减一次、写一条记录"},
          {"rule": "DT2-R2", "already_reserved": true, "sku_same": true, "qty_same": true, "expected_status": "reserved", "replayed": true, "side_effect": "不再扣减、不新增记录"},
          {"rule": "DT2-R3", "already_reserved": true, "sku_same": false, "qty_same": true, "expected_status": "conflict", "replayed": "不适用（失败响应无 replayed）", "side_effect": "无任何改动"},
          {"rule": "DT2-R4", "already_reserved": true, "sku_same": true, "qty_same": false, "expected_status": "conflict", "replayed": "不适用", "side_effect": "无任何改动"},
          {"rule": "DT2-R5", "already_reserved": true, "sku_same": false, "qty_same": false, "expected_status": "conflict", "replayed": "不适用", "side_effect": "无任何改动"}
        ]
      },
      {
        "group": "DT-3 库存充足性",
        "conditions": ["available 与 quantity 的关系", "request_id 是否已存在"],
        "rules": [
          {"rule": "DT3-R1", "available": ">= quantity", "already_reserved": false, "expected_status": "reserved", "side_effect": "available -= quantity，写一条记录"},
          {"rule": "DT3-R2", "available": "== quantity", "already_reserved": false, "expected_status": "reserved", "side_effect": "available 变为 0"},
          {"rule": "DT3-R3", "available": "< quantity", "already_reserved": false, "expected_status": "insufficient_stock", "side_effect": "无改动、无记录"},
          {"rule": "DT3-R4", "available": "0", "already_reserved": false, "expected_status": "insufficient_stock", "side_effect": "无改动、无记录"},
          {"rule": "DT3-R5", "available": "< quantity", "already_reserved": true（同参数）", "expected_status": "reserved", "replayed": true, "side_effect": "幂等优先于库存判定，不因当前库存不足而改判"}
        ]
      },
      {
        "group": "DT-4 事务与异常回滚",
        "conditions": ["fail_at 取值", "异常发生点相对库存更新与记录写入的位置"],
        "rules": [
          {"rule": "DT4-R1", "fail_at": null, "expected": "正常提交", "side_effect": "库存与记录同时生效"},
          {"rule": "DT4-R2", "fail_at": "after_inventory", "expected": "抛出 RuntimeError", "side_effect": "库存与记录均不生效（整体回滚）"},
          {"rule": "DT4-R3", "fail_at": "after_inventory 且该 request_id 已成功预占过", "expected": "抛出 RuntimeError 或按幂等返回 replayed=true（见 open_questions Q3）", "side_effect": "不得产生第二次扣减或第二条记录"},
          {"rule": "DT4-R4", "fail_at": "未知取值（如 'unknown'）", "expected": "见 open_questions Q4", "side_effect": "不得出现部分提交"}
        ]
      },
      {
        "group": "DT-5 并发时序（独立分组，不折叠为静态参数组合）",
        "conditions": ["并发请求的 request_id 是否相同", "并发请求参数是否相同", "库存是否足以容纳全部请求", "交错点（读-改-写窗口）"],
        "rules": [
          {"rule": "DT5-R1", "request_id": "不同", "params": "各自合法", "stock": "不足以容纳全部", "expected": "成功数 × quantity <= 初始库存；失败者为 insufficient_stock；available == 初始库存 - SUM(成功 quantity)；记录数 == 成功数"},
          {"rule": "DT5-R2", "request_id": "不同", "params": "各自合法", "stock": "足以容纳全部", "expected": "全部 reserved，不得为规避竞态而拒绝合法请求"},
          {"rule": "DT5-R3", "request_id": "相同", "params": "完全相同", "stock": "充足", "expected": "恰好一次有效预占；一个 replayed=false，其余 replayed=true；库存只扣一次；记录恰好一条"},
          {"rule": "DT5-R4", "request_id": "相同", "params": "不同（sku 或 quantity）", "stock": "任意", "expected": "至多一个 reserved，其余 conflict；库存与记录只反映那一次"}
        ]
      },
      {
        "group": "DT-6 接口契约",
        "conditions": ["响应类型", "键集合", "status 取值", "函数签名与表结构"],
        "rules": [
          {"rule": "DT6-R1", "response": "成功", "expected": "键集合恰为 {status, request_id, sku, quantity, replayed}，无多余键"},
          {"rule": "DT6-R2", "response": "失败", "expected": "status ∈ {conflict, insufficient_stock, invalid_request}"},
          {"rule": "DT6-R3", "signature": "reserve(db_path, request_id) 位置参数调用", "expected": "可用，默认 sku='sku-1'、quantity=2"},
          {"rule": "DT6-R4", "schema": "inventory(sku, available) 与 reservations(id, request_id, sku, quantity)", "expected": "既有列全部保留（允许新增索引）"},
          {"rule": "DT6-R5", "initialize": "initialize(db_path) 不传 stock", "expected": "默认 stock=10"}
        ]
      }
    ]
  },

  "cases": [
    {
      "name": "C-NORMAL-01 正常预占单次",
      "preconditions": ["initialize(db, 10)", "无历史记录"],
      "actions": ["reserve(db, 'req-1', quantity=2)"],
      "expected_response": {"status": "reserved", "request_id": "req-1", "sku": "sku-1", "quantity": 2, "replayed": false},
      "expected_inventory": "available == 8",
      "expected_records": "reservations 中 request_id='req-1' 恰好 1 条，quantity=2",
      "risk": "R4（成功响应键集合）"
    },
    {
      "name": "C-NORMAL-02 连续不同请求预占至库存边界",
      "preconditions": ["initialize(db, 10)"],
      "actions": ["reserve(db,'a',quantity=4)", "reserve(db,'b',quantity=6)"],
      "expected_response": ["两次均 status=reserved，replayed=false"],
      "expected_inventory": "available == 0",
      "expected_records": "2 条记录，SUM(quantity)=10",
      "risk": "R2/R9"
    },
    {
      "name": "C-IDEM-01 相同请求相同参数串行重复提交",
      "preconditions": ["initialize(db, 10)", "reserve(db,'dup',quantity=2) 已成功"],
      "actions": ["reserve(db,'dup',quantity=2)"],
      "expected_response": {"status": "reserved", "request_id": "dup", "sku": "sku-1", "quantity": 2, "replayed": true},
      "expected_inventory": "available 仍为 8（不二次扣减）",
      "expected_records": "request_id='dup' 仍恰好 1 条",
      "risk": "R1（当前 seen 局部集合导致必然失败）"
    },
    {
      "name": "C-IDEM-02 相同请求重复三次",
      "preconditions": ["initialize(db, 10)"],
      "actions": ["reserve(db,'dup3',quantity=3) 连续调用 3 次"],
      "expected_response": "第1次 replayed=false，第2、3次 replayed=true，status 均为 reserved",
      "expected_inventory": "available == 7",
      "expected_records": "恰好 1 条记录",
      "risk": "R1"
    },
    {
      "name": "C-IDEM-03 幂等跨连接/跨进程重建（持久化幂等键）",
      "preconditions": ["initialize(db, 10)", "reserve(db,'persist',quantity=2) 成功", "重新导入/新建连接后再次调用（模拟进程重启，内存 set 丢失）"],
      "actions": ["reserve(db,'persist',quantity=2)"],
      "expected_response": "status=reserved, replayed=true",
      "expected_inventory": "available == 8",
      "expected_records": "恰好 1 条记录",
      "risk": "R1（内存去重无法满足持久化要求）"
    },
    {
      "name": "C-CONFLICT-01 同编号不同 quantity",
      "preconditions": ["initialize(db, 10)", "reserve(db,'c1',quantity=2) 成功"],
      "actions": ["reserve(db,'c1',quantity=5)"],
      "expected_response": {"status": "conflict"},
      "expected_inventory": "available 仍为 8",
      "expected_records": "仍 1 条，quantity=2",
      "risk": "R5"
    },
    {
      "name": "C-CONFLICT-02 同编号不同 sku",
      "preconditions": ["initialize(db, 10)", "reserve(db,'c2',quantity=2) 成功", "inventory 中额外存在 sku-2（见 open_questions Q1）"],
      "actions": ["reserve(db,'c2',sku='sku-2',quantity=2)"],
      "expected_response": {"status": "conflict"},
      "expected_inventory": "sku-1 available 仍为 8；sku-2 不变",
      "expected_records": "仍 1 条",
      "risk": "R5"
    },
    {
      "name": "C-CONFLICT-03 同编号 sku 与 quantity 同时不同",
      "preconditions": ["initialize(db, 10)", "reserve(db,'c3',quantity=2) 成功"],
      "actions": ["reserve(db,'c3',sku='sku-2',quantity=7)"],
      "expected_response": {"status": "conflict"},
      "expected_inventory": "available 仍为 8",
      "expected_records": "仍 1 条",
      "risk": "R5"
    },
    {
      "name": "C-CONFLICT-04 冲突后原参数重试仍为幂等重放",
      "preconditions": ["initialize(db, 10)", "reserve(db,'c4',quantity=2) 成功", "reserve(db,'c4',quantity=9) 返回 conflict"],
      "actions": ["reserve(db,'c4',quantity=2)"],
      "expected_response": "status=reserved, replayed=true",
      "expected_inventory": "available == 8",
      "expected_records": "恰好 1 条",
      "risk": "R5（冲突不得污染幂等状态）"
    },
    {
      "name": "C-STOCK-01 库存不足",
      "preconditions": ["initialize(db, 3)"],
      "actions": ["reserve(db,'s1',quantity=5)"],
      "expected_response": {"status": "insufficient_stock"},
      "expected_inventory": "available == 3",
      "expected_records": "0 条",
      "risk": "R9"
    },
    {
      "name": "C-STOCK-02 库存为 0",
      "preconditions": ["initialize(db, 0)"],
      "actions": ["reserve(db,'s2',quantity=1)"],
      "expected_response": {"status": "insufficient_stock"},
      "expected_inventory": "available == 0",
      "expected_records": "0 条",
      "risk": "R9"
    },
    {
      "name": "C-STOCK-03 库存不足后同编号以更小数量重试",
      "preconditions": ["initialize(db, 3)", "reserve(db,'s3',quantity=5) 返回 insufficient_stock"],
      "actions": ["reserve(db,'s3',quantity=2)"],
      "expected_response": "见 open_questions Q2（insufficient_stock 是否占用 request_id）",
      "expected_inventory": "若允许则 available == 1；若视为冲突则 available == 3",
      "expected_records": "与上一致：1 条或 0 条",
      "risk": "R5/R9（规则未明确，需业务确认）"
    },
    {
      "name": "C-VALID-01 request_id 为空字符串",
      "preconditions": ["initialize(db, 10)"],
      "actions": ["reserve(db,'',quantity=2)"],
      "expected_response": {"status": "invalid_request"},
      "expected_inventory": "available == 10",
      "expected_records": "0 条",
      "risk": "R6"
    },
    {
      "name": "C-VALID-02 request_id 非字符串",
      "preconditions": ["initialize(db, 10)"],
      "actions": ["reserve(db,None,quantity=2)", "reserve(db,123,quantity=2)"],
      "expected_response": "两次均 invalid_request",
      "expected_inventory": "available == 10",
      "expected_records": "0 条",
      "risk": "R6"
    },
    {
      "name": "C-VALID-03 quantity 为 bool",
      "preconditions": ["initialize(db, 10)"],
      "actions": ["reserve(db,'v3',quantity=True)"],
      "expected_response": {"status": "invalid_request"},
      "expected_inventory": "available == 10",
      "expected_records": "0 条",
      "risk": "R6（bool 是 int 子类，必须显式排除）"
    },
    {
      "name": "C-VALID-04 quantity 为 0/负数/浮点/字符串",
      "preconditions": ["initialize(db, 10)"],
      "actions": ["reserve(db,'v4a',quantity=0)", "reserve(db,'v4b',quantity=-1)", "reserve(db,'v4c',quantity=2.0)", "reserve(db,'v4d',quantity='2')"],
      "expected_response": "四次均 invalid_request",
      "expected_inventory": "available == 10",
      "expected_records": "0 条",
      "risk": "R6"
    },
    {
      "name": "C-VALID-05 未知 sku",
      "preconditions": ["initialize(db, 10)"],
      "actions": ["reserve(db,'v5',sku='sku-unknown',quantity=2)"],
      "expected_response": {"status": "invalid_request"},
      "expected_inventory": "sku-1 available == 10",
      "expected_records": "0 条",
      "risk": "R6"
    },
    {
      "name": "C-VALID-06 非法请求不占用 request_id",
      "preconditions": ["initialize(db, 10)", "reserve(db,'v6',quantity=0) 返回 invalid_request"],
      "actions": ["reserve(db,'v6',quantity=2)"],
      "expected_response": "status=reserved, replayed=false",
      "expected_inventory": "available == 8",
      "expected_records": "1 条",
      "risk": "R6（校验失败不应写入幂等键）"
    },
    {
      "name": "C-TX-01 fail_at='after_inventory' 整体回滚",
      "preconditions": ["initialize(db, 10)"],
      "actions": ["reserve(db,'tx1',quantity=2,fail_at='after_inventory')，捕获 RuntimeError"],
      "expected_response": "抛出 RuntimeError（异常必须传播，不得吞掉）",
      "expected_inventory": "available == 10（库存更新被回滚）",
      "expected_records": "0 条",
      "risk": "R3/R8（当前实现库存已提交，必然失败）"
    },
    {
      "name": "C-TX-02 回滚后同编号可正常预占",
      "preconditions": ["initialize(db, 10)", "C-TX-01 已执行并回滚"],
      "actions": ["reserve(db,'tx1',quantity=2)"],
      "expected_response": "status=reserved, replayed=false",
      "expected_inventory": "available == 8",
      "expected_records": "1 条",
      "risk": "R3（回滚不得残留幂等键）"
    },
    {
      "name": "C-TX-03 回滚不影响其他请求的既有预占",
      "preconditions": ["initialize(db, 10)", "reserve(db,'tx3a',quantity=3) 成功"],
      "actions": ["reserve(db,'tx3b',quantity=2,fail_at='after_inventory')，捕获 RuntimeError"],
      "expected_response": "RuntimeError",
      "expected_inventory": "available == 7（仅 tx3a 生效）",
      "expected_records": "仅 tx3a 一条",
      "risk": "R3"
    },
    {
      "name": "C-TX-04 正常路径不忽略 fail_at 参数",
      "preconditions": ["initialize(db, 10)"],
      "actions": ["reserve(db,'tx4',quantity=2,fail_at=None)", "reserve(db,'tx4b',quantity=2,fail_at='after_inventory')"],
      "expected_response": "第一次 reserved；第二次抛 RuntimeError（证明注入点仍存在）",
      "expected_inventory": "available == 8",
      "expected_records": "仅 tx4 一条",
      "risk": "R8（防止删除注入点使 C-TX-01 假通过）"
    },
    {
      "name": "C-CONC-DIFF-01 不同请求并发竞争，库存不足以容纳全部",
      "preconditions": ["initialize(db, 10)", "N=8 个不同 request_id，每个 quantity=2（总需求 16 > 10）", "使用 threading.Barrier 让 N 个线程同时进入 reserve"],
      "actions": ["并发调用 reserve(db, f'cd{i}', quantity=2)，收集返回与异常"],
      "expected_response": "成功（reserved）数量 <= 5；其余为 insufficient_stock；不得出现未分类异常",
      "expected_inventory": "available == 10 - 2×成功数，且 available >= 0",
      "expected_records": "记录数 == 成功数，SUM(quantity) == 10 - available",
      "risk": "R2/R10（当前实现会超卖，available 可能为负）"
    },
    {
      "name": "C-CONC-DIFF-02 不同请求并发，库存充足时不得拒绝合法请求",
      "preconditions": ["initialize(db, 100)", "N=10 个不同 request_id，每个 quantity=2"],
      "actions": ["Barrier 同步后并发调用"],
      "expected_response": "10 次全部 status=reserved",
      "expected_inventory": "available == 80",
      "expected_records": "10 条，SUM(quantity)=20",
      "risk": "R7（防止用「全部拒绝」规避竞态）"
    },
    {
      "name": "C-CONC-DIFF-03 不同请求并发，恰好耗尽库存",
      "preconditions": ["initialize(db, 10)", "N=5 个不同 request_id，每个 quantity=2"],
      "actions": ["Barrier 同步后并发调用"],
      "expected_response": "5 次全部 reserved",
      "expected_inventory": "available == 0",
      "expected_records": "5 条，SUM(quantity)=10",
      "risk": "R2/R7"
    },
    {
      "name": "C-CONC-DIFF-04 并发一致性不变量（重复多轮）",
      "preconditions": ["initialize(db, 10)", "每轮 N=6 个不同 request_id，quantity 在 1..3 间变化", "重复 R=20 轮，每轮独立数据库"],
      "actions": ["每轮 Barrier 并发调用，轮后校验不变量"],
      "expected_response": "每轮：成功数×quantity 之和 <= 10；失败者均为 insufficient_stock",
      "expected_inventory": "每轮 available == 10 - SUM(成功 quantity)，且 available >= 0",
      "expected_records": "每轮记录数 == 成功数，无重复 request_id",
      "risk": "R2/R10（单轮可能偶发通过，多轮降低假阴性）"
    },
    {
      "name": "C-CONC-SAME-01 相同请求相同参数并发重试",
      "preconditions": ["initialize(db, 10)", "N=6 个线程使用同一 request_id='cs1'、quantity=2", "Barrier 同步"],
      "actions": ["并发调用 reserve(db,'cs1',quantity=2)"],
      "expected_response": "恰好 1 个 replayed=false，其余 replayed=true（或按 open_questions Q5 的允许集合）；不得出现 conflict",
      "expected_inventory": "available == 8（只扣一次）",
      "expected_records": "request_id='cs1' 恰好 1 条",
      "risk": "R1（当前实现会产生 6 次扣减与 6 条记录）"
    },
    {
      "name": "C-CONC-SAME-02 相同请求并发，库存仅够一次",
      "preconditions": ["initialize(db, 2)", "N=4 个线程同一 request_id='cs2'、quantity=2"],
      "actions": ["Barrier 同步后并发调用"],
      "expected_response": "1 个 reserved(replayed=false)，其余 reserved(replayed=true)；不得出现 insufficient_stock 或 conflict（见 Q5）",
      "expected_inventory": "available == 0",
      "expected_records": "恰好 1 条",
      "risk": "R1（幂等与库存判定的并发优先级）"
    },
    {
      "name": "C-CONC-SAME-03 相同 request_id 并发但参数不同",
      "preconditions": ["initialize(db, 10)", "线程 A: ('cs3', quantity=2)，线程 B: ('cs3', quantity=5)，Barrier 同步"],
      "actions": ["并发调用两个不同参数的请求"],
      "expected_response": "至多 1 个 reserved，另一个 conflict",
      "expected_inventory": "available 为 8 或 5（取决于谁先成功），且与成功记录一致",
      "expected_records": "恰好 1 条，quantity 与成功请求一致",
      "risk": "R5（并发下的冲突判定）"
    },
    {
      "name": "C-CONTRACT-01 成功响应键集合精确匹配",
      "preconditions": ["initialize(db, 10)"],
      "actions": ["reserve(db,'ct1',quantity=2)"],
      "expected_response": "set(result.keys()) == {'status','request_id','sku','quantity','replayed'}；类型：status/request_id/sku 为 str，quantity 为 int，replayed 为 bool",
      "expected_inventory": "available == 8",
      "expected_records": "1 条",
      "risk": "R4"
    },
    {
      "name": "C-CONTRACT-02 失败响应 status 取值合法",
      "preconditions": ["initialize(db, 10)"],
      "actions": ["触发 conflict / insufficient_stock / invalid_request 各一次"],
      "expected_response": "每个失败响应的 status ∈ contracts/response.json 的 statuses 集合，且不含 reserved",
      "expected_inventory": "各失败路径均无改动",
      "expected_records": "各失败路径均无新增记录",
      "risk": "R4"
    },
    {
      "name": "C-CONTRACT-03 旧调用方式兼容（位置参数与默认值）",
      "preconditions": ["initialize(db) 不传 stock"],
      "actions": ["reserve(db,'ct3') 仅传两个位置参数"],
      "expected_response": {"status": "reserved", "request_id": "ct3", "sku": "sku-1", "quantity": 2, "replayed": false},
      "expected_inventory": "available == 8（默认 stock=10、默认 quantity=2）",
      "expected_records": "1 条",
      "risk": "R4（签名与默认值不得变更）"
    },
    {
      "name": "C-CONTRACT-04 表结构兼容",
      "preconditions": ["initialize(db, 10)"],
      "actions": ["PRAGMA table_info(inventory)", "PRAGMA table_info(reserv