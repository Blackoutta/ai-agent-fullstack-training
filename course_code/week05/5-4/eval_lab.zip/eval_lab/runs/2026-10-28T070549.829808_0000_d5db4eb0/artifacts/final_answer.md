```json
{
  "scope": {
    "human_confirmed_scope": ["inventory.py 的预占、幂等、事务与接口响应"],
    "high_risks": ["相同请求重复业务效果", "并发超卖", "异常部分提交", "接口不兼容"],
    "out_of_scope": ["支付确认与释放", "多仓库", "生产压测结论"],
    "required_reviews": ["修改了什么", "关键分支在哪里", "旧调用是否兼容"],
    "status": "教学范围；迁移到实际项目时需业务负责人重新确认",
    "basis": "docs/rules.md（版本 1）为唯一有效业务契约；docs/archive_2024.md 已过期，不作为依据",
    "read_only_artifacts": ["inventory.py", "tests/test_smoke.py", "docs/rules.md", "docs/archive_2024.md", "contracts/response.json", "AGENTS.md"],
    "writable_artifacts": ["inventory.py", "tests/test_*.py（新增）"],
    "code_observations": [
      "inventory.py 第 20 行 seen = set() 在每次调用内重建，幂等去重恒不生效（重复请求会二次扣减）",
      "inventory.py 第 26-31 行 SELECT 与 UPDATE 之间无事务/条件更新，time.sleep(0.01) 放大 check-then-act 竞态（并发超卖）",
      "inventory.py 第 33-35 行 fail_at='after_inventory' 在库存已提交后才抛错，预占记录未写入（异常部分提交）",
      "inventory.py 第 36-38 行预占记录写入使用独立连接，与库存更新不在同一事务",
      "inventory.py 第 22-24 行 conflict 分支不可达（seen 恒为空），且无 sku/quantity 一致性比对",
      "inventory.py 第 27-28 行未知 sku 与非法参数共用 invalid_request，符合契约但需回归确认",
      "reservations 表无 request_id 唯一约束，缺少数据库层幂等兜底"
    ]
  },
  "risk_review": [
    {
      "risk": "相同请求重复业务效果",
      "where": "reserve 的 seen 集合（第 20、24、39 行）",
      "impact": "同一 request_id 重复提交会重复扣减库存并插入多条预占记录，replayed 恒为 false",
      "detection": "串行重复提交后比对库存与 reservations 行数；并发相同 request_id 提交后比对有效记录数",
      "severity": "high",
      "in_scope": true
    },
    {
      "risk": "并发超卖",
      "where": "SELECT available 与 UPDATE available 之间的 check-then-act（第 26-31 行）",
      "impact": "不同 request_id 并发时多个调用读到同一库存值，成功总量超过初始库存，库存与预占总量不一致",
      "detection": "多线程并发不同 request_id，断言成功数×quantity ≤ 初始库存且 available == 初始库存 - 成功总量",
      "severity": "high",
      "in_scope": true
    },
    {
      "risk": "异常部分提交",
      "where": "fail_at='after_inventory' 分支（第 33-35 行）与两次独立连接（第 25、36 行）",
      "impact": "库存已扣减但预占记录缺失，抛错后状态不可恢复，库存与记录永久不一致",
      "detection": "注入 fail_at 后断言抛 RuntimeError，且库存与 reservations 均回到调用前状态",
      "severity": "high",
      "in_scope": true
    },
    {
      "risk": "接口不兼容",
      "where": "reserve/initialize 的签名、返回字段、status 取值、表结构",
      "impact": "修复时若改变签名、字段集合、status 字符串或表名/列名，旧调用方（含 test_smoke.py）会破坏",
      "detection": "成功响应键集合精确等于 contracts/response.json 的 5 个键；status 取值属于 4 个枚举；表结构与列名不变；test_smoke.py 不改动仍通过",
      "severity": "high",
      "in_scope": true
    },
    {
      "risk": "参数冲突未识别",
      "where": "conflict 分支不可达（第 22-24 行）",
      "impact": "同一 request_id 携带不同 sku/quantity 被当作新请求或重放，导致库存被错误改变",
      "detection": "先成功预占，再用同 request_id 不同 quantity/sku 提交，断言 status=conflict 且库存与记录不变",
      "severity": "high",
      "in_scope": true
    },
    {
      "risk": "参数校验边界（bool 被当作 int、空串、非字符串、非正数）",
      "where": "第 21 行类型判断",
      "impact": "bool 是 int 子类，若用 isinstance 会放过 True/False；负数和 0 需拒绝",
      "detection": "参数化非法输入断言 invalid_request 且无副作用",
      "severity": "medium",
      "in_scope": true
    },
    {
      "risk": "库存不足路径产生副作用",
      "where": "第 29-30 行 insufficient_stock 分支",
      "impact": "若修复时先写记录再判断库存，会留下脏记录",
      "detection": "库存不足调用后断言库存与 reservations 不变",
      "severity": "medium",
      "in_scope": true
    },
    {
      "risk": "修复引入的过度拒绝",
      "where": "并发控制实现（锁/事务/条件更新）",
      "impact": "用全局拒绝或串行化规避超卖，导致合法请求被拒（rules.md 第 4 条明确禁止）",
      "detection": "并发用例断言成功数等于库存允许的最大值（如库存 10、quantity 2、10 个不同请求 → 恰好 5 成功）",
      "severity": "high",
      "in_scope": true
    },
    {
      "risk": "支付确认与释放、多仓库、生产压测结论",
      "where": "不在 inventory.py 当前实现范围",
      "impact": "若被误纳入测试会引入不存在的接口与不可验证的结论",
      "detection": "不设计相关用例",
      "severity": "n/a",
      "in_scope": false
    }
  ],
  "decision_table": [
    {
      "group": "DT-1 参数校验（单次调用，无前置状态）",
      "conditions": ["request_id 为非空字符串", "quantity 为正整数且非 bool", "sku 存在于 inventory"],
      "rules": [
        {"id": "DT-1-R1", "request_id": "合法", "quantity": "合法", "sku": "存在", "expected_status": "reserved", "side_effect": "扣减库存并写 1 条记录"},
        {"id": "DT-1-R2", "request_id": "空串/None/非字符串", "quantity": "任意", "sku": "任意", "expected_status": "invalid_request", "side_effect": "无"},
        {"id": "DT-1-R3", "request_id": "合法", "quantity": "0/负数/True/False/1.0/'2'", "sku": "任意", "expected_status": "invalid_request", "side_effect": "无"},
        {"id": "DT-1-R4", "request_id": "合法", "quantity": "合法", "sku": "不存在", "expected_status": "invalid_request", "side_effect": "无"}
      ]
    },
    {
      "group": "DT-2 幂等与冲突（同一 request_id 的第二次及以后调用）",
      "conditions": ["该 request_id 是否已有有效预占", "本次 sku 是否与首次一致", "本次 quantity 是否与首次一致"],
      "rules": [
        {"id": "DT-2-R1", "已有预占": "否", "sku 一致": "n/a", "quantity 一致": "n/a", "expected_status": "reserved", "replayed": false, "side_effect": "扣减库存并写 1 条记录"},
        {"id": "DT-2-R2", "已有预占": "是", "sku 一致": "是", "quantity 一致": "是", "expected_status": "reserved", "replayed": true, "side_effect": "库存与记录均不变"},
        {"id": "DT-2-R3", "已有预占": "是", "sku 一致": "否", "quantity 一致": "任意", "expected_status": "conflict", "side_effect": "库存与记录均不变"},
        {"id": "DT-2-R4", "已有预占": "是", "sku 一致": "是", "quantity 一致": "否", "expected_status": "conflict", "side_effect": "库存与记录均不变"}
      ]
    },
    {
      "group": "DT-3 库存充足性（新 request_id，无并发）",
      "conditions": ["available 与 quantity 的关系"],
      "rules": [
        {"id": "DT-3-R1", "available > quantity": "是", "expected_status": "reserved", "side_effect": "available -= quantity，写 1 条记录"},
        {"id": "DT-3-R2", "available == quantity": "是", "expected_status": "reserved", "side_effect": "available = 0，写 1 条记录"},
        {"id": "DT-3-R3", "available < quantity": "是", "expected_status": "insufficient_stock", "side_effect": "无"}
      ]
    },
    {
      "group": "DT-4 事务与异常注入（fail_at 分支）",
      "conditions": ["fail_at 取值", "注入点相对库存更新与记录写入的位置"],
      "rules": [
        {"id": "DT-4-R1", "fail_at": "None", "expected": "正常返回 reserved", "side_effect": "库存与记录同时生效"},
        {"id": "DT-4-R2", "fail_at": "after_inventory", "expected": "抛出 RuntimeError", "side_effect": "库存与记录整体回滚到调用前"},
        {"id": "DT-4-R3", "fail_at": "after_inventory 且该 request_id 已成功预占过", "expected": "抛出 RuntimeError 或按幂等返回 replayed=true（见 open_questions Q1）", "side_effect": "不得产生第二次扣减"}
      ]
    },
    {
      "group": "DT-5 并发（按请求编号关系分组，时序单独设计，不压成静态组合）",
      "conditions": ["并发请求的 request_id 是否互不相同", "并发请求的 request_id 是否相同", "总需求量与库存的关系"],
      "rules": [
        {"id": "DT-5-R1", "request_id 关系": "互不相同", "总需求 > 库存", "expected": "成功数×quantity ≤ 初始库存；其余 insufficient_stock；不出现负库存", "side_effect": "available == 初始库存 - 成功总量；有效记录数 == 成功数"},
        {"id": "DT-5-R2", "request_id 关系": "互不相同", "总需求 == 库存", "expected": "全部成功（不得过度拒绝）", "side_effect": "available == 0；记录数 == 请求数"},
        {"id": "DT-5-R3", "request_id 关系": "完全相同", "expected": "恰好 1 次有效预占，其余 replayed=true", "side_effect": "available 只扣减一次；有效记录数 == 1"},
        {"id": "DT-5-R4", "request_id 关系": "部分相同、部分不同", "expected": "每个不同 request_id 至多 1 次有效预占", "side_effect": "available == 初始库存 - 不同 request_id 成功数×quantity"}
      ]
    },
    {
      "group": "DT-6 契约与兼容（响应结构与旧调用）",
      "conditions": ["响应类型", "调用方式"],
      "rules": [
        {"id": "DT-6-R1", "响应类型": "成功", "expected": "键集合恰为 {status, request_id, sku, quantity, replayed}", "side_effect": "无额外键、无缺失键"},
        {"id": "DT-6-R2", "响应类型": "失败", "expected": "status ∈ {conflict, insufficient_stock, invalid_request}", "side_effect": "无"},
        {"id": "DT-6-R3", "调用方式": "位置参数 reserve(path, 'x', 'sku-1', 2) 与关键字参数混用", "expected": "行为一致", "side_effect": "签名保持兼容"},
        {"id": "DT-6-R4", "调用方式": "initialize(path) 使用默认 stock=10；表名与列名不变", "expected": "旧调用可用", "side_effect": "可新增索引，不得改列"}
      ]
    }
  ],
  "cases": [
    {
      "name": "C01 正常预占（DT-1-R1 / DT-3-R1）",
      "preconditions": ["initialize(db, 10)", "无历史预占"],
      "actions": ["reserve(db, 'req-1', 'sku-1', 2)"],
      "expected_response": {"status": "reserved", "request_id": "req-1", "sku": "sku-1", "quantity": 2, "replayed": false},
      "expected_inventory": {"sku-1": 8},
      "expected_records": [{"request_id": "req-1", "sku": "sku-1", "quantity": 2}],
      "risk": "基线正确性；接口不兼容"
    },
    {
      "name": "C02 库存恰好用尽（DT-3-R2）",
      "preconditions": ["initialize(db, 2)"],
      "actions": ["reserve(db, 'req-1', 'sku-1', 2)"],
      "expected_response": {"status": "reserved", "request_id": "req-1", "sku": "sku-1", "quantity": 2, "replayed": false},
      "expected_inventory": {"sku-1": 0},
      "expected_records": [{"request_id": "req-1", "sku": "sku-1", "quantity": 2}],
      "risk": "边界条件（== 而非 <）"
    },
    {
      "name": "C03 库存不足（DT-3-R3）",
      "preconditions": ["initialize(db, 1)"],
      "actions": ["reserve(db, 'req-1', 'sku-1', 2)"],
      "expected_response": {"status": "insufficient_stock"},
      "expected_inventory": {"sku-1": 1},
      "expected_records": [],
      "risk": "库存不足路径产生副作用"
    },
    {
      "name": "C04 相同请求串行重复提交（DT-2-R2）",
      "preconditions": ["initialize(db, 10)", "reserve(db, 'req-1', 'sku-1', 2) 已成功"],
      "actions": ["reserve(db, 'req-1', 'sku-1', 2)", "reserve(db, 'req-1', 'sku-1', 2)"],
      "expected_response": {"status": "reserved", "request_id": "req-1", "sku": "sku-1", "quantity": 2, "replayed": true},
      "expected_inventory": {"sku-1": 8},
      "expected_records": [{"request_id": "req-1", "sku": "sku-1", "quantity": 2}],
      "risk": "相同请求重复业务效果（高风险）"
    },
    {
      "name": "C05 相同请求跨进程/跨连接重复提交（DT-2-R2）",
      "preconditions": ["initialize(db, 10)", "在独立连接中完成首次预占（模拟进程重启后重试）"],
      "actions": ["新连接中 reserve(db, 'req-1', 'sku-1', 2)"],
      "expected_response": {"status": "reserved", "request_id": "req-1", "sku": "sku-1", "quantity": 2, "replayed": true},
      "expected_inventory": {"sku-1": 8},
      "expected_records": [{"request_id": "req-1", "sku": "sku-1", "quantity": 2}],
      "risk": "幂等状态必须持久化，不能依赖进程内内存（对应 archive_2024 的错误做法）"
    },
    {
      "name": "C06 相同 request_id 不同 quantity（DT-2-R4）",
      "preconditions": ["initialize(db, 10)", "reserve(db, 'req-1', 'sku-1', 2) 已成功"],
      "actions": ["reserve(db, 'req-1', 'sku-1', 5)"],
      "expected_response": {"status": "conflict"},
      "expected_inventory": {"sku-1": 8},
      "expected_records": [{"request_id": "req-1", "sku": "sku-1", "quantity": 2}],
      "risk": "参数冲突（高风险）"
    },
    {
      "name": "C07 相同 request_id 不同 sku（DT-2-R3）",
      "preconditions": ["initialize(db, 10)", "reserve(db, 'req-1', 'sku-1', 2) 已成功"],
      "actions": ["reserve(db, 'req-1', 'sku-2', 2)"],
      "expected_response": {"status": "conflict"},
      "expected_inventory": {"sku-1": 8},
      "expected_records": [{"request_id": "req-1", "sku": "sku-1", "quantity": 2}],
      "risk": "参数冲突；未知 sku 与冲突的优先级（见 open_questions Q2）"
    },
    {
      "name": "C08 冲突后原请求仍可重放（DT-2-R2 回归）",
      "preconditions": ["initialize(db, 10)", "reserve(db, 'req-1', 'sku-1', 2) 已成功", "reserve(db, 'req-1', 'sku-1', 5) 返回 conflict"],
      "actions": ["reserve(db, 'req-1', 'sku-1', 2)"],
      "expected_response": {"status": "reserved", "request_id": "req-1", "sku": "sku-1", "quantity": 2, "replayed": true},
      "expected_inventory": {"sku-1": 8},
      "expected_records": [{"request_id": "req-1", "sku": "sku-1", "quantity": 2}],
      "risk": "冲突调用不得污染幂等状态"
    },
    {
      "name": "C09 非法 request_id（DT-1-R2）",
      "preconditions": ["initialize(db, 10)"],
      "actions": ["reserve(db, '', 'sku-1', 2)", "reserve(db, None, 'sku-1', 2)", "reserve(db, 123, 'sku-1', 2)"],
      "expected_response": {"status": "invalid_request"},
      "expected_inventory": {"sku-1": 10},
      "expected_records": [],
      "risk": "参数校验边界"
    },
    {
      "name": "C10 非法 quantity（DT-1-R3）",
      "preconditions": ["initialize(db, 10)"],
      "actions": ["reserve(db, 'req-1', 'sku-1', 0)", "reserve(db, 'req-1', 'sku-1', -1)", "reserve(db, 'req-1', 'sku-1', True)", "reserve(db, 'req-1', 'sku-1', False)", "reserve(db, 'req-1', 'sku-1', 1.0)", "reserve(db, 'req-1', 'sku-1', '2')"],
      "expected_response": {"status": "invalid_request"},
      "expected_inventory": {"sku-1": 10},
      "expected_records": [],
      "risk": "bool 是 int 子类，易被 isinstance 放过"
    },
    {
      "name": "C11 未知 sku（DT-1-R4）",
      "preconditions": ["initialize(db, 10)"],
      "actions": ["reserve(db, 'req-1', 'sku-404', 2)"],
      "expected_response": {"status": "invalid_request"},
      "expected_inventory": {"sku-1": 10},
      "expected_records": [],
      "risk": "参数校验；未知 sku 不得创建库存行"
    },
    {
      "name": "C12 异常注入整体回滚（DT-4-R2）",
      "preconditions": ["initialize(db, 10)", "无历史预占"],
      "actions": ["reserve(db, 'req-1', 'sku-1', 2, fail_at='after_inventory')"],
      "expected_response": {"exception": "RuntimeError"},
      "expected_inventory": {"sku-1": 10},
      "expected_records": [],
      "risk": "异常部分提交（高风险）"
    },
    {
      "name": "C13 异常注入后同一 request_id 可正常重试（DT-4-R2 后续）",
      "preconditions": ["initialize(db, 10)", "C12 已执行并回滚"],
      "actions": ["reserve(db, 'req-1', 'sku-1', 2)"],
      "expected_response": {"status": "reserved", "request_id": "req-1", "sku": "sku-1", "quantity": 2, "replayed": false},
      "expected_inventory": {"sku-1": 8},
      "expected_records": [{"request_id": "req-1", "sku": "sku-1", "quantity": 2}],
      "risk": "回滚必须彻底，不得残留半成品幂等标记"
    },
    {
      "name": "C14 正常路径不得忽略 fail_at 参数（DT-4-R1 反向）",
      "preconditions": ["initialize(db, 10)"],
      "actions": ["reserve(db, 'req-1', 'sku-1', 2, fail_at='after_inventory')", "reserve(db, 'req-2', 'sku-1', 2, fail_at=None)"],
      "expected_response": {"first": "RuntimeError", "second": {"status": "reserved", "request_id": "req-2", "sku": "sku-1", "quantity": 2, "replayed": false}},
      "expected_inventory": {"sku-1": 8},
      "expected_records": [{"request_id": "req-2", "sku": "sku-1", "quantity": 2}],
      "risk": "为通过测试而删除注入点（rules.md 第 8 条明确禁止）"
    },
    {
      "name": "C15 不同 request_id 并发竞争，总需求超过库存（DT-5-R1）",
      "preconditions": ["initialize(db, 10)", "10 个不同 request_id，quantity=2，总需求 20 > 10"],
      "actions": ["用线程屏障同时发起 10 个 reserve 调用，收集全部返回"],
      "expected_response": {"success_count": 5, "insufficient_stock_count": 5, "other_statuses": "不允许出现 conflict/invalid_request"},
      "expected_inventory": {"sku-1": 0},
      "expected_records": "有效记录数 == 5，且每条 request_id 唯一",
      "risk": "并发超卖（高风险）；时序类用例，需真实并发而非顺序调用"
    },
    {
      "name": "C16 不同 request_id 并发，总需求恰好等于库存（DT-5-R2）",
      "preconditions": ["initialize(db, 10)", "5 个不同 request_id，quantity=2，总需求 10"],
      "actions": ["用线程屏障同时发起 5 个 reserve 调用"],
      "expected_response": {"success_count": 5, "insufficient_stock_count": 0},
      "expected_inventory": {"sku-1": 0},
      "expected_records": "有效记录数 == 5",
      "risk": "过度拒绝（用拒绝规避超卖）；时序类用例"
    },
    {
      "name": "C17 相同 request_id 并发重试（DT-5-R3）",
      "preconditions": ["initialize(db, 10)", "8 个线程使用同一 request_id 'req-1'，quantity=2"],
      "actions": ["用线程屏障同时发起 8 个 reserve 调用"],
      "expected_response": {"reserved_count": 8, "replayed_false_count": 1, "replayed_true_count": 7},
      "expected_inventory": {"sku-1": 8},
      "expected_records": "有效记录数 == 1",
      "risk": "相同请求重复业务效果 + 并发（高风险）；时序类用例"
    },
    {
      "name": "C18 混合并发：部分相同、部分不同 request_id（DT-5-R4）",
      "preconditions": ["initialize(db, 10)", "4 个不同 request_id 各 2 个线程，quantity=2，总需求 16 > 10"],
      "actions": ["用线程屏障同时发起 8 个 reserve 调用"],
      "expected_response": {"distinct_success_ids": "≤ 5 且每个 request_id 至多 1 次 replayed=false"},
      "expected_inventory": "sku-1 == 10 - 2 × distinct_success_ids，且 ≥ 0",
      "expected_records": "有效记录数 == distinct_success_ids",
      "risk": "并发超卖 + 幂等交叉（高风险）；时序类用例"
    },
    {
      "name": "C19 并发下库存与记录一致性不变量（DT-5-R1 强化）",
      "preconditions": ["initialize(db, 10)", "20 个不同 request_id，quantity 在 1..3 之间随机，总需求 > 10"],
      "actions": ["并发发起全部调用，结束后读取 inventory 与 reservations"],
      "expected_response": {"statuses": "仅 reserved / insufficient_stock"},
      "expected_inventory": "sku-1 == 10 - SUM(reservations.quantity)，且 ≥ 0",
      "expected_records": "SUM(reservations.quantity) == 10 - available；无重复 request_id",
      "risk": "并发超卖 + 库存与有效预占总量一致性（高风险）；时序类用例"
    },
    {
      "name": "C20 成功响应键集合精确匹配契约（DT-6-R1）",
      "preconditions": ["initialize(db, 10)"],
      "actions": ["reserve(db, 'req-1', 'sku-1', 2)", "reserve(db, 'req-1', 'sku-1', 2)"],
      "expected_response": {"keys": ["status", "request_id", "sku", "quantity", "replayed"], "note": "两次响应键集合均精确相等，无多余键"},
      "expected_inventory": {"sku-1": 8},
      "expected_records": [{"request_id": "req-1", "sku": "sku-1", "quantity": 2}],
      "risk": "接口不兼容（高风险）"
    },
    {
      "name": "C21 失败响应 status 取值属于契约枚举（DT-6-R2）",
      "preconditions": ["initialize(db, 1)"],
      "actions": ["reserve(db, '', 'sku-1', 2)", "reserve(db, 'req-1', 'sku-404', 2)", "reserve(db, 'req-2', 'sku-1', 5)", "reserve(db, 'req-3', 'sku-1', 2) 后再 reserve(db, 'req-3', 'sku-1', 3)"],
      "expected_response": {"statuses": ["invalid_request", "invalid_request", "insufficient_stock", "conflict"], "all_in_enum": true},
      "expected_inventory": {"sku-1": 0},
      "expected_records": [{"request_id": "req-3", "sku": "sku-1", "quantity": 2}],
      "risk": "接口不兼容（高风险）"
    },
    {
      "name": "C22 旧调用方式兼容：位置参数与默认值（DT-6-R3 / DT-6-R4）",
      "preconditions": ["initialize(db) 使用默认 stock=10"],
      "actions": ["reserve(db, 'req-1')", "reserve(db, 'req-2', 'sku-1', 3)"],
      "expected_response": {"first": {"status": "reserved", "request_id": "req-1", "sku": "sku-1", "quantity": 2, "replayed": false}, "second": {"status": "reserved", "request_id": "req-2", "sku": "sku-1", "quantity": 3, "replayed": false}},
      "expected_inventory": {"sku-1": 5},
      "expected_records": [{"request_id": "req-1", "sku": "sku-1", "quantity": 2}, {"request_id": "req-2", "sku": "sku-1", "quantity": 3}],
      "risk": "接口不兼容（高风险）；旧调用是否兼容"
    },
    {
      "name": "C23 表结构与列名不变（DT-6-R4）",
      "preconditions": ["initialize(db, 10)"],
      "actions": ["读取 sqlite_master 与 PRAGMA table_info(inventory)、PRAGMA table_info(reservations)"],
      "expected_response": {"inventory_columns": ["sku", "available"], "reservations_columns": ["id", "request_id", "sku", "quantity"], "note": "允许新增索引，不允许改列或改表名"},
      "expected_inventory": {"sku-1": 10},
      "expected_records": [],
      "risk": "接口不兼容（高风险）；迁移兼容"
    },
    {
      "name": "C24 既有 smoke 用例不改动仍通过（DT-6 回归）",
      "preconditions": ["tests/test_smoke.py 保持原样未修改"],
      "actions": ["运行 python -m unittest discover -s tests -v"],
      "expected_response": {"test_smoke": "通过"},
      "expected_inventory": "n/a",
      "expected_records": "n/a",
      "risk": "接口不兼容（高风险）；旧调用是否兼容"
    }
  ],
  "coverage_matrix": [
    {"dimension": "正常预占", "cases": ["C01", "C02", "C22"], "decision_rules": ["DT-1-R1", "DT-3-R1", "DT-3-R2"], "covered": true},
    {"dimension": "重复（串行）", "cases": ["C04", "C05", "C08"], "decision_rules": ["DT-2-R2"], "covered": true},
    {"dimension": "重复（并发）", "cases": ["C17"], "decision_rules": ["DT-5-R3"], "covered": true},
    {"dimension": "参数冲突", "cases": ["C06", "C07", "C08"], "decision_rules": ["DT-2-R3", "DT-2-R4"], "covered": true},
    {"dimension": "参数校验", "cases": ["C09", "C10", "C11"], "decision_rules": ["DT-1-R2", "DT-1-R3", "DT-1-R4"], "covered": true},
    {"dimension": "库存不足", "cases": ["C03", "C21"], "decision_rules": ["DT-3-R3"], "covered": true},
    {"dimension": "不同请求并发", "cases": ["C15", "C16", "C18", "C19"], "decision_rules": ["DT-5-R1", "DT-5-R2", "DT-5-R4"], "covered": true},
    {"dimension": "相同请求并发", "cases": ["C17", "C18"], "decision_rules": ["DT-5-R3", "DT-5-R4"], "covered": true},
    {"dimension": "异常回滚", "cases": ["C12", "C13", "C14"], "decision_rules": ["DT-4-R1", "DT-4-R2", "DT-4-R3"], "covered": true},
    {"dimension": "契约（响应结构）", "cases": ["C20", "C21"], "decision_rules": ["DT-6-R1", "DT-6-R2"], "covered": true},
    {"dimension": "契约（签名/表结构/旧调用）", "cases": ["C22", "C23", "C24"], "decision_rules": ["DT-6-R3", "DT-6-R4"], "covered": true},
    {"dimension": "高风险项保留检查", "cases": ["C04", "C05", "C15", "C16", "C17", "C18", "C19", "C12", "C13", "C14", "C20", "C21", "C22", "C23", "C24"], "decision_rules": ["全部 high 风险均有对应用例，未因数量裁剪"], "covered": true},
    {"dimension": "out_of_scope 排除检查", "cases": [], "decision_rules": ["未设计支付确认/释放、多仓库、生产压测结论相关用例"], "covered": true}
  ],
  "open_questions": [
    {"id": "Q1", "question": "同一 request_id 已成功预占后，再以 fail_at='after_inventory' 调用，应抛 RuntimeError 还是按幂等返回 replayed=true？", "why": "rules.md 第 2 条（幂等）与第 8 条（注入必须生效）在此场景可能冲突，需业务负责人裁定优先级", "affects": ["DT-4-R3"]},
    {"id": "Q2", "question": "同一 request_id 已预占 sku-1 后，用 sku-2（不存在的 sku）提交，应返回 conflict 还是 invalid_request？", "why": "参数校验与冲突检测的判定顺序未在 rules.md 中规定", "affects": ["C07", "DT-2-R3"]},
    {"id": "Q3", "question": "conflict 与 insufficient_stock 响应是否允许携带额外字段（如 request_id）？", "why": "contracts/response.json 只约束成功响应键集合，失败响应仅约束 status 取值", "affects": ["C06", "C07", "C21"]},
    {"id": "Q4", "question": "并发场景下，被判定为 insufficient_stock 的请求是否允许在后续库存释放后重试成功？", "why": "释放属于 out_of_scope，当前无法验证；需确认失败请求是否留下任何持久化痕迹", "affects": ["C15", "C19"]},
    {"id": "Q5", "question": "并发用例的线程数与超时阈值是否有验收标准（例如 SQLite busy timeout 15s