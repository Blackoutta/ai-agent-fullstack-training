/** Pi-native adapter only: requests, tool boundaries and a fixed test runner. */
import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
import { Type } from "typebox";
import { appendFileSync, existsSync, readFileSync, realpathSync, readdirSync, lstatSync } from "node:fs";
import { resolve, relative, sep, dirname, join } from "node:path";
import { createHash } from "node:crypto";
import { spawn } from "node:child_process";

export default function (pi: ExtensionAPI) {
  const trace = process.env.EVAL_PROVIDER_TRACE!;
  const root = realpathSync(resolve(process.env.EVAL_WORKSPACE || process.cwd()));
  const readonly = process.env.EVAL_READ_ONLY === "1";
  let turns = 0;
  let requestSeq = 0;
  const servedModels = new Map<number,string>();
  let faultPending = process.env.EVAL_INJECT_READ_TIMEOUT === "1";
  const secret = process.env.EVAL_API_KEY || "";
  const clean = (v: any): any => {
    if (Array.isArray(v)) return v.map(clean);
    if (v && typeof v === "object") {
      if (String(v.type || "").startsWith("thinking")) return { type: "thinking_redacted" };
      const out: any = {};
      for (const [k, val] of Object.entries(v)) {
        if (["authorization", "api_key", "apikey", "reasoning_content", "reasoning", "thought", "thinking"].includes(k.toLowerCase())) continue;
        out[k] = clean(val);
      }
      return out;
    }
    return typeof v === "string" && secret ? v.split(secret).join("[REDACTED]") : v;
  };
  const log = (type: string, data: any) => {
    if (trace) appendFileSync(trace, JSON.stringify({ time: new Date().toISOString(), type, ...clean(data) }) + "\n");
  };
  const sha = (p: string) => createHash("sha256").update(readFileSync(p)).digest("hex");
  const files = () => {
    const out: Record<string,string> = {};
    const walk = (dir: string) => {
      for (const name of readdirSync(dir).sort()) {
        if (["__pycache__", ".git", "node_modules"].includes(name)) continue;
        const p = join(dir,name), st = lstatSync(p);
        if (st.isSymbolicLink()) continue;
        if (st.isDirectory()) walk(p);
        else if (!/\.(pyc|db|sqlite)(-wal|-shm)?$/.test(name)) out[relative(root,p).split(sep).join("/")] = sha(p);
      }
    }; walk(root); return out;
  };
  const canonical = (p: string): string => {
    p = resolve(root,p);
    if (existsSync(p)) return realpathSync(p);
    const parent = dirname(p);
    return parent === p ? p : resolve(canonical(parent), relative(parent,p));
  };
  const initialFiles = files();
  pi.on("before_provider_request", (event) => {
    const payload: any = { ...(event.payload as any), stream: true };
    if (process.env.EVAL_MODEL_PROVIDER === "deepseek") payload.thinking = { type: "disabled" };
    payload.temperature = Number(process.env.EVAL_TEMPERATURE || "0.2");
    payload.max_tokens = Number(process.env.EVAL_MAX_OUTPUT || "8192");
    requestSeq += 1;
    log("provider_request", { request_index: requestSeq, payload });
    return payload;
  });
  pi.on("after_provider_response", (event) => {
    log("provider_response", { request_index: requestSeq, status: event.status, request_id: event.headers["x-request-id"] || null });
  });
  pi.on("provider_stream_event", (event) => {
    const data: any = event.data;
    if (data?.model && servedModels.get(requestSeq) !== data.model) {
      servedModels.set(requestSeq,data.model);
      log("provider_model", { request_index: requestSeq, served_model: data.model });
    }
    if (data?.usage) log("provider_usage", { request_index: requestSeq, usage: data.usage, model: event.model });
  });
  pi.on("turn_start", (_event, ctx) => {
    turns += 1;
    if (turns > Number(process.env.EVAL_MAX_TURNS || "18")) {
      log("budget_exceeded", { turns });
      ctx.abort();
    }
  });
  pi.on("tool_call", (event: any) => {
    log("tool_call", { toolCallId: event.toolCallId, toolName: event.toolName, input: event.input });
    const allow = readonly ? ["read","grep","find","ls"] : ["read","grep","find","ls","edit","write","run_tests"];
    let why = allow.includes(event.toolName) ? "" : "工具未在本次允许列表中";
    if (event.toolName !== "run_tests") {
      const p = canonical(event.input?.path || ".");
      const rel = relative(root,p).split(sep).join("/");
      if (rel === ".." || rel.startsWith("../") || resolve(p) === resolve(dirname(root))) why = "禁止访问工作区以外路径";
      if (["edit","write"].includes(event.toolName)) {
        const allowed = rel === "inventory.py" || (/^tests\/test_[^/]+\.py$/.test(rel) && !(rel in initialFiles));
        if (!allowed || readonly) why = "只允许修改 inventory.py 或新增测试文件";
      }
    }
    if (faultPending && event.toolName === "read") {
      faultPending = false;
      why = "教学故障注入：本次读取超时（仅一次），后续读取已恢复。";
      log("injected_fault", { toolCallId: event.toolCallId, declared: true });
    }
    if (why) {
      log("tool_blocked", { toolCallId: event.toolCallId, toolName: event.toolName, reason: why });
      return { block: true, reason: why };
    }
  });
  pi.on("tool_result", (event: any) => {
    log("tool_result", { toolCallId: event.toolCallId, toolName: event.toolName, isError: event.isError, content: event.content });
  });
  if (!readonly) pi.registerTool({
    name: "run_tests", label: "Run development tests",
    description: "运行本工作区 unittest 测试。无任意 Shell。结果包含实际退出码和验证时的文件指纹。",
    parameters: Type.Object({}),
    async execute(toolCallId, _params, signal) {
      const testedFiles = files();
      const start = Date.now();
      const minimalEnv: Record<string,string> = { PYTHONIOENCODING: "utf-8", PYTHONDONTWRITEBYTECODE: "1", PYTHONHASHSEED: "0" };
      for (const k of ["PATH","LANG","LC_ALL","SYSTEMROOT","TMPDIR"]) if (process.env[k]) minimalEnv[k] = process.env[k]!;
      const child = spawn(process.env.EVAL_PYTHON || "python3", ["-m","unittest","discover","-s","tests","-v"],
        { cwd: root, env: minimalEnv, stdio: ["ignore","pipe","pipe"] });
      let output = "", timedOut = false;
      child.stdout.on("data", d => { output = (output + d.toString("utf8")).slice(-120000); });
      child.stderr.on("data", d => { output = (output + d.toString("utf8")).slice(-120000); });
      const kill = () => child.kill("SIGKILL");
      signal?.addEventListener("abort",kill,{ once: true });
      const timer = setTimeout(() => { timedOut = true; kill(); },30000);
      let exitCode: number | null = null, error: string | null = null;
      try { exitCode = await new Promise<number | null>((ok,bad) => { child.on("error",bad); child.on("close",ok); }); }
      catch (exc) { error = String(exc); }
      finally { clearTimeout(timer); signal?.removeEventListener("abort",kill); }
      const result = { toolCallId, exit_code: exitCode, timed_out: timedOut, error, seconds: (Date.now()-start)/1000,
        tested_files: testedFiles, output: clean(output) };
      log("development_test",result);
      return { content: [{ type: "text" as const, text: JSON.stringify(result) }], details: result };
    }
  });
}
