"""Known valid local reference, kept OUTSIDE the Agent workspace."""
import sqlite3


def initialize(db_path, stock=10):
    with sqlite3.connect(db_path) as db:
        db.execute("PRAGMA journal_mode=WAL")
        db.executescript('''
            CREATE TABLE IF NOT EXISTS inventory(sku TEXT PRIMARY KEY, available INTEGER NOT NULL);
            CREATE TABLE IF NOT EXISTS reservations(
                id INTEGER PRIMARY KEY AUTOINCREMENT, request_id TEXT NOT NULL,
                sku TEXT NOT NULL, quantity INTEGER NOT NULL);
            CREATE UNIQUE INDEX IF NOT EXISTS unique_request ON reservations(request_id);
        ''')
        db.execute("INSERT OR REPLACE INTO inventory VALUES (?, ?)", ("sku-1", stock))


def reserve(db_path, request_id, sku="sku-1", quantity=2, fail_at=None):
    if not isinstance(request_id, str) or not request_id or type(quantity) is not int or quantity <= 0:
        return {"status": "invalid_request"}
    db = sqlite3.connect(db_path, timeout=15, isolation_level=None)
    try:
        db.execute("BEGIN IMMEDIATE")
        previous = db.execute("SELECT sku,quantity FROM reservations WHERE request_id=?", (request_id,)).fetchone()
        if previous:
            db.rollback()
            if previous != (sku, quantity):
                return {"status": "conflict"}
            return {"status": "reserved", "request_id": request_id, "sku": sku,
                    "quantity": quantity, "replayed": True}
        row = db.execute("SELECT available FROM inventory WHERE sku=?", (sku,)).fetchone()
        if row is None:
            db.rollback()
            return {"status": "invalid_request"}
        changed = db.execute("UPDATE inventory SET available=available-? WHERE sku=? AND available>=?",
                             (quantity, sku, quantity)).rowcount
        if not changed:
            db.rollback()
            return {"status": "insufficient_stock"}
        if fail_at == "after_inventory":
            raise RuntimeError("injected_after_inventory")
        db.execute("INSERT INTO reservations(request_id,sku,quantity) VALUES(?,?,?)", (request_id, sku, quantity))
        db.commit()
        return {"status": "reserved", "request_id": request_id, "sku": sku,
                "quantity": quantity, "replayed": False}
    except BaseException:
        db.rollback()
        raise
    finally:
        db.close()
