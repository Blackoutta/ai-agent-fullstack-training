"""课前检查；只有 --api-check 才会产生一次真实模型请求。"""
import shutil
import subprocess
import sys
from lab.cli import emit, main, parser
from lab.config import settings
from lab.io import ROOT


def run():
    p = parser(__doc__)
    p.add_argument("--api-check", action="store_true")
    args = p.parse_args()
    cfg = settings(require_key=args.api_check)
    result = {"python": sys.version.split()[0], "python_supported": sys.version_info >= (3, 10),
              "provider": cfg.provider, "model": cfg.model, "key_configured": bool(cfg.key),
              "base_url": cfg.base_url, "pi_command": cfg.pi}
    for name, command in [("node", ["node", "--version"]), ("pi", cfg.pi + ["--offline", "--version"])]:
        try:
            proc = subprocess.run(command, capture_output=True, text=True, timeout=15)
            result[name] = proc.stdout.strip() if proc.returncode == 0 else proc.stderr.strip()
            result[name + "_available"] = proc.returncode == 0
        except (OSError, subprocess.SubprocessError) as exc:
            result[name], result[name + "_available"] = str(exc), False
    result["pinned_pi_version"] = "1.2.0"
    result["note"] = "npm ci 安装项目本地pi，不修改你原有全局pi。无key时仅能执行本地校验。"
    if args.api_check:
        from lab.llm import chat_json
        from lab.io import write_json
        output = chat_json('只输出JSON：{"ok":true}，不要调用工具。', {"purpose": "connectivity check"},
                           ROOT / "reports/connectivity_trace.json")
        result["api_status"] = output["status"]
        result["api_error"] = output.get("error")
    emit(result)
    return 0 if result["python_supported"] and result.get("pi_available") and result.get("api_status", "ok") == "ok" else 2


if __name__ == "__main__":
    raise SystemExit(main(run))
