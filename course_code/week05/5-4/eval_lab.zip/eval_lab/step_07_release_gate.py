"""5.4/7.4：分层门禁。退出码0=通过，1=拒绝，2=待复核/错误。"""
from lab.cli import emit, main, parser, resolve_run
from lab.grading import release_gate
from lab.evidence import collect_evidence


def run():
    p = parser(__doc__, with_run=True)
    p.add_argument("--program-only", action="store_true", help="仅观察程序检查；不代表完整语义验收")
    p.add_argument("--max-seconds", type=float)
    p.add_argument("--max-tokens", type=int)
    args = p.parse_args()
    directory = resolve_run(args.run)
    collect_evidence(directory)
    result = release_gate(directory, not args.program_only, args.max_seconds, args.max_tokens)
    emit(result)
    return {"accept": 0, "reject": 1, "pending": 2}[result["decision"]]


if __name__ == "__main__":
    raise SystemExit(main(run))
