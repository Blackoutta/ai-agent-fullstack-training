<script setup lang="ts">
import RunExplorer from '../components/RunExplorer.vue'
</script>
<template><RunExplorer review /></template>
